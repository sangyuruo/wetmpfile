MODIFY table t_voucher_transaction 
add column STAKEHOLDER_MEMBER_CODE VARCHAR(32) comment '垫资方';
 
MODIFY table t_voucher_transaction 
add column SETTLEMENT_FLAG int not null COMMENT '结算标志：0，无需结算；1，需要结算';

MODIFY table t_voucher_transaction 
add column DEVICE_ID varchar(128)  COMMENT '设备号';

MODIFY table t_voucher_transaction 
add column PRODUCT_CODE varchar(64)  COMMENT '产品编码';