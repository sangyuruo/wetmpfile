show global variables like '%timeout%';

set global wait_timeout=28800;