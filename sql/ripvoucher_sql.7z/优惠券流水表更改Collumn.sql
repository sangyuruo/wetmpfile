ALTER TABLE t_voucher_transaction ADD COLUMN ISSUER_MEMBER_CODE VARCHAR (32) NOT NULL COMMENT '发布方商户会员号';
ALTER TABLE t_voucher_transaction ADD COLUMN PAYMENT_MODE VARCHAR (32) COMMENT '支持支付方式：1,借记卡;2,账户余额;3,理财账户;4,信用账户;5,信用卡。多个以英文逗号隔开，空则不限制';

ALTER TABLE t_voucher_transaction DROP COLUMN ISSUER_MEMBER_CODE;
ALTER TABLE t_voucher_transaction DROP COLUMN PAYMENT_MODE;

ALTER TABLE t_voucher_transaction_history ADD COLUMN ISSUER_MEMBER_CODE VARCHAR (32) NOT NULL COMMENT '发布方商户会员号';
ALTER TABLE t_voucher_transaction_history ADD COLUMN PAYMENT_MODE VARCHAR (32) COMMENT '支持支付方式：1,借记卡;2,账户余额;3,理财账户;4,信用账户;5,信用卡。多个以英文逗号隔开，空则不限制';
ALTER TABLE t_voucher_history ADD COLUMN PAYMENT_MODE VARCHAR (32) COMMENT '支持支付方式：1,借记卡;2,账户余额;3,理财账户;4,信用账户;5,信用卡。多个以英文逗号隔开，空则不限制';

ALTER TABLE t_voucher_transaction_history DROP COLUMN ISSUER_MEMBER_CODE;
ALTER TABLE t_voucher_transaction_history DROP COLUMN PAYMENT_MODE;
ALTER TABLE t_voucher_history DROP COLUMN PAYMENT_MODE;
