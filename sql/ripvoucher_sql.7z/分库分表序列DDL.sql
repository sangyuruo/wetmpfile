-- CREATE TABLE `vch_sequence` (
--   `name` varchar(20) NOT NULL COMMENT '序列名称',
--   `idc` varchar(20) COMMENT '机房属性',
--   `min_value` varchar(20) NOT NULL COMMENT '最小值',
--   `max_value` varchar(20) NOT NULL COMMENT '最大值',
--   `step` varchar(20) NOT NULL COMMENT '步长，即每次缓冲多少',
--   `value` varchar(20) NOT NULL COMMENT '当前值',
--   `gmt_create` timestamp NOT NULL COMMENT '创建时间',
--   `gmt_modified` timestamp NOT NULL COMMENT '修改时间',
--   `table_index` varchar(45) DEFAULT NULL COMMENT '当前分库值',
--   PRIMARY KEY (`name`)
-- );
-- 
insert into vch_sequence values ('v_seq','sh','1','99999999999','1000','1',CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),'1' );
insert into vch_sequence values ('vtr_seq','sh','1','99999999999','1000','1', CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),'1' );
insert into vch_sequence values ('ab_seq','sh','1','99999999999','1000','1', CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),'1' );
insert into vch_sequence values ('ion_seq','sh','1','99999999999','1000','1', CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),'1' );
insert into vch_sequence values ('ionh_seq','sh','1','99999999999','1000','1', CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),'1' );

