SELECT v.*, vt.*
FROM ripvoucher.t_voucher v
		inner join ripvoucher.t_voucher_transaction vt on
		v.VOUCHER_NO=vt.VOUCHER_NO
WHERE v.voucher_no = #{voucherNo}