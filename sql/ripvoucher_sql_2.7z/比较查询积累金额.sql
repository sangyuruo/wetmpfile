select * from t_voucher v
where v.CONSUMER_MEMBER_CODE = '469280';


SELECT
* 
-- 	vt.DISCOUNT_VALUE , vt.DISCOUNT_AMOUNT ,vt.TRANSACTION_TYPE, vt.CREATE_TIME 
FROM
	T_VOUCHER_TRANSACTION vt
WHERE
	vt.CONSUMER_MEMBER_CODE = '469280'
ORDER BY
	vt.create_time DESC;


select * from t_accumulate_balance where CONSUMER_MEMBER_CODE = '469280' 