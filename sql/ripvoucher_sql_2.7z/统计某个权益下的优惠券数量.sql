select count(1) from t_voucher;
select count(1) from t_voucher_transaction;