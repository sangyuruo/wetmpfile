explain 
SELECT
	v.id, v.CONSUMER_MEMBER_CODE, vt.DISCOUNT_AMOUNT , v.INTEREST_OID,  vt.DISCOUNT_VALUE 
FROM
	t_voucher v
INNER JOIN t_voucher_transaction vt ON (
	v.VOUCHER_NO = vt.VOUCHER_NO
)
WHERE 
			v.consumer_member_code='1114' 
			AND EXISTS
		 	(SELECT 
		 		1 
		 	 FROM 
		 	 	t_voucher_transaction vt2
		 	 WHERE
		 	 	v.CONSUMER_MEMBER_CODE=vt2.CONSUMER_MEMBER_CODE
		 	 	AND v.VOUCHER_NO=vt2.VOUCHER_NO
		 	 	AND vt2.CONSUMER_MEMBER_CODE = '1114'
		 		AND vt2.ORDER_NO = '1'
				AND vt2.CHANNEL ='1'
				AND vt2.TRANSACTION_TYPE = 1
		 	)