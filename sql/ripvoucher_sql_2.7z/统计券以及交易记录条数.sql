
SELECT
	count(*)
FROM
	t_voucher_history ;

SELECT
	count(*)
FROM
	t_voucher_transaction_history;
 
/*#mycat:datanode=dn13*/