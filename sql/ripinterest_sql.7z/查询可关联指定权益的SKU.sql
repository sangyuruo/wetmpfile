SELECT
	*
FROM
	t_interest_sku
WHERE
	INTEREST_ID = 10
AND SKU_CODE IN ('sku1', 'sku2', 'sku3')
AND OPERATION_TYPE = 1