SELECT
	i.oid i_oid,
	i. NAME i_name,
	i.issuer_member_code i_issuerMemberCode,
	i.issuer_name i_issuerName,
	i.create_channel i_createChannel,
-- 	i.HOLD_TEMPLATE_OID i_holdTemplateOid,
	CASE
WHEN i.transaction_phase = 1 THEN
	'BEFORE'
WHEN i.transaction_phase = 2 THEN
	'CURRENT'
WHEN i.transaction_phase = 3 THEN
	'AFTER'
ELSE
	'BEFORE'
END i_transactionPhase,
 CASE
WHEN ol.PAYMENT_MODE IS NULL THEN
	NULL
ELSE
	1
END ol_PAYMENT_MODE,
 CASE
WHEN ol2.PAYMENT_MODE IS NULL THEN
	NULL
ELSE
	1
END ol2_PAYMENT_MODE,
 CASE
WHEN ol.SKU_LIMIT_FLAG = 1 THEN
	(
		SELECT
			isku.SKU_CODE
		FROM
			t_interest_sku isku
		WHERE
			i.id = isku.INTEREST_ID
		AND isku.OPERATION_TYPE = 1
		LIMIT 1
	)
ELSE
	''
END hsku,
 CASE
WHEN ol2.SKU_LIMIT_FLAG = 1 THEN
	(
		SELECT
			isku2.SKU_CODE
		FROM
			t_interest_sku isku2
		WHERE
			i.id = isku2.INTEREST_ID
		AND isku2.OPERATION_TYPE = 2
		LIMIT 1
	)
ELSE
	''
END wsku
-- ,
-- i.SETTLEMENT_FLAG,
-- i.START_TIME,
-- i.END_TIME,
-- i.id 
FROM
	ripinterest.T_INTEREST i
LEFT JOIN ripinterest.t_operation_limit ol ON (
	i.ID = ol.INTEREST_ID
	AND ol.OPERATION_TYPE = 1
)
LEFT JOIN ripinterest.t_operation_limit ol2 ON (
	i.ID = ol2.INTEREST_ID
	AND ol2.OPERATION_TYPE = 2
)
WHERE
	i. STATUS = 1
AND EXISTS (
	SELECT
		1
	FROM
		ripinterest.t_interest_process_agency ipa
	WHERE
		ipa.interest_id = i.id
		and ipa.operation_type=1
)

AND EXISTS (
	SELECT
		1
	FROM
		ripinterest.t_interest_process_agency ipa
	WHERE
		ipa.interest_id = i.id
		and ipa.operation_type=2
)
-- and i.OID in 
-- ('735e7259-46f9-401c-a73d-6702e98f7112',
-- 'acbe0d84-b991-4586-bbf3-a7f8e6ae4bc5',
-- '735e7259-46f9-401c-a73d-6702e98f7112',
-- '784cf666-b5a6-4a87-a8aa-a4cd9312aaef',
-- '24cd6bae-241d-492c-b3d6-4855ef2fa4e6')
 and i.SETTLEMENT_FLAG = 1 
and i.START_TIME < NOW() 
and i.END_TIME > NOW() 
and EXISTS(select null from t_operation_limit ol where ol.INTEREST_ID=i.id and ol.OPERATION_TYPE=1 and ol.RISK_OID is not NULL
and ol.CREDITLINE_OID is not null) 
order by i.CREATE_TIME