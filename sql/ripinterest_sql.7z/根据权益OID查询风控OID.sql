SELECT
	ol.RISK_OID
FROM
	t_operation_limit ol
WHERE
	EXISTS (
		SELECT
			NULL
		FROM
			t_interest i
		WHERE
			i.id = ol.INTEREST_ID
		AND i.oid = ''
	);