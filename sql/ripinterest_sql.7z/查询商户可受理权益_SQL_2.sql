SELECT
	ipa.id ipa_id,
	ipa.interest_id ipa_interestId,
	ipa.operation_type ipa_operationType,
	ipa.member_code ipa_memberCode,
	ipa.create_time ipa_createTime,
	ipa.update_time ipa_updateTime
FROM
	ripinterest.T_INTEREST_PROCESS_AGENCY ipa
WHERE
	ipa.interest_id IN (31)
AND ipa.member_code = 'memberCode1';