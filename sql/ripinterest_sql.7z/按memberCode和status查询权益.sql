SELECT
	i.id i_id,
	i.oid i_oid,
	i. NAME i_name,
	i.purpose i_purpose,
	i.instruction i_instruction,
	i.media_type i_mediaType,
	i.hold_template_oid i_holdTemplateOid,
	i.settlement_flag i_settlementFlag,
	i.issuer_member_code i_issuerMemberCode,
	i.issuer_name i_issuerName,
	i.stakeholder_member_code i_stakeholderMemberCode,
	i.create_channel i_createChannel,
	i.source_channel i_sourceChannel,
	i.start_time i_startTime,
	i.end_time i_endTime,
	i.transaction_phase i_transactionPhase,
	i. STATUS i_status,
	i.create_time i_createTime,
	i.update_time i_updateTime,
	ol.id ol_id,
	ol.interest_id ol_interestId,
	ol.operation_type ol_operationType,
	ol.begin_time ol_beginTime,
	ol.end_time ol_endTime,
	ol.risk_oid ol_riskOid,
	ol.creditline_oid ol_creditlineOid,
	ol.week_limit ol_weekLimit,
	ol.sku_limit_flag ol_skuLimitFlag,
	ol.threshold_amount ol_thresholdAmount,
	ol.payment_mode ol_paymentMode,
	ol.operation_flag ol_operationFlag,
	ol.create_time ol_createTime,
	ol.update_time ol_updateTime,
	vgr.id vgr_id,
	vgr.interest_id vgr_interestId,
	vgr.generation_type vgr_generationType,
	vgr.voucher_type vgr_voucherType,
	vgr.effective_interval vgr_effectiveInterval,
	vgr.effective_day vgr_effectiveDay,
	vgr.deduct_amount vgr_deductAmount,
	vgr.min_order_amount vgr_minOrderAmount,
	vgr.discount_ratio vgr_discountRatio,
	vgr.max_ratio vgr_maxRatio,
	vgr.min_ratio vgr_minRatio,
	vgr.max_amount vgr_maxAmount,
	vgr.min_amount vgr_minAmount,
	vgr.rounding_mode vgr_roundingMode,
	vgr.calc_base vgr_calcBase,
	vgr.create_time vgr_createTime,
	vgr.update_time vgr_updateTime,
	vtr.id vtr_id,
	vtr.voucher_generation_rule_id vtr_voucherGenerationRuleId,
	vtr.voucher_type vtr_voucherType,
	vtr.first_rule_flag vtr_firstRuleFlag,
	vtr.threshold_amount vtr_thresholdAmount,
	vtr.deduct_amount vtr_deductAmount,
	vtr.min_order_amount vtr_minOrderAmount,
	vtr.create_time vtr_createTime,
	vtr.update_time vtr_updateTime
FROM
	ripinterest.T_INTEREST i
LEFT JOIN ripinterest.t_operation_limit ol ON i.ID = ol.INTEREST_ID
LEFT JOIN ripinterest.t_voucher_generation_rule vgr ON i.ID = vgr.INTEREST_ID
LEFT JOIN ripinterest.t_voucher_tiered_rule vtr ON vtr.VOUCHER_GENERATION_RULE_ID = vgr.ID
WHERE
	i. STATUS = 1
AND EXISTS (
	SELECT
		1
	FROM
		ripinterest.t_interest_process_agency ipa
	WHERE
		ipa.interest_id = i.id
	AND ipa.member_code = '10073243176'
)