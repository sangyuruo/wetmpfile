package com.bill99.ebd.rip.acs.vo;

import java.io.Serializable;

import com.bill99.ebd.rip.ApiBaseRequest;

/**
 * 清分服务调用请求对象
 * 
 * @author haipeng.cheng
 * @since 2017年5月10日 下午2:59:09
 * @project rip-acs-inf
 */
public class ClearingRequest extends ApiBaseRequest implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    // 交易类型(WRITEOFF,)
    private String txnType;

    // 是否需要结算，需讨论
    private String stlFlag;

    // 金额
    private Long amt;

    // 交易时间 ISO
    private String txnTime;

    // 垫资方
    private String stakeholderMembercode;

    // 受理方标识
    private String acquirerIdentifier;

    // 结算用户(现金专用)
    private String stlMembercode;

    // 结算账户(现金专用)
    private String stlAcctcode;

    // 产品编号（理财专用）
    private String productCode;

    // 原外部订单号
    private String origOrderNo;

    // 结算商户会员编号
    private String stlMerchantId;

    public String getTxnType() {
        return txnType;
    }

    public void setTxnType(String txnType) {
        this.txnType = txnType;
    }

    public String getStlFlag() {
        return stlFlag;
    }

    public void setStlFlag(String stlFlag) {
        this.stlFlag = stlFlag;
    }

    public Long getAmt() {
        return amt;
    }

    public void setAmt(Long amt) {
        this.amt = amt;
    }

    public String getTxnTime() {
        return txnTime;
    }

    public void setTxnTime(String txnTime) {
        this.txnTime = txnTime;
    }

    public String getStakeholderMembercode() {
        return stakeholderMembercode;
    }

    public void setStakeholderMembercode(String stakeholderMembercode) {
        this.stakeholderMembercode = stakeholderMembercode;
    }

    public String getAcquirerIdentifier() {
        return acquirerIdentifier;
    }

    public void setAcquirerIdentifier(String acquirerIdentifier) {
        this.acquirerIdentifier = acquirerIdentifier;
    }

    public String getStlMembercode() {
        return stlMembercode;
    }

    public void setStlMembercode(String stlMembercode) {
        this.stlMembercode = stlMembercode;
    }

    public String getStlAcctcode() {
        return stlAcctcode;
    }

    public void setStlAcctcode(String stlAcctcode) {
        this.stlAcctcode = stlAcctcode;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getOrigOrderNo() {
        return origOrderNo;
    }

    public void setOrigOrderNo(String origOrderNo) {
        this.origOrderNo = origOrderNo;
    }

    public String getStlMerchantId() {
        return stlMerchantId;
    }

    public void setStlMerchantId(String stlMerchantId) {
        this.stlMerchantId = stlMerchantId;
    }
}
