package com.bill99.ebd.rip.acs.vo;

import java.io.Serializable;
import java.util.Date;

/**
 * 记账交易对象
 * 
 * @author kui.yu
 * @date 2017年8月4日
 */
public class AccountingTxnVo implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer extTxnId;// 外部交易编号

    private Integer origExtTxnId;// 原交易编号

    private Integer ruleId;// 记账规则编号

    private String bizType;// 业务类型

    private String payerMembercode;// 付款方会员编号

    private String payeeMembercode;// 收款方账户

    private Long amt;// 记账金额

    private String dealId;// 交易ID

    private String orderSeqId;// 订单序列号

    private String status;// 记账状态

    private String requestOrderid;// 向PE请求的订单ID

    private String operator;// 操作用户

    private String isReversed;// 是否冲正

    private String memo;// 备注

    private Date createTime;

    private Date updateTime;

    private Integer dataSource;// 数据来源

    public Integer getExtTxnId() {
        return extTxnId;
    }

    public void setExtTxnId(Integer extTxnId) {
        this.extTxnId = extTxnId;
    }

    public Integer getOrigExtTxnId() {
        return origExtTxnId;
    }

    public void setOrigExtTxnId(Integer origExtTxnId) {
        this.origExtTxnId = origExtTxnId;
    }

    public Integer getRuleId() {
        return ruleId;
    }

    public void setRuleId(Integer ruleId) {
        this.ruleId = ruleId;
    }

    public String getBizType() {
        return bizType;
    }

    public void setBizType(String bizType) {
        this.bizType = bizType;
    }

    public String getPayerMembercode() {
        return payerMembercode;
    }

    public void setPayerMembercode(String payerMembercode) {
        this.payerMembercode = payerMembercode;
    }

    public String getPayeeMembercode() {
        return payeeMembercode;
    }

    public void setPayeeMembercode(String payeeMembercode) {
        this.payeeMembercode = payeeMembercode;
    }

    public Long getAmt() {
        return amt;
    }

    public void setAmt(Long amt) {
        this.amt = amt;
    }

    public String getDealId() {
        return dealId;
    }

    public void setDealId(String dealId) {
        this.dealId = dealId;
    }

    public String getOrderSeqId() {
        return orderSeqId;
    }

    public void setOrderSeqId(String orderSeqId) {
        this.orderSeqId = orderSeqId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getRequestOrderid() {
        return requestOrderid;
    }

    public void setRequestOrderid(String requestOrderid) {
        this.requestOrderid = requestOrderid;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public String getIsReversed() {
        return isReversed;
    }

    public void setIsReversed(String isReversed) {
        this.isReversed = isReversed;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getDataSource() {
        return dataSource;
    }

    public void setDataSource(Integer dataSource) {
        this.dataSource = dataSource;
    }

}
