package com.bill99.ebd.rip.acs.vo;

import java.io.Serializable;

import com.bill99.ebd.rip.ApiBaseResponse;

/**
 * @author yong.zheng
 * @version 创建时间：2017年5月17日 上午10:30:33 类说明
 */
public class FdpEndCycleNotifyResponse extends ApiBaseResponse implements Serializable {

}
