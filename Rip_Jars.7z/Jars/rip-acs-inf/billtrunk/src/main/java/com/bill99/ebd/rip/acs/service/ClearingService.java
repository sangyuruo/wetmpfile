package com.bill99.ebd.rip.acs.service;

import com.bill99.ebd.rip.RipException;
import com.bill99.ebd.rip.acs.vo.ClearingRequest;
import com.bill99.ebd.rip.acs.vo.ClearingResponse;
import com.bill99.ebd.rip.acs.vo.FdpEndCycleNotifyRequest;
import com.bill99.ebd.rip.acs.vo.FdpEndCycleNotifyResponse;
import com.bill99.ebd.rip.acs.vo.QueryAccountingTxnRequest;
import com.bill99.ebd.rip.acs.vo.QueryAccountingTxnResponse;
import com.bill99.ebd.rip.acs.vo.RechargeAccountingRequest;
import com.bill99.ebd.rip.acs.vo.RechargeAccountingResponse;

/**
 * 调用交易清分操作服务接口
 * 
 * @author haipeng.cheng
 * @since 2017年5月10日 下午3:02:33
 * @project rip-acs-inf
 */
public interface ClearingService {

    /**
     * 清分接口
     * 
     * @param request
     * @return
     * @throws RipException
     */
    ClearingResponse clearingTxn(ClearingRequest request) throws RipException;

    /**
     * 理财募集结束通知打款接口
     * 
     * @param request
     * @return
     * @throws RipException
     */
    FdpEndCycleNotifyResponse fdpEndCycleNotify(FdpEndCycleNotifyRequest request) throws RipException;

    /**
     * 资金充值手工记账接口
     * 
     * @param request
     * @return
     * @throws RipException
     */
    RechargeAccountingResponse rechargeAccounting(RechargeAccountingRequest request) throws RipException;

    /**
     * 记账交易明细查询接口
     * 
     * @param request
     * @return
     * @throws RipException
     */
    QueryAccountingTxnResponse queryAccountingTxnList(QueryAccountingTxnRequest request) throws RipException;
}
