package com.bill99.ebd.rip.acs.vo;

import java.io.Serializable;

import com.bill99.ebd.rip.ApiBaseResponse;

public class ClearingResponse extends ApiBaseResponse implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

}
