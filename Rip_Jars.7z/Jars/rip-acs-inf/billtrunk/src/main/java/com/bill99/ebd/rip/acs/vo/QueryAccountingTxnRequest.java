package com.bill99.ebd.rip.acs.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.bill99.ebd.rip.ApiBaseRequest;

/**
 * @author yong.zheng
 * @version 创建时间：2017年5月17日 上午10:30:26 类说明
 */
public class QueryAccountingTxnRequest extends ApiBaseRequest implements Serializable {

    private static final long serialVersionUID = 1L;
    
    private Integer extTxnId;//外部交易编号

    private List<Integer> ruleIds;//记账规则编号
    
    private String bizType;// 业务类型

    private String payerMembercode;// 付款方会员编号

    private String payeeMembercode;// 收款方账户
    
    private Date txnStartDate;// 交易开始时间
    
    private Date txnEndDate;// 交易结束时间
    
    private Integer pageIndex = 1;//页码
    
    private Integer pageSize = 10;//每页数量

    public Integer getExtTxnId() {
        return extTxnId;
    }

    public void setExtTxnId(Integer extTxnId) {
        this.extTxnId = extTxnId;
    }

    public String getBizType() {
        return bizType;
    }

    public void setBizType(String bizType) {
        this.bizType = bizType;
    }

    public String getPayerMembercode() {
        return payerMembercode;
    }

    public void setPayerMembercode(String payerMembercode) {
        this.payerMembercode = payerMembercode;
    }

    public String getPayeeMembercode() {
        return payeeMembercode;
    }

    public void setPayeeMembercode(String payeeMembercode) {
        this.payeeMembercode = payeeMembercode;
    }

    public Date getTxnStartDate() {
        return txnStartDate;
    }

    public void setTxnStartDate(Date txnStartDate) {
        this.txnStartDate = txnStartDate;
    }

    public Date getTxnEndDate() {
        return txnEndDate;
    }

    public void setTxnEndDate(Date txnEndDate) {
        this.txnEndDate = txnEndDate;
    }

    public Integer getPageIndex() {
        return pageIndex;
    }

    public void setPageIndex(Integer pageIndex) {
        this.pageIndex = pageIndex;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public List<Integer> getRuleIds() {
        return ruleIds;
    }

    public void setRuleIds(List<Integer> ruleIds) {
        this.ruleIds = ruleIds;
    }

}
