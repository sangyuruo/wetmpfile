package com.bill99.ebd.rip.acs.vo;

import java.io.Serializable;
import java.util.List;

import com.bill99.ebd.rip.ApiBaseResponse;

/**
 * @author yong.zheng
 * @version 创建时间：2017年5月17日 上午10:30:49 类说明
 */
public class QueryAccountingTxnResponse extends ApiBaseResponse implements Serializable {

    private static final long serialVersionUID = 1L;

    private List<AccountingTxnVo> accountingTxnVoList;
    
    private Integer totalNums;//总数量
    
    private Integer totalPages;//总页数
    
    private Integer pageIndex;//页码
    
    private Integer pageSize;//每页数量

    public Integer getTotalNums() {
        return totalNums;
    }

    public void setTotalNums(Integer totalNums) {
        this.totalNums = totalNums;
    }

    public Integer getTotalPages() {
        return totalPages;
    }

    public void setTotalPages(Integer totalPages) {
        this.totalPages = totalPages;
    }

    public Integer getPageIndex() {
        return pageIndex;
    }

    public void setPageIndex(Integer pageIndex) {
        this.pageIndex = pageIndex;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public List<AccountingTxnVo> getAccountingTxnVoList() {
        return accountingTxnVoList;
    }

    public void setAccountingTxnVoList(List<AccountingTxnVo> accountingTxnVoList) {
        this.accountingTxnVoList = accountingTxnVoList;
    }
}
