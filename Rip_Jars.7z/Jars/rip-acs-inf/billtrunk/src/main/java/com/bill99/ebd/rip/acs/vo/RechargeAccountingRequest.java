package com.bill99.ebd.rip.acs.vo;

import java.io.Serializable;

import com.bill99.ebd.rip.ApiBaseRequest;

/**
 * @author yong.zheng
 * @version 创建时间：2017年5月17日 上午10:30:13 类说明
 */
public class RechargeAccountingRequest extends ApiBaseRequest implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    // 充值金额，单位：分
    private long amt;

    // 垫资方会员编号
    private String payerMemeberCode;

    // 出款账户会员编号
    private String payeeMemeberCode;

    public long getAmt() {
        return amt;
    }

    public void setAmt(long amt) {
        this.amt = amt;
    }

    public String getPayerMemeberCode() {
        return payerMemeberCode;
    }

    public void setPayerMemeberCode(String payerMemeberCode) {
        this.payerMemeberCode = payerMemeberCode;
    }

    public String getPayeeMemeberCode() {
        return payeeMemeberCode;
    }

    public void setPayeeMemeberCode(String payeeMemeberCode) {
        this.payeeMemeberCode = payeeMemeberCode;
    }
}
