package com.bill99.ebd.rip.acs.vo;

import java.io.Serializable;

import com.bill99.ebd.rip.ApiBaseRequest;

/**
 * @author yong.zheng
 * @version 创建时间：2017年5月17日 上午10:30:03 类说明
 */
public class FdpEndCycleNotifyRequest extends ApiBaseRequest implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private String productCode;// 产品编号
    private String acquirerMembercode;// 受理方会员编号

    public String getProductCode() {
        return this.productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getAcquirerMembercode() {
        return acquirerMembercode;
    }

    public void setAcquirerMembercode(String acquirerMembercode) {
        this.acquirerMembercode = acquirerMembercode;
    }
}
