package com.bill99.ebd.rip.facade.inf.mmp;

public class Test {

	private String ssname;

	public String getSsname() {
		return ssname;
	}

	public void setSsname(String ssname) {
		this.ssname = ssname;
	}
	
	
}
