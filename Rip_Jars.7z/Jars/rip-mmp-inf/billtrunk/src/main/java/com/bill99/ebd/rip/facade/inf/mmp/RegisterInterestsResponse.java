/**
 * 
 */
package com.bill99.ebd.rip.facade.inf.mmp;

/**
 * 登记权益结果
 * @author liangbiao.yi
 *
 */
public class RegisterInterestsResponse extends BaseResponse {

	private static final long serialVersionUID = -8535063171701584286L;
	private Integer activityId;//返回活动ID
	private Integer interestsRuleId;//返回的权益规则ID
	private Integer interestsId;//返回的权益ID

	public Integer getActivityId() {
		return activityId;
	}

	public void setActivityId(Integer activityId) {
		this.activityId = activityId;
	}

	public Integer getInterestsRuleId() {
		return interestsRuleId;
	}

	public void setInterestsRuleId(Integer interestsRuleId) {
		this.interestsRuleId = interestsRuleId;
	}

	public Integer getInterestsId() {
		return interestsId;
	}

	public void setInterestsId(Integer interestsId) {
		this.interestsId = interestsId;
	}

}
