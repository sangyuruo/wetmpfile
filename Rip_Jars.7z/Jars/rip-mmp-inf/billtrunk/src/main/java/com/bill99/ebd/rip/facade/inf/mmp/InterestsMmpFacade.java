/**
 * 
 */
package com.bill99.ebd.rip.facade.inf.mmp;

import java.util.Date;
import java.util.List;

/**
 * 权益平台mmp门面服务
 * @author liangbiao.yi
 *
 */
public interface InterestsMmpFacade {
	/**
	 * 登记权益
	 * @param request
	 * @return
	 */
	public RegisterInterestsResponse registerInterests(RegisterInterestsRequest request);
	public RegisterInterestsResponse publishActivity(RegisterInterestsReq request);
	/**
	 * 领取券号
	 * @param interestsId 权益ID
	 * @param mobile 手机号
	 * @return
	 */
	public HoldVoucherResponse holdVoucher(Integer interestsId, String mobile);

	/**
	 * 核销券号
	 * @param voucherNo 券号
	 * * @param memberCode 商户的memberCode
	 * @return
	 */
	public BaseResponse writeOffVoucher(String voucherNo, String memberCode);
	/**
	 * 核销券号
	 * 
	 * @param voucherNo 券号
	 * @param acquirerId 受理方ID
	 * @param acquirerType 受理方类型 {@link com.bill99.ebd.rip.srv.AcquirerType}
	 * @return
	 * @author jakoes.wu
	 * @updatedate 2015年2月6日上午11:01:52
	 */
	public BaseResponse writeOffVoucher(String voucherNo, String acquirerId,String acquirerType);

	/**
	 * 根据个人用户会员编号查询所有未使用的券号
	 * @param memberCode 个人用户会员编号
	 * @return
	 */
	public QueryVoucherResponse queryVoucherNoByMemberCode(String memberCode);

	/**
	 * 查询当天该商户核销的成交量,不传时间表示统计改商户下所有的核销成交量
	 * @param memberCode 商户的memberCode 
	 * * @param startTime 统计的开始时间 yyyy-MM-dd HH:mm:ss
	 * * @param endTime 统计的结束时间 yyyy-MM-dd HH:mm:ss
	 * @return
	 */
	public QueryVolumeResponse queryVolumeByMemberCode(String memberCode, String startTime, String endTime,
			Integer activityId);

	/**
	 * 同步商户信息
	 * @param memberCode 商户的memberCode 
	 * @param merchantName 商户名称
	 * @return
	 */
	public BaseResponse synchronizeMerchant(String memberCode, String merchantName);

	/**
	 * 查询活动下的交易成交量
	 * @param activityIds 活动list
	 * @return
	 */
	public QueryVolumeByActivityResponse queryVolumeByMemberCode(List<Integer> activityIds);

	/**
	 * 绑定卡
	 * @param cardNo 银行全卡号
	 * @param memberCode
	 * @param bankType 银行类型
	 */
	@Deprecated
	public BaseResponse bindCard(String cardNo, String memberCode, String bankType);

	/**
	 * 查询银行卡信息
	 * @param memberCode
	 * @return
	 */
	@Deprecated
	public QueryCardResponse queryCard(String memberCode);

	/**
	 * 根据券号查询活动信息
	 * @param voucherNo 券号
	 * @param memberCode 商户的memberCode
	 * @return
	 */
	public QueryActivityDetailResponse queryActivityDetail(String voucherNo, String memberCode);
	
	/**
	 * 根据券号查询活动信息
	 * 
	 * @param acquirerId 受理方ID
	 * @param acquirerType 受理方类型 {@link com.bill99.ebd.rip.srv.AcquirerType}AcquirerType
	 * @return
	 * @author jakoes.wu
	 * @updatedate 2015年2月6日上午11:06:55
	 */
	public QueryActivityDetailResponse queryActivityDetail(String voucherNo, String acquirerId,String acquirerType);

	/**
	 * 根据个人用户会员编号和权益ID查询已领取的券号
	 * @param memberCode 个人用户会员编号
	 * @param interestsId 权益ID
	 * @return
	 */
	public QueryVoucher queryVoucher(String memberCode, Integer interestsId);

	/**
	 * 根据券号查询活动ID
	 * @param voucherNo 券号
	 * @return
	 */
	public Integer queryActivityIdByVoucher(String voucherNo);

	/**
	 * 领取券号
	 * @param interestsId 权益ID
	 * @param mobile 手机号
	 * @return
	 */
	public HoldVoucherResponse holdVoucherAndNotCreateAcct(Integer interestsId, String mobile);

	/**
	 * 根据个人用户memberCode绑定券号
	 * @param memberCode 个人用户会员编号
	 * @param mobile 手机号
	 * @return
	 */
	public BaseResponse bindVoucherByMemberCode(String memberCode, String mobile);
	
	/**
	 * 根据多门店 查询核销笔数
	 *  
	 * @param storeIdList 门店ID列表-必填
	 * @param startTime 开始时间-选填
	 * @param endTime 结束时间 - 选填
	 * @param activityId 活动ID - 选填
	 * @author jakoes.wu
	 * @updatedate 2015年2月3日下午5:01:13
	 */
	public QueryWriteoffRecordResponse queryWriteoffRecord(List<AcquirerDTO> acquirerList,Date startTime, Date endTime,Integer activityId);

	/**
	 * 根据门店查询核销明细
	 * 
	 * @param storeId 门店ID-必填
	 * @param startTime 开始时间-选填
	 * @param endTime 结束时间 - 选填
	 * @param activityId 活动ID - 选填
	 * @author jakoes.wu
	 * @updatedate 2015年2月3日下午5:09:42
	 */
	public QueryVolumeResponse queryWriteoffDetail(List<AcquirerDTO> acquirerList,Date startTime, Date endTime,Integer activityId);

	/**
	 * 追加活动受理方（增量）
	 * 
	 * @param activityId
	 * @param acquirerList
	 * @return
	 * @author jakoes.wu
	 * @updatedate 2015年2月6日上午10:57:59
	 */
	public BaseResponse appendActivityAcquirers(Integer activityId,List<AcquirerDTO> acquirerList);
	/**
	 * 移除活动受理方
	 * 
	 * @param activityId
	 * @param acquirerList
	 * @return
	 * @author jakoes.wu
	 * @updatedate 2015年2月6日上午10:57:59
	 */
	public BaseResponse removeActivityAcquirers(Integer activityId,List<AcquirerDTO> acquirerList);
}
