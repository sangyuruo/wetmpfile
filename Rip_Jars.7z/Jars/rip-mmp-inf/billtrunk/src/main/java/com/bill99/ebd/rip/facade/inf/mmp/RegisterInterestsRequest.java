/**
 * 
 */
package com.bill99.ebd.rip.facade.inf.mmp;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * 登记权益请求
 * @author liangbiao.yi
 *
 */
public class RegisterInterestsRequest implements Serializable {

	private static final long serialVersionUID = -6502350117713130004L;
	private String activityName;//活动名称
	private Date startTime;//活动开始时间
	private Date endTime;//活动结束时间
	private Character interestsType;//权益类型
	private Double discount;//打折比例(折扣)
	private BigDecimal minAmt;//最低金额(单笔立减)类型属性
	private BigDecimal deductAmt;//折扣金额(单笔立减)
	private String ruleName;//规则名称
	private String interestsName;//权益名称
	private String memberCode;//商户memberCode

	public String getActivityName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public Character getInterestsType() {
		return interestsType;
	}

	public void setInterestsType(Character interestsType) {
		this.interestsType = interestsType;
	}

	public Double getDiscount() {
		return discount;
	}

	public void setDiscount(Double discount) {
		this.discount = discount;
	}

	public BigDecimal getMinAmt() {
		return minAmt;
	}

	public void setMinAmt(BigDecimal minAmt) {
		this.minAmt = minAmt;
	}

	public BigDecimal getDeductAmt() {
		return deductAmt;
	}

	public void setDeductAmt(BigDecimal deductAmt) {
		this.deductAmt = deductAmt;
	}

	public String getRuleName() {
		return ruleName;
	}

	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}

	public String getInterestsName() {
		return interestsName;
	}

	public void setInterestsName(String interestsName) {
		this.interestsName = interestsName;
	}

	public String getMemberCode() {
		return memberCode;
	}

	public void setMemberCode(String memberCode) {
		this.memberCode = memberCode;
	}

}
