package com.bill99.ebd.rip.facade.inf.mmp;

public class QueryWriteoffRecordResponse extends BaseResponse {

	/**
	 * @author jakoes.wu
	 * @updatedate 2015年2月3日下午5:05:25
	 */
	private static final long serialVersionUID = 1L;

	private Integer recordNum;//核销笔数

	public Integer getRecordNum() {
		return recordNum;
	}

	public void setRecordNum(Integer recordNum) {
		this.recordNum = recordNum;
	}
	
}
