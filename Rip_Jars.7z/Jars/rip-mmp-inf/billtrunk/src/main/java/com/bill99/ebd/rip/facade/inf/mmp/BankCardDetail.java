/**
 * 
 */
package com.bill99.ebd.rip.facade.inf.mmp;

import java.io.Serializable;

/**
 * 券号交易成交量
 * @author liangbiao.yi
 *
 */
public class BankCardDetail implements Serializable {

	private static final long serialVersionUID = 9219293384226669902L;
	private String cardNo;
	private String memberCode;
	private String bankType;

	public String getCardNo() {
		return cardNo;
	}

	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}

	public String getMemberCode() {
		return memberCode;
	}

	public void setMemberCode(String memberCode) {
		this.memberCode = memberCode;
	}

	public String getBankType() {
		return bankType;
	}

	public void setBankType(String bankType) {
		this.bankType = bankType;
	}

}
