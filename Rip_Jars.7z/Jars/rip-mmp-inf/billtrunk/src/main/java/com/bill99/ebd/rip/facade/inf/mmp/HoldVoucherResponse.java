/**
 * 
 */
package com.bill99.ebd.rip.facade.inf.mmp;

/**
 * 领取券号结果
 * @author liangbiao.yi
 *
 */
public class HoldVoucherResponse extends BaseResponse {

	private static final long serialVersionUID = -5200330056351609620L;
	private String voucherNo;//券号
	private String memberCode;//快钱memberCode
	private String password;//密码
	private boolean isNewAccount;

	public String getVoucherNo() {
		return voucherNo;
	}

	public void setVoucherNo(String voucherNo) {
		this.voucherNo = voucherNo;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getMemberCode() {
		return memberCode;
	}

	public void setMemberCode(String memberCode) {
		this.memberCode = memberCode;
	}

	public boolean isNewAccount() {
		return isNewAccount;
	}

	public void setNewAccount(boolean isNewAccount) {
		this.isNewAccount = isNewAccount;
	}

}
