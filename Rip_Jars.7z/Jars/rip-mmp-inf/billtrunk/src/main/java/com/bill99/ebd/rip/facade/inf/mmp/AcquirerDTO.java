package com.bill99.ebd.rip.facade.inf.mmp;

import java.io.Serializable;

/**
 * 受理方传递对象
 * 
 * @author jakoes.wu
 * @date 2015年2月6日上午10:18:50
 * @project rip-mmp-inf-20150203
 *
 */
public class AcquirerDTO implements Serializable {

	/**
	 * @author jakoes.wu
	 * @updatedate 2015年2月6日上午10:18:48
	 */
	private static final long serialVersionUID = 1L;

	private String acquirerId;//受理方ID
	private String acquirerType;//受理方类型
	private String acquirerName;//受理方名称
	
	public String getAcquirerId() {
		return acquirerId;
	}
	public void setAcquirerId(String acquirerId) {
		this.acquirerId = acquirerId;
	}
	public String getAcquirerType() {
		return acquirerType;
	}
	public void setAcquirerType(String acquirerType) {
		this.acquirerType = acquirerType;
	}
	public String getAcquirerName() {
		return acquirerName;
	}
	public void setAcquirerName(String acquirerName) {
		this.acquirerName = acquirerName;
	}

	public String toString() {
		return "AcquirerDTO [acquirerId=" + acquirerId + ", acquirerType="
				+ acquirerType + ", acquirerName=" + acquirerName
				+ ", getAcquirerId()=" + getAcquirerId()
				+ ", getAcquirerType()=" + getAcquirerType()
				+ ", getAcquirerName()=" + getAcquirerName() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}

}
