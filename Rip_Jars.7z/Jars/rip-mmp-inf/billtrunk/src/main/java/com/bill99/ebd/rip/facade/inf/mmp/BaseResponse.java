/**
 * 
 */
package com.bill99.ebd.rip.facade.inf.mmp;

import java.io.Serializable;

/**
 * @author liangbiao.yi
 *
 */
public class BaseResponse implements Serializable {

	private static final long serialVersionUID = -2363636785276716164L;
	private boolean operateStatus;//操作状态  成功或失败
	private String errorCode;
	private String errorMessage;

	public boolean isOperateStatus() {
		return operateStatus;
	}

	public void setOperateStatus(boolean operateStatus) {
		this.operateStatus = operateStatus;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

}
