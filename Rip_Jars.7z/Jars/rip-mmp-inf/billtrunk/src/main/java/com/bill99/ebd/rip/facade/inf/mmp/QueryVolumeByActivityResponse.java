/**
 * 
 */
package com.bill99.ebd.rip.facade.inf.mmp;

import java.util.Map;

/**
 * 查询成交量结果
 * @author liangbiao.yi
 *
 */
public class QueryVolumeByActivityResponse extends BaseResponse {

	private static final long serialVersionUID = 7762385975653698598L;
	private Map<Integer, VoucherTxnVolume> map;

	public Map<Integer, VoucherTxnVolume> getMap() {
		return map;
	}

	public void setMap(Map<Integer, VoucherTxnVolume> map) {
		this.map = map;
	}

}
