/**
 * 
 */
package com.bill99.ebd.rip.facade.inf.mmp;

import java.util.Date;

/**
 * 查询活动结果
 * @author liangbiao.yi
 *
 */
public class QueryActivityDetailResponse extends BaseResponse {

	private static final long serialVersionUID = 7762385975653698598L;
	private String activityName;
	private Date startTime;
	private Date endTime;

	public String getActivityName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

}
