/**
 * 
 */
package com.bill99.ebd.rip.facade.inf.mmp;

import java.io.Serializable;
import java.util.Date;

/**
 * 券号信息
 * @author liangbiao.yi
 *
 */
public class VoucherDetail implements Serializable {

	private static final long serialVersionUID = 9219293384226669902L;
	private String voucherNo;//券号
	private Date enableDate; //生效日期
	private Date expDate;//失效日期
	private Integer activityId;//活动ID
	private String activeName;//活动名称
	private Date writeoffTime;//核销时间

	public String getVoucherNo() {
		return voucherNo;
	}
	
	public VoucherDetail() {
		super();
	}

	public VoucherDetail(String voucherNo, Date enableDate, Date expDate,
			Integer activityId, String activeName,
			Date writeoffTime) {
		super();
		this.voucherNo = voucherNo;
		this.enableDate = enableDate;
		this.expDate = expDate;
		this.activityId = activityId;
		this.activeName = activeName;
		this.writeoffTime = writeoffTime;
	}
	public VoucherDetail(String voucherNo, Date enableDate, Date expDate,Integer activityId, String activeName) {
		super();
		this.voucherNo = voucherNo;
		this.enableDate = enableDate;
		this.expDate = expDate;
		this.activityId = activityId;
		this.activeName = activeName;
	}


	public void setVoucherNo(String voucherNo) {
		this.voucherNo = voucherNo;
	}

	public Date getEnableDate() {
		return enableDate;
	}

	public void setEnableDate(Date enableDate) {
		this.enableDate = enableDate;
	}

	public String getActiveName() {
		return activeName;
	}

	public void setActiveName(String activeName) {
		this.activeName = activeName;
	}

	public Integer getActivityId() {
		return activityId;
	}

	public void setActivityId(Integer activityId) {
		this.activityId = activityId;
	}

	public Date getExpDate() {
		return expDate;
	}

	public void setExpDate(Date expDate) {
		this.expDate = expDate;
	}

	public Date getWriteoffTime() {
		return writeoffTime;
	}

	public void setWriteoffTime(Date writeoffTime) {
		this.writeoffTime = writeoffTime;
	}

}
