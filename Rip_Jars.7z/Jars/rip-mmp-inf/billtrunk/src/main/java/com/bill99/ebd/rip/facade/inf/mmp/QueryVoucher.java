/**
 * 
 */
package com.bill99.ebd.rip.facade.inf.mmp;

/**
 * @author liangbiao.yi
 *
 */
public class QueryVoucher extends BaseResponse {

	private static final long serialVersionUID = 5945405154453020406L;
	private String voucherNo;//券号
	private String status;//券号使用状态   1:领用    2：核销

	public String getVoucherNo() {
		return voucherNo;
	}

	public void setVoucherNo(String voucherNo) {
		this.voucherNo = voucherNo;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
