/**
 * 
 */
package com.bill99.ebd.rip.facade.inf.mmp;

import java.util.List;

/**
 * 查询成交量结果
 * @author liangbiao.yi
 *
 */
public class QueryVolumeResponse extends BaseResponse {

	private static final long serialVersionUID = 7762385975653698598L;
	private List<VoucherDetail> list;

	public List<VoucherDetail> getList() {
		return list;
	}

	public void setList(List<VoucherDetail> list) {
		this.list = list;
	}

}
