/**
 * 
 */
package com.bill99.ebd.rip.facade.inf.mmp;

import java.util.List;

/**
 * 登记权益请求
 * @author liangbiao.yi
 *
 */
public class RegisterInterestsReq extends RegisterInterestsRequest {

	private static final long serialVersionUID = -6502350117713130004L;
	private String description;//描述
	private String instruction;//使用说明
    private String issuerId;//发布方ID
    private String issuerType;//发布方类型
    private String issuerName;//发布方名称
    private String adContent;//广告内容
    private String activityAddress;//活动地址Code
	
	private List<AcquirerDTO> acquirerList;//受理方集合

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getInstruction() {
		return instruction;
	}

	public void setInstruction(String instruction) {
		this.instruction = instruction;
	}

	public String getIssuerId() {
		return issuerId;
	}

	public void setIssuerId(String issuerId) {
		this.issuerId = issuerId;
	}

	public String getIssuerType() {
		return issuerType;
	}

	public void setIssuerType(String issuerType) {
		this.issuerType = issuerType;
	}

	public String getIssuerName() {
		return issuerName;
	}

	public void setIssuerName(String issuerName) {
		this.issuerName = issuerName;
	}

	public String getAdContent() {
		return adContent;
	}

	public void setAdContent(String adContent) {
		this.adContent = adContent;
	}

	public String getActivityAddress() {
		return activityAddress;
	}

	public void setActivityAddress(String activityAddress) {
		this.activityAddress = activityAddress;
	}

	public List<AcquirerDTO> getAcquirerList() {
		return acquirerList;
	}

	public void setAcquirerList(List<AcquirerDTO> acquirerList) {
		this.acquirerList = acquirerList;
	}

	
	
}
