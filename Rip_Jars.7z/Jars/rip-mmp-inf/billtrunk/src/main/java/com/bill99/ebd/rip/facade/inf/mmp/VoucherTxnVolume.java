/**
 * 
 */
package com.bill99.ebd.rip.facade.inf.mmp;

import java.io.Serializable;

/**
 * 券号交易成交量
 * @author liangbiao.yi
 *
 */
public class VoucherTxnVolume implements Serializable {

	private static final long serialVersionUID = 9219293384226669902L;
	private Integer activityId;//活动ID
	private Integer txnVolume;//成交量

	public Integer getActivityId() {
		return activityId;
	}

	public void setActivityId(Integer activityId) {
		this.activityId = activityId;
	}

	public Integer getTxnVolume() {
		return txnVolume;
	}

	public void setTxnVolume(Integer txnVolume) {
		this.txnVolume = txnVolume;
	}

}
