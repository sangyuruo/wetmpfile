package com.bill99.ebd.rip.persistence;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.domain.model.StakeholderRelatedPoolDto;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.junit.SpringConfiguredJunit4Test;
import com.bill99.ebd.rip.persistence.model.StakeholderRelatedPoolPo;

/**
 * @author yong.zheng
 * @version 创建时间：2017年1月22日 上午9:48:17 类说明
 */
public class StakeholderRelatedPoolPersistenceManagerTest extends SpringConfiguredJunit4Test {

    /**
     * @throws java.lang.Exception
     */
    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
    }

    /**
     * @throws java.lang.Exception
     */
    @AfterClass
    public static void tearDownAfterClass() throws Exception {
    }

    @Autowired
    StakeholderRelatedPoolPersistenceManager stakeholderRelatedPoolPersistenceManager;

    /**
     * @throws java.lang.Exception
     */
    @Before
    public void setUp() throws Exception {
    }

    /**
     * @throws java.lang.Exception
     */
    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void test_create() {
        StakeholderRelatedPoolDto stakeholderRelatedPoolDto = new StakeholderRelatedPoolDto();
        stakeholderRelatedPoolDto.setMemberCode("10011484027");
        stakeholderRelatedPoolDto.setParentMembercode("10000011");
        stakeholderRelatedPoolDto.setExternalFund("1");
        stakeholderRelatedPoolDto.setCrtTime(new Date());
        stakeholderRelatedPoolDto.setUptTime(new Date());
        stakeholderRelatedPoolDto.setMemo("memo");
        stakeholderRelatedPoolDto.setMerchantDescribed("MerchantDescribed");
        stakeholderRelatedPoolDto.setRelatedFoMemberacctcode("123456");
        try {
            stakeholderRelatedPoolPersistenceManager.insertStakeholderRelatedPool(stakeholderRelatedPoolDto);
        } catch (AppBizException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void test_findParentMemberCodeList() {
        try {
            Map<String, Object> paratmters = new HashMap<String, Object>();
            List<StakeholderRelatedPoolPo> stakeholderRelatedPoolPoList = stakeholderRelatedPoolPersistenceManager
                    .findStakeholderRelatedPoolPoList(paratmters);
            System.out.println(stakeholderRelatedPoolPoList);
        } catch (AppBizException e) {
            e.printStackTrace();
        }
    }
}
