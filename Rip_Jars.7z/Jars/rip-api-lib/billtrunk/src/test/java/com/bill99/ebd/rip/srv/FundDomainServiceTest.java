package com.bill99.ebd.rip.srv;

import java.math.BigDecimal;
import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bill99.ebd.rip.domain.FundDomainService;
import com.bill99.ebd.rip.domain.model.FundOutDto;
import com.bill99.ebd.rip.domain.model.FundoutResultDto;
import com.bill99.ebd.rip.domain.model.ReverseFundOutDto;
import com.bill99.ebd.rip.exception.AppBizException;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:springContext.xml")
// @Transactional
// @TransactionConfiguration(transactionManager="txManager", defaultRollback=true)
public class FundDomainServiceTest {

    @Autowired
    private FundDomainService fundDomainService;

    @Test
    public void testFundOut() throws AppBizException {
        FundOutDto fod = new FundOutDto();
        fod.setActivityCode("45072");
        fod.setAmount(new BigDecimal(9));
        fod.setChannel("JUNIT");
        fod.setOrderNo(System.currentTimeMillis() + "");
        fod.setPayeeMembercode("10012189233");
        fod.setPayeeMemberAcctcode("1001218923301");
        fod.setTxnTime(new Date());
        FundoutResultDto fundout = fundDomainService.fundout(fod);
        System.out.println(fundout);
    }

    @Test
    public void testReverseFundOut() throws AppBizException {
        ReverseFundOutDto reverseFundOutDto = new ReverseFundOutDto();
        reverseFundOutDto.setChannel("JUNIT");
        reverseFundOutDto.setOrderNo(System.currentTimeMillis() + "");
        reverseFundOutDto.setOrderSeqId("2001");
        reverseFundOutDto.setTxnTime(new Date());
        fundDomainService.reverseFundout(reverseFundOutDto);
    }
}
