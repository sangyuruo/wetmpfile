/**
 * 
 */
package com.bill99.ebd.rip.checkdb;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.junit.SpringConfiguredJunit4Test;
import com.bill99.ebd.rip.persistence.dao.InterestsStakeholderDao;
import com.bill99.ebd.rip.persistence.model.InterestsStakeholderPo;

/**
 * @author shuangye.liu
 * 
 * @since Jun 20, 2016
 */
public class InterestsStakeholderDaoTest extends SpringConfiguredJunit4Test {

    @Autowired
    private InterestsStakeholderDao dao;

    @Test
    public void test_find() throws Exception {
        List<InterestsStakeholderPo> pos = dao.findInterestsStakeholders(30070);
        System.out.println(ReflectionToStringBuilder.toString(pos));
    }

    @Test
    public void getStakeHolderByInterestsIdAndMembercode() throws Exception {
        InterestsStakeholderPo po = dao.getStakeHolderByInterestsIdAndMembercode(463, "10024757432");
        System.out.println(ReflectionToStringBuilder.toString(po));
    }

    @Test
    public void getStakeHolderByInterestsId() throws Exception {
        InterestsStakeholderPo po = dao.getStakeHolderByInterestsIdAndMembercode(463, null);
        System.out.println(ReflectionToStringBuilder.toString(po));
    }

    @Test
    public void findInterestsStakeholders() throws Exception {
        List<InterestsStakeholderPo> pos = dao.findInterestsStakeholders(463);
        System.out.println(pos.size());
        System.out.println(ReflectionToStringBuilder.toString(pos.get(0)));
    }

    @Test
    public void getStakeholderBudget() throws Exception {
        String membercode = "10012310602";
        Map<String, Object> result = dao.getStakeholderBudget(membercode);
        System.out.println(result.get("membercode"));
        System.out.println(result.get("amount"));

    }

    @Test
    public void getStakeholderWriteoffCreditline() throws Exception {
        String membercode = "100123117283";
        Map<String, Object> result = dao.getStakeholderWriteoffCreditline(membercode);
        System.out.println(result.get("membercode"));
        System.out.println(result.get("amount"));
    }

}
