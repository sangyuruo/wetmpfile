package com.bill99.ebd.rip.srv;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bill99.ebd.rip.domain.FundStakeholderService;
import com.bill99.ebd.rip.exception.AppBizException;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:springContext.xml")
public class FundStakeholderServiceTest {
	
	@Autowired
	FundStakeholderService fundStakeholderService;
	
	@Test
	public void test_getList() {
		try {
			System.out.println(fundStakeholderService.getFundStakeholderList("0"));
		} catch (AppBizException e) {
			e.printStackTrace();
		}
		
	}

}
