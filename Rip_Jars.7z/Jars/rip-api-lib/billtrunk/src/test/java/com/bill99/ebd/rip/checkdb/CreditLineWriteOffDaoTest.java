/**
 * 
 */
package com.bill99.ebd.rip.checkdb;

import java.math.BigDecimal;
import java.util.Date;

import javax.annotation.Resource;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.junit.Test;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import org.unitils.reflectionassert.ReflectionAssert;
import org.unitils.reflectionassert.ReflectionComparatorMode;

import com.bill99.ebd.rip.junit.SpringConfiguredJunit4Test;
import com.bill99.ebd.rip.persistence.dao.CreditLineWriteOffDao;
import com.bill99.ebd.rip.persistence.model.CreditLineWriteOffPo;

/**
 * @author shuangye.liu
 *
 * @since Jun 20, 2016
 */
public class CreditLineWriteOffDaoTest extends SpringConfiguredJunit4Test {

    @Resource
    private CreditLineWriteOffDao dao;

    @Test
    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void test_update() throws Exception {
        CreditLineWriteOffPo po = dao.get(1);
        System.out.println(ReflectionToStringBuilder.toString(po));

        BigDecimal remainingAmount = po.getRemainingAmount();
        po.setRemainingAmount(new BigDecimal("999966"));
        po.setUpdateTime(new Date());

        dao.update(po, remainingAmount);

        CreditLineWriteOffPo po2 = dao.get(1);

        ReflectionAssert.assertReflectionEquals(po2, po, ReflectionComparatorMode.LENIENT_DATES);
    }

}
