package com.bill99.ebd.rip.checkdb;

import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import com.bill99.ebd.rip.enums.ExtInterestsInitStatus;
import com.bill99.ebd.rip.enums.TrueFalse;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.junit.SpringConfiguredJunit4Test;
import com.bill99.ebd.rip.persistence.dao.ExtInterestsInitDao;
import com.bill99.ebd.rip.persistence.model.ExtInterestsInitPo;

public class ExtInterestsInitDaoTest extends SpringConfiguredJunit4Test {
    @Autowired
    private ExtInterestsInitDao extInterestsInitDao;

    /**
     * 测试getFirstValidByInterstsId方法
     */
    @Test
    public void testGetFirstValidByInterstsId() {
        try {
            ExtInterestsInitPo result = extInterestsInitDao.getFirstValidByInterstsId(12002);
            System.out
                    .println("@@result of testGetFirstValidByInterstsId" + ReflectionToStringBuilder.toString(result));
        } catch (AppBizException e) {
            e.printStackTrace();
            Assert.assertTrue(false);
        }
    }
    
    /**
     * 测试getVoucherNoByExtIntersts
     * 
     *
     *@author pengfei.shen
     *@create 2016年10月31日 下午5:32:22
     */
    @Test
    public void testGetVoucherNoByExtIntersts() {
        try {
            ExtInterestsInitPo result = extInterestsInitDao.getVoucherNoByExtIntersts("101000000017","100153261661");
            System.out
                    .println("@@result of testGetVoucherNoByExtIntersts" + ReflectionToStringBuilder.toString(result));
            System.out.println("=================");
            System.out.println(StringUtils.equals(TrueFalse.TRUE.getId(),result.getExtVoucherCodeHiddenFlag()) ? 
                    result.getInterestsInitCode()+"---1":
                        result.getExtVoucherCode()+"----0");
            
            
        } catch (AppBizException e) {
            e.printStackTrace();
            Assert.assertTrue(false);
        }
    }

    @Test
    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void testUpdateExtInterestsInit() {
        try {
            ExtInterestsInitPo po = extInterestsInitDao.getFirstValidByInterstsId(12002);
            po.setUpdateTime(new Date());
            po.setStatus(ExtInterestsInitStatus.RECEIVE.name());
            extInterestsInitDao.update(po, null);
            // ExtInterestsInitPo updatedPo = extInterestsInitDao.getFirstValidByInterstsId(po);
            // ReflectionAssert.assertLenientEquals(po, updatedPo);
        } catch (AppBizException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }
}
