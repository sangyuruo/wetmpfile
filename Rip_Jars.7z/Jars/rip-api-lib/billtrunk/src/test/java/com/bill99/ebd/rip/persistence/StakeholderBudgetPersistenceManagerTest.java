package com.bill99.ebd.rip.persistence;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.domain.model.StakeholderBudgetDto;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.junit.SpringConfiguredJunit4Test;

public class StakeholderBudgetPersistenceManagerTest extends SpringConfiguredJunit4Test {

	@Autowired
	StakeholderBudgetPersistenceManager stakeholderBudgetPersistenceManager;

	@Test
	public void test_create() {
		StakeholderBudgetDto stakeholderBudgetDto = new StakeholderBudgetDto();
		stakeholderBudgetDto.setCreateTime(new Date());
		stakeholderBudgetDto.setExternalFund("1");
		stakeholderBudgetDto.setMemberCode("10000011");
		stakeholderBudgetDto.setMemo("kong");
		stakeholderBudgetDto.setRemainingAmount(new BigDecimal(10000));
		stakeholderBudgetDto.setStakeholderName("name111");
		stakeholderBudgetDto.setTotalAmount(new BigDecimal(20000));
		stakeholderBudgetDto.setUpdateTime(new Date());
		try {
			stakeholderBudgetPersistenceManager.insertStakeholderBudget(stakeholderBudgetDto);
		} catch (AppBizException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void test_update() {		
		Map<String, Object> paraMap = new HashMap<String, Object>();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
		paraMap.put("idStakeholderBudget", 5);
		paraMap.put("totalAmount", 30000);// 金额相加
		paraMap.put("lastUpdateTime", formatter.parse("2017-01-12  11:37:31"));
		paraMap.put("updateTime", new Date());
			stakeholderBudgetPersistenceManager.updateStakeholderBudget(paraMap);
		} catch (AppBizException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void test_getByMbCode() {
		StakeholderBudgetDto stakeholderBudgetDto = null;
		try {
			stakeholderBudgetDto = stakeholderBudgetPersistenceManager.getStakeholderBudget(
					1, "10000011");//"10000011"
		} catch (AppBizException e) {
			e.printStackTrace();
		}
		System.out.println(stakeholderBudgetDto.toString());
	}
}
