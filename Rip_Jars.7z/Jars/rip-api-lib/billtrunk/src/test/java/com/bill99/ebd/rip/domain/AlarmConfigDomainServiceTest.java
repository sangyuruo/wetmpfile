package com.bill99.ebd.rip.domain;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bill99.ebd.rip.domain.alarm.AlarmConfigDomainService;
import com.bill99.ebd.rip.domain.model.AlarmConfigDto;
import com.bill99.ebd.rip.enums.AlarmBizType;
import com.bill99.ebd.rip.enums.TrueFalse;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.dao.page.PageInfo;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:springContext.xml")
public class AlarmConfigDomainServiceTest {
    @Autowired
    private AlarmConfigDomainService alarmConfigDomainService;

    @Test
    public void test_getAlarmConfigByBizId() throws AppBizException {
        AlarmConfigDto dto = alarmConfigDomainService.getAlarmConfigByBizId("0005",
                AlarmBizType.INTERESTSCREDITLINEWRITEOFF, TrueFalse.FALSE);
        System.out.println("@@==================== >>result of testGetAlarmConfigByBizId"
                + ReflectionToStringBuilder.toString(dto));
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getAlarmConfigpages() throws AppBizException {
        Map<String, Object> paraMap = new HashMap<String, Object>();
        paraMap.put("status", "1");
        Map<String, Object> rstMap = alarmConfigDomainService.getAlarmConfigPages(paraMap, 2, 2);

        List<AlarmConfigDto> list = (List<AlarmConfigDto>) rstMap.get("list");
        PageInfo page = (PageInfo) rstMap.get("page");
        System.out.println("@@=================>>result of test_getAlarmConfigpages"
                + ReflectionToStringBuilder.toString(list.size()));
        System.out.println("@@=================>>result of test_getAlarmConfigpages"
                + ReflectionToStringBuilder.toString(page.getPageSize()));
    }

    @Test
    public void test_create() throws AppBizException {
        AlarmConfigDto dto = new AlarmConfigDto();
        // dto.setBizId("0005");
        // dto.setBizType(AlarmBizType.INTERESTSCREDITLINEWRITEOFF);
        dto.setCommonFlag(TrueFalse.TRUE);
        dto.setCreateTime(new Date());
        dto.setMemo("test");
        dto.setNotifyCount(5);
        dto.setNotifyList("123,123,2344");
        dto.setNotifyLimit(10);
        dto.setNotifyTplId("002");
        dto.setNotifyType("0");
        dto.setStatus(TrueFalse.fromId("1"));
        dto.setThresholdValue(new BigDecimal(1000.22));
        dto.setThresholdType("1");
        dto.setUpdateTime(new Date());
        alarmConfigDomainService.insertAlarmConfig(dto);
        AlarmConfigDto dtoRst = alarmConfigDomainService.getAlarmConfigByBizId("0004",
                AlarmBizType.INTERESTSCREDITLINEWRITEOFF, TrueFalse.TRUE);
        System.out.println("@@=================>>result of testGetAlarmConfigByBizId"
                + ReflectionToStringBuilder.toString(dtoRst));
    }

    @Test
    public void test_updateAlarmThresholdInfo() throws AppBizException {
        alarmConfigDomainService.updateAlarmThresholdInfo("", null, 33, TrueFalse.TRUE);
        // AlarmConfigDto dtoRst =
        // alarmConfigDomainService.getAlarmConfigByBizId("0004",AlarmBizType.INTERESTSCREDITLINEWRITEOFF,TrueFalse.FALSE);
        // System.out.println("@@=================>>result of testGetAlarmConfigByBizId" +
        // ReflectionToStringBuilder.toString(dtoRst));
    }

    @Test
    public void test_update() throws AppBizException {
        AlarmConfigDto dto = new AlarmConfigDto();
        dto.setBizId("0003");
        dto.setBizType(AlarmBizType.INTERESTSCREDITLINEHOLD);
        dto.setCommonFlag(TrueFalse.FALSE);
        dto.setNotifyList("123,2333223333,13677772222");
        dto.setNotifyLimit(10);
        dto.setNotifyTplId("002");
        dto.setNotifyType("0");
        dto.setStatus(TrueFalse.fromId("1"));
        dto.setThresholdValue(new BigDecimal(0.33));
        dto.setThresholdType("1");
        dto.setUpdateTime(new Date());
        dto.setIdAlarmCfg(18);
        alarmConfigDomainService.updateAlarmConfig(dto);
        AlarmConfigDto dtoRst = alarmConfigDomainService.getAlarmConfigByBizId("0003",
                AlarmBizType.INTERESTSCREDITLINEHOLD, TrueFalse.FALSE);
        System.out.println("@@=================>>result of testGetAlarmConfigByBizId"
                + ReflectionToStringBuilder.toString(dtoRst));

    }

    @Test
    public void test_getAlarmConfigBySeqId() throws AppBizException {

        AlarmConfigDto alarmConfigDto = alarmConfigDomainService.getAlarmConfigBySeqId(33);

        System.out.println("@@=================>>result of test_getAlarmConfigBySeqId"
                + ReflectionToStringBuilder.toString(alarmConfigDto.getNotifyType()));
    }
}
