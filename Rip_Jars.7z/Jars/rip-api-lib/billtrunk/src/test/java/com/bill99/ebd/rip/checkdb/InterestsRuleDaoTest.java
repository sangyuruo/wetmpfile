/**
 * 
 */
package com.bill99.ebd.rip.checkdb;

import java.util.Date;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import com.bill99.ebd.rip.junit.SpringConfiguredJunit4Test;
import com.bill99.ebd.rip.persistence.dao.InterestsRuleDao;
import com.bill99.ebd.rip.persistence.model.InterestsRulePo;

import junit.framework.Assert;

/**
 * @author shuangye.liu
 *
 * @since Jun 20, 2016
 */
public class InterestsRuleDaoTest extends SpringConfiguredJunit4Test {

    @Autowired
    private InterestsRuleDao dao;

    @Test
    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void test_update() throws Exception {
        InterestsRulePo po = dao.get(1);
        System.out.println(ReflectionToStringBuilder.toString(po));
        Integer remainingLimit = po.getRemainingLimit();
        po.setRemainingLimit(952);
        po.setUpdateTime(new Date());
        dao.update(po, remainingLimit);
        InterestsRulePo updatedPo = dao.get(1);
        Assert.assertEquals(952, updatedPo.getRemainingLimit().intValue());
    }
    
    @Test
    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void test_get() throws Exception {
        InterestsRulePo po = dao.get(41080);
        System.out.println(ReflectionToStringBuilder.toString(po));
    }

}
