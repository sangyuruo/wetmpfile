/**
 * 
 */
package com.bill99.ebd.rip.persistence;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.domain.model.FundInterests;
import com.bill99.ebd.rip.junit.SpringConfiguredJunit4Test;

/**
 * @author wei.wang.rd
 * 
 * @since Nov 04, 2016
 */
public class FundInterestsPersistenceManagerTest extends SpringConfiguredJunit4Test {

    /**
     * @throws java.lang.Exception
     */
    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
    }

    /**
     * @throws java.lang.Exception
     */
    @AfterClass
    public static void tearDownAfterClass() throws Exception {
    }

    @Autowired
    private FundInterestsPersistenceManager fpm;

    /**
     * @throws java.lang.Exception
     */
    @Before
    public void setUp() throws Exception {
    }

    /**
     * @throws java.lang.Exception
     */
    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void test_getFundInterests() throws Exception {
        FundInterests fundInterests = this.fpm.getFundInterests(44079, "10012200266");
        int interestsId = fundInterests.getId();
        Assert.assertEquals("Interests matched,interestsId is 44079", 44079, interestsId);
    }
}
