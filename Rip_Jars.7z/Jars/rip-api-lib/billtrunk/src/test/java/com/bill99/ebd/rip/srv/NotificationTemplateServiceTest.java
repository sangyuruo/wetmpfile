package com.bill99.ebd.rip.srv;

import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bill99.ebd.rip.domain.model.NotificationTemplate;
import com.bill99.ebd.rip.domain.notitication.NotificationTemplateSecService;
import com.bill99.ebd.rip.exception.AppBizException;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:springContext.xml")
public class NotificationTemplateServiceTest {

	@Autowired
	NotificationTemplateSecService notificationTemplateSecService;
	
	@Test
	public void test_insertTemplate() {
		NotificationTemplate template = new NotificationTemplate();
		try {
			template.setContent("亲爱的用户，您已获得1张15元餐饮抵用券，券号：${voucherNo}，科房园区邀请您至特约商户体验消费。详情请至快钱APP->卡券包中查看。回TDKFYQ退订");
			template.setDescription("测试短信");
			template.setMemo("junit测试");
			template.setStatus("1");
			template.setSubject("junit测试短信");
			template.setTdcmd("TDTESTYU");
			template.setTemplateId("19714462");
			template.setType(2);
			template.setCreateDate(new Date());
			template.setUpdateDate(new Date());
			notificationTemplateSecService.insertNotify(template);
		} catch (AppBizException e) {
			e.printStackTrace();
		}
	}
}
