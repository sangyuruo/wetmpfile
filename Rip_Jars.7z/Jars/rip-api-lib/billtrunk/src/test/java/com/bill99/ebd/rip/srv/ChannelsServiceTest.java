package com.bill99.ebd.rip.srv;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bill99.ebd.rip.domain.ChannelsDomainService;
import com.bill99.ebd.rip.exception.AppBizException;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations="classpath:springContext.xml")
//@Transactional
//@TransactionConfiguration(transactionManager="txManager", defaultRollback=true)
public class ChannelsServiceTest {

	@Autowired
	private ChannelsDomainService channelsSerivce;
	
	@Test
	public void containsChannel() throws AppBizException{
		boolean containsChannel = channelsSerivce.containsChannel("ATE");
		System.out.println(containsChannel);
	}
	 
}
