/**
 * 
 */
package com.bill99.ebd.rip.checkdb;

import java.util.Map;

import junit.framework.Assert;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.junit.SpringConfiguredJunit4Test;
import com.bill99.ebd.rip.persistence.dao.FundInterestsDao;
import com.bill99.ebd.rip.persistence.model.InterestsPo;

/**
 * @author wei.wang.rd
 * 
 * @since Nov 4, 2016
 */
public class FundInterestsDaoTest extends SpringConfiguredJunit4Test {

    @Autowired
    private FundInterestsDao dao;

    @Test
    public void testFundInterests() throws Exception {
        Map<String, Object> findInterests = this.dao.findFundInterests(44079, "10012200266");
        InterestsPo interestsPo = (InterestsPo) findInterests.get("interests");
        int interestsId = interestsPo.getId();
        Assert.assertEquals("interestsId is 44079", 44079, interestsId);
    }
}
