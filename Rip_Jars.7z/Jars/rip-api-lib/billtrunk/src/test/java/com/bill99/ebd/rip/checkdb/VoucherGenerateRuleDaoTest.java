/**
 * 
 */
package com.bill99.ebd.rip.checkdb;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.junit.Test;

import com.bill99.ebd.rip.junit.SpringConfiguredJunit4Test;
import com.bill99.ebd.rip.persistence.dao.VoucherGenerateRuleDao;

/**
 * @author shuangye.liu
 *
 * @since Jun 21, 2016
 */
public class VoucherGenerateRuleDaoTest extends SpringConfiguredJunit4Test {

    @Resource
    private VoucherGenerateRuleDao dao;

    @Test
    public void checkConfigration() throws Exception {
        List<Map<String, Object>> map = dao.findVoucherGenerateRules(Arrays.asList(2809));
        System.out.println(map);
    }

}
