/**
 * 
 */
package com.bill99.ebd.rip.persistence;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.domain.model.Interests;
import com.bill99.ebd.rip.enums.AcquirerAbility;
import com.bill99.ebd.rip.junit.SpringConfiguredJunit4Test;

/**
 * @author shuangye.liu
 *
 * @since Jun 15, 2016
 */
public class InterestsPersistenceManagerTest extends SpringConfiguredJunit4Test {

    /**
     * @throws java.lang.Exception
     */
    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
    }

    /**
     * @throws java.lang.Exception
     */
    @AfterClass
    public static void tearDownAfterClass() throws Exception {
    }

    @Autowired
    private InterestsPersistenceManager pm;

    /**
     * @throws java.lang.Exception
     */
    @Before
    public void setUp() throws Exception {
    }

    /**
     * @throws java.lang.Exception
     */
    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void test() throws Exception {
        Interests interests = this.pm.getMerchantAcquirableInterests(28094, "10012310603", AcquirerAbility.HOLD, null);
        System.out.println(interests);
    }

    @Test
    public void test_getInterests() throws Exception {
        Interests interests = this.pm.getInterestsById(28094);
        System.out.println(interests);
    }

}
