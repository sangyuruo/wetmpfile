package com.bill99.ebd.rip.junit;

import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import static org.junit.Assert.*;
/**
 * JUNIT测试Spring配置基类   
 * 
 * 注意：测试方法上要有事物，才能入库。如：@Transactional(propagation = Propagation.REQUIRED)
 * @author jakoes.wu
 * @create 2014-9-4下午4:16:59
 * @project app-rip-20140903
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:springContext.xml")
//@TransactionConfiguration(defaultRollback = false)//是否回滚数据。设置为true，测试完成后执行数据库回滚
public class SpringConfiguredJunit4Test extends AbstractJunit4Test {
	 
}
