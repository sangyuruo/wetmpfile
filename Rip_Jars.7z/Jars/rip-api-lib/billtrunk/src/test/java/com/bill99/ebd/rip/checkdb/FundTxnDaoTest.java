package com.bill99.ebd.rip.checkdb;

import java.math.BigDecimal;
import java.util.Date;

import javax.annotation.Resource;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.junit.Test;

import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.junit.SpringConfiguredJunit4Test;
import com.bill99.ebd.rip.persistence.dao.FundTxnDao;
import com.bill99.ebd.rip.persistence.model.FundTxnPo;

public class FundTxnDaoTest extends SpringConfiguredJunit4Test {

    @Resource(name = "fundTxnIbatisDao")
    private FundTxnDao dao;

    @Test
    public void create() throws Exception {
        FundTxnPo entity = getEntityNewInstanceBatch(FundTxnPo.class);

        dao.create(entity);
        System.out.println("================>" + ToStringBuilder.reflectionToString(entity));

        /*
         * FundTxn item = fundTxnDao.get(entity.getIdFundTxn()); FundTxnCond cond = new FundTxnCond(); List<FundTxn>
         * list = fundTxnDao.queryList(cond, 0, -1); System.out.println("=========size:" + list.size());
         * 
         * assertEquals(item.getIdFundTxn(), entity.getIdFundTxn()); assertTrue("result list is empty",
         * !list.isEmpty()); // fundTxnDao.delete(item);
         */
    }

    @Test
    public void test() throws AppBizException {
        FundTxnPo fundTxn = new FundTxnPo();
        fundTxn.setClearingRetryTimes(0);
        fundTxn.setClearingStatus("F");
        fundTxn.setClearingTime(new Date());
        fundTxn.setCreateTime(new Date());
        fundTxn.setErrorMessage("test err");
        fundTxn.setExtSeqId("231345234");
        fundTxn.setMemo("test memo");
        fundTxn.setOrderSeqId("3483423");
        fundTxn.setOrigPayerMemberCode("3472384023");
        fundTxn.setPayeeAccountCode("11111111111");
        fundTxn.setPayeeMemberCode("333333333333333");
        fundTxn.setPayerAccountCode("2222222222222");
        fundTxn.setPayerMemberCode("4444444444444");
        fundTxn.setPayRetryTimes(1);
        fundTxn.setPayStatus("F");
        fundTxn.setPayTime(new Date());
        fundTxn.setReqOrderId("3745723874053");
        fundTxn.setReqType("Test");
        fundTxn.setResponseCode("99");
        fundTxn.setResponseTime(new Date());
        fundTxn.setStlAmt(new BigDecimal(222));
        fundTxn.setUpdateTime(new Date());
        // dao.create(fundTxn);
        System.out.println(dao.findByReqTypeAndStatus("Test", "F").get(0).getIdFundTxn());
        System.out.println("refundId: " + dao.getRefundTxnByExtSeqId("231345234").getIdFundTxn());
        System.out.println("stlFundId: " + dao.getStlFundTxnByExtSeqId("231345234").getIdFundTxn());
    }
}
