package com.bill99.ebd.rip.checkdb;

import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.enums.UserIdentifier;
import com.bill99.ebd.rip.junit.SpringConfiguredJunit4Test;
import com.bill99.ebd.rip.persistence.dao.InterestsRiskDetailDao;
import com.bill99.ebd.rip.persistence.model.InterestsRiskDetailPo;

public class InterestsRiskDetailDaoTest extends SpringConfiguredJunit4Test {

    @Autowired
    private InterestsRiskDetailDao dao;

    @Test
    public void findRiskDetail() throws Exception {
        Integer interestsId = 14083;
        Map<UserIdentifier, String> map = new HashMap<UserIdentifier, String>();
        map.put(UserIdentifier.MC, "10012202635");
        List<InterestsRiskDetailPo> results = this.dao.findRiskDetail(interestsId, map);
        System.out.println("findRiskDetail retsult:" + ReflectionToStringBuilder.toString(results));

        interestsId = 14083;
        map.put(UserIdentifier.IC, "test123");
        results = this.dao.findRiskDetail(interestsId, map);
        System.out.println("findRiskDetail retsult:" + ReflectionToStringBuilder.toString(results));
    }

    // @Test
    // public void addInterestsRiskDetail() throws Exception {
    // InterestsRiskDetailPo p = new InterestsRiskDetailPo();
    // p.setCreateDate(new Date());
    // p.setHoldTimes(1);
    // p.setIdentifierType("MC");
    // p.setIdentifierValue("12345");
    // p.setInterestsId(123);
    // p.setPeriodLimitType("W");
    // p.setPeriodLimitValue("5");
    // p.setStatus("1");
    // p.setUpdateDate(new Date());
    // dao.addRiskDetail(p);
    // }

    @Test
    public void updateInterestsRiskDetail() throws Exception {
        InterestsRiskDetailPo p = new InterestsRiskDetailPo();
        p.setCreateDate(new Date());
        p.setHoldTimes(1);
        p.setIdentifierType("MC");
        p.setIdentifierValue("12345");
        p.setInterestsId(123);
        p.setPeriodLimitType("W");
        p.setPeriodLimitValue("5");
        p.setStatus("1");
        p.setUpdateDate(new Date());
        p.setId(1768);
        Date expectedUpdateDate = p.getUpdateDate();
        p.setUpdateDate(new Date());
        this.dao.updateInterestsRiskDetailStatus(p,expectedUpdateDate);
    }

    @Test
    public void updateInterestsRiskDetails() throws Exception {
        InterestsRiskDetailPo p = new InterestsRiskDetailPo();
        p.setCreateDate(new Date());
        p.setHoldTimes(3);
        p.setIdentifierType("MC");
        p.setIdentifierValue("12345");
        p.setInterestsId(123);
        p.setPeriodLimitType("W");
        p.setPeriodLimitValue("5");
        p.setStatus("1");
        p.setUpdateDate(new Date());
        p.setId(1768);

        InterestsRiskDetailPo p2 = new InterestsRiskDetailPo();
        p2.setCreateDate(new Date());
        p2.setHoldTimes(3);
        p2.setIdentifierType("MC");
        p2.setIdentifierValue("12345");
        p2.setInterestsId(123);
        p2.setPeriodLimitType("W");
        p2.setPeriodLimitValue("5");
        p2.setStatus("1");
        p2.setUpdateDate(new Date());
        p2.setId(1767);
        this.dao.updateRiskDetails(Arrays.asList(p, p2));
    }
}
