/**
 * 
 */
package com.bill99.ebd.rip.checkdb;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.enums.AcquirerAbility;
import com.bill99.ebd.rip.junit.SpringConfiguredJunit4Test;
import com.bill99.ebd.rip.persistence.dao.VoucherRepositoryDao;
import com.bill99.ebd.rip.persistence.model.VoucherRepositoryPo;

/**
 * @author shuangye.liu
 * 
 * @since Jun 14, 2016
 */
public class VoucherRepositoryDaoTest extends SpringConfiguredJunit4Test {

    @Autowired
    private VoucherRepositoryDao dao;

    @Test
    public void addVoucher() throws Exception {
        VoucherRepositoryPo p = new VoucherRepositoryPo();
        p.setAmount(BigDecimal.ONE);
        p.setAwareType("2");
        p.setConsumerMemberCode("123456");
        p.setCreateTime(new Date());
        p.setDeductAmt(BigDecimal.ONE);
        p.setDiscount(BigDecimal.ZERO);
        p.setEnableDate(new Date());
        p.setExpDate(new Date());
        p.setGenerateType("INNER");
        p.setInterestsId(6024);
        p.setMemberCode("12345");
        p.setMerchantId(123);
        p.setMobile("13585784554");
        p.setOffpriceAmt(BigDecimal.ONE);
        p.setStatus("HOLD");
        p.setTop(BigDecimal.ONE);
        p.setUpdateTime(new Date());
        p.setVoucherDescription("test");
        p.setVoucherLimit(BigDecimal.ONE);
        p.setVoucherName("test");
        p.setVoucherNo("test123" + System.currentTimeMillis());
        p.setVoucherType("1");
        dao.create(p);
        System.out.println(ReflectionToStringBuilder.toString(p));
    }

    @Test
    public void getHoldCount() throws Exception {
        Integer interestsId = 2085;
        String customerMemberCode = "10012042335";
        int count = dao.findHoldCount(interestsId, customerMemberCode);
        System.out.println(count);
    }

    @Test
    public void checkVoucherNo() throws Exception {
        boolean retsult = dao.checkVoucherNo("test123");
        System.out.println("checkVoucherNo retsult:" + retsult);
        boolean retsult2 = dao.checkVoucherNo("test12306");
        System.out.println("checkVoucherNo retsult:" + retsult2);
    }

    @Test
    public void getVoucherByNo() throws Exception {
        String voucherNo = "3460201611011718119300115";
        Map<String, Object> voucherMap = dao.findVoucher(voucherNo, AcquirerAbility.WRITEOFF.getIdentity());
        System.out.println(ReflectionToStringBuilder.toString(voucherMap));
    }

    @Test
    public void getExtVoucher() throws Exception {
        String consumerMembercode = "10011478572";
        String extInterestsCode = "VOUCHER_WANDAFILM_TICKET_1";
        List<Map<String, Object>> extVoucherMap = dao.findExtVoucher(consumerMembercode, extInterestsCode);
        for (Map<String, Object> map : extVoucherMap) {
            System.out.println(map.get("id"));
            System.out.println(ReflectionToStringBuilder.toString(map.get("extInterestsInit")));
        }
        System.out.println(ReflectionToStringBuilder.toString(extVoucherMap));
    }
}
