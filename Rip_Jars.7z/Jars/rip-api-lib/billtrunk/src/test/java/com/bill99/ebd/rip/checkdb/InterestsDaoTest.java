/**
 * 
 */
package com.bill99.ebd.rip.checkdb;

import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.enums.AcquirerAbility;
import com.bill99.ebd.rip.junit.SpringConfiguredJunit4Test;
import com.bill99.ebd.rip.persistence.dao.InterestsDao;

/**
 * @author shuangye.liu
 * 
 * @since Jun 14, 2016
 */
public class InterestsDaoTest extends SpringConfiguredJunit4Test {

    @Autowired
    private InterestsDao dao;

    @Test
    public void checkConfigration() throws Exception {
        Map<String, Object> map = this.dao.getMerchantAcquirableInterests(28094, "10012310603",
                AcquirerAbility.HOLD.getIdentity(), null);
        System.out.println(map);
    }

    @Test
    public void findInterests() throws Exception {
        List<Map<String, Object>> findInterests = this.dao.findInterests("10012042835", "2", "1", "2");
        System.out.println(findInterests.size());
    }

    @Test
    public void getIssuerInterests() throws Exception {
        Map<String, Object> issuerInterests = this.dao.getIssuerInterests(50104, "10012311728");
        System.out.println(issuerInterests);
    }

    @Test
    public void getInterests() throws Exception {
        Map<String, Object> interests = dao.getInterests(2277);
        System.out.println(interests);
    }
}
