package com.bill99.ebd.rip.checkdb;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.junit.SpringConfiguredJunit4Test;
import com.bill99.ebd.rip.persistence.dao.AlarmConfigDao;
import com.bill99.ebd.rip.persistence.model.AlarmConfigPo;

public class AlarmConfigDaoTest extends SpringConfiguredJunit4Test {
    @Autowired
    private AlarmConfigDao dao;

    @Test
    public void test_create() throws Exception {
        AlarmConfigPo p = getEntityNewInstanceBatch(AlarmConfigPo.class);
        p.setBizId("0001");
        p.setBizType("1");
        p.setCommonFlag(1);
        p.setCreateTime(new Date());
        p.setMemo("test");
        p.setNotifyCount(5);
        p.setNotifyList("123,123,234");
        p.setNotifyLimit(10);
        p.setNotifyTplId("002");
        p.setNotifyType("0");
        p.setStatus("1");
        p.setThresholdValue(new BigDecimal(1000));
        p.setThresholdType("1");
        p.setUpdateTime(new Date());
        System.out.println("================>" + ToStringBuilder.reflectionToString(p));
        dao.create(p);
    }

    @Test
    public void test_update() throws Exception {
        AlarmConfigPo p = getEntityNewInstanceBatch(AlarmConfigPo.class);
        p.setIdAlarmCfg(10);
        p.setBizId("0001");
        p.setBizType("2");
        p.setCommonFlag(1);
        p.setCreateTime(new Date());
        p.setMemo("test");
        p.setNotifyCount(5);
        p.setNotifyList("18900000000,18900000001,18900001111");
        p.setNotifyLimit(10);
        p.setNotifyTplId("002");
        p.setNotifyType("0");
        p.setStatus("1");
        p.setThresholdValue(new BigDecimal(299));
        p.setThresholdType("1");
        p.setUpdateTime(new Date());
        System.out.println("===================>" + ToStringBuilder.reflectionToString(p));
        dao.update(p, null);
    }

    @Test
    public void test_getAlarmConfigByBizId() throws Exception {
        // AlarmConfigPo p = getEntityNewInstanceBatch(AlarmConfigPo.class);
        Map<String, Object> paratmters = new HashMap<String, Object>();
        paratmters.put("bizId", "0003");
        paratmters.put("bizType", "1");
        List<AlarmConfigPo> pList = dao.getAlarmConfigByBizId(paratmters);
        System.out.println("================>" + ToStringBuilder.reflectionToString(pList.size()));
    }
}
