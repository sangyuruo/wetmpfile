package com.bill99.ebd.rip.persistence;

import java.math.BigDecimal;
import java.util.Date;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.domain.model.StakeholderBudgetLogDto;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.junit.SpringConfiguredJunit4Test;

public class StakeholderBudgetLogPersistenceManagerTest extends SpringConfiguredJunit4Test {

	@Autowired
	StakeholderBudgetLogPersistenceManager stakeholderBudgetLogPersistenceManager;
	
	@Test
	public void test_insert(){
		StakeholderBudgetLogDto stakeholderBudgetLogDto = new StakeholderBudgetLogDto();
		stakeholderBudgetLogDto.setAmount(new BigDecimal(100000));
		stakeholderBudgetLogDto.setCreateTime(new Date());
		stakeholderBudgetLogDto.setExternalFund("1");
		stakeholderBudgetLogDto.setMemo("wu");
		stakeholderBudgetLogDto.setOperator("admin");
		stakeholderBudgetLogDto.setPayeeMembercode("10000011");
		stakeholderBudgetLogDto.setPayerMembercode("10000012");
		stakeholderBudgetLogDto.setUpdateTime(new Date());
		try {
			stakeholderBudgetLogPersistenceManager.insertStakeholderBudgetLog(stakeholderBudgetLogDto);
		} catch (AppBizException e) {
			e.printStackTrace();
		}
	}
}
