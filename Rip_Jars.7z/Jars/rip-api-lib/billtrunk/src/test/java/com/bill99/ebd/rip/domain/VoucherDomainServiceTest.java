/**
 * 
 */
package com.bill99.ebd.rip.domain;

import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import com.bill99.ebd.rip.domain.model.HoldAndWriteOffVoucherDto;
import com.bill99.ebd.rip.domain.model.HoldAndWriteOffVoucherResultDto;
import com.bill99.ebd.rip.domain.model.HoldVoucherDto;
import com.bill99.ebd.rip.domain.model.Voucher;
import com.bill99.ebd.rip.enums.PayMode;
import com.bill99.ebd.rip.enums.TrueFalse;

/**
 * @author shuangye.liu
 * 
 * @since Jun 17, 2016
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:springContext.xml")
public class VoucherDomainServiceTest {

    @Autowired
    private VoucherDomainService voucherDomainService;

    @Test
    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void testHoldAndWriteOffVoucher() throws Exception {
        HoldAndWriteOffVoucherDto holdAndWriteOffVoucherDto = new HoldAndWriteOffVoucherDto();
        holdAndWriteOffVoucherDto.setMerchantMemberCode("10012188746");
        holdAndWriteOffVoucherDto.setConsumerMemberCode("10012310235");
        holdAndWriteOffVoucherDto.setChannel("ATE");
        holdAndWriteOffVoucherDto.setInitiativeFlag(TrueFalse.TRUE);
        holdAndWriteOffVoucherDto.setPayMode(PayMode.PAY_BANKCARD_DEBIT);
        holdAndWriteOffVoucherDto.setOrderNo("RIP" + System.currentTimeMillis());
        holdAndWriteOffVoucherDto.setOrderAmount(new BigDecimal(100));
        holdAndWriteOffVoucherDto.setTransactionTime(new Date());
        HoldAndWriteOffVoucherResultDto resultDto = this.voucherDomainService
                .holdAndWriteOffVoucher(holdAndWriteOffVoucherDto);
        System.out.println("@@result of testHoldVoucher" + ReflectionToStringBuilder.toString(resultDto));
    }

    @Test
    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void testHoldVoucher() throws Exception {
        HoldVoucherDto v = new HoldVoucherDto();
        v.setMerchantMembercode("10012188746");
        v.setChannel("INTRA");
        v.setOrderNo("1234");
        v.setInterestsId(29068);
        v.setConsumerMembercode("10012310235");
        v.setOrderAmount(new BigDecimal(100));
        Voucher voucher = this.voucherDomainService.holdVoucher(v);
        System.out.println("@@result of testHoldVoucher" + ReflectionToStringBuilder.toString(voucher));
    }

}
