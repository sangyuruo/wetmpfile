package com.bill99.ebd.rip.adapter;

import java.util.Date; 

import org.apache.commons.lang.builder.ToStringBuilder;
import org.junit.Test;

import com.bill99.ebd.rip.domain.model.InterestsRiskDetail;
import com.bill99.ebd.rip.enums.PeriodLimitType;
import com.bill99.ebd.rip.enums.TrueFalse;
import com.bill99.ebd.rip.enums.UserIdentifier;
import com.bill99.ebd.rip.persistence.adapter.InterestsRiskDetailPersistenceAdapter;
import com.bill99.ebd.rip.persistence.model.InterestsRiskDetailPo;

public class InterestsRiskDetailPersistenceAdapterTest {
    private InterestsRiskDetailPersistenceAdapter adapter = new InterestsRiskDetailPersistenceAdapter();

    @Test
    public void testInbound() {
        InterestsRiskDetailPo p = new InterestsRiskDetailPo();
        InterestsRiskDetail d = new InterestsRiskDetail();
        d.setCreateDate(new Date());
        d.setHoldTimes(12);
        d.setId(2342213);
        d.setIdentifierValue("324322343224S4");
        d.setMemo("serewerer2weddddxdd");
        d.setPeriodLimitType(PeriodLimitType.MONTH);
        d.setPeriodLimitValue("23");
        d.setStatus(TrueFalse.TRUE);
        d.setUpdateDate(new Date());
        // d.setUserId("32312312311");
        d.setUserIdType(UserIdentifier.IC);

        this.adapter.inbound(d, p);
        System.out.println("result:" + ToStringBuilder.reflectionToString(p));
    }

    @Test
    public void testOutbound() {
        InterestsRiskDetailPo p = new InterestsRiskDetailPo();
        InterestsRiskDetail d = new InterestsRiskDetail();
        p.setCreateDate(new Date());
        p.setHoldTimes(12);
        p.setId(2342213);
        p.setIdentifierValue("3242234324S4");
        p.setMemo("serewereruuuwe");
        p.setPeriodLimitType(PeriodLimitType.MONTH.getId());
        p.setPeriodLimitValue("23");
        p.setStatus(TrueFalse.TRUE.getId());
        p.setUpdateDate(new Date());
        // p.setUserId("3231231231");
        // p.setUserIdTypes(UserIdentifier.IC.name());

        this.adapter.outbound(p, d);
        System.out.println("result:" + ToStringBuilder.reflectionToString(d));
    }

}
