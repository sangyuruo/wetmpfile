/**
 * 
 */
package com.bill99.ebd.rip.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * @author shuangye.liu
 * @since Sep 29, 2016
 */
public class UtilsTest {

    /**
     * @throws java.lang.Exception
     */
    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
    }

    /**
     * @throws java.lang.Exception
     */
    @AfterClass
    public static void tearDownAfterClass() throws Exception {
    }

    /**
     * @throws java.lang.Exception
     */
    @Before
    public void setUp() throws Exception {
    }

    /**
     * @throws java.lang.Exception
     */
    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void test_getVoucherNo() throws Exception {
        ExecutorService ex = Executors.newFixedThreadPool(10);
        List<Future<Void>> submits = new ArrayList<>();

        final Set<String> ss = new ConcurrentSkipListSet<>();

        for (int i = 0; i < 1000; i++) {
            submits.add(ex.submit(new Callable<Void>() {
                @Override
                public Void call() throws Exception {
                    String s = Utils.getVoucherNo();
                    ss.add(s);
                    return null;
                }

            }));
        }

        for (Future<Void> f : submits) {
            f.get();
        }

        ex.shutdown();
        Assert.assertEquals(1000, ss.size());
    }

}
