package com.bill99.ebd.rip.checkdb;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.enums.AcquirerAbility;
import com.bill99.ebd.rip.junit.SpringConfiguredJunit4Test;
import com.bill99.ebd.rip.persistence.dao.InterestsSkuRelationDao;
import com.bill99.ebd.rip.persistence.model.InterestsSkuRelationPo;

public class InterestsSkuRelationDaoTest extends SpringConfiguredJunit4Test {
    @Autowired
    private InterestsSkuRelationDao dao;

    @Test
    public void test_create() throws Exception {
        InterestsSkuRelationPo p = getEntityNewInstanceBatch(InterestsSkuRelationPo.class);
        /*
         * p.setIdInterestsSkuRel(11); p.setInterestsId(111); p.setMemberCode("22222"); p.setSkuId("2443");
         * p.setCrtTime(new Date()); p.setUptTime(new Date());
         */
        System.out.println("================>" + ToStringBuilder.reflectionToString(p));
        dao.create(p);
    }

    @Test
    public void delete() throws Exception {
        dao.delete(1);
    }

    @Test
    public void findInterestsSkuRelationByInterestsId() throws Exception {
        List<Integer> interestsIds = new ArrayList<>();
        interestsIds.add(50089);
        List<InterestsSkuRelationPo> list = dao.findInterestsSkuRelation(interestsIds, null, null);
        System.out.println(list.size());
    }

    @Test
    public void findInterestsSkuRelationByInterestsIdAndMemberCode() throws Exception {
        List<Integer> interestsIds = new ArrayList<>();
        interestsIds.add(50089);
        List<InterestsSkuRelationPo> list = dao.findInterestsSkuRelation(interestsIds, "10012311728", null);
        System.out.println(list.size());
    }

    @Test
    public void findInterestsSkuRelation() throws Exception {
        List<Integer> interestsIds = new ArrayList<>();
        interestsIds.add(50089);
        List<InterestsSkuRelationPo> list = dao.findInterestsSkuRelation(interestsIds, "10012311728",
                AcquirerAbility.WRITEOFF.getIdentity());
        System.out.println(list.size());
    }

}
