package com.bill99.ebd.rip.srv;

import java.math.BigDecimal;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bill99.ebd.rip.domain.StakeholderBudgetService;
import com.bill99.ebd.rip.exception.AppBizException;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:springContext.xml")
public class StakeholderBudgetServiceTest {
	@Autowired
	StakeholderBudgetService service;
	
	@Test
	public void test_create(){
		
			try {
				service.writeStakeholderBudget("1", new BigDecimal(40000), "100001111", "100002222", "admin_02", "测试充值");
			} catch (AppBizException e) {
				e.printStackTrace();
			}
	}
	
	   
    @Test
    public void test_search(){
        
            try {
                System.out.println(service.getStakeholderBudget("100001111"));
            } catch (AppBizException e) {
                e.printStackTrace();
            }
    }
}
