/**
 * 
 */
package com.bill99.ebd.rip.persistence;

import java.util.Collection;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.Predicate;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.domain.model.Voucher;
import com.bill99.ebd.rip.domain.model.VoucherTransaction;
import com.bill99.ebd.rip.enums.AwareType;
import com.bill99.ebd.rip.enums.TrueFalse;
import com.bill99.ebd.rip.enums.TxnType;
import com.bill99.ebd.rip.junit.SpringConfiguredJunit4Test;

/**
 * @author shuangye.liu
 * 
 * @since Jun 14, 2016
 */
public class VoucherPersistenceManagerTest extends SpringConfiguredJunit4Test {

    @Autowired
    private VoucherPersistenceManager voucherPersistenceManager;

    @Test
    public void test_findTransaction() throws Exception {

        this.voucherPersistenceManager.findTransaction("1470792868794", "ATE", TxnType.WRITEOFF, TrueFalse.FALSE,
                AwareType.AGGRESSIVE);

    }

    @Test
    public void test_findVoucherByTransaction() throws Exception {

        Voucher voucher = this.voucherPersistenceManager.findInnerVoucherByTransaction("1470792868794", "ATE",
                TxnType.WRITEOFF, AwareType.AGGRESSIVE, null);
        Collection<VoucherTransaction> list = CollectionUtils.select(voucher.getVoucherTransactions(),
                new Predicate<VoucherTransaction>() {
                    @Override
                    public boolean evaluate(VoucherTransaction vt) {
                        return vt.getTransactionType() == TxnType.WRITEOFF;
                    }
                });
        VoucherTransaction voucherTransaction = list.iterator().next();
        System.out.println(ToStringBuilder.reflectionToString(voucherTransaction));
    }

}
