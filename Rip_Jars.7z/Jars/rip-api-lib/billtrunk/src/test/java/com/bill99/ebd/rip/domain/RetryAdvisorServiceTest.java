/**
 * 
 */
package com.bill99.ebd.rip.domain;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bill99.ebd.rip.domain.advisor.Retry;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.exception.ConcurrentException;

/**
 * @author shuangye.liu
 *
 * @since Jun 17, 2016
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:springContext.xml")
public class RetryAdvisorServiceTest {

    static class TestDomainServiceImpl {

        @Retry
        public void testThrow() throws ConcurrentException {
            if (new Object() != null) {
                throw new ConcurrentException("test", "test");
            }
        }
    }

    @Autowired
    private TestDomainServiceImpl testDomainService;

    @Test
    public void test() throws AppBizException {
        testDomainService.testThrow();
    }

}
