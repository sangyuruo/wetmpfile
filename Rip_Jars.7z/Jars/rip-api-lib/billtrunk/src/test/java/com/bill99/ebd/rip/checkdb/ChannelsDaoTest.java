//package com.bill99.ebd.rip.checkdb;
//
//import static org.junit.Assert.assertEquals;
//import static org.junit.Assert.assertTrue;
//
//import java.util.List;
//
//import org.apache.commons.lang.builder.ToStringBuilder;
//import org.junit.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//
//import com.bill99.ebd.rip.dal.dao.ChannelsCond;
//import com.bill99.ebd.rip.dal.dao.ChannelsDao;
//import com.bill99.ebd.rip.dal.model.Channels;
//import com.bill99.ebd.rip.junit.SpringConfiguredJunit4Test;
//public class ChannelsDaoTest extends SpringConfiguredJunit4Test{
//
// 
//	@Autowired
//	private ChannelsDao dao;
//	
//	@Test
//	public void checkConfigration() throws Exception{
//		
//		Channels entity =  getEntityNewInstanceBatch(Channels.class);
//		
//		dao.add(entity);
//		System.out.println(ToStringBuilder.reflectionToString(entity));		
//		
//		Channels item = dao.get(entity.getId());
//		ChannelsCond cond = new ChannelsCond();
//		List<Channels> list = dao.queryList(cond, 0, -1);
//		System.out.println("=========size:" + list.size());
//		dao.delete(item);
//		assertEquals(item.getId(), entity.getId());
//		assertTrue("result list is empty",!list.isEmpty());
//	}
//	
//	 
//}
