package com.bill99.ebd.rip.checkdb;

import java.util.Date;

import javax.annotation.Resource;

import org.junit.Test;

import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.junit.SpringConfiguredJunit4Test;
import com.bill99.ebd.rip.persistence.dao.RequestJobDao;
import com.bill99.ebd.rip.persistence.model.RequestJobPo;

public class RequestJobDaoTest extends SpringConfiguredJunit4Test {

    @Resource(name = "requestJobIbatisDao")
    private RequestJobDao dao;

    @Test
    public void test() throws AppBizException {
        RequestJobPo requestJob = new RequestJobPo();
        requestJob.setCreateTime(new Date());
        requestJob.setMemo("test");
        requestJob.setOrderNo("12345667");
        requestJob.setOrigOrderNo("12345678");
        requestJob.setRequestId("fjeir45234");
        requestJob.setRequestMessage("test dao");
        requestJob.setRequestType("CANCEL");
        requestJob.setResponseCode("00");
        requestJob.setResponseMessage("test resp");
        requestJob.setRetryTimes(1);
        requestJob.setStatus("F");
        requestJob.setUpdateTime(new Date());
        // dao.create(requestJob);
        // System.out.println("1:" + dao.findRequestJobByOrderNo("12345667").getIdRequestJob());
        // System.out.println("2:" + dao.findRequestJobByOrderNoAndOrigOrderNo("12345667",
        // "12345678").getIdRequestJob());
        // List<String> status = new ArrayList<String>();
        // status.add("I");
        // status.add("F");
        // System.out.println("3:" + dao.findRequestJobByStatusByRequestType(status,
        // "CANCEL").get(0).getIdRequestJob());
        RequestJobPo job = dao.findRequestJobByOrderNoAndOrigOrderNo("12345667", "12345678");
        job.setMemo("update succss");
        job.setUpdateTime(new Date());
        dao.update(job, null);
    }
}
