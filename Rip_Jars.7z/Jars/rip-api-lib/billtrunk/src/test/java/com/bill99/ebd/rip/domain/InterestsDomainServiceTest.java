package com.bill99.ebd.rip.domain;

import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bill99.ebd.rip.exception.AppBizException;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:springContext.xml")
public class InterestsDomainServiceTest {
    
    @Autowired
    private InterestsDomainService interestsDomainService;

    @Test
    public void test_updateExpiredTime() throws AppBizException {
//        interestsDomainService.updateExpiredTime(50153, new Date(), new Date());
        System.out.println(interestsDomainService.findInterestsByInterestsId(50153).getExpireDate());
    }
}
