/**
 * 
 */
package com.bill99.ebd.rip.persistence;

import java.util.HashMap;
import java.util.Map;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.junit.SpringConfiguredJunit4Test;

/** 
 * @author yong.zheng
 * @version 创建时间：2017年1月17日 上午10:34:07 
 * 类说明 
 */
/**
 * @author yong.zheng
 * 
 */
public class InterestsSkuRelPersistenceManagerTest extends SpringConfiguredJunit4Test {
    /**
     * @throws java.lang.Exception
     */
    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
    }

    /**
     * @throws java.lang.Exception
     */
    @AfterClass
    public static void tearDownAfterClass() throws Exception {
    }

    @Autowired
    private InterestsSkuRelationPersistenceManager iskuRelManager;

    /**
     * @throws java.lang.Exception
     */
    @Before
    public void setUp() throws Exception {
    }

    /**
     * @throws java.lang.Exception
     */
    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void testPageQuery() throws Exception {
        Integer pageIndex = 1;
        Integer pageSize = 10;
        Map<String, Object> paramterMap = new HashMap<String, Object>();
        paramterMap.put("keywords", "rip1114");
        paramterMap.put("interestsId", null);
        paramterMap.put("memberCode", null);
        paramterMap.put("skuDes", null);
        Map<String, Object> skuListMap = this.iskuRelManager.pageQueryByParamMap(paramterMap, pageIndex, pageSize);
        System.out.println(skuListMap);
        System.out.println(123);
    }
}
