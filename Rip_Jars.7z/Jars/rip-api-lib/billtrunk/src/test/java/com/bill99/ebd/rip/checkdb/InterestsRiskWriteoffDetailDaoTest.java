package com.bill99.ebd.rip.checkdb;

import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.enums.TrueFalse;
import com.bill99.ebd.rip.junit.SpringConfiguredJunit4Test;
import com.bill99.ebd.rip.persistence.dao.InterestsRiskWfDetailDao;
import com.bill99.ebd.rip.persistence.model.InterestsRiskWfDetailPo;

public class InterestsRiskWriteoffDetailDaoTest extends SpringConfiguredJunit4Test {

    @Autowired
    private InterestsRiskWfDetailDao interestsRiskWfDetailDao;

    @Test
    public void create() throws Exception {

        InterestsRiskWfDetailPo entity = getEntityNewInstanceBatch(InterestsRiskWfDetailPo.class);
        interestsRiskWfDetailDao.create(entity);
        System.out.println("===========>" + entity.getIdInterestsRiskWfDetail());
    }

    @Test
    public void findRiskWfDetailByStatus() throws Exception {
        List<InterestsRiskWfDetailPo> list = interestsRiskWfDetailDao.findRiskWfDetailByStatus(new Date(), 10, 1);
        System.out.println(list.size());

    }

    @Test
    public void updateStauts() throws Exception {
        List<InterestsRiskWfDetailPo> list = interestsRiskWfDetailDao.findRiskWfDetailByStatus(new Date(), 10, 1);
        System.out.println(list.size());

        InterestsRiskWfDetailPo po = list.get(0);
        po.setStatus(TrueFalse.FALSE.getId());
        interestsRiskWfDetailDao.update(po, null);
        System.out.println("update," + po.getStatus());
    }

}
