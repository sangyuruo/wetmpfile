/**
 * 
 */
package com.bill99.ebd.rip.checkdb;

import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import com.bill99.ebd.rip.junit.SpringConfiguredJunit4Test;
import com.bill99.ebd.rip.persistence.dao.AccountBalanceCreditLineDao;
import com.bill99.ebd.rip.persistence.model.AccountBalanceCreditLinePo;

/**
 * @author shuang ye.liu
 * 
 * 
 * @since Jun 20 , 20162
 */
public class AccountBalanceCreditLineDaoTest extends SpringConfiguredJunit4Test {

    @Autowired
    private AccountBalanceCreditLineDao dao;

    @Test
    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void test_update() throws Exception {
        AccountBalanceCreditLinePo po = dao.get(1);
        System.out.println(ReflectionToStringBuilder.toString(po));

        BigDecimal remainingAmount = po.getRemainingAmount();
        po.setRemainingAmount(new BigDecimal("999966"));
        po.setUpdateTime(new Date());

        dao.update(po, remainingAmount);

        System.out.println("11111");
    }

}
