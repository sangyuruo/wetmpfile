/**
 * 
 */
package com.bill99.ebd.rip.checkdb;

import java.math.BigDecimal;
import java.util.Date;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.enums.TxnType;
import com.bill99.ebd.rip.junit.SpringConfiguredJunit4Test;
import com.bill99.ebd.rip.persistence.dao.VoucherTransactionDao;
import com.bill99.ebd.rip.persistence.model.VoucherTransactionPo;

/**
 * @author shuangye.liu
 *
 * @since Jun 14, 2016
 */
public class VoucherTransactionDaoTest extends SpringConfiguredJunit4Test {

    @Autowired
    private VoucherTransactionDao dao;

    @Test
    public void addVoucherTransaction() throws Exception {
        VoucherTransactionPo p = new VoucherTransactionPo();
        p.setAmount(BigDecimal.ONE);
        p.setInterestsId(1245);
        p.setMobile("13585784554");
        p.setUpdateTime(new Date());
        p.setVoucherNo("125478");
        p.setAcquirerId("12345");
        p.setAcquirerType("1");
        p.setCancelFlag("0");
        p.setCancelHoldFlag("1");
        p.setChannel("INTRA");
        p.setClearingStatus("I");
        p.setConsumerMembercode("12345");
        p.setDeviceId("deviceId");
        p.setExternalFund("1");
        p.setExtSeqId("12543");
        p.setTxnType(TxnType.HOLD.name());
        p.setMemo("test");
        p.setMerchantMemberCode("1234");
        p.setOrigSalesAmt(BigDecimal.ONE);
        p.setOrigTransactionId(1234);
        p.setPayMode("1");
        p.setProductCode("productCode");
        p.setSrcType("KQB");
        p.setVoucherPayAmt(BigDecimal.ONE);
        dao.create(p);
    }

}
