package com.bill99.ebd.rip.checkdb;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.enums.TrueFalse;
import com.bill99.ebd.rip.junit.SpringConfiguredJunit4Test;
import com.bill99.ebd.rip.persistence.dao.WithdrawTxnDao;
import com.bill99.ebd.rip.persistence.model.WithdrawTxnPo;

public class WithdrawTxnDaoTest extends SpringConfiguredJunit4Test {

    @Autowired
    private WithdrawTxnDao dao;

    @Test
    public void create() throws Exception {
        WithdrawTxnPo entity = getEntityNewInstanceBatch(WithdrawTxnPo.class);
        entity.setChannel("JUNIT");
        entity.setIsReverse(TrueFalse.FALSE.getId());
        entity.setOrgiWithdrawTxnId(null);
        dao.create(entity);
        System.out.println("================>" + ToStringBuilder.reflectionToString(entity));

    }

    @Test
    public void findByExtSeqId() throws Exception {
        WithdrawTxnPo result = dao.findByExtSeqId("243458797");
        System.out.println("================>" + ToStringBuilder.reflectionToString(result));

    }

    @Test
    public void findByChannelAndExtSeqId() throws Exception {
        WithdrawTxnPo result = dao.findByChannelAndExtSeqId("FPD", "1478676159367");
        System.out.println("================>" + ToStringBuilder.reflectionToString(result));

    }

}
