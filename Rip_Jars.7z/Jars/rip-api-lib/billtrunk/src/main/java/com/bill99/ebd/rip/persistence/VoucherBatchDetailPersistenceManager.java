package com.bill99.ebd.rip.persistence;

import java.util.List;
import java.util.Map;

import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.model.VoucherBatchDetailPo;
import com.bill99.ebd.rip.util.Page;

public interface VoucherBatchDetailPersistenceManager {

    void createVoucherBatchDetail(VoucherBatchDetailPo voucherBatchDetail) throws AppBizException;

    void createVoucherBatchDetails(List<VoucherBatchDetailPo> voucherBatchDetails) throws AppBizException;

    public void deleteByMemberIdAndInterestsId(Integer memberId, Integer interestsId) throws AppBizException;

    public void deleteByBatchNo(Integer batchNo, Integer interestsId) throws AppBizException;

    Page<VoucherBatchDetailPo> find(Integer batchId, Integer pageNumber, Integer pageSize) throws AppBizException;

    List<VoucherBatchDetailPo> findVoucherBatchDetails(Integer batchId, List<Integer> sequenceIds)
            throws AppBizException;

    List<VoucherBatchDetailPo> queryByBatchNo(Integer batchNo) throws AppBizException;

    List<VoucherBatchDetailPo> selectVoucherBatchByBatchNo(Integer batchId, Integer first, Integer pageSize)
            throws AppBizException;

    List<VoucherBatchDetailPo> queryByMemberIdAndInterests(Integer memberId, Integer interestsId)
            throws AppBizException;

    void updateByBatchNoAndCustomerMemberCode(Integer batchNo, Integer memberId, String voucherNo)
            throws AppBizException;

    void updateVoucherBatchDetail(VoucherBatchDetailPo voucherBatchDetail) throws AppBizException;

    void updateVoucherBatchDetails(List<VoucherBatchDetailPo> voucherBatchDetails) throws AppBizException;

    Integer countByVoucherBatchAndVoucherNo(Integer batchNo) throws AppBizException;

    void deleteVoucherBatchDetailById(Integer id) throws AppBizException;

    List<VoucherBatchDetailPo> queryByCustomerMemberCodeAndInterests(String customerCode, Integer interestsId)
            throws AppBizException;

    public Map<String, Object> pageQuery(Integer interestsId, String customerMemberCode, Integer pageIndex,
            Integer pageSize) throws AppBizException;

    VoucherBatchDetailPo findById(Integer id) throws AppBizException;
}
