/**
 * 
 */
package com.bill99.ebd.rip.util;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author shuangye.liu
 *
 * @since Jun 12, 2016
 */
public class ThreadLocalCache {

    private static final Logger logger = LoggerFactory.getLogger(ThreadLocalCache.class);

    private static final ThreadLocal<Map<Object, Object>> cacheHolder = new ThreadLocal<Map<Object, Object>>();

    private static final ThreadLocal<Integer> countHolder = new ThreadLocal<Integer>();

    public static void init() {
        Map<Object, Object> cache = cacheHolder.get();
        Integer count = countHolder.get();
        Integer resultCount = null;
        if (cache == null) {
            cacheHolder.set(new HashMap<Object, Object>());
            resultCount = 1;
        } else {
            resultCount = count + 1;
        }
        countHolder.set(resultCount);
        logger.info("init(), count: {} -> {}", count, resultCount);
    }

    public static void remove() {
        Integer count = countHolder.get();
        Integer resultCount = null;
        if (count == null || count < 2) {
            cacheHolder.remove();
            resultCount = null;
        } else {
            resultCount = count - 1;
        }
        countHolder.set(resultCount);
        logger.info("remove(), count: {} -> {}", count, resultCount);
    }

    public static void put(Object key, Object value) {
        Map<Object, Object> cache = cacheHolder.get();
        if (cache != null) {
            cache.put(key, value);
        }
    }

    public static Object get(Object key) {
        Map<Object, Object> cache = cacheHolder.get();
        if (cache != null) {
            return cache.get(key);
        } else {
            return null;
        }
    }

}
