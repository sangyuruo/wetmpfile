package com.bill99.ebd.rip.persistence;

import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.model.FundTxnPo;

public interface FundTxnPersistenceManager {

    void createFundTxn(FundTxnPo fundTxn) throws AppBizException;

    void updateFundTxn(FundTxnPo fundTxn) throws AppBizException;

    FundTxnPo getStlFundTxnByExtSeqId(String origOrderNo) throws AppBizException;
}
