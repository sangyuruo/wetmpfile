package com.bill99.ebd.rip.persistence;

import java.util.List;

import com.bill99.ebd.rip.domain.model.Channel;
import com.bill99.ebd.rip.exception.AppBizException;

public interface ChannelPersistenceManager {

    List<Channel> getChannels() throws AppBizException;
}
