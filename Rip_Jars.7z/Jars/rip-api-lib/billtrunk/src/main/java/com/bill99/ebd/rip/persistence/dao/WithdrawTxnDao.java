package com.bill99.ebd.rip.persistence.dao;

import java.util.List;
import java.util.Map;

import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.model.WithdrawTxnPo;

/**
 * 出款资金表DB操作接口
 * 
 * @author haipeng.cheng
 * @since 2016年11月2日 下午2:10:00
 * @project rip-api-lib_1031
 */
public interface WithdrawTxnDao extends CrudDao<WithdrawTxnPo> {

    public List<Map<String, String>> sumSuccFundoutAmtByInterestsIds(List<String> payStatus, List<Integer> interestsIds);

    public WithdrawTxnPo findByExtSeqId(String extSeqId) throws AppBizException;

    public WithdrawTxnPo findByChannelAndExtSeqId(String channel, String extSeqId) throws AppBizException;

    public List<WithdrawTxnPo> pageFindByClrStatus(String clrStatus, Integer pageIndex, Integer pageSize)
            throws AppBizException;

    public WithdrawTxnPo getWithdrawTransaction(Integer idWithdrawTxn) throws AppBizException;
}
