package com.bill99.ebd.rip.persistence.dao;

import java.util.List;
import java.util.Map;

import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.model.StakeholderBudgetPo;

public interface StakeholderBudgetDao extends CrudDao<StakeholderBudgetPo>{

	/**
	 * 查询商户活动预算
	 * @param paratmters
	 * @return
	 * @throws AppBizException
	 */
	List<StakeholderBudgetPo> getStakeholderBudget(Map<String, Object> paratmters) throws AppBizException;

	/**
	 * 根据ID和updateTime更新账户预算款信息
	 * @param paramterMap
	 * @throws AppBizException
	 */
	void updateStakeholderBudget(Map<String, Object> paramterMap) throws AppBizException;
	
}
