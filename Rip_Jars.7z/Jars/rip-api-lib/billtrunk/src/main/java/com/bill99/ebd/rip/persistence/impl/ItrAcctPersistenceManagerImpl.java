/**
 * 
 */
package com.bill99.ebd.rip.persistence.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.domain.model.ItrAcct;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.ItrAcctPersistenceManager;
import com.bill99.ebd.rip.persistence.adapter.ItrAcctPersistenceAdapter;
import com.bill99.ebd.rip.persistence.dao.ItrAcctDao;
import com.bill99.ebd.rip.persistence.model.ItrAcctPo;
import com.bill99.ebd.rip.util.ThreadLocalCacheHelper;

/**
 * 
 * 
 * @author wei.wang.rd
 * @since Oct 23, 2016
 */
public class ItrAcctPersistenceManagerImpl implements ItrAcctPersistenceManager {

    private static final Logger logger = LoggerFactory.getLogger(ItrAcctPersistenceManagerImpl.class);

    private static ItrAcctPersistenceAdapter itrAcctPersistenceAdapter = new ItrAcctPersistenceAdapter();

    private ItrAcctDao itrAcctDao;

    @Autowired
    public void setItrAcctDao(ItrAcctDao itrAcctDao) {
        this.itrAcctDao = itrAcctDao;
    }

    @Override
    public void saveOrUpdateItrAcct(ItrAcct newItrAcct, ItrAcct oldItrAcct) throws AppBizException {
        Integer idItrAcct = newItrAcct.getIdItrAcct();
        if (null == idItrAcct) {
            createItrAcct(newItrAcct);
        } else {
            updateItrAcct(newItrAcct, oldItrAcct);
        }
    }

    @Override
    public void createItrAcct(ItrAcct itrAcct) throws AppBizException {
        ItrAcctPo po = new ItrAcctPo();
        itrAcctPersistenceAdapter.inbound(itrAcct, po);
        itrAcctDao.create(po);
        ThreadLocalCacheHelper.putPo(po);
        itrAcctPersistenceAdapter.outbound(po, itrAcct);
    }

    @Override
    public void updateItrAcct(ItrAcct newItrAcct, ItrAcct oldItrAcct) throws AppBizException {
        ItrAcctPo po = new ItrAcctPo();
        itrAcctPersistenceAdapter.inbound(newItrAcct, po);
        ItrAcctPo oldPo = null;
        if (oldItrAcct != null) {
            oldPo = new ItrAcctPo();
            itrAcctPersistenceAdapter.inbound(oldItrAcct, oldPo);
        }
        itrAcctDao.update(po, oldPo);
        itrAcctPersistenceAdapter.outbound(po, newItrAcct);
        ThreadLocalCacheHelper.putPo(po);
    }

    @Override
    public ItrAcct getItrAcct(String membercode) throws AppBizException {
        ItrAcct itrAcct = new ItrAcct();
        ItrAcctPo itrAcctPo = itrAcctDao.getItrAcctByMembercode(membercode);
        if (itrAcctPo == null) {
            return null;
        }
        itrAcctPersistenceAdapter.doOutbound(itrAcctPo, itrAcct);
        return itrAcct;
    }

}
