package com.bill99.ebd.rip.persistence;

import java.util.Map;

import com.bill99.ebd.rip.domain.model.StakeholderBudgetDto;
import com.bill99.ebd.rip.exception.AppBizException;

/**
 * 垫资方活动预算
 * @author yangyang.yu
 *
 */
public interface StakeholderBudgetPersistenceManager {

	/**
	 * 添加
	 * @param stakeholderBudgetDto
	 * @throws AppBizException
	 */
	void insertStakeholderBudget(StakeholderBudgetDto stakeholderBudgetDto) throws AppBizException;

	/**
	 * 更新账户额度
	 * @param stakeholderBudgetDto
	 * @throws AppBizException
	 */
	void updateStakeholderBudget(Map<String, Object> paramterMap) throws AppBizException;

	/**
	 * 根据membercode获取对象
	 * @param idStakeholderBudget
	 * @param memberCode
	 * @return
	 * @throws AppBizException
	 */
	StakeholderBudgetDto getStakeholderBudget(Integer idStakeholderBudget, String memberCode) throws AppBizException;
}
