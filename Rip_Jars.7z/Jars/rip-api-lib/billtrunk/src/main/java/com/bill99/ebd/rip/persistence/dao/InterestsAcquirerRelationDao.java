package com.bill99.ebd.rip.persistence.dao;

import java.util.List;
import java.util.Map;

import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.model.InterestsAcquirerRelationPo;

public interface InterestsAcquirerRelationDao extends CrudDao<InterestsAcquirerRelationPo> {

    public List<InterestsAcquirerRelationPo> findInterestsAcquirerRel(Integer interestsId, String acquirerType,
            String acquirerId, String acquirerName) throws AppBizException;

    public Map<String, Object> pageQuery(Map<String, Object> conditions, Integer pageIndex, Integer pageSize)
            throws AppBizException;
    
    public List<InterestsAcquirerRelationPo> findInterestsAcquirerByInterestsId(Integer interestsId) throws AppBizException;
}
