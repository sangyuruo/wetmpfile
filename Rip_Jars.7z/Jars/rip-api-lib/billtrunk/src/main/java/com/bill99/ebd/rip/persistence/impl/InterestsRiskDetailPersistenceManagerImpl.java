package com.bill99.ebd.rip.persistence.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.domain.model.InterestsRiskDetail;
import com.bill99.ebd.rip.enums.UserIdentifier;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.InterestsRiskDetailPersistenceManager;
import com.bill99.ebd.rip.persistence.adapter.InterestsRiskDetailPersistenceAdapter;
import com.bill99.ebd.rip.persistence.dao.InterestsRiskDetailDao;
import com.bill99.ebd.rip.persistence.model.InterestsRiskDetailPo;
import com.bill99.ebd.rip.util.ApiUtils;
import com.bill99.ebd.rip.util.ThreadLocalCacheHelper;

public class InterestsRiskDetailPersistenceManagerImpl implements InterestsRiskDetailPersistenceManager {

    @Autowired
    private InterestsRiskDetailDao interestsRiskDetailDao;

    private InterestsRiskDetailPersistenceAdapter interestsRiskDetailPersistenceAdapter = new InterestsRiskDetailPersistenceAdapter();

    @Override
    public void addOrUpdteRiskDetails(List<InterestsRiskDetail> riskDetailList) throws AppBizException {
        List<InterestsRiskDetailPo> pos = new ArrayList<InterestsRiskDetailPo>();
        for (InterestsRiskDetail riskDetail : riskDetailList) {
            InterestsRiskDetailPo interestsRiskDetailPo = new InterestsRiskDetailPo();
            this.interestsRiskDetailPersistenceAdapter.inbound(riskDetail, interestsRiskDetailPo);
            pos.add(interestsRiskDetailPo);
        }
        List<InterestsRiskDetailPo> copies = ThreadLocalCacheHelper.getPos(pos);
        Map<Integer, InterestsRiskDetailPo> copiesMap = new HashMap<>();
        this.convertListToMap(copies, copiesMap);

        List<InterestsRiskDetailPo> addPos = new ArrayList<>();
        List<InterestsRiskDetailPo> updatePos = new ArrayList<>();
        for (InterestsRiskDetailPo po : pos) {
            if (po.getId() == null) {
                addPos.add(po);
            } else {
                if (!ApiUtils.equals(po, copiesMap.get(po.getId()))) {
                    updatePos.add(po);
                }
            }
        }
        if (CollectionUtils.isNotEmpty(addPos)) {
            this.interestsRiskDetailDao.addRiskDetails(addPos);
        }

        if (CollectionUtils.isNotEmpty(updatePos)) {
            this.interestsRiskDetailDao.updateRiskDetails(updatePos);
        }
    }

    @Override
    public void addRiskDetail(InterestsRiskDetail interestsRiskDetail) throws AppBizException {
        InterestsRiskDetailPo interestsRiskDetailPo = new InterestsRiskDetailPo();
        this.interestsRiskDetailPersistenceAdapter.inbound(interestsRiskDetail, interestsRiskDetailPo);
        this.interestsRiskDetailDao.addRiskDetail(interestsRiskDetailPo);

    }

    private void convertListToMap(List<InterestsRiskDetailPo> poList, Map<Integer, InterestsRiskDetailPo> poMap) {
        if (poList == null || poList.isEmpty()) {
            return;
        }
        for (InterestsRiskDetailPo po : poList) {
            poMap.put(po.getId(), po);
        }
    }

    @Override
    public List<InterestsRiskDetail> findRiskDetail(Integer interestsId, Map<UserIdentifier, String> identifierMap)
            throws AppBizException {
        List<InterestsRiskDetailPo> poList = this.interestsRiskDetailDao.findRiskDetail(interestsId, identifierMap);
        if (poList == null) {
            return null;
        }

        List<InterestsRiskDetail> restList = new ArrayList<InterestsRiskDetail>();
        for (InterestsRiskDetailPo po : poList) {
            InterestsRiskDetail d = new InterestsRiskDetail();
            this.interestsRiskDetailPersistenceAdapter.outbound(po, d);
            restList.add(d);
        }
        return restList;
    }

    @Override
    public List<InterestsRiskDetail> findRiskDetailByMemberCodes(Integer interestsId, List<String> memberCodes)
            throws AppBizException {
        List<InterestsRiskDetailPo> poList = this.interestsRiskDetailDao.findRiskDetailByMemberCodes(interestsId,
                memberCodes);
        if (poList == null) {
            return null;
        }

        List<InterestsRiskDetail> restList = new ArrayList<InterestsRiskDetail>();
        for (InterestsRiskDetailPo po : poList) {
            InterestsRiskDetail d = new InterestsRiskDetail();
            this.interestsRiskDetailPersistenceAdapter.outbound(po, d);
            restList.add(d);
        }
        return restList;
    }

    @Override
    public void updateRiskDetail(InterestsRiskDetail interestsRiskDetail, InterestsRiskDetailPo copy)
            throws AppBizException {
        InterestsRiskDetailPo interestsRiskDetailPo = new InterestsRiskDetailPo();
        this.interestsRiskDetailPersistenceAdapter.inbound(interestsRiskDetail, interestsRiskDetailPo);
        Date expectedUpdateDate = interestsRiskDetailPo.getUpdateDate();
        interestsRiskDetailPo.setUpdateDate(new Date());
        this.interestsRiskDetailDao.updateInterestsRiskDetailStatus(interestsRiskDetailPo,expectedUpdateDate);
    }
    
    @Override
    public int updateInterestsRiskDetailStatus(InterestsRiskDetailPo interestsRiskDetailPo,Date expectedUpdateDate) throws AppBizException {
        return interestsRiskDetailDao.updateInterestsRiskDetailStatus(interestsRiskDetailPo,expectedUpdateDate);
    }

    @Override
    public List<InterestsRiskDetailPo> queryRiskDetailForUpdateStatus(Date nowDay, int size,Integer maxId) throws AppBizException {
        return interestsRiskDetailDao.queryRiskDetailForUpdateStatus(nowDay, size,maxId);
    }
    
    @Override
    public InterestsRiskDetailPo getRiskDetailById(Integer id) throws AppBizException {
        return interestsRiskDetailDao.getRiskDetailById(id);
    }
    
}
