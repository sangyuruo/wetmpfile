package com.bill99.ebd.rip.persistence.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.domain.model.InterestsStakeholder;
import com.bill99.ebd.rip.domain.model.StakeholderBudget;
import com.bill99.ebd.rip.domain.model.StakeholderWriteoffCreditline;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.InterestsStakeholderPersistenceManager;
import com.bill99.ebd.rip.persistence.adapter.InterestsStakeholderPersistenceAdapter;
import com.bill99.ebd.rip.persistence.dao.InterestsStakeholderDao;
import com.bill99.ebd.rip.persistence.model.InterestsStakeholderPo;
import com.bill99.ebd.rip.util.ToStringUtils;

public class InterestsStakeholderPersistenceManagerImpl implements InterestsStakeholderPersistenceManager {

    private Log log = LogFactory.getLog(getClass());
    private InterestsStakeholderDao interestsStakeholderDao;

    @Autowired
    public void setInterestsStakeholderDao(InterestsStakeholderDao interestsStakeholderDao) {
        this.interestsStakeholderDao = interestsStakeholderDao;
    }

    @Override
    public InterestsStakeholder findInterestsStakeholder(Integer interestsId) throws AppBizException {
        List<InterestsStakeholderPo> list = this.interestsStakeholderDao.findInterestsStakeholders(interestsId);
        if (list.isEmpty()) {
            return null;
        }
        InterestsStakeholderPersistenceAdapter adapter = new InterestsStakeholderPersistenceAdapter();
        InterestsStakeholder interestsStakeholder = new InterestsStakeholder();
        adapter.doOutbound(list.get(0), interestsStakeholder);
        return interestsStakeholder;
    }

    @Override
    public StakeholderBudget getStakeholderBudget(String membercode) throws AppBizException {
        Map<String, Object> resultMap = this.interestsStakeholderDao.getStakeholderBudget(membercode);
        if (resultMap == null) {
            return null;
        }

        StakeholderBudget budget = new StakeholderBudget();
        budget.setMembercode((String) resultMap.get("membercode"));
        budget.setAmount((BigDecimal) resultMap.get("amount"));
        log.info("@@getStakeholderBudget done,result=" + ToStringUtils.recursiveReflectionToString(budget));
        return budget;
    }

    @Override
    public StakeholderWriteoffCreditline getStakeholderWriteoffCreditline(String membercode) throws AppBizException {
        Map<String, Object> resultMap = this.interestsStakeholderDao.getStakeholderWriteoffCreditline(membercode);
        if (resultMap == null) {
            return null;
        }

        StakeholderWriteoffCreditline creditline = new StakeholderWriteoffCreditline();
        creditline.setMembercode((String) resultMap.get("membercode"));
        creditline.setAmount((BigDecimal) resultMap.get("amount"));
        log.info("@@getStakeholderWriteoffCreditline done,result="
                + ToStringUtils.recursiveReflectionToString(creditline));
        return creditline;
    }

    @Override
    public List<InterestsStakeholder> queryInterestsStakeholder(Map<String, Object> paratmters) throws AppBizException {
        List<InterestsStakeholder> interestsStakeholderList = new ArrayList<InterestsStakeholder>();
        List<InterestsStakeholderPo> list = this.interestsStakeholderDao.findInterestsStakeholdersByParam(paratmters);
        if (list.isEmpty()) {
            return null;
        }
        InterestsStakeholderPersistenceAdapter adapter = new InterestsStakeholderPersistenceAdapter();
        for (InterestsStakeholderPo po : list) {
            InterestsStakeholder interestsStakeholder = new InterestsStakeholder();
            adapter.doOutbound(po, interestsStakeholder);
            interestsStakeholderList.add(interestsStakeholder);
        }
        return interestsStakeholderList;
    }

}
