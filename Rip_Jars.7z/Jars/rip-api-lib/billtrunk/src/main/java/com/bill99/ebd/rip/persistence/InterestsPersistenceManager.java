/**
 *
 */
package com.bill99.ebd.rip.persistence;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.bill99.ebd.rip.domain.model.AcquirerInterestsDto;
import com.bill99.ebd.rip.domain.model.Interests;
import com.bill99.ebd.rip.domain.model.InterestsAcquirerRelation;
import com.bill99.ebd.rip.domain.model.InterestsDto;
import com.bill99.ebd.rip.domain.model.InterestsRule;
import com.bill99.ebd.rip.enums.AcquirerAbility;
import com.bill99.ebd.rip.enums.AwareType;
import com.bill99.ebd.rip.enums.HoldScene;
import com.bill99.ebd.rip.exception.AppBizException;

/**
 *
 * @author shuangye.liu
 * @since Jun 12, 2016
 */
public interface InterestsPersistenceManager {

    void createInterests(Interests interests) throws AppBizException;

    List<AcquirerInterestsDto> findAcquirerInterestsDto(String merchantMembercode) throws AppBizException;

    List<Interests> findInterests(String merchantMembercode, AcquirerAbility ability, AwareType awareType,
            HoldScene holdScene) throws AppBizException;

    List<Interests> findInterestsByActivityId(Integer activityId) throws AppBizException;

    List<InterestsDto> findInterestsDto(String merchantMembercode, AcquirerAbility ability, AwareType awareType)
            throws AppBizException;

    Map<String, Integer> findInterestsIds(List<String> oids) throws AppBizException;

    InterestsRule findInterestsRule(Integer interestsId) throws AppBizException;

    List<InterestsAcquirerRelation> findRelatedAcquirerRelation(Integer interestsId) throws AppBizException;

    Interests getInterestsById(Integer interestsId) throws AppBizException;

    Interests getInterestsByIdAndIssuerId(Integer interestsId, String issuerId) throws AppBizException;

    Interests getMerchantAcquirableInterests(Integer interestsId, String merchantMembercode, AcquirerAbility ability,
            HoldScene holdScene) throws AppBizException;

    boolean syncActivityStatusChange(Integer activityId, String changeStatusCmd) throws AppBizException;

    boolean updateExpiredTime(Integer interestsId, Date expiredDate, Date holdExpiredDate) throws AppBizException;

    void updateInterests(Interests interests) throws AppBizException;
}
