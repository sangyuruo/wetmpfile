package com.bill99.ebd.rip.persistence.dao;

import java.util.List;
import java.util.Map;

import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.model.MemberPo;

public interface MemberDao extends CrudDao<MemberPo> {

    public MemberPo queryById(Integer id) throws AppBizException;

    public List<MemberPo> query(String memberName, String memberCode) throws AppBizException;

    public Map<String, Object> pageQuery(Map<String, Object> paramterMap, Integer pageIndex, Integer pageSize)
            throws AppBizException;

    public MemberPo queryByMemberCode(String memberCode) throws AppBizException;
}
