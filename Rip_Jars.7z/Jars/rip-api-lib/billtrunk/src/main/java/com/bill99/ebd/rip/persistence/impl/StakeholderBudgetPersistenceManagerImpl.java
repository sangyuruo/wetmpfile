package com.bill99.ebd.rip.persistence.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.domain.model.StakeholderBudgetDto;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.StakeholderBudgetPersistenceManager;
import com.bill99.ebd.rip.persistence.adapter.StakeholderBudgetPoPersistenceAdapter;
import com.bill99.ebd.rip.persistence.dao.StakeholderBudgetDao;
import com.bill99.ebd.rip.persistence.model.StakeholderBudgetPo;

public class StakeholderBudgetPersistenceManagerImpl implements StakeholderBudgetPersistenceManager {

	private StakeholderBudgetDao stakeholderBudgetIBatis;

	private StakeholderBudgetPoPersistenceAdapter adapter = new StakeholderBudgetPoPersistenceAdapter();

	@Autowired
	public void setStakeholderBudgetDaoIBatis(StakeholderBudgetDao stakeholderBudgetIBatis) {
		this.stakeholderBudgetIBatis = stakeholderBudgetIBatis;
	}

	@Override
	public void insertStakeholderBudget(StakeholderBudgetDto stakeholderBudgetDto) throws AppBizException {
		StakeholderBudgetPo stakeholderBudgetPo = new StakeholderBudgetPo();
		adapter.inbound(stakeholderBudgetDto, stakeholderBudgetPo);
		// 如果没设定时间，初始化创建时间
		if (null == stakeholderBudgetPo.getCreateTime()) {
			stakeholderBudgetPo.setCreateTime(new Date());
		}
		stakeholderBudgetIBatis.create(stakeholderBudgetPo);
	}

	@Override
	public void updateStakeholderBudget(Map<String, Object> paramterMap) throws AppBizException {
		stakeholderBudgetIBatis.updateStakeholderBudget(paramterMap);
	}

	@Override
	public StakeholderBudgetDto getStakeholderBudget(Integer idStakeholderBudget, String memberCode)
			throws AppBizException {
		Map<String, Object> paramterMap = new HashMap<String, Object>();
		paramterMap.put("idStakeholderBudget", idStakeholderBudget);
		paramterMap.put("memberCode", memberCode);

		List<StakeholderBudgetPo> stakeholderBudgetPoList = this.stakeholderBudgetIBatis
				.getStakeholderBudget(paramterMap);
		StakeholderBudgetDto stakeholderBudgetDto = null;
		if (stakeholderBudgetPoList.size() > 0) {
			stakeholderBudgetDto = new StakeholderBudgetDto();
			adapter.outbound(stakeholderBudgetPoList.get(0), stakeholderBudgetDto);
		}
		return stakeholderBudgetDto;
	}

}
