/**
 * 
 */
package com.bill99.ebd.rip.persistence;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.bill99.ebd.rip.domain.model.ConsumerVoucherDto;
import com.bill99.ebd.rip.domain.model.ExtInterestsInit;
import com.bill99.ebd.rip.domain.model.ExtVoucherResultDto;
import com.bill99.ebd.rip.domain.model.Voucher;
import com.bill99.ebd.rip.domain.model.VoucherTransaction;
import com.bill99.ebd.rip.enums.AwareType;
import com.bill99.ebd.rip.enums.ExtInterestsInitStatus;
import com.bill99.ebd.rip.enums.HoldScene;
import com.bill99.ebd.rip.enums.InterestsGenerateType;
import com.bill99.ebd.rip.enums.TrueFalse;
import com.bill99.ebd.rip.enums.TxnType;
import com.bill99.ebd.rip.enums.VoucherStatus;
import com.bill99.ebd.rip.exception.AppBizException;

/**
 * @author shuangye.liu
 * 
 * @since Jun 12, 2016
 */
public interface VoucherPersistenceManager {

    Boolean checkVoucherNo(String voucherNo) throws AppBizException;

    Integer countTimes(Integer interestsId, String consumerMemberCode) throws AppBizException;

    Map<Integer, Integer> countTimes(List<Integer> interestsIds, String consumerMemberCode) throws AppBizException;

    void createVoucher(Voucher voucher) throws AppBizException;

    void createVouchers(List<Voucher> vouchers) throws AppBizException;

    List<Voucher> findConsumerAllVouchers(String consumerMemberCode) throws AppBizException;

    List<ConsumerVoucherDto> findConsumerVouchers(String consumerMemberCode, String merchantMemberCode,
            VoucherStatus status, InterestsGenerateType generateType) throws AppBizException;

    List<ExtVoucherResultDto> findExtVouchers(String consumerMembercode, String extInterestsCode)
            throws AppBizException;

    Voucher findInnerVoucherByTransaction(String orderNo, String channel, TxnType transactionType, AwareType awareType,
            HoldScene holdScene) throws AppBizException;

    ExtInterestsInit findOneExtInterestsInit(Integer interestsId, ExtInterestsInitStatus status) throws AppBizException;

    VoucherTransaction findTransaction(String orderNo, String channel, TxnType transactionType, TrueFalse isCanceled,
            AwareType awareType) throws AppBizException;

    Voucher findVoucher(String voucherNo) throws AppBizException;

    List<Voucher> findVoucherByTransaction(String orderNo, String channel, TxnType transactionType,
            AwareType awareType, HoldScene holdScene, String acquirerAbility) throws AppBizException;

    boolean hasBoundCard(String consumerMemberCode, Date firstBindCardStartDate, Date firstBindCardEndDate)
            throws AppBizException;

    void updateVoucher(Voucher voucher) throws AppBizException;

}
