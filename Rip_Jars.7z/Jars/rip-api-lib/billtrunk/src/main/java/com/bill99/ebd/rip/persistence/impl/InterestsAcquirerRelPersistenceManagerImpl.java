package com.bill99.ebd.rip.persistence.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.domain.model.InterestsAcquirerRelation;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.InterestsAcquirerRelPersistenceManager;
import com.bill99.ebd.rip.persistence.adapter.InterestsAcquirerRelationPersistenceAdapter;
import com.bill99.ebd.rip.persistence.dao.InterestsAcquirerRelationDao;
import com.bill99.ebd.rip.persistence.model.InterestsAcquirerRelationPo;

public class InterestsAcquirerRelPersistenceManagerImpl implements InterestsAcquirerRelPersistenceManager {

    private InterestsAcquirerRelationDao interestsAcquirerRelDao;

    @Autowired
    public void setInterestsAcquirerRelDao(InterestsAcquirerRelationDao interestsAcquirerRelDao) {
        this.interestsAcquirerRelDao = interestsAcquirerRelDao;
    }

    @Override
    public void createInterestsAcquirerRel(InterestsAcquirerRelationPo interestsAcquirerRelation)
            throws AppBizException {
        interestsAcquirerRelDao.create(interestsAcquirerRelation);
    }

    @Override
    public void updateInterestsAcquirerRel(InterestsAcquirerRelationPo interestsAcquirerRelation)
            throws AppBizException {

        interestsAcquirerRelDao.update(interestsAcquirerRelation, null);
    }

    @Override
    public List<InterestsAcquirerRelationPo> findInterestsAcquirerRels(Integer interestsId, String acquirerType,
            String acquirerId, String acquirerName) throws AppBizException {
        Map<String, Object> paramterMap = new HashMap<String, Object>();
        paramterMap.put("interestsId", interestsId);
        paramterMap.put("acquirerType", acquirerType);
        paramterMap.put("acquirerId", acquirerId);
        paramterMap.put("acquirerName", acquirerName);
        return interestsAcquirerRelDao.findInterestsAcquirerRel(interestsId, acquirerType, acquirerId, acquirerName);
    }

    @Override
    public Map<String, Object> pageQuery(String acquirerType, String keywords, String acquirerAbility,
            Integer interestsId, Integer pageIndex, Integer pageSize) throws AppBizException {
        Map<String, Object> paramterMap = new HashMap<String, Object>();
        paramterMap.put("interestsId", interestsId);
        paramterMap.put("acquirerType", acquirerType);
        paramterMap.put("keywords", keywords);
        paramterMap.put("acquirerAbility", acquirerAbility);
        return interestsAcquirerRelDao.pageQuery(paramterMap, pageIndex, pageSize);
    }

    @Override
    public List<InterestsAcquirerRelation> findInterestsAcquirerRelsByInterestsId(Integer interestsId)
            throws AppBizException {
        List<InterestsAcquirerRelationPo> pos = interestsAcquirerRelDao.findInterestsAcquirerByInterestsId(interestsId);
        InterestsAcquirerRelationPersistenceAdapter adapter = new InterestsAcquirerRelationPersistenceAdapter();
        List<InterestsAcquirerRelation> dtos = new ArrayList<InterestsAcquirerRelation>();
        for (InterestsAcquirerRelationPo po : pos) {
            InterestsAcquirerRelation dto = new InterestsAcquirerRelation();
            adapter.outbound(po, dto);
            dtos.add(dto);
        }
        return dtos;
    }

    @Override
    public void deleteById(Integer id) throws AppBizException {
        interestsAcquirerRelDao.delete(id);
    }
}
