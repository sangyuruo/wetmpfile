package com.bill99.ebd.rip.persistence;

import java.util.List;

import com.bill99.ebd.rip.domain.model.FundStakeholder;
import com.bill99.ebd.rip.exception.AppBizException;

public interface FundStakeholderPersistenceManager {

    /**
     * @return
     * @throws AppBizException
     */
    public List<FundStakeholder> getFundStakeholderList(String externalFund) throws AppBizException;

    public FundStakeholder getFundStakeholderByMembercode(String membercode) throws AppBizException;
}
