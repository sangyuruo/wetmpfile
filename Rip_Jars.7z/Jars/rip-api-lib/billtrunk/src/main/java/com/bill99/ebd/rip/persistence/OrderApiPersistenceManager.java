package com.bill99.ebd.rip.persistence;

import java.util.Date;

import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.model.OrderAPIPageInfo;
import com.bill99.ebd.rip.persistence.model.OrderApiPo;

/**
 * 
 * @author haipeng.cheng
 * @since 2016年9月30日 上午10:45:32
 * @project rip-api-lib
 */
public interface OrderApiPersistenceManager {

    void createOrderApi(OrderApiPo orderApiPo) throws AppBizException;

    /**
     * 删除当前日期之前 参数：day天前的数据
     * 
     * @param Map
     *            {"day":15}
     * @throws AppBizException
     */
    void delOrderApi(Date day, Integer maxId, Integer minId) throws AppBizException;

    /**
     * 查询 当前日期之前 参数：day天前的数据总数，最大id，最小id
     * 
     * @param day
     * @param limit
     * @return
     * @throws AppBizException
     */
    OrderAPIPageInfo queryOrderAPIPageInfo(Date day, Integer limit) throws AppBizException;

    void updateOrderApi(OrderApiPo newPo, OrderApiPo oldPo) throws AppBizException;

}
