/**
 * 
 */
package com.bill99.ebd.rip.persistence;

import com.bill99.ebd.rip.domain.model.FundInterests;
import com.bill99.ebd.rip.exception.AppBizException;

/**
 * 
 * @author wei.wang.rd
 * @since Nov 03, 2016
 */
public interface FundInterestsPersistenceManager {

    /**
     * 根据权益id,受理方会员编号,从数据库构造资金模式的权益领域对象
     * 
     * @param interestsId
     *            权益Id
     * @param acquirerId
     *            受理方会员编号
     * @return 资金模式的权益领域模型
     * */
    FundInterests getFundInterests(Integer interestsId, String acquirerId) throws AppBizException;

}
