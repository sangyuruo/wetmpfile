package com.bill99.ebd.rip.persistence.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.domain.model.InterestsRiskWfDetail;
import com.bill99.ebd.rip.domain.model.InterestsRule;
import com.bill99.ebd.rip.enums.PeriodLimitType;
import com.bill99.ebd.rip.enums.TrueFalse;
import com.bill99.ebd.rip.enums.UserIdentifier;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.exception.ConcurrentException;
import com.bill99.ebd.rip.persistence.InterestsPersistenceManager;
import com.bill99.ebd.rip.persistence.InterestsRiskWfDetailPersistenceManager;
import com.bill99.ebd.rip.persistence.adapter.InterestsRiskWfDetailPersistenceAdapter;
import com.bill99.ebd.rip.persistence.dao.InterestsRiskWfDetailDao;
import com.bill99.ebd.rip.persistence.model.InterestsRiskWfDetailPo;
import com.bill99.ebd.rip.util.ApiUtils;
import com.bill99.ebd.rip.util.DateUtils;
import com.bill99.ebd.rip.util.RipTask;
import com.bill99.ebd.rip.util.ThreadLocalCacheHelper;
import com.bill99.ebd.rip.util.TransactionHelper;

public class InterestsRiskWfDetailPersistenceManagerImpl implements InterestsRiskWfDetailPersistenceManager {

    private static final Logger log = LoggerFactory.getLogger(InterestsRiskWfDetailPersistenceManagerImpl.class);
    
    private static final int QUERY_BATCH_SIZE = 1000;

    @Autowired
    private InterestsRiskWfDetailDao interestsRiskWfDetailDao;
    @Autowired
    private InterestsPersistenceManager interestsPersistenceManager;
    @Autowired
    private TransactionHelper transactionHelper;
    private InterestsRiskWfDetailPersistenceAdapter interestsRiskWfDetailPersistenceAdapter = new InterestsRiskWfDetailPersistenceAdapter();
    private Map<Integer, InterestsRule> cachedInterestsRule = new HashMap<Integer, InterestsRule>();

    private int retryTime = 3;

    @Override
    public List<InterestsRiskWfDetail> findRiskWfDetail(Integer interestsId, Map<UserIdentifier, String> identifierMap)
            throws AppBizException {
        List<InterestsRiskWfDetailPo> poList = interestsRiskWfDetailDao.findRiskWfDetail(interestsId, identifierMap);
        if (poList == null) {
            return null;
        }

        List<InterestsRiskWfDetail> restList = new ArrayList<InterestsRiskWfDetail>();
        for (InterestsRiskWfDetailPo po : poList) {
            InterestsRiskWfDetail d = new InterestsRiskWfDetail();
            interestsRiskWfDetailPersistenceAdapter.outbound(po, d);
            restList.add(d);
        }
        return restList;
    }

    @Override
    public void addRiskWfDetail(InterestsRiskWfDetail interestsRiskWfDetail) throws AppBizException {
        InterestsRiskWfDetailPo interestsRiskWfDetailPo = new InterestsRiskWfDetailPo();
        interestsRiskWfDetailPersistenceAdapter.inbound(interestsRiskWfDetail, interestsRiskWfDetailPo);
        this.interestsRiskWfDetailDao.addRiskWfDetail(interestsRiskWfDetailPo);

    }

    @Override
    public void updateRiskWfDetail(InterestsRiskWfDetail interestsRiskWfDetail, InterestsRiskWfDetailPo copy)
            throws AppBizException {
        InterestsRiskWfDetailPo interestsRiskWfDetailPo = new InterestsRiskWfDetailPo();
        interestsRiskWfDetailPersistenceAdapter.inbound(interestsRiskWfDetail, interestsRiskWfDetailPo);
        this.interestsRiskWfDetailDao.updateRiskWfDetail(interestsRiskWfDetailPo, copy.getUpdateDate());
    }

    @Override
    public void addOrUpdteRiskWfDetails(List<InterestsRiskWfDetail> riskDetailWfList) throws AppBizException {
        List<InterestsRiskWfDetailPo> pos = new ArrayList<InterestsRiskWfDetailPo>();
        for (InterestsRiskWfDetail riskWfDetail : riskDetailWfList) {
            InterestsRiskWfDetailPo interestsRiskWfDetailPo = new InterestsRiskWfDetailPo();
            interestsRiskWfDetailPersistenceAdapter.inbound(riskWfDetail, interestsRiskWfDetailPo);
            pos.add(interestsRiskWfDetailPo);
        }
        List<InterestsRiskWfDetailPo> copies = ThreadLocalCacheHelper.getPos(pos);
        Map<Integer, InterestsRiskWfDetailPo> copiesMap = new HashMap<Integer, InterestsRiskWfDetailPo>();
        convertListToMap(copies, copiesMap);
        for (InterestsRiskWfDetailPo po : pos) {
            if (po.getIdInterestsRiskWfDetail() == null) {
                this.interestsRiskWfDetailDao.addRiskWfDetail(po);
            } else {
                if (!ApiUtils.equals(po, copiesMap.get(po.getIdInterestsRiskWfDetail()))) {
                    this.interestsRiskWfDetailDao.updateRiskWfDetail(po, copiesMap.get(po.getIdInterestsRiskWfDetail())
                            .getUpdateDate());
                }
            }
        }
    }

    private void convertListToMap(List<InterestsRiskWfDetailPo> poList, Map<Integer, InterestsRiskWfDetailPo> poMap) {
        if (poList == null || poList.isEmpty()) {
            return;
        }
        for (InterestsRiskWfDetailPo po : poList) {
            poMap.put(po.getIdInterestsRiskWfDetail(), po);
        }
    }

    @Override
    public void checkInterestsRiskWriteoffPeriod() throws AppBizException {
        Integer maxId = 0;
        do {
            List<InterestsRiskWfDetailPo> list = interestsRiskWfDetailDao.findRiskWfDetailByStatus(DateUtils.getDayOfToday(),QUERY_BATCH_SIZE, maxId);
            if (CollectionUtils.isEmpty(list)) {
                break;
            }
            maxId = list.get(list.size() - 1).getIdInterestsRiskWfDetail();
            try {
                for (InterestsRiskWfDetailPo po: list) {
                    checkAndProcessRiskDetail(po);
                }
            } catch (AppBizException e) {
                log.error("@@errors occurred when execute [InterestsRiskPeriodUpdateJob],errorCode=" + e.getErrorCode()
                        + ",errorMessage=" + e.getErrorMessage(), e);
            } catch (Exception e) {
                log.error("@@errors occurred when execute [InterestsRiskPeriodUpdateJob],message=" + e.getMessage(), e);
            }
        } while (true);
        
    }

    /**
     * 对每一个风控数据进行验证并更新
     * 
     * @param interestsRuleMapCache
     *            权益规则缓存
     * @param ird
     *            风控数据
     * @throws AppBizException
     */
    public void checkAndProcessRiskDetail( InterestsRiskWfDetailPo ird)
            throws AppBizException {
        
        if (checkIsUpdateAndSetStatus(ird)) {
            try {
                doUpdateWithRetryPolice(ird);
            } catch (AppBizException ae) {
                log.error("@@ConcurrentException InterestsRiskDetail status job ,retry {},error:{},IdInterestsRiskWfDetail:{}", retryTime, ae,ird.getIdInterestsRiskWfDetail());
            }
        }
    }

    private void doUpdateWithRetryPolice(InterestsRiskWfDetailPo ird) throws AppBizException {
        for (int i = 1; i <= retryTime ;) {
            try {
                ird.setStatus(TrueFalse.FALSE.getId());
                updateRiskDetailBatch(ird);
                break;
            } catch (ConcurrentException ce) {
                i++;
                log.error("@@ConcurrentException InterestsRiskDetail status job ,next retry {}", i);
                if (i <= retryTime) {
                    ird = interestsRiskWfDetailDao.getRiskDetailWFById(ird.getIdInterestsRiskWfDetail());
                } else {
                    throw ce;
                }
            }
        }
    }
    
    public void updateRiskDetailBatch(final InterestsRiskWfDetailPo riskDetail) throws AppBizException {
        transactionHelper.execute(new RipTask<Void>() {
            @Override
            public Void run() throws AppBizException {
                Date expectedUpdateDate = riskDetail.getUpdateDate();
                riskDetail.setUpdateDate(new Date());
                interestsRiskWfDetailDao.updateRiskWfDetail(riskDetail, expectedUpdateDate);
                return null;
            }
        });
    }
    
    public boolean checkIsUpdateAndSetStatus(InterestsRiskWfDetailPo detail) throws AppBizException {

        Integer interestsId = detail.getInterestsId();
        InterestsRule interestsRule = getCachedInterestsRule(interestsId);
        if (StringUtils.equals(PeriodLimitType.DAY.getId(), interestsRule.getWfPeriodLimitType().getId())) {
            // 0点执行任务，立刻置为失效
            detail.setStatus(TrueFalse.FALSE.getId());
            return true;
        }
        if (StringUtils.equals(PeriodLimitType.WEEK.getId(), interestsRule.getWfPeriodLimitType().getId())) {
            // 如果当天是周一，置为失效
            Calendar today = Calendar.getInstance(Locale.CHINA);
            // today.setFirstDayOfWeek(Calendar.MONDAY);
            int dayOfWeek = today.get(Calendar.DAY_OF_WEEK);// 获取时间
            boolean isTodayIsMonday = (dayOfWeek == Calendar.MONDAY);

            if (isTodayIsMonday) {
                detail.setStatus(TrueFalse.FALSE.getId());
                return true;
            }
        }
        if (StringUtils.equals(PeriodLimitType.MONTH.getId(), interestsRule.getWfPeriodLimitType().getId())) {
            // 如果当天是1号，置为失效
            Calendar today = Calendar.getInstance(Locale.CHINA);
            int dayOfMonth = today.get(Calendar.DAY_OF_MONTH);// 获取时间
            boolean isTheFirstDayOfMonth = (dayOfMonth == 1);
            if (isTheFirstDayOfMonth) {
                detail.setStatus(TrueFalse.FALSE.getId());
                return true;
            }
        }

        return false;
    }

    /**
     * 根据权益ID获取权益规则（先从内存缓存中获取，再从数据库中获取）
     * 
     * @param interestsId
     * @return
     * @throws AppBizException
     * @author jakoes.wu
     * @updatedate 2015年11月2日下午5:21:43
     */
    private InterestsRule getCachedInterestsRule(Integer interestsId) throws AppBizException {
        if (cachedInterestsRule.containsKey(interestsId)) {
            return cachedInterestsRule.get(interestsId);
        }

        InterestsRule interestsRule = interestsPersistenceManager.findInterestsRule(interestsId);
        cachedInterestsRule.put(interestsId, interestsRule);
        return interestsRule;
    }

    public void setRetryTime(int retryTime) {
        this.retryTime = retryTime;
    }
    
}
