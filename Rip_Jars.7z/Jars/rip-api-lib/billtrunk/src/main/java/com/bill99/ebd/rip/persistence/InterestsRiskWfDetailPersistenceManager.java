/**
 * 
 */
package com.bill99.ebd.rip.persistence;

import java.util.List;
import java.util.Map;

import com.bill99.ebd.rip.domain.model.InterestsRiskWfDetail;
import com.bill99.ebd.rip.enums.UserIdentifier;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.model.InterestsRiskWfDetailPo;

/**
 * @author shuangye.liu
 * 
 * @since Jun 13, 2016
 */
public interface InterestsRiskWfDetailPersistenceManager {

    /**
     * 
     * @param interestsId
     * @param types
     * @param values
     * @return
     * @throws AppBizException
     */
    List<InterestsRiskWfDetail> findRiskWfDetail(Integer interestsId, Map<UserIdentifier, String> identifierMap)
            throws AppBizException;

    void addRiskWfDetail(InterestsRiskWfDetail interestsRiskDetail) throws AppBizException;

    void updateRiskWfDetail(InterestsRiskWfDetail interestsRiskWfDetail, InterestsRiskWfDetailPo copy)
            throws AppBizException;

    void addOrUpdteRiskWfDetails(List<InterestsRiskWfDetail> riskWfDetailList) throws AppBizException;

    /**
     * 检查及更新核销记录当期状态
     * 
     * @throws AppBizException
     * @author jakoes.wu
     * @updatedate 2016年8月5日下午3:38:10
     */
    void checkInterestsRiskWriteoffPeriod() throws AppBizException;
}
