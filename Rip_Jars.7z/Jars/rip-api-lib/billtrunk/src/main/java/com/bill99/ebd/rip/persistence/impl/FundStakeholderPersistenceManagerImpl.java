package com.bill99.ebd.rip.persistence.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.domain.model.FundStakeholder;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.FundStakeholderPersistenceManager;
import com.bill99.ebd.rip.persistence.adapter.FundStakeholderPersistenceAdapter;
import com.bill99.ebd.rip.persistence.dao.FundStakeholderDao;
import com.bill99.ebd.rip.persistence.model.FundStakeholderPo;

public class FundStakeholderPersistenceManagerImpl implements FundStakeholderPersistenceManager {

    @Autowired
    FundStakeholderDao fundStakeholderDao;

    private FundStakeholderPersistenceAdapter adapter = new FundStakeholderPersistenceAdapter();

    @Override
    public List<FundStakeholder> getFundStakeholderList(String externalFund) throws AppBizException {
        List<FundStakeholder> dtoList = null;
        List<FundStakeholderPo> poList = fundStakeholderDao.getFundStakeholderList(externalFund);
        if (null != poList && poList.size() > 0) {
            dtoList = new ArrayList<FundStakeholder>();
            for (FundStakeholderPo fundStakeholderPo : poList) {
                FundStakeholder fundStakeholder = new FundStakeholder();
                adapter.outbound(fundStakeholderPo, fundStakeholder);
                dtoList.add(fundStakeholder);
            }
        }
        return dtoList;
    }

    @Override
    public FundStakeholder getFundStakeholderByMembercode(String membercode) throws AppBizException {
        FundStakeholderPo fundStakeholderPo = this.fundStakeholderDao.getFundStakeholderByMembercode(membercode);
        if (null != fundStakeholderPo) {
            FundStakeholder fundStakeholder = new FundStakeholder();
            adapter.outbound(fundStakeholderPo, fundStakeholder);
            return fundStakeholder;
        }
        return null;
    }

}
