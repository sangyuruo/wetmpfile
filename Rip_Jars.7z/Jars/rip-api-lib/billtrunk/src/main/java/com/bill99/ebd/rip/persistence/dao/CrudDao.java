/**
 * 
 */
package com.bill99.ebd.rip.persistence.dao;

import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.model.PersistenceObject;

/**
 * @author shuangye.liu
 *
 * @since Jul 18, 2016
 */
public interface CrudDao<T extends PersistenceObject> {

    void create(T po) throws AppBizException;

    void update(T newPo, T oldPo) throws AppBizException;

    void delete(Integer id) throws AppBizException;

}
