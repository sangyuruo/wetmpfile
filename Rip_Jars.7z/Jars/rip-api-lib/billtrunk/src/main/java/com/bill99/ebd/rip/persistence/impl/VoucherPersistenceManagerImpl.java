package com.bill99.ebd.rip.persistence.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.domain.model.ConsumerVoucherDto;
import com.bill99.ebd.rip.domain.model.ExtInterestsInit;
import com.bill99.ebd.rip.domain.model.ExtVoucherResultDto;
import com.bill99.ebd.rip.domain.model.Voucher;
import com.bill99.ebd.rip.domain.model.VoucherTransaction;
import com.bill99.ebd.rip.enums.AcquirerAbility;
import com.bill99.ebd.rip.enums.AwareType;
import com.bill99.ebd.rip.enums.ExtInterestsInitStatus;
import com.bill99.ebd.rip.enums.HoldScene;
import com.bill99.ebd.rip.enums.InterestsGenerateType;
import com.bill99.ebd.rip.enums.TrueFalse;
import com.bill99.ebd.rip.enums.TxnType;
import com.bill99.ebd.rip.enums.VoucherStatus;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.VoucherPersistenceManager;
import com.bill99.ebd.rip.persistence.adapter.ExtInterestsInitPersistenceAdapter;
import com.bill99.ebd.rip.persistence.adapter.ExtVoucherModelAdapter;
import com.bill99.ebd.rip.persistence.adapter.VoucherModelAdapter;
import com.bill99.ebd.rip.persistence.adapter.VoucherRepositoryPersistenceAdapter;
import com.bill99.ebd.rip.persistence.adapter.VoucherTransactionPersistenceAdapter;
import com.bill99.ebd.rip.persistence.dao.ExtInterestsInitDao;
import com.bill99.ebd.rip.persistence.dao.PersistenceUpdateHelper;
import com.bill99.ebd.rip.persistence.dao.VoucherRepositoryDao;
import com.bill99.ebd.rip.persistence.dao.VoucherTransactionDao;
import com.bill99.ebd.rip.persistence.model.ExtInterestsInitPo;
import com.bill99.ebd.rip.persistence.model.VoucherRepositoryPo;
import com.bill99.ebd.rip.persistence.model.VoucherTransactionPo;
import com.bill99.ebd.rip.util.ApiUtils;
import com.bill99.ebd.rip.util.ThreadLocalCacheHelper;

public class VoucherPersistenceManagerImpl implements VoucherPersistenceManager {

    private final ExtInterestsInitPersistenceAdapter extInterestsInitPersistenceAdapter = new ExtInterestsInitPersistenceAdapter();

    private ExtInterestsInitDao extInterestsInitDao;

    private VoucherRepositoryDao voucherRepositoryDao;

    private VoucherTransactionDao voucherTransactionDao;

    private VoucherRepositoryPo addVoucherPo(Voucher voucher) throws AppBizException {
        VoucherRepositoryPersistenceAdapter adapter = new VoucherRepositoryPersistenceAdapter();
        VoucherRepositoryPo voucherRepositoryPo = new VoucherRepositoryPo();
        adapter.inbound(voucher, voucherRepositoryPo);
        this.voucherRepositoryDao.create(voucherRepositoryPo);
        return voucherRepositoryPo;
    }

    @Override
    public Boolean checkVoucherNo(String voucherNo) throws AppBizException {
        return this.voucherRepositoryDao.checkVoucherNo(voucherNo);
    }

    @Override
    public Integer countTimes(Integer interestsId, String consumerMemberCode) throws AppBizException {
        return this.voucherRepositoryDao.findHoldCount(interestsId, consumerMemberCode);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bill99.ebd.rip.persistence.VoucherPersistenceManager#countTimes(java.util.List, java.lang.String)
     */
    @Override
    public Map<Integer, Integer> countTimes(List<Integer> interestsIds, String customerMemberCode)
            throws AppBizException {
        return this.voucherRepositoryDao.findHoldCounts(interestsIds, customerMemberCode);
    }

    @Override
    public void createVoucher(Voucher voucher) throws AppBizException {
        VoucherRepositoryPo voucherRepositoryPo = this.addVoucherPo(voucher);
        this.updateExtInterestsInitPo(voucherRepositoryPo, voucher.getExtInterestsInit());
        this.updateVoucherTransactionsPo(voucherRepositoryPo, voucher.getVoucherTransactions());
    }

    @Override
    public void createVouchers(List<Voucher> vouchers) throws AppBizException {
        VoucherRepositoryPersistenceAdapter adapter = new VoucherRepositoryPersistenceAdapter();
        VoucherTransactionPersistenceAdapter voucherTransactionAdapter = new VoucherTransactionPersistenceAdapter();
        List<VoucherRepositoryPo> pos = new ArrayList<>();
        List<VoucherTransactionPo> voucherTransactionPos = new ArrayList<>();
        for (Voucher voucher : vouchers) {
            VoucherRepositoryPo po = new VoucherRepositoryPo();
            adapter.inbound(voucher, po);
            pos.add(po);

            List<VoucherTransaction> voucherTransactions = voucher.getVoucherTransactions();
            for (VoucherTransaction voucherTransaction : voucherTransactions) {
                VoucherTransactionPo voucherTransactionPo = new VoucherTransactionPo();
                voucherTransactionAdapter.inbound(voucherTransaction, voucherTransactionPo);
                voucherTransactionPos.add(voucherTransactionPo);
            }

        }

        this.voucherRepositoryDao.batchCreate(pos);

        this.voucherTransactionDao.batchCreate(voucherTransactionPos);
    }

    @Override
    public List<Voucher> findConsumerAllVouchers(String consumerMemberCode) throws AppBizException {
        VoucherRepositoryPersistenceAdapter voucherRepositoryPersistenceAdapter = new VoucherRepositoryPersistenceAdapter();
        List<Voucher> allConsumerVouchers = new ArrayList<Voucher>();
        List<VoucherRepositoryPo> allVouchers = this.voucherRepositoryDao.findConsumerAllVouchers(consumerMemberCode);
        if (CollectionUtils.isNotEmpty(allVouchers)) {
            for (VoucherRepositoryPo voucherRepositoryPo : allVouchers) {
                Voucher voucher = new Voucher();
                voucherRepositoryPersistenceAdapter.outbound(voucherRepositoryPo, voucher);
                allConsumerVouchers.add(voucher);
            }
        }
        return allConsumerVouchers;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bill99.ebd.rip.persistence.VoucherPersistenceManager#findConsumerVouchers(java.lang.String,
     * java.lang.String, com.bill99.ebd.rip.enums.VoucherStatus, com.bill99.ebd.rip.enums.InterestsGenerateType)
     */
    @Override
    public List<ConsumerVoucherDto> findConsumerVouchers(String consumerMemberCode, String merchantMemberCode,
            VoucherStatus status, InterestsGenerateType generateType) throws AppBizException {
        return this.voucherRepositoryDao.findConsumerVouchers(consumerMemberCode, merchantMemberCode, status.name(),
                generateType.name());
    }

    @Override
    public List<ExtVoucherResultDto> findExtVouchers(String consumerMembercode, String extInterestsCode)
            throws AppBizException {
        List<Map<String, Object>> list = this.voucherRepositoryDao.findExtVoucher(consumerMembercode, extInterestsCode);

        if (org.springframework.util.CollectionUtils.isEmpty(list)) {
            return Collections.emptyList();
        }

        List<ExtVoucherResultDto> extVoucherResultDtoList = new ArrayList<ExtVoucherResultDto>();
        for (Map<String, Object> extVoucherObjectsMap : list) {
            if (CollectionUtils.sizeIsEmpty(extVoucherObjectsMap)) {
                continue;
            }
            ExtVoucherModelAdapter adapter = new ExtVoucherModelAdapter();
            ExtVoucherResultDto extVoucherResultDto = adapter.outboundVoucher(extVoucherObjectsMap);
            extVoucherResultDtoList.add(extVoucherResultDto);
        }
        return extVoucherResultDtoList;
    }

    @Override
    public Voucher findInnerVoucherByTransaction(String orderNo, String channel, TxnType transactionType,
            AwareType awareType, HoldScene holdScene) throws AppBizException {
        String awareTypeString = null;
        String holdSceneString = null;
        if (awareType != null) {
            awareTypeString = awareType.getId();
        }
        if (holdScene != null) {
            holdSceneString = holdScene.getIdentity();
        }

        List<Map<String, Object>> list = this.voucherRepositoryDao.findVoucherByTransaction(orderNo, channel,
                transactionType.name(), awareTypeString, holdSceneString, InterestsGenerateType.INNER.name(),
                AcquirerAbility.WRITEOFF.getIdentity());
        if (CollectionUtils.isEmpty(list)) {
            return null;
        }
        Map<String, Object> voucherObjectsMap = list.get(0);
        if (CollectionUtils.sizeIsEmpty(voucherObjectsMap)) {
            return null;
        }
        String voucherNo = (String) voucherObjectsMap.get("voucherNo");
        List<VoucherTransactionPo> voucherTransactionPos = this.voucherTransactionDao
                .findVoucherTransactions(voucherNo);
        VoucherModelAdapter adapter = new VoucherModelAdapter();
        return adapter.outboundVoucher(voucherObjectsMap, voucherTransactionPos);
    }

    @Override
    public ExtInterestsInit findOneExtInterestsInit(Integer interestsId, ExtInterestsInitStatus status)
            throws AppBizException {
        ExtInterestsInitPo p = this.extInterestsInitDao.getFirstValidByInterstsId(interestsId);
        if (null == p) {
            return null;
        }
        ExtInterestsInit d = new ExtInterestsInit();
        this.extInterestsInitPersistenceAdapter.outbound(p, d);
        return d;
    }

    @Override
    public VoucherTransaction findTransaction(String orderNo, String channel, TxnType transactionType,
            TrueFalse isCanceled, AwareType awareType) throws AppBizException {
        String awareTypeString = null;
        if (awareType != null) {
            awareTypeString = awareType.getId();
        }
        VoucherTransactionPo voucherTransactionPo = this.voucherTransactionDao.findVoucherTransaction(orderNo, channel,
                transactionType.name(), isCanceled.getId(), awareTypeString);
        if (voucherTransactionPo == null) {
            return null;
        }
        VoucherTransactionPersistenceAdapter adapter = new VoucherTransactionPersistenceAdapter();
        VoucherTransaction voucherTransaction = new VoucherTransaction();
        adapter.outbound(voucherTransactionPo, voucherTransaction);
        return voucherTransaction;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bill99.ebd.rip.persistence.VoucherPersistenceManager#findVoucherNo(java.lang.String)
     */
    @Override
    public Voucher findVoucher(String voucherNo) throws AppBizException {
        Map<String, Object> voucherObjectsMap = this.voucherRepositoryDao.findVoucher(voucherNo,
                AcquirerAbility.WRITEOFF.getIdentity());
        if (CollectionUtils.sizeIsEmpty(voucherObjectsMap)) {
            return null;
        }
        List<VoucherTransactionPo> voucherTransactionPos = this.voucherTransactionDao
                .findVoucherTransactions(voucherNo);
        VoucherModelAdapter adapter = new VoucherModelAdapter();
        return adapter.outboundVoucher(voucherObjectsMap, voucherTransactionPos);
    }

    @Override
    public List<Voucher> findVoucherByTransaction(String orderNo, String channel, TxnType transactionType,
            AwareType awareType, HoldScene holdScene, String acquirerAbility) throws AppBizException {
        String awareTypeString = null;
        String holdSceneString = null;
        if (awareType != null) {
            awareTypeString = awareType.getId();
        }
        if (holdScene != null) {
            holdSceneString = holdScene.getIdentity();
        }

        List<Map<String, Object>> list = this.voucherRepositoryDao.findVoucherByTransaction(orderNo, channel,
                transactionType.name(), awareTypeString, holdSceneString, null, acquirerAbility);
        if (org.springframework.util.CollectionUtils.isEmpty(list)) {
            return Collections.emptyList();
        }

        List<Voucher> voucherList = new ArrayList<Voucher>();
        for (Map<String, Object> voucherObjectsMap : list) {
            if (CollectionUtils.sizeIsEmpty(voucherObjectsMap)) {
                continue;
            }
            String voucherNo = (String) voucherObjectsMap.get("voucherNo");
            List<VoucherTransactionPo> voucherTransactionPos = this.voucherTransactionDao
                    .findVoucherTransactions(voucherNo);
            VoucherModelAdapter adapter = new VoucherModelAdapter();
            voucherList.add(adapter.outboundVoucher(voucherObjectsMap, voucherTransactionPos));
        }
        return voucherList;
    }

    @Override
    public boolean hasBoundCard(String consumerMemberCode, Date firstBindCardStartDate, Date firstBindCardEndDate)
            throws AppBizException {
        return this.voucherRepositoryDao.hasBoundCard(consumerMemberCode, firstBindCardStartDate, firstBindCardEndDate);
    }

    @Autowired
    public void setExtInterestsInitDao(ExtInterestsInitDao extInterestsInitDao) {
        this.extInterestsInitDao = extInterestsInitDao;
    }

    @Autowired
    public void setVoucherRepositoryDao(VoucherRepositoryDao voucherRepositoryDao) {
        this.voucherRepositoryDao = voucherRepositoryDao;
    }

    @Autowired
    public void setVoucherTransactionDao(VoucherTransactionDao voucherTransactionDao) {
        this.voucherTransactionDao = voucherTransactionDao;
    }

    private void updateExtInterestsInitPo(VoucherRepositoryPo voucherRepositoryPo, ExtInterestsInit extInterestsInit)
            throws AppBizException {
        ExtInterestsInitPo po = null;
        if (extInterestsInit != null) {
            ExtInterestsInitPersistenceAdapter adapter = new ExtInterestsInitPersistenceAdapter();
            po = new ExtInterestsInitPo();
            adapter.inbound(extInterestsInit, po);
        }

        ExtInterestsInitPo copy = ThreadLocalCacheHelper.getRelatedPo(voucherRepositoryPo, ExtInterestsInitPo.class);

        PersistenceUpdateHelper.updatePo(po, copy, this.extInterestsInitDao);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bill99.ebd.rip.persistence.VoucherPersistenceManager#updateVoucher(com.bill99.ebd.rip.domain.model.Voucher)
     */
    @Override
    public void updateVoucher(Voucher voucher) throws AppBizException {
        VoucherRepositoryPo voucherRepositoryPo = this.updateVoucherRepositoryPo(voucher);
        this.updateExtInterestsInitPo(voucherRepositoryPo, voucher.getExtInterestsInit());
        this.updateVoucherTransactionsPo(voucherRepositoryPo, voucher.getVoucherTransactions());
    }

    private VoucherRepositoryPo updateVoucherRepositoryPo(Voucher voucher) throws AppBizException {
        VoucherRepositoryPersistenceAdapter adapter = new VoucherRepositoryPersistenceAdapter();
        VoucherRepositoryPo po = new VoucherRepositoryPo();
        adapter.inbound(voucher, po);

        VoucherRepositoryPo copy = ThreadLocalCacheHelper.getPo(po);

        if (!ApiUtils.equals(po, copy)) {
            this.voucherRepositoryDao.update(po, copy);
        }

        return po;
    }

    private void updateVoucherTransactionsPo(VoucherRepositoryPo voucherRepositoryPo,
            List<VoucherTransaction> voucherTransactions) throws AppBizException {
        List<VoucherTransactionPo> pos = new ArrayList<>();
        if (!CollectionUtils.sizeIsEmpty(voucherTransactions)) {
            VoucherTransactionPersistenceAdapter adapter = new VoucherTransactionPersistenceAdapter();
            for (VoucherTransaction voucherTransaction : voucherTransactions) {
                VoucherTransactionPo po = new VoucherTransactionPo();
                adapter.inbound(voucherTransaction, po);
                pos.add(po);
            }
        }

        List<VoucherTransactionPo> copies = ThreadLocalCacheHelper.getRelatedPos(voucherRepositoryPo,
                VoucherTransactionPo.class);

        PersistenceUpdateHelper.updatePos(pos, copies, this.voucherTransactionDao);
    }

}
