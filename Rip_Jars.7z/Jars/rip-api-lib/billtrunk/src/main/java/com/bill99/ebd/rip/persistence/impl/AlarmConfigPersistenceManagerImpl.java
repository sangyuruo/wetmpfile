package com.bill99.ebd.rip.persistence.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.domain.model.AlarmConfigDto;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.AlarmConfigPersistenceManager;
import com.bill99.ebd.rip.persistence.adapter.AlarmConfigPersistenceAdapter;
import com.bill99.ebd.rip.persistence.dao.AlarmConfigDao;
import com.bill99.ebd.rip.persistence.dao.page.PageInfo;
import com.bill99.ebd.rip.persistence.model.AlarmConfigPo;

/**
 * 权益活动预警
 * 
 * @author yangyang.yu
 * 
 * @since 2016-11-23
 */
public class AlarmConfigPersistenceManagerImpl implements AlarmConfigPersistenceManager {

	private AlarmConfigDao alarmConfigDaoIBatis;

	@Autowired
	public void setAlarmConfigDaoIBatis(AlarmConfigDao alarmConfigDaoIBatis) {
		this.alarmConfigDaoIBatis = alarmConfigDaoIBatis;
	}

	@Override
	public void createAlarmConfig(AlarmConfigDto alarm) throws AppBizException {
		AlarmConfigPersistenceAdapter adapter = new AlarmConfigPersistenceAdapter();
		AlarmConfigPo alarmConfigPo = new AlarmConfigPo();
		adapter.inbound(alarm, alarmConfigPo);
		// 如果没设定时间，初始化创建时间
		if (null == alarmConfigPo.getCreateTime()) {
			alarmConfigPo.setCreateTime(new Date());
		}
		alarmConfigDaoIBatis.create(alarmConfigPo);
	}

	@Override
	public void updateAlarmConfig(AlarmConfigDto alarm) throws AppBizException {
		AlarmConfigPersistenceAdapter adapter = new AlarmConfigPersistenceAdapter();
		AlarmConfigPo alarmConfigPo = new AlarmConfigPo();
		adapter.inbound(alarm, alarmConfigPo);
		// 如果没设定时间，初始化修改时间
		if (null == alarmConfigPo.getUpdateTime()) {
			alarmConfigPo.setUpdateTime(new Date());
		}
		alarmConfigDaoIBatis.update(alarmConfigPo, null);
	}
	
	@Override
	public void updateAlarmThresholdInfo(String bizId, String bizType, Integer notifyCount, String comFlag) throws AppBizException {
		AlarmConfigPo alarmConfigPo = new AlarmConfigPo();
		alarmConfigPo.setCommonFlag(Integer.parseInt(comFlag));
		alarmConfigPo.setBizId(bizId);
		alarmConfigPo.setBizType(bizType);
		alarmConfigPo.setNotifyCount(notifyCount); 
		// 如果没设定时间，初始化修改时间
		if (null == alarmConfigPo.getUpdateTime()) {
			alarmConfigPo.setUpdateTime(new Date());
		}
		alarmConfigDaoIBatis.updateAlarmThresholdInfo(alarmConfigPo, null);
	}
 
	@Override
	public AlarmConfigDto getAlarmConfigByBizId(String bizId, String bizType, String comFlag) throws AppBizException {
        Map<String, Object> paramterMap = new HashMap<String, Object>();
        paramterMap.put("commonFlag", comFlag);
	    paramterMap.put("bizId", bizId);
	    paramterMap.put("bizType", bizType);

		List<AlarmConfigPo> alarmConfigPoList = this.alarmConfigDaoIBatis.getAlarmConfigByBizId(paramterMap);
		AlarmConfigPersistenceAdapter adapter = new AlarmConfigPersistenceAdapter();
		AlarmConfigDto alarmConfigDto = null;
		if (alarmConfigPoList.size() > 0) {
		    alarmConfigDto = new AlarmConfigDto();
			adapter.outbound(alarmConfigPoList.get(0), alarmConfigDto);
		}
		return alarmConfigDto;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Map<String, Object> getAlarmConfigPages(Map<String, Object> paramterMap, Integer pageIndex, Integer pageSize)
			throws AppBizException {
		Map<String, Object> resultMap = new HashMap<String, Object>();//返回结果
		// 数据库查询结果
		Map<String, Object> queryResultMap = this.alarmConfigDaoIBatis.getAlarmConfigPages(paramterMap, pageIndex, pageSize);

		// PO ==> Dto
		AlarmConfigPersistenceAdapter adapter = new AlarmConfigPersistenceAdapter();
		List<AlarmConfigDto> listDto = new ArrayList<AlarmConfigDto>();;
		if (null != queryResultMap) {
			List<AlarmConfigPo> listPo = (List<AlarmConfigPo>) queryResultMap.get("list");
			PageInfo pageInfo = (PageInfo) queryResultMap.get("page");
			if (null != listPo && listPo.size() > 0) {
				for (AlarmConfigPo po : listPo) {
					AlarmConfigDto alarmConfigDto = new AlarmConfigDto();
					adapter.outbound(po, alarmConfigDto);
					listDto.add(alarmConfigDto);
				}
			}
			resultMap.put("list", listDto);
			resultMap.put("page", pageInfo);
		}
		return resultMap;
	}

	@Override
	public AlarmConfigDto getAlarmConfigBySeqId(Integer seqId) throws AppBizException {
        Map<String, Object> paramterMap = new HashMap<String, Object>();

        paramterMap.put("idAlarmCfg", seqId);
		AlarmConfigPo alarmConfigPo = this.alarmConfigDaoIBatis.getAlarmConfigBySeqId(paramterMap);
		AlarmConfigPersistenceAdapter adapter = new AlarmConfigPersistenceAdapter();
		AlarmConfigDto alarmConfigDto = null;
		// 对象转换
		if (null != alarmConfigPo) {
		    alarmConfigDto = new AlarmConfigDto();
			adapter.outbound(alarmConfigPo, alarmConfigDto);
		}
		return alarmConfigDto;
	}

}
