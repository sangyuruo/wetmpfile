package com.bill99.ebd.rip.persistence.impl;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.OrderApiPersistenceManager;
import com.bill99.ebd.rip.persistence.dao.OrderApiDao;
import com.bill99.ebd.rip.persistence.model.OrderAPIPageInfo;
import com.bill99.ebd.rip.persistence.model.OrderApiPo;

/**
 * 
 * @author haipeng.cheng
 * @since 2016年9月30日 上午10:44:55
 * @project rip-api-lib
 */
public class OrderApiPersistenceManagerImpl implements OrderApiPersistenceManager {

    @Autowired
    private OrderApiDao orderApiIbatisDao;

    @Override
    public void createOrderApi(OrderApiPo orderApiPo) throws AppBizException {
        this.orderApiIbatisDao.create(orderApiPo);
    }

    @Override
    public void delOrderApi(Date day, Integer maxId, Integer minId) throws AppBizException {
        this.orderApiIbatisDao.delOrderApi(day, maxId, minId);
    }

    @Override
    public OrderAPIPageInfo queryOrderAPIPageInfo(Date day, Integer limit) throws AppBizException {
        return this.orderApiIbatisDao.queryAllOrderApi(day, limit);
    }

    @Override
    public void updateOrderApi(OrderApiPo newPo, OrderApiPo oldPo) throws AppBizException {
        this.orderApiIbatisDao.update(newPo, oldPo);
    }

}
