package com.bill99.ebd.rip.persistence;

import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.common.RipCache;
import com.bill99.ebd.rip.domain.model.Interests;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.srv.balance.CacheKeyGenerator;
import com.bill99.ebd.rip.util.RestUtils;
import com.bill99.ebd.rip.util.RipTask;
import com.fasterxml.jackson.core.type.TypeReference;

public class InterestsRelResolver {

    private static final Logger logger = LoggerFactory.getLogger(InterestsRelResolver.class);

    private RipCache ripCache;

    /**
     * Get interests list from cache, if no exists, run task to get them. Then save them into cache, and return.
     * 
     * @param merchantMemberCode
     * @param ability
     * @param awareType
     * @param holdScene
     * @param task
     * @return
     * @throws AppBizException
     */
    public List<Interests> getInterestsFromCache(final String merchantMemberCode, final String ability,
            final String awareType, final String holdScene, final RipTask<List<Interests>> task) throws AppBizException {
        try {
            String interestsRedisKey = CacheKeyGenerator.genInterestsRedisKey(merchantMemberCode, ability, awareType,
                    holdScene);
            String interestsRedisLockKey = CacheKeyGenerator.genInterestsRedisLockKey(merchantMemberCode, ability,
                    awareType, holdScene);

            String interestsListString = this.ripCache.getValue(interestsRedisKey, interestsRedisLockKey,
                    new RipTask<String>() {
                        @Override
                        public String run() throws AppBizException {
                            List<Interests> interestsList = task.run();

                            if (CollectionUtils.isEmpty(interestsList)) {
                                return null;
                            }
                            return RestUtils.objectToJSONString(interestsList);
                        }
                    });
            if (StringUtils.isEmpty(interestsListString)) {
                return null;
            } else {
                return RestUtils.stringToObject(interestsListString, new TypeReference<List<Interests>>() {
                });
            }
        } catch (AppBizException e) {
            throw e;
        } catch (Exception e) {
            logger.warn("getInterestsFromCache error, ignore", e);
            return null;
        }
    }

    /**
     * @param ripCache
     *            the ripCache to set
     */
    @Autowired
    public void setRipCache(RipCache ripCache) {
        this.ripCache = ripCache;
    }

}
