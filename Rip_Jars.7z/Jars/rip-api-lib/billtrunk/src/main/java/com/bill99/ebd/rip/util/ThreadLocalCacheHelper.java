/**
 * 
 */
package com.bill99.ebd.rip.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import com.bill99.ebd.rip.persistence.model.InterestsRulePo;
import com.bill99.ebd.rip.persistence.model.PersistenceObject;

/**
 * @author shuangye.liu
 *
 * @since Jun 12, 2016
 */
public class ThreadLocalCacheHelper {

    private static final String KEY_SEPARATER = "@";

    /**
     * Initiation cache
     * 
     */
    public static void init() {
        ThreadLocalCache.init();
    }

    /**
     * Clean cache
     * 
     */
    public static void remove() {
        ThreadLocalCache.remove();
    }

    /**
     * Deep clone Persistence Object, and put the copy into cache.
     * 
     * @param id
     * @param po
     * @return the copy
     */
    public static <P extends PersistenceObject> P putPo(P po) {
        if (po == null) {
            return null;
        }
        String key = generateKey(po);
        P copy = Utils.deepClone(po);
        ThreadLocalCache.put(key, copy);
        return copy;
    }

    /**
     * Get the copy of Persistence Object from cache
     * 
     * @param id
     * @param poClass
     * @return copy
     */
    @SuppressWarnings("unchecked")
    public static <P extends PersistenceObject> P getPo(P po) {
        if (po == null) {
            return null;
        }
        String key = generateKey(po);
        return (P) ThreadLocalCache.get(key);
    }

    public static <P extends PersistenceObject> List<P> getPos(List<P> pos) {
        if (pos == null || pos.isEmpty()) {
            return null;
        }
        List<P> copies = new ArrayList<P>();
        for (P po : pos) {
            P copy = getPo(po);
            if (copy != null) {
                copies.add(copy);
            }
        }
        return copies;
    }

    /**
     * Generate cache Key for single Persistence Object
     * 
     * @param id
     * @param poClass
     * @return cache key
     */
    public static String generateKey(PersistenceObject po) {
        if (po == null) {
            return null;
        }
        return po.getClass().getCanonicalName() + KEY_SEPARATER + po.persistenceId();
    }

    public static <P extends PersistenceObject> String generateRelationKey(PersistenceObject parent,
            Class<P> childClass) {
        if (parent == null || childClass == null) {
            return null;
        }
        return generateKey(parent) + KEY_SEPARATER + childClass.getCanonicalName();
    }

    /**
     * 
     * @param parent
     * @param childCopy
     */
    public static void putPoRelation(PersistenceObject parent, PersistenceObject childCopy) {
        if (parent == null || childCopy == null) {
            return;
        }
        String key = generateRelationKey(parent, childCopy.getClass());
        ThreadLocalCache.put(key, childCopy);
    }

    @SuppressWarnings("unchecked")
    public static <P extends PersistenceObject> P getRelatedPo(PersistenceObject parent, Class<P> childClass) {
        if (parent == null || childClass == null) {
            return null;
        }
        String key = generateRelationKey(parent, childClass);
        return (P) ThreadLocalCache.get(key);
    }

    @SuppressWarnings("unchecked")
    public static <P extends PersistenceObject> List<P> getRelatedPos(PersistenceObject parent, Class<P> childClass) {
        if (parent == null || childClass == null) {
            return null;
        }
        String key = generateRelationKey(parent, childClass);
        return (List<P>) ThreadLocalCache.get(key);
    }

    public static <P extends PersistenceObject> void putPoRelations(PersistenceObject parent, List<P> childrenCopy) {
        if (parent == null || childrenCopy == null || childrenCopy.isEmpty()) {
            return;
        }
        String key = generateRelationKey(parent, childrenCopy.iterator().next().getClass());
        ThreadLocalCache.put(key, childrenCopy);
    }

    public static void main(String[] args) {
        ThreadLocalCacheHelper.init();

        InterestsRulePo po1 = new InterestsRulePo();
        po1.setRuleId(1);
        ThreadLocalCacheHelper.putPo(po1);

        InterestsRulePo po2 = new InterestsRulePo();
        po2.setRuleId(2);
        ThreadLocalCacheHelper.putPo(po2);

        List<InterestsRulePo> pos1 = Arrays.asList(po1, po2);

        List<InterestsRulePo> pos2 = ThreadLocalCacheHelper.getPos(pos1);

        System.out.println(ApiUtils.equals(pos1, pos2));

        ThreadLocalCacheHelper.remove();

        HashMap<String, String> map1 = new HashMap<String, String>();
        map1.put("1", "1");
        map1.put("2", "2");

        HashMap<String, String> map2 = new HashMap<String, String>();
        map2.put("2", "2");

        System.out.println(ApiUtils.equals(map1, map2));

    }

}
