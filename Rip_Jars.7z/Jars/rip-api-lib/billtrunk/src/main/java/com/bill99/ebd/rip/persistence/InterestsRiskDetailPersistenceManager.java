/**
 * 
 */
package com.bill99.ebd.rip.persistence;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.bill99.ebd.rip.domain.model.InterestsRiskDetail;
import com.bill99.ebd.rip.enums.UserIdentifier;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.model.InterestsRiskDetailPo;

/**
 * @author shuangye.liu
 *
 * @since Jun 13, 2016
 */
public interface InterestsRiskDetailPersistenceManager {

    void addOrUpdteRiskDetails(List<InterestsRiskDetail> riskDetailList) throws AppBizException;

    void addRiskDetail(InterestsRiskDetail interestsRiskDetail) throws AppBizException;

    /**
     * 
     * @param interestsId
     * @param types
     * @param values
     * @return
     * @throws AppBizException
     */
    List<InterestsRiskDetail> findRiskDetail(Integer interestsId, Map<UserIdentifier, String> identifierMap)
            throws AppBizException;

    List<InterestsRiskDetail> findRiskDetailByMemberCodes(Integer interestsId, List<String> memberCodes)
            throws AppBizException;

    void updateRiskDetail(InterestsRiskDetail interestsRiskDetail, InterestsRiskDetailPo copy) throws AppBizException;
    
    int updateInterestsRiskDetailStatus(InterestsRiskDetailPo interestsRiskDetailPo,Date expectedDate) throws AppBizException;
    
    List<InterestsRiskDetailPo> queryRiskDetailForUpdateStatus(Date nowDay,int size, Integer maxId) throws AppBizException;
    
    InterestsRiskDetailPo getRiskDetailById(Integer id) throws AppBizException ;
    
}
