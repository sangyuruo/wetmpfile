package com.bill99.ebd.rip.persistence;

import java.util.Date;
import java.util.List;

import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.model.VoucherBatchPo;
import com.bill99.ebd.rip.util.Page;

public interface VoucherBatchPersistenceManager {

    void createVoucherBatch(VoucherBatchPo voucherBatchPo) throws AppBizException;

    Page<VoucherBatchPo> find(Integer pageNumber, Integer pageSize) throws AppBizException;

    List<VoucherBatchPo> queryByStatusAndHoldTime(List<String> status, Date holdTime) throws AppBizException;

    void updateVoucherBatch(VoucherBatchPo voucherBatchPo) throws AppBizException;

    void deleteByBatchId(Integer batchId) throws AppBizException;
    
    void deleteByInterestsId(Integer interestsId) throws AppBizException;

    List<VoucherBatchPo> queryByInterestAndStatus(Integer interestsId, String status) throws AppBizException;

    VoucherBatchPo findById(Integer batchId) throws AppBizException;
    
}
