package com.bill99.ebd.rip.persistence.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.VoucherBatchDetailPersistenceManager;
import com.bill99.ebd.rip.persistence.dao.VoucherBatchDetailDao;
import com.bill99.ebd.rip.persistence.model.VoucherBatchDetailPo;
import com.bill99.ebd.rip.util.Page;

public class VoucherBatchDetailPersistenceManagerImpl implements VoucherBatchDetailPersistenceManager {

    private VoucherBatchDetailDao voucherBatchDetailDao;

    @Override
    public void createVoucherBatchDetail(VoucherBatchDetailPo voucherBatchDetail) throws AppBizException {
        this.voucherBatchDetailDao.create(voucherBatchDetail);
    }

    @Override
    public void createVoucherBatchDetails(List<VoucherBatchDetailPo> voucherBatchDetails) throws AppBizException {
        this.voucherBatchDetailDao.batchCreate(voucherBatchDetails);
    }

    @Override
    public void deleteByMemberIdAndInterestsId(Integer memberId, Integer interestsId) throws AppBizException {
        this.voucherBatchDetailDao.deleteByMemberAndInterests(memberId, interestsId);
    }

    @Override
    public Page<VoucherBatchDetailPo> find(Integer batchId, Integer pageNumber, Integer pageSize)
            throws AppBizException {
        Integer totalCount = this.voucherBatchDetailDao.count(batchId);
        if (totalCount == null || totalCount.intValue() == 0) {
            return null;
        }
        List<VoucherBatchDetailPo> datas = this.voucherBatchDetailDao.find(batchId, pageNumber, pageSize);
        return new Page<>(totalCount, pageNumber, pageSize, datas);
    }

    @Override
    public List<VoucherBatchDetailPo> findVoucherBatchDetails(Integer batchId, List<Integer> sequenceIds)
            throws AppBizException {
        return this.voucherBatchDetailDao.findVoucherBatchDetails(batchId, sequenceIds);
    }

    @Override
    public List<VoucherBatchDetailPo> queryByBatchNo(Integer batchNo) throws AppBizException {
        return this.voucherBatchDetailDao.selectByBatchNo(batchNo);
    }

    @Override
    public List<VoucherBatchDetailPo> selectVoucherBatchByBatchNo(Integer batchId, Integer first, Integer pageSize)
            throws AppBizException {
        return this.voucherBatchDetailDao.selectVoucherBatchByBatchNo(batchId, first, pageSize);
    }

    @Override
    public List<VoucherBatchDetailPo> queryByMemberIdAndInterests(Integer memberId, Integer interestsId)
            throws AppBizException {
        return this.voucherBatchDetailDao.selectByMemberIdAndInterestsId(memberId, interestsId);
    }

    @Autowired
    public void setVoucherBatchDetailDao(VoucherBatchDetailDao voucherBatchDetailDao) {
        this.voucherBatchDetailDao = voucherBatchDetailDao;
    }

    @Override
    public void updateByBatchNoAndCustomerMemberCode(Integer batchNo, Integer memberId, String voucherNo)
            throws AppBizException {
        this.voucherBatchDetailDao.updateByBatchNoAndMemberId(batchNo, memberId, voucherNo);
    }

    @Override
    public void updateVoucherBatchDetail(VoucherBatchDetailPo voucherBatchDetail) throws AppBizException {
        this.voucherBatchDetailDao.update(voucherBatchDetail, null);
    }

    @Override
    public void updateVoucherBatchDetails(List<VoucherBatchDetailPo> voucherBatchDetails) throws AppBizException {
        this.voucherBatchDetailDao.batchUpdate(voucherBatchDetails);
    }

    @Override
    public Integer countByVoucherBatchAndVoucherNo(Integer batchNo) throws AppBizException {
        return this.voucherBatchDetailDao.countByVoucherBatchAndVoucherNo(batchNo);
    }

    @Override
    public void deleteByBatchNo(Integer batchNo, Integer interestsId) throws AppBizException {
        this.voucherBatchDetailDao.deleteByBatchNo(batchNo, interestsId);
    }

    @Override
    public void deleteVoucherBatchDetailById(Integer id) throws AppBizException {
        this.voucherBatchDetailDao.delete(id);

    }

    @Override
    public List<VoucherBatchDetailPo> queryByCustomerMemberCodeAndInterests(String customerCode, Integer interestsId)
            throws AppBizException {
        return this.voucherBatchDetailDao.selectByConsumerCodeAndInterestsId(customerCode, interestsId);
    }

    @Override
    public Map<String, Object> pageQuery(Integer interestsId, String customerMemberCode, Integer pageIndex,
            Integer pageSize) throws AppBizException {
        Map<String, Object> paramterMap = new HashMap<String, Object>();
        paramterMap.put("interestsId", interestsId);
        paramterMap.put("customerMemberCode", customerMemberCode);
        paramterMap.put("pageNumber", pageIndex);
        paramterMap.put("pageSize", pageSize);
        return voucherBatchDetailDao.pageQuery(paramterMap, pageIndex, pageSize);
    }

    @Override
    public VoucherBatchDetailPo findById(Integer id) throws AppBizException {
        return voucherBatchDetailDao.findById(id);
    }
}
