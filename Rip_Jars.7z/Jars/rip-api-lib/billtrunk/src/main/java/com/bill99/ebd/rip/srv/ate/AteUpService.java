package com.bill99.ebd.rip.srv.ate;

import java.io.IOException;

import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.facade.inf.market.ate.ATENotifyResponse;
import com.bill99.ebd.rip.persistence.model.RequestJobPo;

/**
 * ATE统一支付服务接口（异步处理业务）
 * 
 * @author jakoes.wu
 * @date 2016年7月29日下午3:48:43
 * @project rip-api-lib-r20160726-MERGE
 * 
 */
public interface AteUpService {

    /**
     * 处理ATE通知请求
     * 
     * @param isDomainServiceEnabled
     * @author jakoes.wu
     * @updatedate 2016年7月29日下午4:55:53
     */
    public void processNotifyRequest(Boolean isDomainServiceEnabled) throws AppBizException;

    /**
     * 处理一条ATE通知请求
     * 
     * @param requestJob
     * @param response
     * @param isDomainServiceEnabled
     * @throws AppBizException
     * @throws IOException
     * @author jakoes.wu
     * @updatedate 2016年7月29日下午4:55:40
     */
    public void processNotifyRequestJob(RequestJobPo requestJob, ATENotifyResponse response,
            Boolean isDomainServiceEnabled) throws AppBizException, IOException;

    /**
     * 处理ATE核销撤销请求
     * 
     * @param isDomainServiceEnabled
     * @author jakoes.wu
     * @updatedate 2016年7月29日下午5:24:57
     */
    public void processCancelRequest(Boolean isDomainServiceEnabled) throws AppBizException;

    /**
     * 处理一条ATE核销撤销请求
     * 
     * @param
     * @param isDomainServiceEnabled
     * @throws AppBizException
     * @throws IOException
     * @author jakoes.wu
     * @updatedate 2016年7月29日下午5:26:22
     */
    public void processCancelRequestJob(RequestJobPo requestJob, Boolean isDomainServiceEnabled)
            throws AppBizException, IOException;
}
