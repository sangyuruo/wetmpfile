package com.bill99.ebd.rip.persistence;

import com.bill99.ebd.rip.domain.model.NotificationTemplate;
import com.bill99.ebd.rip.exception.AppBizException;

public interface NotificationTemplatePersistenceManager {
	
	/**
	 * 插入短信模板
	 * @param notificationTemplate
	 * @throws AppBizException
	 */
	public Integer insertNotify(NotificationTemplate notificationTemplate) throws AppBizException;
}
