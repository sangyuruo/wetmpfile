package com.bill99.ebd.rip.persistence.dao;

import java.util.Date;

import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.model.OrderAPIPageInfo;
import com.bill99.ebd.rip.persistence.model.OrderApiPo;

/**
 * 
 * @author haipeng.cheng
 * @since 2016年9月30日 上午10:45:04
 * @project rip-api-lib
 */
public interface OrderApiDao extends CrudDao<OrderApiPo> {

    /**
     * 删除当前日期 YYYYMMDD之前 参数：day天前的数据
     * 
     * @param Map
     *            {"day":15}
     * @throws AppBizException
     */
    void delOrderApi(Date day, Integer maxId, Integer minId) throws AppBizException;

    OrderAPIPageInfo queryAllOrderApi(Date day, Integer limit) throws AppBizException;

}
