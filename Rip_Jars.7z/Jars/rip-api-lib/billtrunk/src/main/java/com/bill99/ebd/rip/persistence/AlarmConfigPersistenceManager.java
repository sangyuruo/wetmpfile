package com.bill99.ebd.rip.persistence;

import java.util.Map;

import com.bill99.ebd.rip.domain.model.AlarmConfigDto;
import com.bill99.ebd.rip.exception.AppBizException;

/**
 * 权益活动预警
 * @author yangyang.yu
 *
 * @since  2016-11-23
 */
public interface AlarmConfigPersistenceManager {
	
    /**
     * 添加权益活动预警
     * @param alarm
     * @throws AppBizException
     */
    void createAlarmConfig(AlarmConfigDto alarm) throws AppBizException;

    /**
     * 修改权益活动预警
     * @param fundTxn
     * @throws AppBizException
     */
    void updateAlarmConfig(AlarmConfigDto alarm) throws AppBizException;

    /**
     * 根据权益id查询权益活动预警
     * @param bizId
     * @param bizType
     * @param comFlag 是否通用
     * @return
     * @throws AppBizException
     */
    AlarmConfigDto getAlarmConfigByBizId(String bizId, String bizType, String comFlag) throws AppBizException;

	/**
	 * 根据权益id,类型修改报警次数
	 * @param bizId
	 * @param bizType
	 * @param comFlag 是否通用
	 * @param notifyCount
	 * @throws AppBizException
	 */
	void updateAlarmThresholdInfo(String bizId, String bizType, Integer notifyCount, String comFlag) throws AppBizException;
	

    /**
     * 获取权益预警信息列表
     * @param paraMap
     * @param pageIndex
     * @param pageSize
     * @return
     * @throws AppBizException
     */
    Map<String, Object> getAlarmConfigPages(Map<String, Object> paraMap, Integer pageIndex, Integer pageSize) throws AppBizException;

    /**
     * 根据主键id获取预警信息
     * @param seqId
     * @return
     * @throws AppBizException
     */
    AlarmConfigDto getAlarmConfigBySeqId(Integer seqId) throws AppBizException;

}
