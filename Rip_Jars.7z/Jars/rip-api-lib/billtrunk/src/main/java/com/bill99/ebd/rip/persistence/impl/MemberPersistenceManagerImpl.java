package com.bill99.ebd.rip.persistence.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.MemberPersistenceManager;
import com.bill99.ebd.rip.persistence.dao.MemberDao;
import com.bill99.ebd.rip.persistence.model.MemberPo;

public class MemberPersistenceManagerImpl implements MemberPersistenceManager {

    private MemberDao memberDao;

    @Autowired
    public void setMemberDao(MemberDao memberDao) {
        this.memberDao = memberDao;
    }

    @Override
    public void createMember(MemberPo memberPo) throws AppBizException {
        memberDao.create(memberPo);
    }

    @Override
    public void updateMember(MemberPo memberPo) throws AppBizException {
        memberDao.update(memberPo, null);
    }

    @Override
    public List<MemberPo> findMember(String memberName, String memberCode) throws AppBizException {
        return memberDao.query(memberName, memberCode);
    }

    @Override
    public Map<String, Object> pageQuery(String keywords, Integer pageIndex, Integer pageSize) throws AppBizException {
        Map<String, Object> paramterMap = new HashMap<String, Object>();
        paramterMap.put("keywords", keywords);
        return memberDao.pageQuery(paramterMap, pageIndex, pageSize);
    }

    @Override
    public MemberPo findMemberById(Integer id) throws AppBizException {
        return memberDao.queryById(id);
    }

    @Override
    public MemberPo findMemberByMemberCode(String memberCode) throws AppBizException {
        return memberDao.queryByMemberCode(memberCode);
    }
}
