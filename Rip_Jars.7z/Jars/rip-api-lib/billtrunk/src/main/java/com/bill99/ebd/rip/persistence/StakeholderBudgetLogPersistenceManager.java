package com.bill99.ebd.rip.persistence;

import com.bill99.ebd.rip.domain.model.StakeholderBudgetLogDto;
import com.bill99.ebd.rip.exception.AppBizException;

/**
 * 垫资方活动预算变更记录
 * @author yangyang.yu
 *
 */
public interface StakeholderBudgetLogPersistenceManager {

	/**
	 * 垫资方活动预算变更记录
	 * @param stakeholderBudgetLogDto
	 * @throws AppBizException
	 */
	void insertStakeholderBudgetLog(StakeholderBudgetLogDto stakeholderBudgetLogDto) throws AppBizException;
}
