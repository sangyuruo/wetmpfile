package com.bill99.ebd.rip.srv.ate.impl;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.logging.log4j.ThreadContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.dal.model.RequestJob;
import com.bill99.ebd.rip.domain.InterestsDomainService;
import com.bill99.ebd.rip.domain.VoucherDomainService;
import com.bill99.ebd.rip.domain.model.HoldVoucherDto;
import com.bill99.ebd.rip.domain.model.HoldVoucherResultDto;
import com.bill99.ebd.rip.domain.model.Interests;
import com.bill99.ebd.rip.domain.model.IssueRefundDto;
import com.bill99.ebd.rip.domain.model.Voucher;
import com.bill99.ebd.rip.domain.model.VoucherTransaction;
import com.bill99.ebd.rip.enums.ATEType;
import com.bill99.ebd.rip.enums.AppExCodeEnum;
import com.bill99.ebd.rip.enums.AwareType;
import com.bill99.ebd.rip.enums.FOStatus;
import com.bill99.ebd.rip.enums.HoldScene;
import com.bill99.ebd.rip.enums.InterestsGenerateType;
import com.bill99.ebd.rip.enums.JobStatus;
import com.bill99.ebd.rip.enums.PayMode;
import com.bill99.ebd.rip.enums.TrueFalse;
import com.bill99.ebd.rip.enums.TxnType;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.facade.inf.market.ate.ATECancelWriteoffRequest;
import com.bill99.ebd.rip.facade.inf.market.ate.ATENotifyRequest;
import com.bill99.ebd.rip.facade.inf.market.ate.ATENotifyResponse;
import com.bill99.ebd.rip.persistence.RequestJobPersistenceManager;
import com.bill99.ebd.rip.persistence.VoucherPersistenceManager;
import com.bill99.ebd.rip.persistence.dao.RequestJobDao;
import com.bill99.ebd.rip.persistence.model.RequestJobPo;
import com.bill99.ebd.rip.srv.ate.AteUpService;
import com.bill99.ebd.rip.srv.ate.InterestsATEUPService;
import com.bill99.ebd.rip.srv.ate.dto.ATEOrderDetail;
import com.bill99.ebd.rip.srv.ate.dto.OrderItem;
import com.bill99.ebd.rip.util.RestUtils;
import com.bill99.ebd.rip.util.ToStringUtils;
import com.bill99.seashell.common.util.StringUtil;

/**
 * ATE统一支付服务接口（异步处理业务）
 * 
 * @author jakoes.wu
 * @date 2016年7月29日下午3:48:43
 * @project rip-api-lib-r20160726-MERGE
 * 
 */
public class AteUpServiceImpl implements AteUpService {

    private static final Logger logger = LoggerFactory.getLogger(AteUpServiceImpl.class);

    private static final String KEY_REQUEST_ID = "requestId";

    private static final String CHANNEL_ATE = "ATE";

    // private static final String REQUEST_JOB_STATUS_I = "I";

    private static final String REQUEST_JOB_STATUS_F = "F";

    @Autowired
    private VoucherDomainService voucherDomainService;

    @Autowired
    private VoucherPersistenceManager voucherPersistenceManager;

    @Autowired
    private InterestsDomainService interestsDomainService;

    @Autowired
    private InterestsATEUPService interestsATEUPService;

    @Autowired
    private RequestJobPersistenceManager requestJobPersistenceManager;

    @Autowired
    private RequestJobDao requestJobDao;

    private IssueRefundDto adapt(ATENotifyRequest request) throws AppBizException {
        IssueRefundDto dto = new IssueRefundDto();
        dto.setChannel(CHANNEL_ATE);
        dto.setConsumerMemberCode(request.getConsumerMembercode());
        dto.setMerchantMemberCode(request.getMerchantMembercode());
        dto.setOrderAmount(request.getOrderAmt());
        dto.setOriginalOrderNo(request.getOrderNo());
        dto.setOrderNo(request.getOrderNo());
        dto.setVoucherNo(this.getWriteOffVoucherNo(request));
        return dto;
    }

    private void changeRequestJobStatus(String stauts, RequestJobPo requestJob, String responseCode,
            String responseMessage) throws AppBizException {
        requestJob.setResponseCode(responseCode);
        requestJob.setResponseMessage(responseMessage);
        requestJob.setStatus(stauts);
        requestJob.setUpdateTime(new Date());
        this.requestJobPersistenceManager.updateRequestJob(requestJob);
    }

    private String getWriteOffVoucherNo(ATENotifyRequest ateNotifyRequest) throws AppBizException {
        if (StringUtils.isNotBlank(ateNotifyRequest.getVoucherNo())) {
            return ateNotifyRequest.getVoucherNo();
        }
        // find write off voucher by the OrderNo
        VoucherTransaction voucherTransaction = this.voucherPersistenceManager
                .findTransaction(ateNotifyRequest.getOrderNo(), CHANNEL_ATE, TxnType.WRITEOFF, TrueFalse.FALSE, null);
        if (voucherTransaction != null) {
            return voucherTransaction.getVoucherNo();
        }
        return null;
    }

    private boolean hasHoldAggressiveVoucher(String orderNo) throws AppBizException {
        VoucherTransaction voucherTransaction = this.voucherPersistenceManager.findTransaction(orderNo, CHANNEL_ATE,
                TxnType.HOLD, TrueFalse.FALSE, AwareType.AGGRESSIVE);
        if (voucherTransaction == null) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * 根据订单好查询权益是否有核销记录
     * 
     * @param orderNo
     * @return
     * @throws AppBizException
     * 
     * @author pengfei.shen
     * @create 2016年7月29日 下午5:35:46
     */
    private boolean hasWriteOffRecord(String orderNo) throws AppBizException {
        boolean hasWriteOffRecord = false;
        VoucherTransaction txn = this.voucherPersistenceManager.findTransaction(orderNo, CHANNEL_ATE, TxnType.WRITEOFF,
                TrueFalse.FALSE, null);
        if (txn != null) {
            hasWriteOffRecord = true;
        }
        return hasWriteOffRecord;
    }

    private HoldVoucherResultDto holdVoucherBySkuMatchedInterests(List<String> skuIds, String merchantMemberCode,
            String consumerMemberCode, PayMode payMode, BigDecimal orderAmount, BigDecimal payAmount, String orderNo,
            RequestJobPo requestJob, String deviceId) throws AppBizException {
        List<Interests> interestsBySku = this.interestsDomainService.findHoldableInterestsBySku(skuIds,
                merchantMemberCode, consumerMemberCode, payMode, orderAmount, payAmount, AwareType.AGGRESSIVE,
                HoldScene.AFTER);
        if (CollectionUtils.isEmpty(interestsBySku)) {
            return null;
        }
        logger.info("@@AteUpServiceImpl holdVoucherBySkuMatchedInterests interestsBySku size [{}]",
                interestsBySku.size());
        // modify by wujiajun at 09.08 分离权益为内部权益和外部权益列表
        List<Interests> innerInterestsList = new ArrayList<>();
        List<Interests> extInterestsList = new ArrayList<>();
        for (Interests interests : interestsBySku) {
            if (interests != null && interests.getGenerateType() == InterestsGenerateType.INNER) {
                innerInterestsList.add(interests);
            } else if (interests != null && interests.getGenerateType() == InterestsGenerateType.OUTER) {
                extInterestsList.add(interests);
            }
        }

        logger.info("@@AteUpServiceImpl holdVoucherBySkuMatchedInterests innerInterestsList size [{}]",
                innerInterestsList.size());
        logger.info("@@AteUpServiceImpl holdVoucherBySkuMatchedInterests extInterestsList size [{}]",
                extInterestsList.size());

        // List<HoldVoucherResultDto> holdVoucherList = new ArrayList<HoldVoucherResultDto>();
        HoldVoucherResultDto innerHoldVoucher = new HoldVoucherResultDto();
        StringBuffer errors = new StringBuffer();
        // 领内部券-----start------
        for (Interests interests : innerInterestsList) {
            try {
                HoldVoucherDto holdVoucherDto = new HoldVoucherDto();
                holdVoucherDto.setChannel(CHANNEL_ATE);
                holdVoucherDto.setConsumerMembercode(consumerMemberCode);
                holdVoucherDto.setMerchantMembercode(merchantMemberCode);
                holdVoucherDto.setOrderAmount(orderAmount);
                holdVoucherDto.setPayAmount(payAmount);
                holdVoucherDto.setOrderNo(orderNo);
                holdVoucherDto.setInterestsId(interests.getId());
                holdVoucherDto.setHoldScene(HoldScene.AFTER);
                holdVoucherDto.setDeviceId(deviceId);
                logger.info("@@try do hold Voucher By Interests: {}, holdVoucherDto : {}",
                        ToStringUtils.recursiveReflectionToString(interests),
                        ToStringUtils.recursiveReflectionToString(holdVoucherDto));
                // return this.voucherDomainService.holdVoucherByInterests(interests, holdVoucherDto);
                // holdVoucherList.add(this.voucherDomainService.holdVoucherByInterests(interests, holdVoucherDto));
                Voucher voucher = this.voucherDomainService.holdVoucherByInterests(interests, holdVoucherDto);
                HoldVoucherResultDto holdVoucherResultDto = new HoldVoucherResultDto();
                holdVoucherResultDto.setConsumerMembercode(voucher.getConsumerMemberCode());
                holdVoucherResultDto.setVoucherNo(voucher.getVoucherNo());
                holdVoucherResultDto.setVoucherAmt(voucher.getAmount());
                innerHoldVoucher = holdVoucherResultDto;
                break;
            } catch (AppBizException abe) {
                logger.error("hold voucher occurs biz error.", abe);
                errors.append("interestsId:" + interests.getId() + ",errorCode:" + abe.getErrorCode() + ",errorMessage:"
                        + abe.getMessage() + "|");
                continue;
            } catch (Throwable e) {
                logger.error("hold voucher occurs unkonwn error.", e);
                errors.append("interestsId:" + interests.getId() + ",errorMessage:" + e.getMessage() + "|");
                continue;
            }
        }
        // 领内部券-----end------

        // 领外部券-----start------
        for (Interests interests : extInterestsList) {
            try {
                HoldVoucherDto holdVoucherDto = new HoldVoucherDto();
                holdVoucherDto.setChannel(CHANNEL_ATE);
                holdVoucherDto.setConsumerMembercode(consumerMemberCode);
                holdVoucherDto.setMerchantMembercode(merchantMemberCode);
                holdVoucherDto.setOrderAmount(orderAmount);
                holdVoucherDto.setPayAmount(payAmount);
                holdVoucherDto.setOrderNo(orderNo);
                holdVoucherDto.setInterestsId(interests.getId());
                holdVoucherDto.setHoldScene(HoldScene.AFTER);
                holdVoucherDto.setDeviceId(deviceId);
                logger.info("@@try do hold Ext Voucher By Interests: {}, holdVoucherDto : {}",
                        ToStringUtils.recursiveReflectionToString(interests),
                        ToStringUtils.recursiveReflectionToString(holdVoucherDto));
                // holdVoucherList.add(this.voucherDomainService.holdExtVoucherByInterests(interests, holdVoucherDto));
                this.voucherDomainService.holdExtVoucherByInterests(interests, holdVoucherDto);
            } catch (AppBizException abe) {
                logger.error("hold ext voucher occurs biz error.", abe);
                errors.append("interestsId:" + interests.getId() + ",errorCode:" + abe.getErrorCode() + ",errorMessage:"
                        + abe.getMessage() + "|");
                // TODO 异常处理，待设计
                continue;
            } catch (Throwable e) {
                logger.error("hold ext voucher occurs unkonwn error.", e);
                errors.append("interestsId:" + interests.getId() + ",errorMessage:" + e.getMessage() + "|");
                // TODO 异常处理，待设计
                continue;
            }
        }
        // 领外部券-----end------

        if (StringUtils.isNotBlank(errors.toString())) {
            requestJob.setResponseMessage(errors.toString());
        }
        // return holdVoucherList;

        // holder voucher all failed
        // return null;
        return innerHoldVoucher;
    }

    @Override
    public void processCancelRequest(Boolean isDomainServiceEnabled) throws AppBizException {

        List<String> statusList = new ArrayList<String>();
        statusList.add(REQUEST_JOB_STATUS_F);
        List<RequestJobPo> requestJobList = this.requestJobDao.findRequestJobByStatusByRequestType(statusList,
                ATEType.WRITEOFF_CANCEL.getCode());
        if (requestJobList == null || requestJobList.isEmpty()) {
            if (logger.isInfoEnabled()) {
                logger.info("@@no requestJobList results .isDomainServiceEnabled=" + isDomainServiceEnabled);
            }
            return;
        }
        for (RequestJobPo requestJob : requestJobList) {
            logger.info("@@begin to process RequestJob:" + ToStringBuilder.reflectionToString(requestJob));
            if (StringUtil.isEmpty(requestJob.getRequestMessage())) {
                logger.error("@@requestJob no requestMessage results .");
                continue;
            }

            ThreadContext.put(KEY_REQUEST_ID, requestJob.getRequestId());
            try {

                // 处理一条请求任务
                this.processCancelRequestJob(requestJob, isDomainServiceEnabled);

                // 修改状态
                this.changeRequestJobStatus(JobStatus.SUCCESS.getId(), requestJob, AppExCodeEnum.SUCCESS.getCode(),
                        AppExCodeEnum.SUCCESS.getMessage());
            } catch (AppBizException ae) {
                logger.error("@@meet error when do cancel[" + ae.getErrorCode() + "]:" + ae.getErrorMessage(), ae);
                requestJob.setRetryTimes(requestJob.getRetryTimes() + 1);
                this.changeRequestJobStatus(JobStatus.FAILED.getId(), requestJob, ae.getErrorCode(),
                        ae.getErrorMessage());
            } catch (Exception e) {
                logger.error("@@meet unkonw error when cancel:" + e.getMessage(), e);
                requestJob.setRetryTimes(requestJob.getRetryTimes() + 1);
                this.changeRequestJobStatus(JobStatus.FAILED.getId(), requestJob, AppExCodeEnum.UNKNOW_ERROR.getCode(),
                        AppExCodeEnum.UNKNOW_ERROR.getMessage());
            } finally {
                ThreadContext.remove(KEY_REQUEST_ID);
            }

            logger.info("@@cancel RequestJob done");
        }
    }

    @Override
    public void processCancelRequestJob(RequestJobPo requestJob, Boolean isDomainServiceEnabled)
            throws AppBizException, IOException {
        if (Boolean.TRUE == isDomainServiceEnabled) {
            logger.info("@@invoke domain service [CancelWriteoff]");
            this.processCancelRequestJobWithDomainService(requestJob);
        } else {
            logger.info("@@invoke old service [CancelWriteoff]");
            ATECancelWriteoffRequest cancelWriteoffReq = RestUtils.stringToObject(requestJob.getRequestMessage(),
                    ATECancelWriteoffRequest.class);
            this.interestsATEUPService.doCancelWriteoff(cancelWriteoffReq.getVoucherNo(),
                    cancelWriteoffReq.getMerchantMembercode(), cancelWriteoffReq.getConsumerMembercode(),
                    cancelWriteoffReq.getOrderNo(), cancelWriteoffReq.getOrigOrderNo(), cancelWriteoffReq.getOrderAmt(),
                    null);
        }
    }

    private void processCancelRequestJobWithDomainService(RequestJobPo requestJob) throws IOException, AppBizException {
        ATECancelWriteoffRequest request = RestUtils.stringToObject(requestJob.getRequestMessage(),
                ATECancelWriteoffRequest.class);
        IssueRefundDto dto = new IssueRefundDto();
        dto.setConsumerMemberCode(request.getConsumerMembercode());
        dto.setMerchantMemberCode(request.getMerchantMembercode());
        dto.setOrderAmount(request.getOrderAmt());
        dto.setOriginalOrderNo(request.getOrigOrderNo());
        dto.setOrderNo(request.getOrderNo());
        dto.setVoucherNo(request.getVoucherNo());
        dto.setChannel(CHANNEL_ATE);
        this.voucherDomainService.issueRefund(dto);
    }

    @Override
    public void processNotifyRequest(Boolean isDomainServiceEnabled) throws AppBizException {
        List<String> statusList = new ArrayList<String>();
        statusList.add(REQUEST_JOB_STATUS_F);
        List<RequestJobPo> requestJobList = this.requestJobDao.findRequestJobByStatusByRequestType(statusList,
                ATEType.PAY_NOTIFY.getCode());

        if (requestJobList == null || requestJobList.isEmpty()) {
            if (logger.isInfoEnabled()) {
                logger.info("@@no requestJobList results .isDomainServiceEnabled=" + isDomainServiceEnabled);
            }
            return;
        }

        for (RequestJobPo requestJob : requestJobList) {
            logger.info("@@begin to process RequestJob:" + ToStringBuilder.reflectionToString(requestJob));
            if (StringUtil.isEmpty(requestJob.getRequestMessage())) {
                logger.error("@@requestJob no requestMessage results .");
                continue;
            }

            // TODO 待重构，这里不应该依赖inf里的ATENotifyResponse，这个ATENotifyResponse不会向上返回给调用方
            ATENotifyResponse response = new ATENotifyResponse();
            response.setRequestId(requestJob.getRequestId());
            response.setResponseCode(AppExCodeEnum.SUCCESS.getCode());
            ThreadContext.put(KEY_REQUEST_ID, requestJob.getRequestId());

            try {

                // 处理一条请求任务
                this.processNotifyRequestJob(requestJob, response, isDomainServiceEnabled);

                // 修改状态
                String responseMessage = RestUtils.objectToJSONString(response);
                this.changeRequestJobStatus(FOStatus.SUCCESS.getId(), requestJob, response.getResponseCode(),
                        responseMessage);
            } catch (AppBizException ae) {
                logger.error("@@meet error when do notify[" + ae.getErrorCode() + "]:" + ae.getErrorMessage(), ae);
                response.setResponseCode(ae.getErrorCode());
                response.setResponseMessage(ae.getErrorMessage());
                requestJob.setRetryTimes(requestJob.getRetryTimes() + 1);
                this.changeRequestJobStatus(FOStatus.FAILED.getId(), requestJob, response.getResponseCode(),
                        response.getResponseMessage());
            } catch (Exception e) {
                logger.error("@@meet unkonw error when notify:" + e.getMessage(), e);
                requestJob.setRetryTimes(requestJob.getRetryTimes() + 1);
                response.setResponseCode(AppExCodeEnum.UNKNOW_ERROR.getCode());
                response.setResponseMessage(AppExCodeEnum.UNKNOW_ERROR.getMessage());
                this.changeRequestJobStatus(FOStatus.FAILED.getId(), requestJob, response.getResponseCode(),
                        response.getResponseMessage());
            } finally {
                ThreadContext.remove(KEY_REQUEST_ID);
            }

            logger.info("@@cancel RequestJob done");
        }

    }

    @Override
    public void processNotifyRequestJob(RequestJobPo requestJob, ATENotifyResponse response,
            Boolean isDomainServiceEnabled) throws AppBizException, IOException {
        if (Boolean.TRUE == isDomainServiceEnabled) {
            logger.info("@@invoke domain service [notify]");
            this.processNotifyRequestJobWithDomainService(requestJob, response);
        } else {
            logger.info("@@invoke old service [notify]");
            RequestJob requestJobHibernatePo = this.transferToHibernatePo(requestJob);
            this.interestsATEUPService.processRequestJob(requestJobHibernatePo, response);
        }
    }

    private void processNotifyRequestJobWithDomainService(RequestJobPo requestJob, ATENotifyResponse response)
            throws AppBizException, IOException {
        ATENotifyRequest ateNotifyRequest = RestUtils.stringToObject(requestJob.getRequestMessage(),
                ATENotifyRequest.class);
        boolean isSuccess = ateNotifyRequest.isPayResult();
        String merchantMemberCode = ateNotifyRequest.getMerchantMembercode();
        String consumerMemberCode = ateNotifyRequest.getConsumerMembercode();
        BigDecimal orderAmount = ateNotifyRequest.getOrderAmt();
        BigDecimal payAmount = ateNotifyRequest.getPayAmt();
        String orderNo = ateNotifyRequest.getOrderNo();
        String deviceId = ateNotifyRequest.getDeviceId();

        String payModeString = ateNotifyRequest.getPayMode();
        PayMode payMode = null;
        if (StringUtils.isNotBlank(payModeString)) {
            payMode = PayMode.fromId(payModeString);
        }

        String productTag = ateNotifyRequest.getProductTag();
        List<String> skuIds = null;
        try {
            skuIds = this.productTagToSkuIds(productTag);
        } catch (Throwable t) {
            logger.info("ProductTag was bad-formed,thread exited,", t);
            // throw new AppBizException(AppExCodeEnum.PARAM_ERROR);
        }

        if (isSuccess) {
            // 如果券号为空，判断，不为说明享受了权益
            if (StringUtils.isBlank(ateNotifyRequest.getVoucherNo())) {
                boolean hasWriteOffRecord = this.hasWriteOffRecord(ateNotifyRequest.getOrderNo());
                if (hasWriteOffRecord) {
                    // TODO 本分支判断 只正对代金券 ，待改造 ---如果有记录判断支付金额是否相等
                    if (ateNotifyRequest.getPayAmt().equals(ateNotifyRequest.getOrderAmt())) {
                        // pay failed, cancel write off voucher
                        IssueRefundDto cancelWriteOffVoucherDto = this.adapt(ateNotifyRequest);
                        this.voucherDomainService.issueRefund(cancelWriteOffVoucherDto);
                    }
                }
            }
            // pay succeeded, check if already hold voucher
            boolean holdAggressiveVoucher = this.hasHoldAggressiveVoucher(orderNo);
            if (holdAggressiveVoucher) {
                logger.warn("@@order no {} hold voucher exists.", ateNotifyRequest.getOrderNo());
                return;
            }
            // hold voucher
            HoldVoucherResultDto holdVoucherResultDto = this.holdVoucherBySkuMatchedInterests(skuIds,
                    merchantMemberCode, consumerMemberCode, payMode, orderAmount, payAmount, orderNo, requestJob,
                    deviceId);
            if (holdVoucherResultDto != null) {
                response.setVoucherNo(holdVoucherResultDto.getVoucherNo());
                response.setInterestsAmt(holdVoucherResultDto.getVoucherAmt());
                response.setResponseMessage(RestUtils.objectToJSONString(response));
            }
            logger.info("@@notify of hold voucher response: {}", ReflectionToStringBuilder.toString(response));
        } else {
            // pay failed, cancel write off voucher
            IssueRefundDto cancelWriteOffVoucherDto = this.adapt(ateNotifyRequest);
            this.voucherDomainService.issueRefund(cancelWriteOffVoucherDto);
        }
    }

    private List<String> productTagToSkuIds(String productTag) throws IOException {
        List<String> origiSkuList = new ArrayList<String>();
        if (StringUtils.isNotBlank(productTag)) {
            ATEOrderDetail ateOrderDetail = RestUtils.stringToObject(productTag, ATEOrderDetail.class);
            if (ateOrderDetail != null) {
                List<OrderItem> productList = ateOrderDetail.getProductList();
                for (OrderItem item : productList) {
                    origiSkuList.add(item.getId());
                }
            }
        }
        logger.info("@@found skuIds {}.", origiSkuList);
        return origiSkuList;
    }

    private RequestJob transferToHibernatePo(RequestJobPo requestJob) {
        RequestJob requestJobHibernatePo = new RequestJob();
        requestJobHibernatePo.setCreateTime(requestJob.getCreateTime());
        requestJobHibernatePo.setIdRequestJob(requestJob.getIdRequestJob());
        requestJobHibernatePo.setMemo(requestJob.getMemo());
        requestJobHibernatePo.setOrderNo(requestJob.getOrderNo());
        requestJobHibernatePo.setOrigOrderNo(requestJob.getOrigOrderNo());
        requestJobHibernatePo.setRequestId(requestJob.getRequestId());
        requestJobHibernatePo.setRequestMessage(requestJob.getRequestMessage());
        requestJobHibernatePo.setRequestType(requestJob.getRequestType());
        requestJobHibernatePo.setResponseCode(requestJob.getResponseCode());
        requestJobHibernatePo.setResponseMessage(requestJob.getRequestMessage());
        requestJobHibernatePo.setRetryTimes(requestJob.getRetryTimes());
        requestJobHibernatePo.setStatus(requestJob.getStatus());
        requestJobHibernatePo.setUpdateTime(requestJob.getUpdateTime());
        return requestJobHibernatePo;
    }

}
