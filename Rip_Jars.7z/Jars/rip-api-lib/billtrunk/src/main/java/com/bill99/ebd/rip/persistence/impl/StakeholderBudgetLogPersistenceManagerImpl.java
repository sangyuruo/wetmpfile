package com.bill99.ebd.rip.persistence.impl;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.domain.model.StakeholderBudgetLogDto;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.StakeholderBudgetLogPersistenceManager;
import com.bill99.ebd.rip.persistence.adapter.StakeholderBudgetLogPoPersistenceAdapter;
import com.bill99.ebd.rip.persistence.dao.StakeholderBudgetLogDao;
import com.bill99.ebd.rip.persistence.model.StakeholderBudgetLogPo;

public class StakeholderBudgetLogPersistenceManagerImpl implements StakeholderBudgetLogPersistenceManager {
	private StakeholderBudgetLogDao stakeholderBudgetLogDao;

	@Autowired
	public void setStakeholderBudgetLogDaoIBatis(StakeholderBudgetLogDao stakeholderBudgetLogDao) {
		this.stakeholderBudgetLogDao = stakeholderBudgetLogDao;
	}

	@Override
	public void insertStakeholderBudgetLog(StakeholderBudgetLogDto stakeholderBudgetLogDto) throws AppBizException {
		StakeholderBudgetLogPoPersistenceAdapter adapter = new StakeholderBudgetLogPoPersistenceAdapter();
		StakeholderBudgetLogPo stakeholderBudgetLogPo = new StakeholderBudgetLogPo();
		adapter.inbound(stakeholderBudgetLogDto, stakeholderBudgetLogPo);
		// 如果没设定时间，初始化创建时间
		if (null == stakeholderBudgetLogPo.getCreateTime()) {
			stakeholderBudgetLogPo.setCreateTime(new Date());
		}
		stakeholderBudgetLogDao.create(stakeholderBudgetLogPo);
	}

}
