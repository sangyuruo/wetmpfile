package com.bill99.ebd.rip.util;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.enums.TrueFalse;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.wrapper.MaServiceWrapper;

/**
 * 受理商户会员编号工具类
 * 
 * @author kui.yu
 * @date 2017年6月30日
 */
public class AcquirerMemberCodeUtil {

    private static final String VALIDATE_FAILDE = "验证失败";

    private static final String FORMAT_FAILDE = "格式不正确";

    private static final String NOT_EXIST = "不存在";

    @Autowired
    private MaServiceWrapper maServiceWrapper;

    public Map<String, String> validate(String memberCode) {
        Map<String, String> resultMap = new HashMap<String, String>();
        resultMap.put("status", TrueFalse.FALSE.getId());
        resultMap.put("message", AcquirerMemberCodeUtil.VALIDATE_FAILDE);
        if (StringUtils.isNotBlank(memberCode)) {
            memberCode = memberCode.trim();
            String rex11 = "^\\d{11}$";// 11位数字
            String rex15 = "^\\d{15}$";// 15位数字
            Pattern p11 = Pattern.compile(rex11);
            Pattern p15 = Pattern.compile(rex15);
            if (p15.matcher(memberCode).find()) {
                resultMap.put("status", TrueFalse.TRUE.getId());
            } else if (p11.matcher(memberCode).find()) {
                try {
                    // 验证是否存在
                    maServiceWrapper.getMemberByMemberCode(memberCode);
                    resultMap.put("status", TrueFalse.TRUE.getId());
                } catch (AppBizException e) {
                    resultMap.put("message", AcquirerMemberCodeUtil.NOT_EXIST);
                }
            } else {
                resultMap.put("message", AcquirerMemberCodeUtil.FORMAT_FAILDE);
            }
        }
        return resultMap;
    }

}
