/**
 * 
 */
package com.bill99.ebd.rip.persistence;

import com.bill99.ebd.rip.domain.model.ItrAcct;
import com.bill99.ebd.rip.exception.AppBizException;

/**
 * 
 * @author wei.wang.rd
 * @since Oct 23, 2016
 */
public interface ItrAcctPersistenceManager {

    public void saveOrUpdateItrAcct(ItrAcct newItrAcct, ItrAcct oldItrAcct) throws AppBizException;

    void createItrAcct(ItrAcct itrAcct) throws AppBizException;

    public void updateItrAcct(ItrAcct newItrAcct, ItrAcct oldItrAcct) throws AppBizException;
    
    ItrAcct getItrAcct(String membercode) throws AppBizException;

}
