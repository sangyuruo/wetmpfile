/**
 * 
 */
package com.bill99.ebd.rip.persistence.impl;

import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.domain.model.FundInterests;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.FundInterestsPersistenceManager;
import com.bill99.ebd.rip.persistence.adapter.FundInterestsModelsAdaptHelper;
import com.bill99.ebd.rip.persistence.dao.FundInterestsDao;

/**
 * @author wei.wang.rd
 * @since Nov 03, 2016
 */
public class FundInterestsPersistenceManagerImpl implements FundInterestsPersistenceManager {

    private static final Logger logger = LoggerFactory.getLogger(FundInterestsPersistenceManagerImpl.class);

    private FundInterestsDao fundInterestsDao;

    @Autowired
    public void setFundInterestsDao(FundInterestsDao fundInterestsDao) {
        this.fundInterestsDao = fundInterestsDao;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bill99.ebd.rip.persistence.FundInterestsPersistenceManager#getFundInterests(java.lang.Integer,
     * java.lang.String)
     */
    @Override
    public FundInterests getFundInterests(Integer interestsId, String acquirerId) throws AppBizException {
        logger.info("@@begin to getFundInterests, interestsId = {} acquirerId = {} ", interestsId, acquirerId);
        Map<String, Object> fundInterestsObjectsMap = this.fundInterestsDao.findFundInterests(interestsId, acquirerId);
        if (CollectionUtils.sizeIsEmpty(fundInterestsObjectsMap)) {
            logger.info("@@NO FundInterests matched.");
            return null;
        }
        FundInterestsModelsAdaptHelper adaptHelper = new FundInterestsModelsAdaptHelper();
        FundInterests fundInterests = adaptHelper.outboundInterests(fundInterestsObjectsMap);
        logger.info("@@Interests matched, interestsId = {} ", interestsId);
        return fundInterests;

    }
}
