package com.bill99.ebd.rip.persistence.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.domain.model.WithdrawTransaction;
import com.bill99.ebd.rip.enums.FOStatus;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.WithdrawTxnPersistenceManager;
import com.bill99.ebd.rip.persistence.adapter.WithdrawPersistenceAdapter;
import com.bill99.ebd.rip.persistence.dao.WithdrawTxnDao;
import com.bill99.ebd.rip.persistence.model.WithdrawTxnPo;

public class WithdrawTxnPersistenceManagerImpl implements WithdrawTxnPersistenceManager {

    private static final WithdrawPersistenceAdapter withdrawAdapter = new WithdrawPersistenceAdapter();

    @Autowired
    private WithdrawTxnDao withdrawTxnDao;

    @Override
    public void save(WithdrawTransaction withdrawTx) throws AppBizException {
        WithdrawTxnPo withdrawTxnPo = new WithdrawTxnPo();
        withdrawAdapter.inbound(withdrawTx, withdrawTxnPo);
        withdrawTxnDao.create(withdrawTxnPo);
        withdrawTx.setIdWithdrawTxn(withdrawTxnPo.getIdWithdrawTxn());
    }

    @Override
    public void update(WithdrawTransaction newWithdrawTx, WithdrawTransaction oldWithdrawTx) throws AppBizException {
        WithdrawTxnPo newWithdrawTxnPo = new WithdrawTxnPo();
        WithdrawTxnPo oldWithdrawTxnPo = null;
        withdrawAdapter.inbound(newWithdrawTx, newWithdrawTxnPo);
        if (oldWithdrawTx != null) {
            oldWithdrawTxnPo = new WithdrawTxnPo();
            withdrawAdapter.inbound(oldWithdrawTx, oldWithdrawTxnPo);
        }
        withdrawTxnDao.update(newWithdrawTxnPo, oldWithdrawTxnPo);
    }

    @Override
    public WithdrawTransaction findByExtSeqId(String extSeqId) throws AppBizException {
        WithdrawTxnPo po = withdrawTxnDao.findByExtSeqId(extSeqId);
        if (po == null) {
            return null;
        }
        WithdrawTransaction withdrawTxn = new WithdrawTransaction();
        withdrawAdapter.outbound(po, withdrawTxn);
        return withdrawTxn;
    }

    @Override
    public WithdrawTransaction findByChannelAndExtSeqId(String channel, String extSeqId) throws AppBizException {
        WithdrawTxnPo po = withdrawTxnDao.findByChannelAndExtSeqId(channel, extSeqId);
        if (po == null) {
            return null;
        }
        WithdrawTransaction withdrawTxn = new WithdrawTransaction();
        withdrawAdapter.outbound(po, withdrawTxn);
        return withdrawTxn;
    }

    @Override
    public List<WithdrawTransaction> pageFindByPayStatusAndClrStatus(String payStatus, String clrStatus,
            Integer pageIndex, Integer pageSize) throws AppBizException {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Map<Integer, BigDecimal> caculateSuccFundAmtByInterestsIds(List<FOStatus> status, List<Integer> interestsIds) {
        if (CollectionUtils.isEmpty(status)) {
            return Collections.emptyMap();
        }
        List<String> statusList = new ArrayList<String>();
        for (FOStatus stat : status) {
            if (stat != null) {
                statusList.add(stat.getId());
            }
        }
        if (CollectionUtils.isEmpty(statusList)) {
            return Collections.emptyMap();
        }
        // 给统计有结果的interestsId赋值
        List<Integer> realArrayList = new ArrayList<Integer>(interestsIds);
        List<Map<String, String>> list = withdrawTxnDao.sumSuccFundoutAmtByInterestsIds(statusList, interestsIds);
        Map<Integer, BigDecimal> result = new HashMap<Integer, BigDecimal>();
        if (CollectionUtils.isEmpty(list)) {
            for (Integer interestId : interestsIds) {
                result.put(interestId, BigDecimal.ZERO);
            }
            return result;
        }
        for (Map<String, String> map : list) {
            Integer interestsId = MapUtils.getInteger(map, "INTERESTSID");
            String sumAmt = MapUtils.getString(map, "AMT");
            result.put(interestsId, new BigDecimal(sumAmt));
            // 去掉已经处理过的interestsId记录
            realArrayList.removeAll(Arrays.asList(interestsId));
        }
        // 给没有统计结果的interestsId赋值
        for (Integer interestsId : realArrayList) {
            result.put(interestsId, BigDecimal.ZERO);
        }
        return result;
    }

    @Override
    public WithdrawTransaction getWithdrawTransaction(Integer idWithdrawTxn) throws AppBizException {
        WithdrawTxnPo po = withdrawTxnDao.getWithdrawTransaction(idWithdrawTxn);
        if (po == null) {
            return null;
        }
        WithdrawTransaction withdrawTxn = new WithdrawTransaction();
        withdrawAdapter.outbound(po, withdrawTxn);
        return withdrawTxn;
    }

}
