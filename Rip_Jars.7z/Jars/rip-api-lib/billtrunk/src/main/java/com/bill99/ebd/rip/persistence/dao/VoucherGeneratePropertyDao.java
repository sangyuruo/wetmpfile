/**
 * 
 */
package com.bill99.ebd.rip.persistence.dao;

import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.model.VoucherGeneratePropertyPo;

/**
 * @author shuangye.liu
 * 
 * @since Jun 21, 2016
 */
public interface VoucherGeneratePropertyDao extends CrudDao<VoucherGeneratePropertyPo> {

    void deleteByGenRuleId(Integer genRuleId) throws AppBizException;

}
