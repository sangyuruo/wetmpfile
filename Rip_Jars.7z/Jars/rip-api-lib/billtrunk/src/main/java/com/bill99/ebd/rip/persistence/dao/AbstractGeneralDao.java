package com.bill99.ebd.rip.persistence.dao;

import com.bill99.ebd.rip.persistence.dao.page.PageInfo;
import com.bill99.ebd.rip.spring.ibatis.SqlMapClientDaoSupport;

/**
 * 
 */
public abstract class AbstractGeneralDao extends SqlMapClientDaoSupport {

    private String namespace;

    public String getNamespace() {
        return this.namespace;
    }

    public void setNamespace(String namespace) {
        this.namespace = namespace;
    }

    protected String getFullActionName(String action) {
        return getNamespace().concat(".").concat(action);
    }

    public void initPageInfo(PageInfo pageInfo) {
        Integer counts = pageInfo.getCounts();
        Integer pageIndex = pageInfo.getPageIndex();
        Integer pageSize = pageInfo.getPageSize();
        Integer flag = counts % pageSize;
        Integer minTotalPages = counts / pageSize;

        Integer limitClauseStart;
        Integer limitClauseEnd;

        limitClauseStart = (pageIndex - 1) * pageSize;
        limitClauseEnd = limitClauseStart + pageSize;
        Integer totalPages = (flag > 0) ? minTotalPages + 1 : minTotalPages;
        /*
         * Integer totalPages = (flag > 0) ? minTotalPages + 1 : minTotalPages; if (pageInfo.getCounts() <=
         * pageInfo.getPageSize()) { limitClauseStart = 0; limitClauseEnd = counts; } else {
         * 
         * if (flag > 0) { limitClauseEnd = counts - limitClauseStart; } else { limitClauseEnd = (pageIndex + 1) *
         * pageSize; } }
         */
        pageInfo.setTotalPages(totalPages);
        pageInfo.setLimitRwnStart(limitClauseStart);
        pageInfo.setLimitRwnEnd(limitClauseEnd);
    }
}
