package com.bill99.ebd.rip.persistence.dao;

import java.util.List;

import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.model.VoucherTransactionPo;

public interface VoucherTransactionDao extends CrudDao<VoucherTransactionPo> {

    /**
     * 批量创建
     * 
     * @param pos
     * @throws AppBizException
     */
    void batchCreate(List<VoucherTransactionPo> pos) throws AppBizException;

    VoucherTransactionPo findVoucherTransaction(String extSeqId, String channel, String txnType, String cancelFlag,
            String awareType) throws AppBizException;

    List<VoucherTransactionPo> findVoucherTransactions(String voucherNo) throws AppBizException;

}
