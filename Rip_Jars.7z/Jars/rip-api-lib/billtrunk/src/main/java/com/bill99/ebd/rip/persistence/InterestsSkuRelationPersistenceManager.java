/**
 * 
 */
package com.bill99.ebd.rip.persistence;

import java.util.List;
import java.util.Map;

import com.bill99.ebd.rip.domain.model.InterestsSkuRelation;
import com.bill99.ebd.rip.enums.AcquirerAbility;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.model.InterestsSkuRelationPo;

/**
 * @author shuangye.liu
 * 
 * @since Jul 22, 2016
 */
public interface InterestsSkuRelationPersistenceManager {
    public void createInterestsSkuRel(InterestsSkuRelationPo interestsSkuRelationPo) throws AppBizException;

    public void updateInterestsSkuRel(InterestsSkuRelationPo interestsSkuRelationPo) throws AppBizException;

    public Map<String, Object> pageQuery(String keywords, Integer interestsId, String memberCode, String ability,
            Integer pageIndex, Integer pageSize) throws AppBizException;
    
    public Map<String, Object> pageQueryByParamMap(Map<String, Object> paramMap, Integer pageIndex, Integer pageSize)
            throws AppBizException;

    public void deleteById(Integer id) throws AppBizException;
    
    public void deleteBySkuId(Integer interestsId, String skuId, String ability) throws AppBizException;

    /**
     * 获取某权益下的所有SKU信息
     * 
     * @param interestsId
     * @return
     * @throws AppBizException
     * @author jakoes.wu
     * @updatedate 2017年2月8日下午4:03:31
     */
    public List<InterestsSkuRelation> findInterestsSkuRelation(Integer interestsId, AcquirerAbility acquirerAbility)
            throws AppBizException;

    public List<InterestsSkuRelation> findInterestsSkuRelation(List<Integer> interestsIds, String merchantMemberCode,
            AcquirerAbility acquirerAbility) throws AppBizException;

}
