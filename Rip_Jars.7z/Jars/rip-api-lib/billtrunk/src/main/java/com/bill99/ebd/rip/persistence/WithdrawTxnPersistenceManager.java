package com.bill99.ebd.rip.persistence;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.bill99.ebd.rip.domain.model.WithdrawTransaction;
import com.bill99.ebd.rip.enums.FOStatus;
import com.bill99.ebd.rip.exception.AppBizException;

public interface WithdrawTxnPersistenceManager {

    public void save(WithdrawTransaction withdrawTx) throws AppBizException;

    public void update(WithdrawTransaction newWithdrawTx, WithdrawTransaction oldWithdrawTx) throws AppBizException;

    public WithdrawTransaction findByExtSeqId(String extSeqId) throws AppBizException;

    public WithdrawTransaction getWithdrawTransaction(Integer idWithdrawTxn) throws AppBizException;

    public WithdrawTransaction findByChannelAndExtSeqId(String channel, String extSeqId) throws AppBizException;

    public List<WithdrawTransaction> pageFindByPayStatusAndClrStatus(String payStatus, String clrStatus,
            Integer pageIndex, Integer pageSize) throws AppBizException;

    public Map<Integer, BigDecimal> caculateSuccFundAmtByInterestsIds(List<FOStatus> status, List<Integer> interestsIds);
}
