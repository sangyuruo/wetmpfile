package com.bill99.ebd.rip.persistence.impl;

import java.util.List;

import javax.annotation.Resource;

import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.RequestJobPersistenceManager;
import com.bill99.ebd.rip.persistence.dao.ibatis.RequestJobDaoIBatisImpl;
import com.bill99.ebd.rip.persistence.model.RequestJobPo;

public class RequestJobPersistenceManagerImpl implements RequestJobPersistenceManager {

    @Resource(name = "requestJobIbatisDao")
    private RequestJobDaoIBatisImpl reqeustJobDao;

    @Override
    public void createRequestJob(RequestJobPo requestJob) throws AppBizException {
        reqeustJobDao.create(requestJob);
    }

    @Override
    public void updateRequestJob(RequestJobPo requestJob) throws AppBizException {
        reqeustJobDao.update(requestJob, null);
    }

    @Override
    public RequestJobPo findRequestJobByOrderNoAndOrigOrderNo(String orderNo, String orgiOrderNo)
            throws AppBizException {
        return reqeustJobDao.findRequestJobByOrderNoAndOrigOrderNo(orderNo, orgiOrderNo);
    }

    @Override
    public RequestJobPo findRequestJobByOrderNo(String orderNo) throws AppBizException {
        return reqeustJobDao.findRequestJobByOrderNo(orderNo);
    }

    @Override
    public List<RequestJobPo> findRequestJobByStatusByRequestType(List<String> status, String reqType)
            throws AppBizException {
        return reqeustJobDao.findRequestJobByStatusByRequestType(status, reqType);
    }
}
