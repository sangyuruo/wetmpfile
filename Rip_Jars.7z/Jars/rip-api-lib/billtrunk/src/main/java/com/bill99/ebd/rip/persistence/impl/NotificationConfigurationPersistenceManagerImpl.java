/**
 * 
 */
package com.bill99.ebd.rip.persistence.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.domain.model.NotificationConfiguration;
import com.bill99.ebd.rip.domain.model.NotificationTemplate;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.NotificationConfigurationPersistenceManager;
import com.bill99.ebd.rip.persistence.adapter.NotificationConfigurationPersistenceAdapter;
import com.bill99.ebd.rip.persistence.adapter.NotificationTemplatePersistenceAdapter;
import com.bill99.ebd.rip.persistence.dao.NotificationConfigurationDao;
import com.bill99.ebd.rip.persistence.model.NotificationConfigurationPo;
import com.bill99.ebd.rip.persistence.model.NotificationTemplatePo;

/**
 * @author wei.wang.rd
 * @since Sep 26,2016
 * 
 */
public class NotificationConfigurationPersistenceManagerImpl implements NotificationConfigurationPersistenceManager {

    @Autowired
    private NotificationConfigurationDao notificationConfigurationDao;

    @Override
    public List<NotificationConfiguration> findNotificationConfiguration(Integer insterestsId) throws AppBizException {
        List<NotificationConfiguration> result = new ArrayList<NotificationConfiguration>();
        NotificationConfigurationPersistenceAdapter ncpAdapter = new NotificationConfigurationPersistenceAdapter();
        NotificationTemplatePersistenceAdapter ntpAdapter = new NotificationTemplatePersistenceAdapter();
        List<Map<String, Object>> notificationConfigurations = notificationConfigurationDao
                .getInterestsNotificationConfigurations(insterestsId);
        if (notificationConfigurations != null && notificationConfigurations.size() > 0) {
            for (Map<String, Object> ncMap : notificationConfigurations) {
                NotificationTemplatePo notificationTemplatePo = (NotificationTemplatePo) ncMap
                        .get("notificationTemplate");
                NotificationConfigurationPo ncPo = (NotificationConfigurationPo) ncMap.get("notificationConfiguration");
                NotificationTemplate nt = new NotificationTemplate();
                NotificationConfiguration nc = new NotificationConfiguration();
                ntpAdapter.outbound(notificationTemplatePo, nt);
                ncpAdapter.outbound(ncPo, nc);
                nc.setNotificationTemplate(nt);
                result.add(nc);
            }
        }
        return result;
    }
}
