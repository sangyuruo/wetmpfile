package com.bill99.ebd.rip.persistence.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.VoucherBatchPersistenceManager;
import com.bill99.ebd.rip.persistence.dao.VoucherBatchDao;
import com.bill99.ebd.rip.persistence.model.VoucherBatchPo;
import com.bill99.ebd.rip.util.Page;

public class VoucherBatchPersistenceManagerImpl implements VoucherBatchPersistenceManager {

    private VoucherBatchDao voucherBatchDao;

    @Override
    public void createVoucherBatch(VoucherBatchPo voucherBatchPo) throws AppBizException {
        this.voucherBatchDao.create(voucherBatchPo);
    }

    @Override
    public Page<VoucherBatchPo> find(Integer pageNumber, Integer pageSize) throws AppBizException {
        Integer totalCount = this.voucherBatchDao.count();
        if (totalCount == null || totalCount.intValue() == 0) {
            return null;
        }
        List<VoucherBatchPo> datas = this.voucherBatchDao.find(pageNumber, pageSize);
        return new Page<>(totalCount, pageNumber, pageSize, datas);
    }

    @Override
    public List<VoucherBatchPo> queryByStatusAndHoldTime(List<String> status, Date holdTime) throws AppBizException {
        return this.voucherBatchDao.selectByStatusAndHoldTime(status, holdTime);
    }

    @Autowired
    public void setVoucherBatchDao(VoucherBatchDao voucherBatchDao) {
        this.voucherBatchDao = voucherBatchDao;
    }

    @Override
    public void updateVoucherBatch(VoucherBatchPo voucherBatchPo) throws AppBizException {
        this.voucherBatchDao.update(voucherBatchPo, null);
    }

    @Override
    public void deleteByBatchId(Integer batchId) throws AppBizException {
        this.voucherBatchDao.deleteById(batchId);
    }

    @Override
    public List<VoucherBatchPo> queryByInterestAndStatus(Integer interestsId, String status) throws AppBizException {
        return voucherBatchDao.findByInterestsIdAndStatus(interestsId, status);
    }

    @Override
    public VoucherBatchPo findById(Integer batchId) throws AppBizException {
        return voucherBatchDao.selectById(batchId);
    }

    @Override
    public void deleteByInterestsId(Integer interestsId) throws AppBizException {
        this.voucherBatchDao.deleteByInterestId(interestsId);

    }

}
