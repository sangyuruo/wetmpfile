package com.bill99.ebd.rip.persistence.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.domain.model.StakeholderRelatedPool;
import com.bill99.ebd.rip.domain.model.StakeholderRelatedPoolDto;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.StakeholderRelatedPoolPersistenceManager;
import com.bill99.ebd.rip.persistence.adapter.StakeholderRelatedPoolPoPersistenceAdapter;
import com.bill99.ebd.rip.persistence.dao.StakeholderRelatedPoolDao;
import com.bill99.ebd.rip.persistence.model.StakeholderRelatedPoolPo;

/**
 * @author yong.zheng
 * @version 创建时间：2017年1月20日 下午5:34:33 类说明
 */
public class StakeholderRelatedPoolPersistenceManagerImpl implements StakeholderRelatedPoolPersistenceManager {

    private StakeholderRelatedPoolDao stakeholderRelatedPoolDaoIBatis;

    private StakeholderRelatedPoolPoPersistenceAdapter adapter = new StakeholderRelatedPoolPoPersistenceAdapter();

    @Autowired
    public void setStakeholderRelatedPoolDaoIBatis(StakeholderRelatedPoolDao stakeholderRelatedPoolDao) {
        this.stakeholderRelatedPoolDaoIBatis = stakeholderRelatedPoolDao;
    }

    @Override
    public void insertStakeholderRelatedPool(StakeholderRelatedPoolDto stakeholderRelatedPoolDto)
            throws AppBizException {
        StakeholderRelatedPoolPo po = new StakeholderRelatedPoolPo();
        adapter.inbound(stakeholderRelatedPoolDto, po);
        if (null == po.getCrtTime())
            po.setCrtTime(new Date());
        stakeholderRelatedPoolDaoIBatis.create(po);
    }

    @Override
    public Map<String, Object> pageQueryByParamMap(StakeholderRelatedPool stakeholderRelatedPool, Integer pageIndex,
            Integer pageSize) throws AppBizException {
        Map<String, Object> paramterMap = new HashMap<String, Object>();
        paramterMap.put("idStakeholderRelatedPool", stakeholderRelatedPool.getIdStakeholderRelatedPool());
        paramterMap.put("memberCode", stakeholderRelatedPool.getMemberCode());
        paramterMap.put("parentMembercode", stakeholderRelatedPool.getParentMembercode());
        paramterMap.put("externalFund", stakeholderRelatedPool.getExternalFund());
        paramterMap.put("memo", stakeholderRelatedPool.getMemo());
        paramterMap.put("merchantDescribed", stakeholderRelatedPool.getMerchantDescribed());
        paramterMap.put("relatedFoMemberacctcode", stakeholderRelatedPool.getRelatedFoMemberacctcode());
        return stakeholderRelatedPoolDaoIBatis.pageQuery(paramterMap, pageIndex, pageSize);
    }

    @Override
    public List<StakeholderRelatedPoolPo> findStakeholderRelatedPoolPoList(Map<String, Object> paratmters)
            throws AppBizException {
        return stakeholderRelatedPoolDaoIBatis.findStakeholderRelatedPoolPo(paratmters);
    }

    /**
     * 根据memberCode删除出款账户
     * @param memberCode
     * @throws AppBizException
     */
    @Override
    public void deleteByMemberCode(String memberCode) throws AppBizException {
        this.stakeholderRelatedPoolDaoIBatis.deleteByMemberCode(memberCode);
    }

}
