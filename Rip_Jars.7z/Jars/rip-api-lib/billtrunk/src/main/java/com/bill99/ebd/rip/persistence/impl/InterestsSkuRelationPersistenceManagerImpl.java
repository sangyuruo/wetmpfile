/**
 * 
 */
package com.bill99.ebd.rip.persistence.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.domain.model.InterestsSkuRelation;
import com.bill99.ebd.rip.enums.AcquirerAbility;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.InterestsSkuRelationPersistenceManager;
import com.bill99.ebd.rip.persistence.adapter.InterestsSkuRelationPersistenceAdapter;
import com.bill99.ebd.rip.persistence.dao.InterestsSkuRelationDao;
import com.bill99.ebd.rip.persistence.model.InterestsSkuRelationPo;

/**
 * @author shuangye.liu
 * 
 * @since Jul 22, 2016
 */
public class InterestsSkuRelationPersistenceManagerImpl implements InterestsSkuRelationPersistenceManager {

    private InterestsSkuRelationDao interestsSkuRelationDao;

    @Autowired
    public void setInterestsSkuRelationDao(InterestsSkuRelationDao interestsSkuRelationDao) {
        this.interestsSkuRelationDao = interestsSkuRelationDao;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bill99.ebd.rip.persistence.InterestsSkuRelationPersistenceManager#findInterestsSkuRelation(java.lang.Integer,
     * java.lang.String)
     */
    @Override
    public List<InterestsSkuRelation> findInterestsSkuRelation(List<Integer> interestsIds, String merchantMemberCode,
            AcquirerAbility acquirerAbility) throws AppBizException {
        List<InterestsSkuRelationPo> interestsSkuRelationPos = this.interestsSkuRelationDao.findInterestsSkuRelation(
                interestsIds, merchantMemberCode, acquirerAbility.getIdentity());
        if (CollectionUtils.isEmpty(interestsSkuRelationPos)) {
            return null;
        }
        List<InterestsSkuRelation> interestsSkuRelations = new ArrayList<>();
        InterestsSkuRelationPersistenceAdapter adapter = new InterestsSkuRelationPersistenceAdapter();
        for (InterestsSkuRelationPo po : interestsSkuRelationPos) {
            InterestsSkuRelation interestsSkuRelation = new InterestsSkuRelation();
            adapter.outbound(po, interestsSkuRelation);
            interestsSkuRelations.add(interestsSkuRelation);
        }
        return interestsSkuRelations;
    }

    @Override
    public void createInterestsSkuRel(InterestsSkuRelationPo interestsSkuRelationPo) throws AppBizException {
        interestsSkuRelationDao.create(interestsSkuRelationPo);
    }

    @Override
    public void updateInterestsSkuRel(InterestsSkuRelationPo interestsSkuRelationPo) throws AppBizException {
        interestsSkuRelationDao.update(interestsSkuRelationPo, null);
    }

    @Override
    public Map<String, Object> pageQuery(String keywords, Integer interestsId, String memberCode, String ability,
            Integer pageIndex, Integer pageSize) throws AppBizException {
        Map<String, Object> paramterMap = new HashMap<String, Object>();
        paramterMap.put("keywords", keywords);
        paramterMap.put("interestsId", interestsId);
        paramterMap.put("memberCode", memberCode);
        paramterMap.put("acquirerAbility", ability);
        return interestsSkuRelationDao.pageQuery(paramterMap, pageIndex, pageSize);
    }
    
    @Override
    public void deleteById(Integer id) throws AppBizException {
        interestsSkuRelationDao.delete(id);
    }
    
    @Override
    public void deleteBySkuId(Integer interestsId, String skuId, String ability) throws AppBizException {
        Map<String, Object> paramterMap = new HashMap<String, Object>();
        paramterMap.put("skuId", skuId);
        paramterMap.put("interestsId", interestsId);
        paramterMap.put("acquirerAbility", ability);
        interestsSkuRelationDao.deleteBySkuId(paramterMap);
    };

    @Override
    public Map<String, Object> pageQueryByParamMap(Map<String, Object> paramMap, Integer pageIndex, Integer pageSize)
            throws AppBizException {
        Map<String, Object> paramterMap = new HashMap<String, Object>();
        paramterMap.put("keywords", paramMap.get("keywords"));
        paramterMap.put("interestsId", paramMap.get("interestsId"));
        paramterMap.put("memberCode", paramMap.get("memberCode"));
        paramterMap.put("skuDes", paramMap.get("skuDes"));
        return interestsSkuRelationDao.pageQueryInterestsSkuRelationDto(paramterMap, pageIndex, pageSize);
    }

    @Override
    public List<InterestsSkuRelation> findInterestsSkuRelation(Integer interestsId, AcquirerAbility acquirerAbility)
            throws AppBizException {
        List<Integer> interestsIds = new ArrayList<>();
        interestsIds.add(interestsId);
        return findInterestsSkuRelation(interestsIds, null, acquirerAbility);
    }
}
