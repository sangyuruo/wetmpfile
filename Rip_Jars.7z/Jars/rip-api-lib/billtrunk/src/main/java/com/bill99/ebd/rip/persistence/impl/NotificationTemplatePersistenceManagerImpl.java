package com.bill99.ebd.rip.persistence.impl;

import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.domain.model.NotificationTemplate;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.NotificationTemplatePersistenceManager;
import com.bill99.ebd.rip.persistence.adapter.NotificationTemplatePersistenceAdapter;
import com.bill99.ebd.rip.persistence.dao.NotificationTemplateDao;
import com.bill99.ebd.rip.persistence.model.NotificationTemplatePo;

public class NotificationTemplatePersistenceManagerImpl implements NotificationTemplatePersistenceManager {

	@Autowired
	NotificationTemplateDao notificationTemplateDao;

	NotificationTemplatePersistenceAdapter adapter = new NotificationTemplatePersistenceAdapter();

	@Override
	public Integer insertNotify(NotificationTemplate notificationTemplate) throws AppBizException {
		NotificationTemplatePo templatePo = new NotificationTemplatePo();
		adapter.inbound(notificationTemplate, templatePo);
		this.notificationTemplateDao.create(templatePo);
		return templatePo.getId();
	}

}
