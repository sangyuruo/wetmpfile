package com.bill99.ebd.rip.persistence.dao;

import java.util.List;
import java.util.Map;

import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.model.AlarmConfigPo;

/**
 * 权益活动预警
 * 
 * @author yangyang.yu
 * 
 * @since 2016-11-23
 */
public interface AlarmConfigDao extends CrudDao<AlarmConfigPo> {

    /**
     * 根据权益Id获取预警信息
     * 
     * @param bizId
     * @return
     * @throws AppBizException
     */
    List<AlarmConfigPo> getAlarmConfigByBizId(Map<String, Object> paratmters) throws AppBizException;

    /**
     * 根据活动id和类型修改报警次数
     * 
     * @param newPo
     * @param oldPo
     * @throws AppBizException
     */
    void updateAlarmThresholdInfo(AlarmConfigPo newPo, AlarmConfigPo oldPo) throws AppBizException;

    /**
     * 查询预警信息列表
     * 
     * @param paratmters
     * @return
     * @throws AppBizException
     */
    Map<String, Object> getAlarmConfigPages(Map<String, Object> paratmters, Integer pageIndex, Integer pageSize)
            throws AppBizException;

    /**
     * 根据主键Id获取预警信息
     * 
     * @param seqId
     * @return
     * @throws AppBizException
     */
    AlarmConfigPo getAlarmConfigBySeqId(Map<String, Object> paraMap) throws AppBizException;

    /**
     * 根据主键Id获取预警信息
     * 
     * @param seqId
     * @return
     * @throws AppBizException
     */
    AlarmConfigPo getAlarmConfigById(Map<String, Object> paraMap) throws AppBizException;

}
