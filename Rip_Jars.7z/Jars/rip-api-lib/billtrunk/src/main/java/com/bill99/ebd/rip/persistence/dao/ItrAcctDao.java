/**
 * 
 */
package com.bill99.ebd.rip.persistence.dao;

import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.model.ItrAcctPo;

/**
 * @author wei.wang.rd
 * 
 */
public interface ItrAcctDao extends CrudDao<ItrAcctPo> {

    /**
     * 根据会员编号查找资金属性
     * 
     * @param membercode
     * @throws AppBizExceptions
     */
    public ItrAcctPo getItrAcctByMembercode(String membercode) throws AppBizException;

    /**
     * 根据主键获取权益账户
     * 
     * @param membercode
     * @throws AppBizExceptions
     */
    public ItrAcctPo getItrAcct(Integer idItrAcct) throws AppBizException;

}
