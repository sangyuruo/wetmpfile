/**
 * 
 */
package com.bill99.ebd.rip.persistence;

import java.util.List;
import java.util.Map;

import com.bill99.ebd.rip.domain.model.InterestsStakeholder;
import com.bill99.ebd.rip.domain.model.StakeholderBudget;
import com.bill99.ebd.rip.domain.model.StakeholderWriteoffCreditline;
import com.bill99.ebd.rip.exception.AppBizException;

/**
 * @author shuangye.liu
 * 
 * @since Jun 12, 2016
 */
public interface InterestsStakeholderPersistenceManager {

    InterestsStakeholder findInterestsStakeholder(Integer interestsId) throws AppBizException;

    /**
     * 获取垫资方活动预算总额（充值记账）
     * 
     * @param membercode
     * @return
     * @throws AppBizException
     * @author jakoes.wu
     * @updatedate 2016年12月22日下午9:48:14
     */
    StakeholderBudget getStakeholderBudget(String membercode) throws AppBizException;

    /**
     * 获取垫资方核销资金总额度
     * 
     * @param membercode
     * @return
     * @throws AppBizException
     * @author jakoes.wu
     * @updatedate 2016年12月22日下午9:48:38
     */
    StakeholderWriteoffCreditline getStakeholderWriteoffCreditline(String membercode) throws AppBizException;

    /**
     * 获取权益垫资方信息列表
     * 
     * @param paratmters
     * @return
     * @throws AppBizException
     */
    List<InterestsStakeholder> queryInterestsStakeholder(Map<String, Object> paratmters) throws AppBizException;
}
