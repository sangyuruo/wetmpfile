/**
 *
 */
package com.bill99.ebd.rip.persistence.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.domain.model.AcquirerInterestsDto;
import com.bill99.ebd.rip.domain.model.FundStakeholder;
import com.bill99.ebd.rip.domain.model.Interests;
import com.bill99.ebd.rip.domain.model.InterestsAcquirerRelation;
import com.bill99.ebd.rip.domain.model.InterestsDto;
import com.bill99.ebd.rip.domain.model.InterestsPayMode;
import com.bill99.ebd.rip.domain.model.InterestsRiskConfiguration;
import com.bill99.ebd.rip.domain.model.InterestsRule;
import com.bill99.ebd.rip.domain.model.InterestsScenarioRelation;
import com.bill99.ebd.rip.domain.model.InterestsSkuRelation;
import com.bill99.ebd.rip.domain.model.InterestsStakeholder;
import com.bill99.ebd.rip.domain.model.NotificationConfiguration;
import com.bill99.ebd.rip.domain.model.NotificationTemplate;
import com.bill99.ebd.rip.domain.model.PercentRule;
import com.bill99.ebd.rip.domain.model.RandomRule;
import com.bill99.ebd.rip.domain.model.ReleaseCreditLine;
import com.bill99.ebd.rip.domain.model.TieredRule;
import com.bill99.ebd.rip.domain.model.VoucherBatch;
import com.bill99.ebd.rip.domain.model.VoucherBatchDetail;
import com.bill99.ebd.rip.domain.model.VoucherGenerateRule;
import com.bill99.ebd.rip.domain.model.VoucherWriteOffRule;
import com.bill99.ebd.rip.domain.model.WriteOffCreditLine;
import com.bill99.ebd.rip.enums.AcquirerAbility;
import com.bill99.ebd.rip.enums.AcquirerType;
import com.bill99.ebd.rip.enums.ActivityChangeStatusCmd;
import com.bill99.ebd.rip.enums.AwareType;
import com.bill99.ebd.rip.enums.CouponSendStatus;
import com.bill99.ebd.rip.enums.HoldScene;
import com.bill99.ebd.rip.enums.InterestsMediaType;
import com.bill99.ebd.rip.enums.InterestsStatus;
import com.bill99.ebd.rip.enums.VoucherGenerateType;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.InterestsPersistenceManager;
import com.bill99.ebd.rip.persistence.InterestsRelResolver;
import com.bill99.ebd.rip.persistence.NotificationConfigurationPersistenceManager;
import com.bill99.ebd.rip.persistence.adapter.FundStakeholderPersistenceAdapter;
import com.bill99.ebd.rip.persistence.adapter.InterestsAcquirerRelationPersistenceAdapter;
import com.bill99.ebd.rip.persistence.adapter.InterestsModelsAdaptHelper;
import com.bill99.ebd.rip.persistence.adapter.InterestsPayModePersistenceAdapter;
import com.bill99.ebd.rip.persistence.adapter.InterestsPersistenceAdapter;
import com.bill99.ebd.rip.persistence.adapter.InterestsRiskConfigurationPersistenceAdapter;
import com.bill99.ebd.rip.persistence.adapter.InterestsRulePersistenceAdapter;
import com.bill99.ebd.rip.persistence.adapter.InterestsScenarioRelationPersistenceAdapter;
import com.bill99.ebd.rip.persistence.adapter.InterestsSkuRelationPersistenceAdapter;
import com.bill99.ebd.rip.persistence.adapter.InterestsStakeholderPersistenceAdapter;
import com.bill99.ebd.rip.persistence.adapter.NotificationConfigurationPersistenceAdapter;
import com.bill99.ebd.rip.persistence.adapter.NotificationTemplatePersistenceAdapter;
import com.bill99.ebd.rip.persistence.adapter.PercentRulePersistenceAdapter;
import com.bill99.ebd.rip.persistence.adapter.RandomRulePersistenceAdapter;
import com.bill99.ebd.rip.persistence.adapter.ReleaseCreditLinePersistenceAdapter;
import com.bill99.ebd.rip.persistence.adapter.TieredRulePersistenceAdapter;
import com.bill99.ebd.rip.persistence.adapter.VoucherBatchPersistenceAdapter;
import com.bill99.ebd.rip.persistence.adapter.VoucherGenerateRulePersistenceAdapter;
import com.bill99.ebd.rip.persistence.adapter.VoucherWriteOffRulePersistenceAdapter;
import com.bill99.ebd.rip.persistence.adapter.WriteOffCreditLinePersistenceAdapter;
import com.bill99.ebd.rip.persistence.dao.AccountBalanceCreditLineDao;
import com.bill99.ebd.rip.persistence.dao.CreditLineWriteOffDao;
import com.bill99.ebd.rip.persistence.dao.FundStakeholderDao;
import com.bill99.ebd.rip.persistence.dao.InterestsAcquirerRelationDao;
import com.bill99.ebd.rip.persistence.dao.InterestsDao;
import com.bill99.ebd.rip.persistence.dao.InterestsPayModeDao;
import com.bill99.ebd.rip.persistence.dao.InterestsRiskConfigurationDao;
import com.bill99.ebd.rip.persistence.dao.InterestsRuleDao;
import com.bill99.ebd.rip.persistence.dao.InterestsScenarioRelationDao;
import com.bill99.ebd.rip.persistence.dao.InterestsSkuRelationDao;
import com.bill99.ebd.rip.persistence.dao.InterestsStakeholderDao;
import com.bill99.ebd.rip.persistence.dao.NotificationConfigurationDao;
import com.bill99.ebd.rip.persistence.dao.NotificationTemplateDao;
import com.bill99.ebd.rip.persistence.dao.PersistenceUpdateHelper;
import com.bill99.ebd.rip.persistence.dao.VoucherBatchDao;
import com.bill99.ebd.rip.persistence.dao.VoucherGeneratePropertyDao;
import com.bill99.ebd.rip.persistence.dao.VoucherGenerateRuleDao;
import com.bill99.ebd.rip.persistence.dao.VoucherWriteOffRuleDao;
import com.bill99.ebd.rip.persistence.model.AccountBalanceCreditLinePo;
import com.bill99.ebd.rip.persistence.model.CreditLineWriteOffPo;
import com.bill99.ebd.rip.persistence.model.FundStakeholderPo;
import com.bill99.ebd.rip.persistence.model.InterestsAcquirerRelationPo;
import com.bill99.ebd.rip.persistence.model.InterestsPayModePo;
import com.bill99.ebd.rip.persistence.model.InterestsPo;
import com.bill99.ebd.rip.persistence.model.InterestsRiskConfigurationPo;
import com.bill99.ebd.rip.persistence.model.InterestsRulePo;
import com.bill99.ebd.rip.persistence.model.InterestsScenarioRelationPo;
import com.bill99.ebd.rip.persistence.model.InterestsSkuRelationPo;
import com.bill99.ebd.rip.persistence.model.InterestsStakeholderPo;
import com.bill99.ebd.rip.persistence.model.NotificationConfigurationPo;
import com.bill99.ebd.rip.persistence.model.NotificationTemplatePo;
import com.bill99.ebd.rip.persistence.model.VoucherBatchDetailPo;
import com.bill99.ebd.rip.persistence.model.VoucherBatchPo;
import com.bill99.ebd.rip.persistence.model.VoucherGeneratePropertyPo;
import com.bill99.ebd.rip.persistence.model.VoucherGenerateRulePo;
import com.bill99.ebd.rip.persistence.model.VoucherWriteOffRulePo;
import com.bill99.ebd.rip.util.ApiUtils;
import com.bill99.ebd.rip.util.RestUtils;
import com.bill99.ebd.rip.util.RipTask;
import com.bill99.ebd.rip.util.ThreadLocalCacheHelper;

/**
 *
 *
 * @author shuangye.liu
 * @since Jun 13, 2016
 */
public class InterestsPersistenceManagerImpl implements InterestsPersistenceManager {

    private static final Logger logger = LoggerFactory.getLogger(InterestsPersistenceManagerImpl.class);

    private static final String KEY_ID = "id";

    // private static final Double REQUEST_LIST_SIZE = (double) 100;// 参数list最大长度

    private static final String KEY_INTERESTS_ID = "interestsId";

    private InterestsDao interestsDao;

    private InterestsRuleDao interestsRuleDao;

    private AccountBalanceCreditLineDao accountBalanceCreditLineDao;

    private CreditLineWriteOffDao creditLineWriteOffDao;

    private VoucherGenerateRuleDao voucherGenerateRuleDao;

    private InterestsStakeholderDao interestsStakeholderDao;

    private InterestsPayModeDao interestsPayModeDao;

    private InterestsRiskConfigurationDao interestsRiskConfigurationDao;

    private VoucherWriteOffRuleDao voucherWriteOffRuleDao;

    private VoucherGeneratePropertyDao voucherGeneratePropertyDao;

    private InterestsScenarioRelationDao interestsScenarioRelationDao;

    private InterestsAcquirerRelationDao interestsAcquirerRelationDao;

    private NotificationTemplateDao notificationTemplateDao;

    private NotificationConfigurationDao notificationConfigurationDao;

    private NotificationConfigurationPersistenceManager notificationConfigurationPersistenceManager;

    private FundStakeholderDao fundStakeholderDao;

    private VoucherBatchDao voucherBatchDao;

    private InterestsRelResolver interestsRelResolver;

    private InterestsSkuRelationDao interestsSkuRelationDao;

    // private VoucherBatchPersistenceManager voucherBatchPersistenceManager;

    // private VoucherBatchDetailPersistenceManager voucherBatchDetailPersistenceManager;

    public Map<String, Object> convert(Map<Object, Object> objMap) {
        Map<String, Object> map = new HashMap<String, Object>();
        for (Entry<Object, Object> obj : objMap.entrySet()) {
            String key = (String) obj.getKey();
            map.put(key, obj.getValue());
        }
        return map;
    }

    public List<Integer> convert2List(Set<Object> set) {
        List<Integer> list = new ArrayList<Integer>();
        for (Object obj : set) {
            Integer interestsId = (Integer) obj;
            list.add(interestsId);
        }
        return list;
    }

    private void createGenerateRule(InterestsPo interestsPo, VoucherGenerateRule generateRule) throws AppBizException {
        if (generateRule == null) {
            return;
        }
        VoucherGenerateRulePersistenceAdapter adapter = new VoucherGenerateRulePersistenceAdapter();
        VoucherGenerateRulePo po = new VoucherGenerateRulePo();
        adapter.inbound(generateRule, po);
        po.setInterestsId(interestsPo.getId());
        po.setCreateTime(new Date());
        po.setUpdateTime(new Date());
        this.voucherGenerateRuleDao.create(po);
        ThreadLocalCacheHelper.putPoRelation(interestsPo, po);
        generateRule.setId(po.getId());

        VoucherGenerateType type = generateRule.getType();
        switch (type) {
        case BASIC:
            VoucherWriteOffRule writeOffRule = generateRule.getWriteOffRule();
            this.createWriteOffRule(po, writeOffRule);
            writeOffRule.setId(writeOffRule.getId());
            break;
        case RANDOM:
            RandomRule randomRule = generateRule.getRandomRule();
            this.createRandomRule(po, randomRule);
            break;
        case TIERED:
            TieredRule tieredRule = generateRule.getTieredRule();
            this.createTieredRule(po, tieredRule);
            break;
        case PERCENT:
            PercentRule percentRule = generateRule.getPercentRule();
            this.createPercentRule(po, percentRule);
            break;
        default:
            throw new IllegalArgumentException("Invalid value: " + type);
        }
    }

    private void createHoldVoucherBatch(InterestsPo interestsPo, VoucherBatch voucherBatch) throws AppBizException {
        if (voucherBatch == null) {
            return;
        }
        VoucherBatchPo voucherBatchPo = new VoucherBatchPo();
        voucherBatchPo.setInterestsId(interestsPo.getId());
        voucherBatchPo.setHoldTime(voucherBatch.getHoldTime());
        voucherBatchPo.setStatus(CouponSendStatus.INIT.getId());
        voucherBatchPo.setMemo(voucherBatch.getMemo());
        voucherBatchPo.setCreateTime(new Date());
        voucherBatchPo.setUpdateTime(new Date());
        this.voucherBatchDao.create(voucherBatchPo);
    }

    @Override
    public void createInterests(Interests interests) throws AppBizException {
        InterestsRulePo interestsRulePo = this.createInterestsRule(interests.getInterestsRule());
        InterestsPo interestsPo = this.createInterestsPo(interests, interestsRulePo);
        interests.setId(interestsPo.getId());
        this.createRiskConfigurations(interestsPo, interestsRulePo,
                interests.getInterestsRule().getRiskConfigurations());
        this.createGenerateRule(interestsPo, interests.getGenerateRule());
        this.createInterestsScenarioRelation(interestsPo, interests.getScenarioRelation());
        this.createInterestsPayModes(interestsPo, interests);
        this.createInterestsStakeHolder(interestsPo, interests.getStakeholder());
        this.saveOrUpdateInterestsInterestsSkuRelation(interestsPo, interests.getInterestsSkuRelation());
        this.createInterestsAcquirerRelation(interestsPo, interests.getInterestsAcquirerRelations());
        this.createNotificationConfiguration(interestsPo, interests.getNotificationConfigurations());
        this.createHoldVoucherBatch(interestsPo, interests.getVoucherBatch());// 待权益生效后 到指定时间发券
    }

    // 创建权益受理方关系
    private void createInterestsAcquirerRelation(InterestsPo interestsPo,
            List<InterestsAcquirerRelation> interestsAcquirerRelations) throws AppBizException {
        if (interestsAcquirerRelations == null || interestsAcquirerRelations.isEmpty()) {
            return;
        }
        InterestsAcquirerRelationPersistenceAdapter interestsAcquirerRelationPersistenceAdapter = new InterestsAcquirerRelationPersistenceAdapter();
        List<InterestsAcquirerRelationPo> pos = new ArrayList<InterestsAcquirerRelationPo>();
        if (interestsAcquirerRelations != null && interestsAcquirerRelations.size() > 0) {
            for (InterestsAcquirerRelation interestsAcquirerRelation : interestsAcquirerRelations) {
                InterestsAcquirerRelationPo interestsAcquirerRelationPo = new InterestsAcquirerRelationPo();
                interestsAcquirerRelationPersistenceAdapter.inbound(interestsAcquirerRelation,
                        interestsAcquirerRelationPo);
                interestsAcquirerRelationPo.setInterestsId(interestsPo.getId());
                interestsAcquirerRelationPo.setCrtTime(new Date());
                interestsAcquirerRelationPo.setUptTime(new Date());
                pos.add(interestsAcquirerRelationPo);
            }
            List<InterestsAcquirerRelationPo> copies = new ArrayList<InterestsAcquirerRelationPo>();
            PersistenceUpdateHelper.updatePos(pos, copies, this.interestsAcquirerRelationDao);
            ThreadLocalCacheHelper.putPoRelations(interestsPo, pos);
        }
    }

    private void createInterestsPayModes(InterestsPo interestsPo, Interests interests) throws AppBizException {
        if (interests == null) {
            return;
        }
        List<InterestsPayMode> holdPayModes = interests.getPayModes();
        List<InterestsPayMode> writeOffPayModes = interests.getWriteOffPayModes();
        InterestsPayModePersistenceAdapter adapter = new InterestsPayModePersistenceAdapter();
        List<InterestsPayModePo> pos = new ArrayList<InterestsPayModePo>();
        // 领用支付方式
        if (CollectionUtils.isNotEmpty(interests.getPayModes())) {
            for (InterestsPayMode payMode : holdPayModes) {
                InterestsPayModePo po = new InterestsPayModePo();
                adapter.inbound(payMode, po);
                po.setInterestsId(interestsPo.getId());
                pos.add(po);
            }
        }

        // 核销支付方式
        if (CollectionUtils.isNotEmpty(interests.getWriteOffPayModes())) {
            for (InterestsPayMode payMode : writeOffPayModes) {
                InterestsPayModePo po = new InterestsPayModePo();
                adapter.inbound(payMode, po);
                po.setInterestsId(interestsPo.getId());
                pos.add(po);
            }
        }

        logger.info("@@@@@@@==============pos", RestUtils.objectToJSONString(pos));
        List<InterestsPayModePo> copies = new ArrayList<InterestsPayModePo>();
        PersistenceUpdateHelper.updatePos(pos, copies, this.interestsPayModeDao);
        ThreadLocalCacheHelper.putPoRelations(interestsPo, pos);
    }

    private InterestsPo createInterestsPo(Interests interests, InterestsRulePo interestsRulePo) throws AppBizException {
        InterestsPersistenceAdapter adapter = new InterestsPersistenceAdapter();
        InterestsPo po = new InterestsPo();
        adapter.inbound(interests, po);
        po.setRuleId(interestsRulePo.getRuleId());
        po.setCreateTime(new Date());
        po.setUpdateTime(new Date());
        this.interestsDao.create(po);
        interests.setId(po.getId());
        ThreadLocalCacheHelper.putPo(po);
        ThreadLocalCacheHelper.putPoRelation(po, interestsRulePo);
        return po;
    }

    private InterestsRulePo createInterestsRule(InterestsRule interestsRule) throws AppBizException {
        InterestsRulePersistenceAdapter interestsRulePersistenceAdapter = new InterestsRulePersistenceAdapter();
        InterestsRulePo po = new InterestsRulePo();
        interestsRulePersistenceAdapter.inbound(interestsRule, po);
        po.setCreateTime(new Date());
        po.setUpdateTime(new Date());
        this.interestsRuleDao.create(po);
        interestsRule.setRuleId(po.getRuleId());
        return po;
    }

    private void createInterestsScenarioRelation(InterestsPo interestsPo, InterestsScenarioRelation scenarioRelation)
            throws AppBizException {
        if (scenarioRelation == null) {
            return;
        }
        InterestsScenarioRelationPersistenceAdapter adapter = new InterestsScenarioRelationPersistenceAdapter();
        InterestsScenarioRelationPo po = new InterestsScenarioRelationPo();
        adapter.inbound(scenarioRelation, po);
        po.setInterestsId(interestsPo.getId());
        po.setCreateTime(new Date());
        po.setUpdateTime(new Date());

        AccountBalanceCreditLinePo releaseCreditLine = this.createReleaseCreditLine(po,
                scenarioRelation.getReleaseCreditLine());
        if (releaseCreditLine != null) {
            scenarioRelation.getReleaseCreditLine().setId(releaseCreditLine.getId());
            po.setBalanceAccountId(releaseCreditLine.getId());
        }
        CreditLineWriteOffPo writeOffCreditLine = this.createWriteOffCreditLine(po,
                scenarioRelation.getWriteOffCreditLine());
        if (writeOffCreditLine != null) {
            scenarioRelation.getWriteOffCreditLine().setId(writeOffCreditLine.getIdCreditLineWriteoff());
            po.setCreditLineWriteoffId(writeOffCreditLine.getIdCreditLineWriteoff());
        }

        if (po.getBalanceAccountId() == null && po.getCreditLineWriteoffId() == null) {
            logger.info("@@both hold credieline and writeoff creditline is empty,ignore scenarioRelation persistence.");
            return;
        }
        this.interestsScenarioRelationDao.create(po);
        ThreadLocalCacheHelper.putPoRelation(interestsPo, po);
        ThreadLocalCacheHelper.putPoRelation(po, releaseCreditLine);
        ThreadLocalCacheHelper.putPoRelation(po, writeOffCreditLine);
        scenarioRelation.setId(po.getId());
    }

    // 创建活动垫资方
    private void createInterestsStakeHolder(InterestsPo interestsPo, InterestsStakeholder stakeholder)
            throws AppBizException {
        if (stakeholder == null) {
            return;
        }
        InterestsStakeholderPersistenceAdapter adapter = new InterestsStakeholderPersistenceAdapter();
        FundStakeholderPersistenceAdapter fspAdapter = new FundStakeholderPersistenceAdapter();
        InterestsStakeholderPo po = new InterestsStakeholderPo();
        adapter.inbound(stakeholder, po);
        po.setInterestsId(interestsPo.getId());
        po.setCreateDate(new Date());
        po.setUpdateDate(new Date());
        this.interestsStakeholderDao.create(po);
        FundStakeholder fundStakeholder = stakeholder.getFundStakeholder();
        if (null != fundStakeholder) {
            FundStakeholderPo fundStakeholderPo = this.fundStakeholderDao
                    .getFundStakeholderByMembercode(fundStakeholder.getMembercode());
            if (null == fundStakeholderPo) {
                fundStakeholderPo = new FundStakeholderPo();
                fspAdapter.inbound(fundStakeholder, fundStakeholderPo);
                fundStakeholderPo.setCreateTime(new Date());
                fundStakeholderPo.setUpdateTime(new Date());
                this.fundStakeholderDao.create(fundStakeholderPo);
            }
        }
        ThreadLocalCacheHelper.putPoRelation(interestsPo, po);
        stakeholder.setId(po.getId());
    }

    // 创建通知配置
    private void createNotificationConfiguration(InterestsPo interestsPo,
            List<NotificationConfiguration> notificationConfigurations) throws AppBizException {
        if (notificationConfigurations == null || notificationConfigurations.isEmpty()) {
            return;
        }
        NotificationConfigurationPersistenceAdapter ncpAdapter = new NotificationConfigurationPersistenceAdapter();
        NotificationTemplatePersistenceAdapter ntpAdapter = new NotificationTemplatePersistenceAdapter();
        if (null != notificationConfigurations && notificationConfigurations.size() > 0) {
            List<NotificationConfigurationPo> pos = new ArrayList<NotificationConfigurationPo>();
            for (NotificationConfiguration notificationConfiguration : notificationConfigurations) {
                NotificationConfigurationPo po = new NotificationConfigurationPo();
                ncpAdapter.inbound(notificationConfiguration, po);
                NotificationTemplate notificationTemplate = notificationConfiguration.getNotificationTemplate();
                NotificationTemplatePo notificationTemplatePo = new NotificationTemplatePo();
                ntpAdapter.inbound(notificationTemplate, notificationTemplatePo);
                this.notificationTemplateDao.create(notificationTemplatePo);
                po.setTplId(notificationTemplatePo.getId());
                po.setBizId(interestsPo.getId());
                pos.add(po);
            }
            List<NotificationConfigurationPo> copies = new ArrayList<NotificationConfigurationPo>();
            PersistenceUpdateHelper.updatePos(pos, copies, this.notificationConfigurationDao);
            ThreadLocalCacheHelper.putPoRelations(interestsPo, pos);
        }
    }

    private void createPercentRule(VoucherGenerateRulePo generateRulePo, PercentRule percentRule)
            throws AppBizException {
        PercentRulePersistenceAdapter adapter = new PercentRulePersistenceAdapter();
        List<VoucherGeneratePropertyPo> pos = new ArrayList<VoucherGeneratePropertyPo>();
        adapter.inbound(percentRule, pos);
        for (VoucherGeneratePropertyPo po : pos) {
            po.setGenerateRuleId(generateRulePo.getId());
        }
        List<VoucherGeneratePropertyPo> copies = new ArrayList<VoucherGeneratePropertyPo>();
        PersistenceUpdateHelper.updatePos(pos, copies, this.voucherGeneratePropertyDao);
        ThreadLocalCacheHelper.putPoRelations(generateRulePo, pos);
    }

    private void createRandomRule(VoucherGenerateRulePo generateRulePo, RandomRule randomRule) throws AppBizException {
        RandomRulePersistenceAdapter adapter = new RandomRulePersistenceAdapter();
        List<VoucherGeneratePropertyPo> pos = new ArrayList<VoucherGeneratePropertyPo>();
        adapter.inbound(randomRule, pos);
        for (VoucherGeneratePropertyPo po : pos) {
            po.setGenerateRuleId(generateRulePo.getId());
        }
        List<VoucherGeneratePropertyPo> copies = new ArrayList<VoucherGeneratePropertyPo>();
        PersistenceUpdateHelper.updatePos(pos, copies, this.voucherGeneratePropertyDao);
        ThreadLocalCacheHelper.putPoRelations(generateRulePo, pos);
    }

    private AccountBalanceCreditLinePo createReleaseCreditLine(InterestsScenarioRelationPo scenarioRelationPo,
            ReleaseCreditLine releaseCreditLine) throws AppBizException {
        if (releaseCreditLine == null) {
            return null;
        }
        ReleaseCreditLinePersistenceAdapter adapter = new ReleaseCreditLinePersistenceAdapter();
        AccountBalanceCreditLinePo po = new AccountBalanceCreditLinePo();
        adapter.inbound(releaseCreditLine, po);
        po.setInterestsId(scenarioRelationPo.getInterestsId());
        po.setCreateTime(new Date());
        po.setUpdateTime(new Date());
        this.accountBalanceCreditLineDao.create(po);
        return po;
    }

    private void createRiskConfigurations(InterestsPo interestsPo, InterestsRulePo interetsRulePo,
            List<InterestsRiskConfiguration> riskConfigurations) throws AppBizException {
        if (riskConfigurations == null || riskConfigurations.isEmpty()
                || InterestsMediaType.FUND == InterestsMediaType.fromId(interestsPo.getInterestsMediaType())) {
            return;
        }
        InterestsRiskConfigurationPersistenceAdapter adapter = new InterestsRiskConfigurationPersistenceAdapter();
        List<InterestsRiskConfigurationPo> pos = new ArrayList<InterestsRiskConfigurationPo>();
        for (InterestsRiskConfiguration riskConfiguration : riskConfigurations) {
            InterestsRiskConfigurationPo po = new InterestsRiskConfigurationPo();
            adapter.inbound(riskConfiguration, po);
            po.setInterestsId(interestsPo.getId());
            pos.add(po);
        }

        List<InterestsRiskConfigurationPo> copies = new ArrayList<InterestsRiskConfigurationPo>();

        /*
         * if (pos.size() != copies.size()) { throw new UnsupportedOperationException(); }
         */
        PersistenceUpdateHelper.updatePos(pos, copies, this.interestsRiskConfigurationDao);
        ThreadLocalCacheHelper.putPoRelations(interetsRulePo, pos);
    }

    private void createTieredRule(VoucherGenerateRulePo generateRulePo, TieredRule tieredRule) throws AppBizException {
        TieredRulePersistenceAdapter adapter = new TieredRulePersistenceAdapter();
        List<VoucherGeneratePropertyPo> pos = new ArrayList<VoucherGeneratePropertyPo>();
        adapter.inbound(tieredRule, pos);
        for (VoucherGeneratePropertyPo po : pos) {
            po.setGenerateRuleId(generateRulePo.getId());
        }

        List<VoucherGeneratePropertyPo> copies = new ArrayList<VoucherGeneratePropertyPo>();

        PersistenceUpdateHelper.updatePos(pos, copies, this.voucherGeneratePropertyDao);
        ThreadLocalCacheHelper.putPoRelations(generateRulePo, pos);
    }

    private VoucherBatchPo createVoucherBatch(InterestsPo interestsPo, List<VoucherBatchDetail> voucherBatchDetails)
            throws AppBizException {
        VoucherBatchPo voucherBatchPo = new VoucherBatchPo();
        voucherBatchPo.setInterestsId(interestsPo.getId());
        voucherBatchPo.setHoldTime(interestsPo.getHoldEnableDate());
        voucherBatchPo.setStatus(CouponSendStatus.INIT.getId());
        voucherBatchPo.setTotal(voucherBatchDetails.size());
        voucherBatchPo.setMemo("刷卡即会员操作.interestsId:" + interestsPo.getId());
        voucherBatchPo.setCreateTime(new Date());
        voucherBatchPo.setUpdateTime(new Date());
        // voucherBatchPersistenceManager.createVoucherBatch(voucherBatchPo);
        return voucherBatchPo;
    }

    private void createVoucherBatchDetail(InterestsPo interestsPo, List<VoucherBatchDetail> voucherBatchDetails,
            VoucherBatchPo voucherBatchPo) throws AppBizException {
        for (int i = 0; i < voucherBatchDetails.size(); i++) {
            VoucherBatchDetailPo voucherBatchDetailPo = new VoucherBatchDetailPo();
            voucherBatchDetailPo.setBatchId(voucherBatchPo.getId());
            voucherBatchDetailPo.setSequenceId(i + 1);
            voucherBatchDetailPo.setInterestsId(interestsPo.getId());
            voucherBatchDetailPo.setConsumerMemberCode(voucherBatchDetails.get(i).getConsumerMemberCode());
            voucherBatchDetailPo.setMerchantMemberCode(interestsPo.getIssuerId());
            voucherBatchDetailPo.setOrderAmount(voucherBatchDetails.get(i).getOrderAmount());
            voucherBatchDetailPo.setHoldScene(interestsPo.getHoldScene());
            voucherBatchDetailPo
                    .setMemo("刷卡即会员操作.interestsId:" + interestsPo.getId() + ",batchId:" + voucherBatchPo.getId());
            voucherBatchDetailPo.setCreateTime(new Date());
            voucherBatchDetailPo.setUpdateTime(new Date());
            // voucherBatchDetailPersistenceManager.createVoucherBatchDetail(voucherBatchDetailPo);
        }
    }

    private CreditLineWriteOffPo createWriteOffCreditLine(InterestsScenarioRelationPo scenarioRelationPo,
            WriteOffCreditLine writeOffCreditLine) throws AppBizException {
        if (writeOffCreditLine == null) {
            return null;
        }
        WriteOffCreditLinePersistenceAdapter adapter = new WriteOffCreditLinePersistenceAdapter();
        CreditLineWriteOffPo po = new CreditLineWriteOffPo();
        adapter.inbound(writeOffCreditLine, po);
        po.setInterestsId(scenarioRelationPo.getInterestsId());
        po.setCreateTime(new Date());
        po.setUpdateTime(new Date());
        this.creditLineWriteOffDao.create(po);
        return po;
    }

    private void createWriteOffRule(VoucherGenerateRulePo generateRulePo, VoucherWriteOffRule writeOffRule)
            throws AppBizException {
        VoucherWriteOffRulePersistenceAdapter adapter = new VoucherWriteOffRulePersistenceAdapter();
        VoucherWriteOffRulePo po = new VoucherWriteOffRulePo();
        adapter.inbound(writeOffRule, po);
        po.setGenerateRuleId(generateRulePo.getId());
        po.setCreateTime(new Date());
        po.setUpdateTime(new Date());
        this.voucherWriteOffRuleDao.create(po);
        ThreadLocalCacheHelper.putPoRelation(generateRulePo, po);
    }

    private void deleteVoucherBatchAndDetail(InterestsPo interestsPo) throws AppBizException {
        List<VoucherBatchPo> voucherBatchPoList = null;
        // voucherBatchPersistenceManager.queryByInterestAndStatus(interestsPo.getId(),CouponSendStatus.INIT.getId());

        if (voucherBatchPoList.size() > 0 && voucherBatchPoList != null) {
            for (int i = 0; i < voucherBatchPoList.size(); i++) {
                Integer batchId = voucherBatchPoList.get(i).getId();
                // delete voucher batch detail
                // voucherBatchPersistenceManager.deleteByBatchId(batchId);

                // delete voucher batch detail
                List<VoucherBatchDetailPo> tempVoucherBatchDetails = null;
                // voucherBatchDetailPersistenceManager.selectVoucherBatchByBatchNo(batchId,0,REQUEST_LIST_SIZE.intValue());
                if (tempVoucherBatchDetails != null && tempVoucherBatchDetails.size() > 0) {
                    for (VoucherBatchDetailPo voucherBatchDetailPo : tempVoucherBatchDetails) {
                        // voucherBatchDetailPersistenceManager.deleteVoucherBatchDetailById(voucherBatchDetailPo.getId());
                    }
                }
            }
        }
    }

    @Override
    public List<AcquirerInterestsDto> findAcquirerInterestsDto(String merchantMemberCode) throws AppBizException {
        List<Map<String, Object>> acquirerInterestsMapList = this.interestsDao
                .findAcquirerInterests(merchantMemberCode);
        if (CollectionUtils.isEmpty(acquirerInterestsMapList)) {
            return Collections.emptyList();
        }
        Map<Integer, AcquirerInterestsDto> map = new HashMap<Integer, AcquirerInterestsDto>();
        for (Map<String, Object> acquirerInterestsMap : acquirerInterestsMapList) {
            Integer interestsId = MapUtils.getInteger(acquirerInterestsMap, "ID");
            if (interestsId == null) {
                continue;
            }
            AcquirerInterestsDto acquirerInterestsDto = map.get(interestsId);
            if (null == acquirerInterestsDto) {
                acquirerInterestsDto = new AcquirerInterestsDto();
                acquirerInterestsDto.setAwareType(MapUtils.getString(acquirerInterestsMap, "AWARE_TYPE"));
                acquirerInterestsDto.setEnableDate((Date) acquirerInterestsMap.get("ENABLE_DATE"));
                acquirerInterestsDto.setExpireDate((Date) acquirerInterestsMap.get("EXP_DATE"));
                acquirerInterestsDto.setHoldScene(MapUtils.getString(acquirerInterestsMap, "HOLD_SCENE"));
                acquirerInterestsDto.setId(interestsId);
                acquirerInterestsDto.setInstructions(MapUtils.getString(acquirerInterestsMap, "INSTRUCTIONS"));
                acquirerInterestsDto.setInterestsName(MapUtils.getString(acquirerInterestsMap, "INTERESTS_NAME"));
                acquirerInterestsDto.setIssuerId(MapUtils.getString(acquirerInterestsMap, "ISSUER_ID"));
                map.put(interestsId, acquirerInterestsDto);
            }
            Integer acquirerAbility = MapUtils.getInteger(acquirerInterestsMap, "ACQUIRER_ABILITY");
            if (null == acquirerAbility) {
                continue;
            }
            if (acquirerAbility == 2) {
                acquirerInterestsDto.setWriteoffAbility(true);
            } else if (acquirerAbility == 1) {
                acquirerInterestsDto.setHoldAbility(true);
            }
        }
        return new ArrayList<AcquirerInterestsDto>(map.values());
    }

    @Override
    public List<Interests> findInterests(final String merchantMemberCode, final AcquirerAbility ability,
            final AwareType awareType, final HoldScene holdScene) throws AppBizException {
        String holdSceneIdentity = holdScene == null ? null : holdScene.getIdentity();
        // haipeng.cheng begin
        return this.interestsRelResolver.getInterestsFromCache(merchantMemberCode, ability.getIdentity(),
                awareType.getId(), holdSceneIdentity, new RipTask<List<Interests>>() {
                    @Override
                    public List<Interests> run() throws AppBizException {
                        return InterestsPersistenceManagerImpl.this.findInterestsFromDB(merchantMemberCode, ability,
                                awareType, holdScene);
                    }
                });
    }

    @Override
    public List<Interests> findInterestsByActivityId(Integer activityId) throws AppBizException {
        VoucherBatchPersistenceAdapter vbpa = new VoucherBatchPersistenceAdapter();
        List<Map<String, Object>> interestsMaps = this.interestsDao.findInterestsByActivityId(activityId);

        if (CollectionUtils.isEmpty(interestsMaps)) {
            return null;
        }

        List<Integer> interestsIds = new ArrayList<>();
        for (Map<String, Object> interestsMap : interestsMaps) {
            Integer interestsId = (Integer) interestsMap.get(KEY_ID);
            interestsIds.add(interestsId);
        }

        // key: interestsId, value: generateRuleMap
        Map<Integer, Map<String, Object>> voucherGenerateRuleMap = new HashMap<>();
        List<Map<String, Object>> generateRuleMaps = this.voucherGenerateRuleDao.findVoucherGenerateRules(interestsIds);
        if (CollectionUtils.isNotEmpty(generateRuleMaps)) {
            for (Map<String, Object> generateRuleMap : generateRuleMaps) {
                Integer interestsId = (Integer) generateRuleMap.get(KEY_INTERESTS_ID);
                voucherGenerateRuleMap.put(interestsId, generateRuleMap);
            }
        }

        InterestsModelsAdaptHelper adaptHelper = new InterestsModelsAdaptHelper();
        List<Interests> interestsList = new ArrayList<>();
        for (Map<String, Object> interestsMap : interestsMaps) {
            Integer interestsId = (Integer) interestsMap.get(KEY_ID);
            Map<String, Object> generateRuleMap = voucherGenerateRuleMap.get(interestsId);
            if (!CollectionUtils.sizeIsEmpty(generateRuleMap)) {
                interestsMap.putAll(generateRuleMap);
            }
            Interests interests = adaptHelper.outboundInterests(interestsMap);
            List<NotificationConfiguration> notificationConfiguration = this.notificationConfigurationPersistenceManager
                    .findNotificationConfiguration(interestsId);
            interests.setNotificationConfigurations(notificationConfiguration);
            VoucherBatchPo voucherBatchPo = this.voucherBatchDao.getVoucherBatchByInterestsId(interestsId);
            if (null != voucherBatchPo) {
                VoucherBatch voucherBatch = new VoucherBatch();
                vbpa.outbound(voucherBatchPo, voucherBatch);
                interests.setVoucherBatch(voucherBatch);
            }
            interestsList.add(interests);
        }
        return interestsList;
    }

    /*
     * (non-Javadoc)
     *
     * @see com.bill99.ebd.rip.persistence.InterestsPersistenceManager#findInterests(java.lang.String,
     * com.bill99.ebd.rip.enums.AcquirerAbility, com.bill99.ebd.rip.enums.AwareType)
     */
    @Override
    public List<InterestsDto> findInterestsDto(String merchantMemberCode, AcquirerAbility ability, AwareType awareType)
            throws AppBizException {
        return this.interestsDao.findInterestsDto(merchantMemberCode, ability.getIdentity(), awareType.getId());
    }

    private List<Interests> findInterestsFromDB(String merchantMemberCode, AcquirerAbility ability, AwareType awareType,
            HoldScene holdScene) throws AppBizException {
        String holdSceneIdentity = holdScene == null ? null : holdScene.getIdentity();

        List<Map<String, Object>> interestsMaps = this.interestsDao.findInterests(merchantMemberCode,
                ability.getIdentity(), awareType.getId(), holdSceneIdentity);

        if (CollectionUtils.isEmpty(interestsMaps)) {
            return null;
        }

        List<Integer> interestsIds = new ArrayList<>();
        for (Map<String, Object> interestsMap : interestsMaps) {
            Integer interestsId = (Integer) interestsMap.get(KEY_ID);
            interestsIds.add(interestsId);
        }

        // key: interestsId, value: generateRuleMap
        Map<Integer, Map<String, Object>> voucherGenerateRuleMap = new HashMap<>();
        // List<Map<String, Object>> generateRuleMaps =
        // this.voucherGenerateRuleDao.findVoucherGenerateRules(interestsIds);
        List<Map<String, Object>> generateRuleMaps = this.voucherGenerateRuleDao.findVoucherGenerateRules(interestsIds);
        if (CollectionUtils.isNotEmpty(generateRuleMaps)) {
            for (Map<String, Object> generateRuleMap : generateRuleMaps) {
                Integer interestsId = (Integer) generateRuleMap.get(KEY_INTERESTS_ID);
                voucherGenerateRuleMap.put(interestsId, generateRuleMap);
            }
        }

        InterestsModelsAdaptHelper adaptHelper = new InterestsModelsAdaptHelper();
        List<Interests> interestsList = new ArrayList<>();
        for (Map<String, Object> interestsMap : interestsMaps) {
            Integer interestsId = (Integer) interestsMap.get(KEY_ID);
            Map<String, Object> generateRuleMap = voucherGenerateRuleMap.get(interestsId);
            if (!CollectionUtils.sizeIsEmpty(generateRuleMap)) {
                interestsMap.putAll(generateRuleMap);
            }
            interestsList.add(adaptHelper.outboundInterests(interestsMap));
        }

        return interestsList;
    }

    @Override
    public Map<String, Integer> findInterestsIds(List<String> oids) throws AppBizException {
        return this.interestsDao.findInterestsIds(oids);
    }

    /*
     * (non-Javadoc)
     *
     * @see com.bill99.ebd.rip.persistence.InterestsPersistenceManager#findInterestsRule(java.lang.Integer)
     */
    @SuppressWarnings("unchecked")
    @Override
    public InterestsRule findInterestsRule(Integer interestsId) throws AppBizException {
        Map<String, Object> interestsRuleObjectsMap = this.interestsRuleDao.findByInterestsId(interestsId);
        if (CollectionUtils.sizeIsEmpty(interestsRuleObjectsMap)) {
            return null;
        }

        InterestsRulePo interestsRulePo = (InterestsRulePo) interestsRuleObjectsMap.get("interestsRule");
        List<InterestsRiskConfigurationPo> riskConfigurationPos = (List<InterestsRiskConfigurationPo>) interestsRuleObjectsMap
                .get("interestsRiskConfiguration");
        InterestsModelsAdaptHelper adaptHelper = new InterestsModelsAdaptHelper();
        return adaptHelper.outboundInterestsRule(interestsRulePo, riskConfigurationPos);
    }

    @Override
    public List<InterestsAcquirerRelation> findRelatedAcquirerRelation(Integer interestsId) throws AppBizException {
        List<InterestsAcquirerRelation> iarList = new ArrayList<InterestsAcquirerRelation>();
        InterestsAcquirerRelationPersistenceAdapter iarpAdapter = new InterestsAcquirerRelationPersistenceAdapter();
        List<InterestsAcquirerRelationPo> acquirerRelationPoList = this.interestsAcquirerRelationDao
                .findInterestsAcquirerByInterestsId(interestsId);
        for (InterestsAcquirerRelationPo acquirerRelationPo : acquirerRelationPoList) {
            InterestsAcquirerRelation interestsAcquirerRelation = new InterestsAcquirerRelation();
            iarpAdapter.outbound(acquirerRelationPo, interestsAcquirerRelation);
            iarList.add(interestsAcquirerRelation);
        }
        return iarList;
    }

    /*
     * (non-Javadoc)
     *
     * @see com.bill99.ebd.rip.persistence.InterestsPersistenceManager#getInterestsById(java.lang.Integer)
     */
    @Override
    public Interests getInterestsById(Integer interestsId) throws AppBizException {
        Map<String, Object> interestsObjectsMap = this.interestsDao.getInterests(interestsId);
        if (CollectionUtils.sizeIsEmpty(interestsObjectsMap)) {
            return null;
        }
        List<Map<String, Object>> voucherGenerateRuleObjectsMaps = this.voucherGenerateRuleDao
                .findVoucherGenerateRules(Arrays.asList(interestsId));
        if (CollectionUtils.isNotEmpty(voucherGenerateRuleObjectsMaps)) {
            interestsObjectsMap.putAll(voucherGenerateRuleObjectsMaps.iterator().next());
        }
        InterestsModelsAdaptHelper adaptHelper = new InterestsModelsAdaptHelper();
        return adaptHelper.outboundInterests(interestsObjectsMap);
    }

    /*
     * (non-Javadoc)
     *
     * @see com.bill99.ebd.rip.persistence.InterestsPersistenceManager#getInterestsById(java.lang.Integer)
     */
    @Override
    public Interests getInterestsByIdAndIssuerId(Integer interestsId, String issuerId) throws AppBizException {
        Map<String, Object> interestsObjectsMap = this.interestsDao.getIssuerInterests(interestsId, issuerId);
        if (CollectionUtils.sizeIsEmpty(interestsObjectsMap)) {
            return null;
        }
        List<Map<String, Object>> voucherGenerateRuleObjectsMaps = this.voucherGenerateRuleDao
                .findVoucherGenerateRules(Arrays.asList(interestsId));
        if (CollectionUtils.isNotEmpty(voucherGenerateRuleObjectsMaps)) {
            interestsObjectsMap.putAll(voucherGenerateRuleObjectsMaps.iterator().next());
        }

        InterestsModelsAdaptHelper adaptHelper = new InterestsModelsAdaptHelper();
        return adaptHelper.outboundInterests(interestsObjectsMap);
    }

    @Override
    public Interests getMerchantAcquirableInterests(Integer interestsId, String merchantMemberCode,
            AcquirerAbility ability, HoldScene holdScene) throws AppBizException {
        String holdSceneString = null;
        if (holdScene != null) {
            holdSceneString = holdScene.getIdentity();
        }
        Map<String, Object> interestsObjectsMap = this.interestsDao.getMerchantAcquirableInterests(interestsId,
                merchantMemberCode, ability.getIdentity(), holdSceneString);
        if (CollectionUtils.sizeIsEmpty(interestsObjectsMap)) {
            return null;
        }

        List<Map<String, Object>> voucherGenerateRuleObjectsMaps = this.voucherGenerateRuleDao
                .findVoucherGenerateRules(Arrays.asList(interestsId));
        if (CollectionUtils.isNotEmpty(voucherGenerateRuleObjectsMaps)) {
            interestsObjectsMap.putAll(voucherGenerateRuleObjectsMaps.iterator().next());
        }

        InterestsModelsAdaptHelper adaptHelper = new InterestsModelsAdaptHelper();
        return adaptHelper.outboundInterests(interestsObjectsMap);
    }

    private void saveOrUpdateInterestsAcquirerRels(InterestsPo interestsPo,
            List<InterestsAcquirerRelation> interestsAcquirers) throws AppBizException {
        if (interestsAcquirers != null) {
            List<InterestsAcquirerRelationPo> pos = this.interestsAcquirerRelationDao
                    .findInterestsAcquirerByInterestsId(interestsPo.getId());
            InterestsAcquirerRelationPersistenceAdapter adapter = new InterestsAcquirerRelationPersistenceAdapter();
            Map<String, Integer> acquirerIds = new HashMap<String, Integer>();
            // delete not clude
            for (InterestsAcquirerRelationPo tpo : pos) {
                acquirerIds.put(tpo.getAcquirerId(), tpo.getId());
                boolean notExistFlag = true;
                for (InterestsAcquirerRelation acquirer : interestsAcquirers) {
                    if (tpo.getAcquirerId().equals(acquirer.getAcquirerId())) {
                        notExistFlag = false;
                    }
                }
                if (notExistFlag) {
                    this.interestsAcquirerRelationDao.delete(tpo.getId());
                }
            }
            // save or udpate
            for (InterestsAcquirerRelation acquirer : interestsAcquirers) {
                InterestsAcquirerRelationPo po = new InterestsAcquirerRelationPo();
                adapter.inbound(acquirer, po);
                if (acquirerIds.containsKey(acquirer.getAcquirerId())) {
                    // udpate
                    po.setId(acquirerIds.get(acquirer.getAcquirerId()));
                    this.interestsAcquirerRelationDao.update(po, null);
                } else {
                    // create
                    po.setCrtTime(new Date());
                    if (po.getAcquirerType() == null) {
                        po.setAcquirerType(AcquirerType.MEMBER.getIdentity());
                    }
                    this.interestsAcquirerRelationDao.create(po);
                }
            }
        }
    }

    private void saveOrUpdateInterestsInterestsSkuRelation(InterestsPo interestsPo,
            List<InterestsSkuRelation> interestsSkuRelations) throws AppBizException {
        if (interestsSkuRelations == null || interestsSkuRelations.isEmpty()) {
            logger.info("@@ InterestsPersistenceManagerImpl saveOrUpdateInterestsInterestsSkuRelation "
                    + "interestsSkuRelations is null");
            return;
        }
        // TODO查出所有sku 一条一条删除
        // delete sku by interestsId
        this.interestsSkuRelationDao.deleteSkuByInterestsId(interestsPo.getId());

        // add new sku
        InterestsSkuRelationPersistenceAdapter interestsSkuRelationPersistenceAdapter = new InterestsSkuRelationPersistenceAdapter();
        List<InterestsSkuRelationPo> pos = new ArrayList<InterestsSkuRelationPo>();
        if (interestsSkuRelations != null && interestsSkuRelations.size() > 0) {
            for (InterestsSkuRelation interestsSkuRelation : interestsSkuRelations) {
                InterestsSkuRelationPo interestsSkuRelationPo = new InterestsSkuRelationPo();
                interestsSkuRelationPersistenceAdapter.inbound(interestsSkuRelation, interestsSkuRelationPo);
                interestsSkuRelationPo.setInterestsId(interestsPo.getId());
                interestsSkuRelationPo.setMemberCode(interestsPo.getIssuerId());
                interestsSkuRelationPo.setCrtTime(new Date());
                interestsSkuRelationPo.setUptTime(new Date());
                pos.add(interestsSkuRelationPo);
            }
            List<InterestsSkuRelationPo> copies = new ArrayList<InterestsSkuRelationPo>();
            PersistenceUpdateHelper.updatePos(pos, copies, this.interestsSkuRelationDao);
            ThreadLocalCacheHelper.putPoRelations(interestsPo, pos);
        }
    }

    private void saveOrUpdateVoucherBatch(InterestsPo interestsPo, List<VoucherBatchDetail> voucherBatchDetails)
            throws AppBizException {

        if (voucherBatchDetails == null || voucherBatchDetails.isEmpty()) {
            logger.info("@@ InterestsPersistenceManagerImpl saveOrUpdateInterestsInterestsSkuRelation "
                    + "voucherBatchDetails is null");
            return;
        }
        // delete voucher batch and detail
        this.deleteVoucherBatchAndDetail(interestsPo);

        // add new voucher batch
        VoucherBatchPo voucherBatchPo = this.createVoucherBatch(interestsPo, voucherBatchDetails);

        // add new Voucher Detail
        this.createVoucherBatchDetail(interestsPo, voucherBatchDetails, voucherBatchPo);
    }

    @Autowired
    public void setAccountBalanceCreditLineDao(AccountBalanceCreditLineDao accountBalanceCreditLineDao) {
        this.accountBalanceCreditLineDao = accountBalanceCreditLineDao;
    }

    @Autowired
    public void setCreditLineWriteOffDao(CreditLineWriteOffDao creditLineWriteOffDao) {
        this.creditLineWriteOffDao = creditLineWriteOffDao;
    }

    @Autowired
    public void setFundStakeholderDao(FundStakeholderDao fundStakeholderDao) {
        this.fundStakeholderDao = fundStakeholderDao;
    }

    @Autowired
    public void setInterestsAcquirerRelationDao(InterestsAcquirerRelationDao interestsAcquirerRelationDao) {
        this.interestsAcquirerRelationDao = interestsAcquirerRelationDao;
    }

    @Autowired
    public void setInterestsDao(InterestsDao interestsDao) {
        this.interestsDao = interestsDao;
    }

    @Autowired
    public void setInterestsPayModeDao(InterestsPayModeDao interestsPayModeDao) {
        this.interestsPayModeDao = interestsPayModeDao;
    }

    @Autowired
    public void setInterestsRelResolver(InterestsRelResolver interestsRelResolver) {
        this.interestsRelResolver = interestsRelResolver;
    }

    @Autowired
    public void setInterestsRiskConfigurationDao(InterestsRiskConfigurationDao interestsRiskConfigurationDao) {
        this.interestsRiskConfigurationDao = interestsRiskConfigurationDao;
    }

    @Autowired
    public void setInterestsRuleDao(InterestsRuleDao interestsRuleDao) {
        this.interestsRuleDao = interestsRuleDao;
    }

    @Autowired
    public void setInterestsScenarioRelationDao(InterestsScenarioRelationDao interestsScenarioRelationDao) {
        this.interestsScenarioRelationDao = interestsScenarioRelationDao;
    }

    @Autowired
    public void setInterestsSkuRelationDao(InterestsSkuRelationDao interestsSkuRelationDao) {
        this.interestsSkuRelationDao = interestsSkuRelationDao;
    }

    @Autowired
    public void setInterestsStakeholderDao(InterestsStakeholderDao interestsStakeholderDao) {
        this.interestsStakeholderDao = interestsStakeholderDao;
    }

    @Autowired
    public void setNotificationConfigurationDao(NotificationConfigurationDao notificationConfigurationDao) {
        this.notificationConfigurationDao = notificationConfigurationDao;
    }

    @Autowired
    public void setNotificationConfigurationPersistenceManager(
            NotificationConfigurationPersistenceManager notificationConfigurationPersistenceManager) {
        this.notificationConfigurationPersistenceManager = notificationConfigurationPersistenceManager;
    }

    @Autowired
    public void setNotificationTemplateDao(NotificationTemplateDao notificationTemplateDao) {
        this.notificationTemplateDao = notificationTemplateDao;
    }

    @Autowired
    public void setVoucherBatchDao(VoucherBatchDao voucherBatchDao) {
        this.voucherBatchDao = voucherBatchDao;
    }

    @Autowired
    public void setVoucherGeneratePropertyDao(VoucherGeneratePropertyDao voucherGeneratePropertyDao) {
        this.voucherGeneratePropertyDao = voucherGeneratePropertyDao;
    }

    @Autowired
    public void setVoucherGenerateRuleDao(VoucherGenerateRuleDao voucherGenerateRuleDao) {
        this.voucherGenerateRuleDao = voucherGenerateRuleDao;
    }

    @Autowired
    public void setVoucherWriteOffRuleDao(VoucherWriteOffRuleDao voucherWriteOffRuleDao) {
        this.voucherWriteOffRuleDao = voucherWriteOffRuleDao;
    }

    @Override
    public boolean syncActivityStatusChange(Integer activityId, String changeStatusCmd) throws AppBizException {
        String nextStatus = null;
        String pirorStatus = null;
        Date issueDate = null;
        boolean interestsFlag = true;
        if (changeStatusCmd.equalsIgnoreCase(ActivityChangeStatusCmd.ISSUE.getCmd())) {
            pirorStatus = InterestsStatus.INIT.getId().toString();
            nextStatus = InterestsStatus.ENABLE.getId().toString();
            issueDate = new Date();
        }
        if (changeStatusCmd.equalsIgnoreCase(ActivityChangeStatusCmd.SUSPEND.getCmd())) {
            pirorStatus = InterestsStatus.ENABLE.getId().toString();
            nextStatus = InterestsStatus.DISABLED.getId().toString();
            interestsFlag = false;
        }
        if (changeStatusCmd.equalsIgnoreCase(ActivityChangeStatusCmd.RESUME.getCmd())) {
            pirorStatus = InterestsStatus.DISABLED.getId().toString();
            nextStatus = InterestsStatus.ENABLE.getId().toString();
            issueDate = new Date();
        }
        Integer updatedRows = this.interestsDao.syncActivityStatusChange(activityId, pirorStatus, nextStatus,
                issueDate);
        return interestsFlag && (updatedRows > 0);
    }

    @Override
    public boolean updateExpiredTime(Integer interestsId, Date expiredDate, Date holdExpiredDate)
            throws AppBizException {
        Integer updatedRows = this.interestsDao.updateExpiredTime(interestsId, expiredDate, holdExpiredDate);
        return updatedRows > 0;
    }

    private void updateGenerateRule(InterestsPo interestsPo, VoucherGenerateRule generateRule) throws AppBizException {
        if (generateRule == null) {
            return;
        }
        VoucherGenerateRulePersistenceAdapter adapter = new VoucherGenerateRulePersistenceAdapter();
        VoucherGenerateRulePo po = new VoucherGenerateRulePo();
        adapter.inbound(generateRule, po);

        VoucherGenerateRulePo copy = ThreadLocalCacheHelper.getRelatedPo(interestsPo, VoucherGenerateRulePo.class);
        // missing cache,load po from local repository
        if (null == copy) {
            copy = this.voucherGenerateRuleDao.getVoucherGenerateRule(generateRule.getId());
        }
        if (!ApiUtils.equals(po, copy)) {
            this.voucherGenerateRuleDao.update(po, copy);
            ThreadLocalCacheHelper.putPoRelation(interestsPo, po);
        }

        VoucherGenerateType type = generateRule.getType();
        switch (type) {
        case BASIC:
            VoucherWriteOffRule writeOffRule = generateRule.getWriteOffRule();
            this.updateWriteOffRule(po, writeOffRule);
            break;
        case RANDOM:
            RandomRule randomRule = generateRule.getRandomRule();
            this.updateRandomRule(po, randomRule);
            break;
        case TIERED:
            TieredRule tieredRule = generateRule.getTieredRule();
            this.updateTieredRule(po, tieredRule);
            break;
        default:
            throw new IllegalArgumentException("Invalid value: " + type);
        }
    }

    @Override
    public void updateInterests(Interests interests) throws AppBizException {
        InterestsPo interestsPo = this.updateInterestsPo(interests);
        this.updateInterestsRule(interestsPo, interests.getInterestsRule());
        this.updateGenerateRule(interestsPo, interests.getGenerateRule());
        this.updateInterestsScenarioRelation(interestsPo, interests.getScenarioRelation());
        this.updateInterestsPayModes(interestsPo, interests.getPayModes());
        this.updateNotificationConfiguration(interestsPo, interests.getNotificationConfigurations());
        this.saveOrUpdateInterestsAcquirerRels(interestsPo, interests.getInterestsAcquirerRelations());
        this.saveOrUpdateInterestsInterestsSkuRelation(interestsPo, interests.getInterestsSkuRelation());
        // VoucherGenerateRulePo generateRulePo = this.updateGenerateRule(interestsPo, interests.getGenerateRule());
        // this.updateWriteOffRule(generateRulePo, interests.getGenerateRule().getWriteOffRule());
        // this.updateReleaseCreditLine(interests.getScenarioRelation().getReleaseCreditLine());
        // this.updateWriteOffCreditLine(interests.getScenarioRelation().getWriteOffCreditLine());
        this.updateInterestsStakeHolder(interestsPo, interests.getStakeholder());
        // this.saveOrUpdateVoucherBatch(interestsPo, interests.getVoucherBatchDetail());
    }

    private InterestsAcquirerRelationPo updateInterestsAcquirerRelPo(InterestsAcquirerRelation interestsAcquirerRel)
            throws AppBizException {
        InterestsAcquirerRelationPersistenceAdapter adapter = new InterestsAcquirerRelationPersistenceAdapter();
        InterestsAcquirerRelationPo po = new InterestsAcquirerRelationPo();
        adapter.inbound(interestsAcquirerRel, po);

        InterestsAcquirerRelationPo copy = ThreadLocalCacheHelper.getPo(po);

        if (!ApiUtils.equals(po, copy)) {
            this.interestsAcquirerRelationDao.update(po, null);
        }
        return po;
    }

    private void updateInterestsPayModes(InterestsPo interestsPo, List<InterestsPayMode> payModes)
            throws AppBizException {
        if (payModes == null || payModes.isEmpty()) {
            return;
        }
        InterestsPayModePersistenceAdapter adapter = new InterestsPayModePersistenceAdapter();
        List<InterestsPayModePo> pos = new ArrayList<InterestsPayModePo>();
        for (InterestsPayMode payMode : payModes) {
            InterestsPayModePo po = new InterestsPayModePo();
            adapter.inbound(payMode, po);
            pos.add(po);
        }

        List<InterestsPayModePo> copies = ThreadLocalCacheHelper.getRelatedPos(interestsPo, InterestsPayModePo.class);
        // TODO compare and add/update/delete InterestsPayModePo
        if (pos.size() != copies.size()) {
            throw new UnsupportedOperationException();
        }
    }

    private InterestsPo updateInterestsPo(Interests interests) throws AppBizException {
        InterestsPersistenceAdapter adapter = new InterestsPersistenceAdapter();
        InterestsPo po = new InterestsPo();
        adapter.inbound(interests, po);

        InterestsPo copy = ThreadLocalCacheHelper.getPo(po);

        if (!ApiUtils.equals(po, copy)) {
            this.interestsDao.update(po, null);
        }
        return po;
    }

    /*
     * private void updateReleaseCreditLine(InterestsScenarioRelationPo scenarioRelationPo, ReleaseCreditLine
     * releaseCreditLine) throws AppBizException { if (releaseCreditLine == null) { return; } // TODO, miss update or
     * delete scenario ReleaseCreditLinePersistenceAdapter adapter = new ReleaseCreditLinePersistenceAdapter();
     * AccountBalanceCreditLinePo po = new AccountBalanceCreditLinePo(); adapter.inbound(releaseCreditLine, po);
     *
     * AccountBalanceCreditLinePo copy = ThreadLocalCacheHelper.getRelatedPo(scenarioRelationPo,
     * AccountBalanceCreditLinePo.class);
     *
     * if (!ApiUtils.equals(po, copy)) { accountBalanceCreditLineDao.update(po, copy.getRemainingAmount());
     * ThreadLocalCacheHelper.putPoRelation(scenarioRelationPo, po); }
     *
     * }
     */

    /*
     * private void updateWriteOffCreditLine(InterestsScenarioRelationPo scenarioRelationPo, WriteOffCreditLine
     * writeOffCreditLine) throws AppBizException { if (writeOffCreditLine == null) { return; } // TODO, miss update or
     * delete scenario WriteOffCreditLinePersistenceAdapter adapter = new WriteOffCreditLinePersistenceAdapter();
     * CreditLineWriteOffPo po = new CreditLineWriteOffPo(); adapter.inbound(writeOffCreditLine, po);
     *
     * CreditLineWriteOffPo copy = ThreadLocalCacheHelper.getRelatedPo(scenarioRelationPo, CreditLineWriteOffPo.class);
     *
     * if (!ApiUtils.equals(po, copy)) { creditLineWriteOffDao.update(po, copy.getRemainingAmount());
     * ThreadLocalCacheHelper.putPoRelation(scenarioRelationPo, po); } }
     */

    private void updateInterestsRule(InterestsPo interestsPo, InterestsRule interestsRule) throws AppBizException {
        // TODO InterestsRule may be null in future, then this will be createing InterestsRule here
        if (interestsRule == null) {
            return;
        }
        InterestsRulePersistenceAdapter adapter = new InterestsRulePersistenceAdapter();
        InterestsRulePo po = new InterestsRulePo();
        adapter.inbound(interestsRule, po);

        InterestsRulePo copy = ThreadLocalCacheHelper.getRelatedPo(interestsPo, InterestsRulePo.class);
        // missing copy,then load from db
        if (copy == null) {
            Integer ruleId = interestsRule.getRuleId();
            copy = this.interestsRuleDao.get(ruleId);
        }
        if (!ApiUtils.equals(po, copy)) {
            this.interestsRuleDao.update(po, copy.getRemainingLimit());
            ThreadLocalCacheHelper.putPoRelation(interestsPo, po);
        }
        this.updateRiskConfigurations(po, interestsRule.getRiskConfigurations());
    }

    private void updateInterestsScenarioRelation(InterestsPo interestsPo, InterestsScenarioRelation scenarioRelation)
            throws AppBizException {

        if (scenarioRelation == null) {
            return;
        }
        InterestsScenarioRelationPersistenceAdapter adapter = new InterestsScenarioRelationPersistenceAdapter();
        InterestsScenarioRelationPo po = new InterestsScenarioRelationPo();
        adapter.inbound(scenarioRelation, po);

        InterestsScenarioRelationPo copy = ThreadLocalCacheHelper.getRelatedPo(interestsPo,
                InterestsScenarioRelationPo.class);

        if (!ApiUtils.equals(po, copy)) {
            this.interestsScenarioRelationDao.update(po, null);
            ThreadLocalCacheHelper.putPoRelation(interestsPo, po);
        }
        scenarioRelation.getReleaseCreditLine().setId(copy.getBalanceAccountId());
        this.updateReleaseCreditLine(po, scenarioRelation.getReleaseCreditLine());
        scenarioRelation.getWriteOffCreditLine().setId(copy.getCreditLineWriteoffId());
        this.updateWriteOffCreditLine(po, scenarioRelation.getWriteOffCreditLine());

        // scenario relation cannot be update
    }

    private void updateInterestsStakeHolder(InterestsPo interestsPo, InterestsStakeholder stakeholder)
            throws AppBizException {
        if (stakeholder == null) {
            return;
        }
        InterestsStakeholderPersistenceAdapter adapter = new InterestsStakeholderPersistenceAdapter();
        FundStakeholderPersistenceAdapter fspAdapter = new FundStakeholderPersistenceAdapter();
        InterestsStakeholderPo po = new InterestsStakeholderPo();
        adapter.inbound(stakeholder, po);
        InterestsStakeholderPo copy = ThreadLocalCacheHelper.getRelatedPo(interestsPo, InterestsStakeholderPo.class);
        if (null == copy && po.getId() == null) {
            copy = this.interestsStakeholderDao.getStakeHolderByInterestsIdAndMembercode(po.getInterestsId(),
                    po.getMembercode());
            po.setId(copy.getId());
        }
        if (!ApiUtils.equals(po, copy)) {
            this.interestsStakeholderDao.update(po, null);
            FundStakeholder fundStakeholder = stakeholder.getFundStakeholder();
            if (null != fundStakeholder) {
                FundStakeholderPo fundStakeholderPo = this.fundStakeholderDao
                        .getFundStakeholderByMembercode(fundStakeholder.getMembercode());
                if (fundStakeholderPo != null) {
                    fundStakeholderPo.setUpdateTime(new Date());
                    fundStakeholderPo.setExternalFund(fundStakeholder.getExternalFund());
                    this.fundStakeholderDao.update(fundStakeholderPo, null);
                } else {
                    fundStakeholderPo = new FundStakeholderPo();
                    fspAdapter.inbound(fundStakeholder, fundStakeholderPo);
                    fundStakeholderPo.setCreateTime(new Date());
                    fundStakeholderPo.setUpdateTime(new Date());
                    this.fundStakeholderDao.create(fundStakeholderPo);
                }
            }
            ThreadLocalCacheHelper.putPoRelation(interestsPo, po);
            // PersistenceUpdateHelper.updatePo(po, copy, this.interestsStakeholderDao);
        }
    }

    private void updateNotificationConfiguration(InterestsPo interestsPo,
            List<NotificationConfiguration> notificationConfigurations) throws AppBizException {
        if (notificationConfigurations == null || notificationConfigurations.isEmpty()) {
            return;
        }
        NotificationConfigurationPersistenceAdapter ncpAdapter = new NotificationConfigurationPersistenceAdapter();
        NotificationTemplatePersistenceAdapter ntpAdapter = new NotificationTemplatePersistenceAdapter();
        List<NotificationConfiguration> copies = this.notificationConfigurationPersistenceManager
                .findNotificationConfiguration(interestsPo.getId());
        Map<String, NotificationConfiguration> copiesMap = new HashMap<String, NotificationConfiguration>();
        for (NotificationConfiguration notificationConfiguration : copies) {
            String key = notificationConfiguration.getBizType() + notificationConfiguration.getBizId();
            copiesMap.put(key, notificationConfiguration);
        }
        for (NotificationConfiguration nc : notificationConfigurations) {
            String key = nc.getBizType() + nc.getBizId();
            NotificationConfiguration copy = copiesMap.get(key);
            if (copy == null) {
                NotificationConfigurationPo po = new NotificationConfigurationPo();
                ncpAdapter.inbound(nc, po);
                NotificationTemplate notificationTemplate = nc.getNotificationTemplate();
                NotificationTemplatePo notificationTemplatePo = new NotificationTemplatePo();
                ntpAdapter.inbound(notificationTemplate, notificationTemplatePo);
                this.notificationTemplateDao.create(notificationTemplatePo);
                po.setTplId(notificationTemplatePo.getId());
                this.notificationConfigurationDao.create(po);
            } else {
                if (!copy.getNotificationTemplate().getContent()
                        .equalsIgnoreCase(nc.getNotificationTemplate().getContent())) {
                    NotificationTemplate notificationTemplate = nc.getNotificationTemplate();
                    NotificationTemplatePo notificationTemplatePo = new NotificationTemplatePo();
                    ntpAdapter.inbound(notificationTemplate, notificationTemplatePo);
                    this.notificationTemplateDao.update(notificationTemplatePo, null);
                }
            }

        }
    }

    private void updateRandomRule(VoucherGenerateRulePo generateRulePo, RandomRule randomRule) throws AppBizException {
        if (generateRulePo != null) {
            RandomRulePersistenceAdapter adapter = new RandomRulePersistenceAdapter();
            List<VoucherGeneratePropertyPo> pos = new ArrayList<VoucherGeneratePropertyPo>();
            adapter.inbound(randomRule, pos);
            for (VoucherGeneratePropertyPo po : pos) {
                po.setGenerateRuleId(generateRulePo.getId());
            }
            // DELETE related voucherGenProperties
            this.voucherGeneratePropertyDao.deleteByGenRuleId(generateRulePo.getId());

            List<VoucherGeneratePropertyPo> copies = new ArrayList<VoucherGeneratePropertyPo>();
            PersistenceUpdateHelper.updatePos(pos, copies, this.voucherGeneratePropertyDao);
            ThreadLocalCacheHelper.putPoRelations(generateRulePo, pos);
        }
    }

    private void updateReleaseCreditLine(InterestsScenarioRelationPo scenarioRelationPo,
            ReleaseCreditLine releaseCreditLine) throws AppBizException {
        if (releaseCreditLine == null) {
            return;
        }
        // TODO, miss update or delete scenario
        ReleaseCreditLinePersistenceAdapter adapter = new ReleaseCreditLinePersistenceAdapter();
        AccountBalanceCreditLinePo po = new AccountBalanceCreditLinePo();
        adapter.inbound(releaseCreditLine, po);

        AccountBalanceCreditLinePo copy = ThreadLocalCacheHelper.getRelatedPo(scenarioRelationPo,
                AccountBalanceCreditLinePo.class);

        if (!ApiUtils.equals(po, copy)) {
            this.accountBalanceCreditLineDao.update(po, po.getRemainingAmount());
        }

    }

    private void updateRiskConfigurations(InterestsRulePo interestsRulePo,
            List<InterestsRiskConfiguration> riskConfigurations) {
        if (riskConfigurations == null || riskConfigurations.isEmpty()) {
            return;
        }
        InterestsRiskConfigurationPersistenceAdapter adapter = new InterestsRiskConfigurationPersistenceAdapter();
        List<InterestsRiskConfigurationPo> pos = new ArrayList<InterestsRiskConfigurationPo>();
        for (InterestsRiskConfiguration riskConfiguration : riskConfigurations) {
            InterestsRiskConfigurationPo po = new InterestsRiskConfigurationPo();
            adapter.inbound(riskConfiguration, po);
            pos.add(po);
        }

        List<InterestsRiskConfigurationPo> copies = ThreadLocalCacheHelper.getRelatedPos(interestsRulePo,
                InterestsRiskConfigurationPo.class);

        // TODO compare and add/update/delete InterestsRiskConfigurationPo
        /*
         * if (copies != null && pos.size() != copies.size()) { throw new UnsupportedOperationException(); }
         */
    }

    private void updateTieredRule(VoucherGenerateRulePo generateRulePo, TieredRule tieredRule) throws AppBizException {
        TieredRulePersistenceAdapter adapter = new TieredRulePersistenceAdapter();
        List<VoucherGeneratePropertyPo> pos = new ArrayList<VoucherGeneratePropertyPo>();
        adapter.inbound(tieredRule, pos);

        for (VoucherGeneratePropertyPo po : pos) {
            po.setGenerateRuleId(generateRulePo.getId());
        }
        this.voucherGeneratePropertyDao.deleteByGenRuleId(generateRulePo.getId());
        List<VoucherGeneratePropertyPo> copies = new ArrayList<VoucherGeneratePropertyPo>();
        PersistenceUpdateHelper.updatePos(pos, copies, this.voucherGeneratePropertyDao);
        ThreadLocalCacheHelper.putPoRelations(generateRulePo, pos);
    }

    private void updateWriteOffCreditLine(InterestsScenarioRelationPo scenarioRelationPo,
            WriteOffCreditLine writeOffCreditLine) throws AppBizException {
        if (writeOffCreditLine == null) {
            return;
        }
        // TODO, miss update or delete scenario
        WriteOffCreditLinePersistenceAdapter adapter = new WriteOffCreditLinePersistenceAdapter();
        CreditLineWriteOffPo po = new CreditLineWriteOffPo();
        adapter.inbound(writeOffCreditLine, po);

        CreditLineWriteOffPo copy = ThreadLocalCacheHelper.getRelatedPo(scenarioRelationPo, CreditLineWriteOffPo.class);

        if (!ApiUtils.equals(po, copy)) {
            this.creditLineWriteOffDao.update(po, po.getRemainingAmount());
        }
    }

    private void updateWriteOffRule(VoucherGenerateRulePo generateRulePo, VoucherWriteOffRule writeOffRule)
            throws AppBizException {
        VoucherWriteOffRulePersistenceAdapter adapter = new VoucherWriteOffRulePersistenceAdapter();
        VoucherWriteOffRulePo po = new VoucherWriteOffRulePo();
        adapter.inbound(writeOffRule, po);
        VoucherWriteOffRulePo copy = ThreadLocalCacheHelper.getRelatedPo(generateRulePo, VoucherWriteOffRulePo.class);
        // WriteoffRule missing id, load Related VoucherWriteoffRule By generateRulePo
        if (copy != null && writeOffRule.getId() == null) {
            copy = this.voucherWriteOffRuleDao.getVoucherWriteoffRuleByGenRuleId(generateRulePo.getId());
            po.setId(copy.getId());
        }
        PersistenceUpdateHelper.updatePo(po, copy, this.voucherWriteOffRuleDao);
        ThreadLocalCacheHelper.putPoRelation(generateRulePo, po);
    }
}
