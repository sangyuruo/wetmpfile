package com.bill99.ebd.rip.persistence.dao;

import java.util.List;

import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.model.ChannelPo;

public interface ChannelsDao {

	List<ChannelPo> getChannels() throws AppBizException;
}
