package com.bill99.ebd.rip.persistence;

import java.util.List;
import java.util.Map;

import com.bill99.ebd.rip.domain.model.StakeholderRelatedPool;
import com.bill99.ebd.rip.domain.model.StakeholderRelatedPoolDto;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.model.StakeholderRelatedPoolPo;

/**
 * @author yong.zheng
 * @version 创建时间：2017年1月20日 下午5:33:54 类说明
 */
public interface StakeholderRelatedPoolPersistenceManager {

    /**
     * 添加
     * 
     * @param stakeholderRelatedPool
     * @throws AppBizException
     */
    void insertStakeholderRelatedPool(StakeholderRelatedPoolDto stakeholderRelatedPoolDto) throws AppBizException;

    /**
     * 查询
     * 
     * @param stakeholderRelatedPool
     * @param pageIndex
     * @param pageSize
     * @return
     * @throws AppBizException
     */
    public Map<String, Object> pageQueryByParamMap(StakeholderRelatedPool stakeholderRelatedPool, Integer pageIndex,
            Integer pageSize) throws AppBizException;

    /**
     * 查询父商户会员编号列表
     * 
     * @return
     * @throws AppBizException
     */
    public List<StakeholderRelatedPoolPo> findStakeholderRelatedPoolPoList(Map<String, Object> paratmters)
            throws AppBizException;
    
    public void deleteByMemberCode(String memberCode) throws AppBizException;
}
