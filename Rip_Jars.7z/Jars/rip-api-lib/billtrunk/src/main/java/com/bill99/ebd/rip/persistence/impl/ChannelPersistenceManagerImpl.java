package com.bill99.ebd.rip.persistence.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.domain.model.Channel;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.ChannelPersistenceManager;
import com.bill99.ebd.rip.persistence.adapter.ChannelPersistenceAdapter;
import com.bill99.ebd.rip.persistence.dao.ChannelsDao;
import com.bill99.ebd.rip.persistence.model.ChannelPo;

public class ChannelPersistenceManagerImpl implements ChannelPersistenceManager {

    private ChannelsDao channelsDaoIBatis;

    @Autowired
    public void setChannelsDaoIBatis(ChannelsDao channelsDaoIBatis) {
        this.channelsDaoIBatis = channelsDaoIBatis;
    }

    @Override
    public List<Channel> getChannels() throws AppBizException {
        List<ChannelPo> channelPoList = this.channelsDaoIBatis.getChannels();

        return convertChannelPoListToDomainList(channelPoList);
    }

    private List<Channel> convertChannelPoListToDomainList(List<ChannelPo> channelPoList) throws AppBizException {
        List<Channel> channelDomainList = new ArrayList<Channel>();
        ChannelPersistenceAdapter adapter = new ChannelPersistenceAdapter();
        if (channelPoList != null && channelPoList.size() > 0) {
            for (ChannelPo channelPo : channelPoList) {
                Channel channelDomain = new Channel();
                adapter.outbound(channelPo, channelDomain);
                channelDomainList.add(channelDomain);
            }
        }
        return channelDomainList;
    }

}
