package com.bill99.ebd.rip.persistence.dao;

import com.bill99.ebd.rip.persistence.model.StakeholderBudgetLogPo;

public interface StakeholderBudgetLogDao extends CrudDao<StakeholderBudgetLogPo>{

}
