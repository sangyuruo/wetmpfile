/**
 * 
 */
package com.bill99.ebd.rip.util;

import java.util.Map;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang.builder.EqualsBuilder;

import com.bill99.ebd.rip.domain.model.RandomRule;

/**
 * @author shuangye.liu
 *
 * @since Jun 12, 2016
 */
public class ApiUtils {

    public static boolean equals(Object o1, Object o2) {
        return EqualsBuilder.reflectionEquals(o1, o2);
    }

    public static Map<String, Object> objectToMap(Object object) {
        return convertObjectToMap(object);
    }

    public static Map<String, Object> objectPropertyToMap(Object object) {
        Map<String, Object> objectMap = convertObjectToMap(object);
        objectMap.remove("class");
        return objectMap;
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> convertObjectToMap(Object object) {
        try {
            return PropertyUtils.describe(object);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static void main(String[] args) {
        RandomRule r = new RandomRule();
        System.out.println(objectToMap(r));
    }

}
