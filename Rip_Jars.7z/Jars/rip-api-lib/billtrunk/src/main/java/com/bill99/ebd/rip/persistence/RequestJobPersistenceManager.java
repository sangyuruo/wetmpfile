package com.bill99.ebd.rip.persistence;

import java.util.List;

import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.model.RequestJobPo;

public interface RequestJobPersistenceManager {

    void createRequestJob(RequestJobPo requestJob) throws AppBizException;

    void updateRequestJob(RequestJobPo requestJob) throws AppBizException;

    RequestJobPo findRequestJobByOrderNoAndOrigOrderNo(String orderNo, String orgiOrderNo) throws AppBizException;

    RequestJobPo findRequestJobByOrderNo(String orderNo) throws AppBizException;

    List<RequestJobPo> findRequestJobByStatusByRequestType(List<String> status, String reqType) throws AppBizException;
}
