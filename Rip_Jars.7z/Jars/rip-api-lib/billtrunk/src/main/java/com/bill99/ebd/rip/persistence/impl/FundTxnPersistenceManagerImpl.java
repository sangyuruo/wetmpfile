package com.bill99.ebd.rip.persistence.impl;

import javax.annotation.Resource;

import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.FundTxnPersistenceManager;
import com.bill99.ebd.rip.persistence.dao.ibatis.FundTxnDaoIBatisImpl;
import com.bill99.ebd.rip.persistence.model.FundTxnPo;

public class FundTxnPersistenceManagerImpl implements FundTxnPersistenceManager {

    @Resource(name = "fundTxnIbatisDao")
    private FundTxnDaoIBatisImpl fundTxnDao;

    @Override
    public void createFundTxn(FundTxnPo fundTxn) throws AppBizException {
        fundTxnDao.create(fundTxn);
    }

    @Override
    public void updateFundTxn(FundTxnPo fundTxn) throws AppBizException {
        fundTxnDao.update(fundTxn, null);
    }

    @Override
    public FundTxnPo getStlFundTxnByExtSeqId(String origOrderNo) throws AppBizException {
        return fundTxnDao.getStlFundTxnByExtSeqId(origOrderNo);
    }
}
