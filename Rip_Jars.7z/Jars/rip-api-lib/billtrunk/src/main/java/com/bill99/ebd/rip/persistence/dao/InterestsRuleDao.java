package com.bill99.ebd.rip.persistence.dao;

import java.util.Map;

import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.model.InterestsRulePo;

public interface InterestsRuleDao extends CrudDao<InterestsRulePo> {

    void update(InterestsRulePo po, Integer expectedRemainingLimit) throws AppBizException;

    InterestsRulePo get(Integer ruleId) throws AppBizException;

    Map<String, Object> findByInterestsId(Integer interestsId) throws AppBizException;

}
