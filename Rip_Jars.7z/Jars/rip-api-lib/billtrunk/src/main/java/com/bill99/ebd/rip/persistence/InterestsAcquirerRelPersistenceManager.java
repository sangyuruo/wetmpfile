package com.bill99.ebd.rip.persistence;

import java.util.List;
import java.util.Map;

import com.bill99.ebd.rip.domain.model.InterestsAcquirerRelation;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.model.InterestsAcquirerRelationPo;

public interface InterestsAcquirerRelPersistenceManager {

    public void createInterestsAcquirerRel(InterestsAcquirerRelationPo interestsAcquirerRelation)
            throws AppBizException;

    public void updateInterestsAcquirerRel(InterestsAcquirerRelationPo interestsAcquirerRelation)
            throws AppBizException;

    public List<InterestsAcquirerRelationPo> findInterestsAcquirerRels(Integer interestsId, String acquirerType,
            String acquirerId, String acquirerName) throws AppBizException;

    public Map<String, Object> pageQuery(String acquirerType, String keywords, String acquirerAbility,
            Integer interestsId, Integer pageIndex, Integer pageSize) throws AppBizException;

    public List<InterestsAcquirerRelation> findInterestsAcquirerRelsByInterestsId(Integer interestsId)
            throws AppBizException;

    void deleteById(Integer id) throws AppBizException;
}
