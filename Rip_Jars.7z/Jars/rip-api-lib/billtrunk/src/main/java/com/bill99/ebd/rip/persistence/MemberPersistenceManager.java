package com.bill99.ebd.rip.persistence;

import java.util.List;
import java.util.Map;

import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.persistence.model.MemberPo;

public interface MemberPersistenceManager {

    public void createMember(MemberPo memberPo) throws AppBizException;

    public void updateMember(MemberPo memberPo) throws AppBizException;

    public MemberPo findMemberById(Integer id) throws AppBizException;

    public List<MemberPo> findMember(String memberName, String memberCode) throws AppBizException;

    public Map<String, Object> pageQuery(String keywords, Integer pageIndex, Integer pageSize) throws AppBizException;

    public MemberPo findMemberByMemberCode(String memberCode) throws AppBizException;
}
