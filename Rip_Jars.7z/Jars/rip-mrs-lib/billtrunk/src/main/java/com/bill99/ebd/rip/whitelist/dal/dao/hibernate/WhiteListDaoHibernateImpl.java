package com.bill99.ebd.rip.whitelist.dal.dao.hibernate;

import com.bill99.ebd.rip.dal.dao.hibernate.generic.HibernateGenericDao;
import com.bill99.ebd.rip.whitelist.dal.dao.WhiteListDao;
import com.bill99.ebd.rip.whitelist.dal.model.WhiteList;
import com.bill99.ebd.rip.whitelist.dal.model.WhiteListCond;

/**
 * @ClassName: WhiteListDaoHibernateImpl
 * @Description: WhiteListDaoHibernateImpl
 * @author gumin
 * @date 2015年8月19日 下午3:15:24
 */
public class WhiteListDaoHibernateImpl extends
		HibernateGenericDao<WhiteList, Integer, WhiteListCond> implements
		WhiteListDao {

}
