package com.bill99.ebd.rip.whitelist.dal.model;

import com.bill99.ebd.rip.dal.dao.hibernate.generic.Condition;
import com.bill99.ebd.rip.dal.dao.hibernate.generic.OrderableCondition;
import com.bill99.ebd.rip.enums.WhiteListKeyType;

@Condition
public class WhiteListCond extends WhiteList implements OrderableCondition{
	
	private static final long serialVersionUID = -6375166079036072523L;
	
	// 白名单类别 || 组名
	private String whiteListName;
	
	// 关键字类型 ： 电话号码 || memberCode
	private WhiteListKeyType whiteListKeyType;
	
	// 关键字 ： 电话号码 || memberCode
	private String keyWord;
	
	private String orders;
	
	public String getWhiteListName() {
		return whiteListName;
	}

	public void setWhiteListName(String whiteListName) {
		this.whiteListName = whiteListName;
	}
	
	public WhiteListKeyType getWhiteListKeyType() {
		return whiteListKeyType;
	}

	public void setWhiteListKeyType(WhiteListKeyType whiteListKeyType) {
		this.whiteListKeyType = whiteListKeyType;
	}

	public String getKeyWord() {
		return keyWord;
	}

	public void setKeyWord(String keyWord) {
		this.keyWord = keyWord;
	}

	@Override
	public String getOrders() {
		return orders;
	}

	@Override
	public void setOrders(String arg0) {
		this.orders = arg0;
	}
	
}
