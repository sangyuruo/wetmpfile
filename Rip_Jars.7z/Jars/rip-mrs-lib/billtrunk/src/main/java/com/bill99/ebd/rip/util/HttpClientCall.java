package com.bill99.ebd.rip.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;

import org.apache.commons.httpclient.DefaultHttpMethodRetryHandler;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.params.HttpMethodParams;
import org.apache.commons.httpclient.protocol.Protocol;
import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bill99.ebd.rip.exception.AppBizException;


/**
 * http请求
 * @author emily.gu
 *
 */
public class HttpClientCall {
	
	private final Log logger = LogFactory.getLog(this.getClass());
	
	/**
	 * 通知url
	 */
	private String url;
	
	/**
	 * 编码
	 */
	private String encoding = "UTF-8";
	
	/**
	 * 超时时间 默认10秒
	 */
	private int timeout = 10000;

	public HttpClientCall(String url) {
		super();
		this.url = url;
	}
	
	/**
	 * Get方式调用
	 * @return
	 * @throws AppBizException
	 */
	public String call() throws AppBizException {
		return makeCall(this.url);
	}
	
	@SuppressWarnings("deprecation")
	private String makeCall(String url) throws AppBizException {
		if(url.startsWith("https")){
			Protocol myhttps = new Protocol("https", new MySecureProtocolSocketFactory (), 443);
			Protocol.registerProtocol("https", myhttps);
		}
		
		HttpClient client = new HttpClient();
		client.getParams().setParameter(HttpMethodParams.HTTP_CONTENT_CHARSET,encoding);
		client.getHttpConnectionManager().getParams().setConnectionTimeout(timeout);
		
		GetMethod method = new GetMethod(url);
		method.getParams().setParameter(HttpMethodParams.RETRY_HANDLER,new DefaultHttpMethodRetryHandler(3, false));
		method.getParams().setParameter(HttpMethodParams.SO_TIMEOUT,timeout);   

		InputStream is = null;
		try {
			int statusCode = client.executeMethod(method);
			String charset = method.getResponseCharSet();

			is = method.getResponseBodyAsStream();
			StringWriter sw = new StringWriter();
			IOUtils.copy(is, sw, charset);

			if (statusCode != HttpStatus.SC_OK) {
				logger.error("Method failed: " + method.getStatusLine()	+ " @url:[" + url + "]" );
				logger.error("The response is [" + sw.toString() + "]");
				throw new AppBizException("","Failed when execute HttpClientCall, http return status:["
								+ statusCode + "]");
			}
			
			return sw.toString();
		} catch (Exception e) {
			logger.error("Error while call url [" + url + "]" + e.getMessage(),e);
			throw new AppBizException("","Error while call url[" + url + "] " + e.getMessage());
		} finally {
			if(null!=is){
				try {
					is.close();
				} catch (IOException e) {
					logger.error("httpclient call ,close inputstream error.",e);
				}
			}
			method.releaseConnection();
		}
	}
	

}
