package com.bill99.ebd.rip.rule.srv.impl;

/**
 * @description: 推断类
 */
public class Inference {
	/**
	 * 结果信息
	 */
	private String result;

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

}
