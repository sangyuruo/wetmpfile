/**
 * 
 */
package com.bill99.ebd.rip.srv;

import com.bill99.ebd.rip.exception.AppBizException;

/**
 * @project: app-rip-1007
 * @description:
 * @author: lei.yu
 * @create_time: 2015年10月12日
 * @modify_time: 2015年10月12日
 */
public interface ActivityCheckPlugin {

	public void check(Integer activityId, String memCode) throws AppBizException;
}
