package com.bill99.ebd.rip.weixin.srv.impl;

import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bill99.ebd.rip.Param.SysConfigParam;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.srv.ParamConfigService;
import com.bill99.ebd.rip.util.HttpClientCall;
import com.bill99.ebd.rip.util.JsonUtil;
import com.bill99.ebd.rip.util.SignaUtil;
import com.bill99.ebd.rip.weixin.srv.WeixinService;
import com.bill99.seashell.domain.service.cache.manager.ManagerClient;

/**
 * 微信服务接口
 * @author emily.gu
 * @create_time 2015.10.09
 */
public class WeixinServiceImpl implements WeixinService {
	
	private final static Log logger = LogFactory.getLog(WeixinServiceImpl.class);
	
	// 
	ManagerClient client;
	
	@Resource(name = "paramConfigService")
	private ParamConfigService paramConfigService;
	
	// 初始化缓存数据
	public void init() {
		logger.info("WeixinServiceImpl.init in.....");
		String appid = paramConfigService
				.getByName(SysConfigParam.WEIXIN, SysConfigParam.WEIXIN_APP_ID);
		String secret = paramConfigService
				.getByName(SysConfigParam.WEIXIN, SysConfigParam.WEIXIN_SECRET);
		String accessToken = null;
		String jsapiTicket = null;
		try {
			accessToken = getAccessToken(appid, secret);
			jsapiTicket = getJsapiTicket(accessToken);
			
		} catch (AppBizException e) {
			logger.error(e.getErrorCode() + " : " + e.getErrorMessage());
			logger.error("init weixin data error !");
			e.printStackTrace();
		}
		
		if (jsapiTicket != null) {
			client.set(SysConfigParam.ACCESS_TOKEN, 7200, accessToken);
			client.set(SysConfigParam.JSAPITICKET, 7200,jsapiTicket);
		} else {
			logger.error("jsapiTicket == null ; init weixin data error !");
		}
		logger.info("WeixinServiceImpl.init out.....");
	}
	
	/**
	 * 获取AccessToken
	 * @return
	 */
	public String getAccessToken() {
		Object ob = client.get(SysConfigParam.ACCESS_TOKEN);
		
		return ob == null ? null : ob.toString();
	}
	
	/**
	 * 获取JsapiTicket
	 * @return
	 */
	public String getJsapiTicket() {
		Object ob = client.get(SysConfigParam.JSAPITICKET);
		return ob == null ? null : ob.toString();
	}
	
	/**
	 * 生成签名
	 * @param noncestr 随机字符串
	 * @param timestamp 时间戳
	 * @param url 访问的url
	 * @param signaType 加密方式 微信为SHA-1
	 * @return signature
	 * @throws AppBizException
	 */
	public String signa(String noncestr, String timestamp, String url, String signaType) throws AppBizException {
		logger.info("WeixinServiceImpl.signa in ......  ");
		String signature = null;
		StringBuffer sb = new StringBuffer("jsapi_ticket=");
		sb.append(getJsapiTicket());
		sb.append("&noncestr=").append(noncestr);
		sb.append("&timestamp=").append(timestamp);
		sb.append("&url=").append(url);
		
		logger.info(sb.toString());
		// 签名
		signature = SignaUtil.signa(signaType, sb.toString());
		signature = signature.toLowerCase(); 
		
		logger.info("signature : " + signature);
		logger.info("WeixinServiceImpl.signa in ......  ");
		return signature;
	}
	
	/**
	 * 获取AccessToken
	 * @param appid
	 * @param secret
	 * @return String
	 * @throws AppBizException
	 */
	private String getAccessToken(String appid, String secret) throws AppBizException {
		StringBuffer sb = new StringBuffer("https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=");
		sb.append(appid).append("&secret=").append(secret);
		String getAccessTokenStr = sb.toString();
		String result = httpCall(getAccessTokenStr);
		logger.info("getAccessToken =======================");
		logger.info("accessToken : " + result);
		
		Map<String, String> map = JsonUtil.convert2Map(result);
		String accessToken = getWeixinRes(map, SysConfigParam.ACCESS_TOKEN);
		return accessToken;
		
		/*{"errcode":40013,"errmsg":"invalid appid"}*/
		
		/*String accessToken = 
				"{\"access_token\":
				\"ahKSmvFT_liQAutGevpQ_ZpAaaETT_PPkyx3BcFu3Z7huHInb9LYb7Hl5AlibCdZVRFHKp2CdLHcBr9yCrHf-uL6tNemkKIL1C8ozv3LYKo\",
				\"expires_in\":7200}";*/
	}
	
	/**
	 *  获取JsapiTicket
	 * @param accessToken
	 * @return
	 * @throws AppBizException
	 */
	private String getJsapiTicket(String accessToken) throws AppBizException{
		String jsapiTicket = null;
		if (accessToken == null) {
			logger.error("getAccessToken error ! ");
			return jsapiTicket;
		}
		
		StringBuffer sb = new StringBuffer("https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token=");
		sb.append(accessToken).append("&type=jsapi");
		
		String result = httpCall(sb.toString());
		logger.info("getJsapiTicket =======================");
		logger.info("jsapiTicket : " + result);
		
		Map<String, String> map = JsonUtil.convert2Map(result);
		jsapiTicket = getWeixinRes(map, SysConfigParam.JSAPITICKET);
        return jsapiTicket;
		 /*{"errcode":0,"errmsg":"ok",
		  * "ticket":"kgt8ON7yVITDhtdwci0qefxgmL8XmF-z67_YqDSsWZSiMs72tQ_RuwqPmqmlJBzDXdyN091GLXQih9j5ukly_A","expires_in":7200}*/
		/*{"errcode":40001,"errmsg":"invalid credential, access_token is invalid or not latest hint: [LQ0430vr20]"}*/
		
	}
	
	/**
	 * 解析微信结果
	 * @param map
	 * @param key
	 * @return String
	 */
	private String getWeixinRes(Map<String, String> map, String key) {
        logger.info("getWeixinRes key : " + key);
		if ( map.get(SysConfigParam.ERRCODE) != null && 
				(!map.get(SysConfigParam.ERRCODE).toString().equals(SysConfigParam.WEIXIN_SUCCESS))) {
			logger.error(map.get(SysConfigParam.ERRCODE + " : " + map.get(SysConfigParam.ERRMSG)));
			return null;
		} else {
			return map.get(key);
		}
	}
	
	/**
	 * get方式请求
	 * @param str
	 * @return String
	 * @throws AppBizException
	 */
	private String httpCall(String str) throws AppBizException {
		HttpClientCall call = new HttpClientCall(str);
		String returnStr = null;
		returnStr = call.call();
		return returnStr;
	}

	public void setClient(ManagerClient client) {
		this.client = client;
	}
	
}
