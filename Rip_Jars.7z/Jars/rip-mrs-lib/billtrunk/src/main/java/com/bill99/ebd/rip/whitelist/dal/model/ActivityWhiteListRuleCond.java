/**
 * 
 */
package com.bill99.ebd.rip.whitelist.dal.model;

import com.bill99.ebd.rip.dal.dao.hibernate.generic.Condition;

/**
 * @project: app-rip-0819
 * @description:
 * @author: lei.yu
 * @create_time: 2015年8月19日
 * @modify_time: 2015年8月19日
 */
@Condition
public class ActivityWhiteListRuleCond extends ActivityWhiteListRule {

	private static final long serialVersionUID = 1289934281257272489L;

}
