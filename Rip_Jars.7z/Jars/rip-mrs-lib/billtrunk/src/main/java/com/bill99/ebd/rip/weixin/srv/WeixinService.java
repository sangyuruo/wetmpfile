package com.bill99.ebd.rip.weixin.srv;

import com.bill99.ebd.rip.exception.AppBizException;

public interface WeixinService {
	
	/**
	 * 初始化缓存
	 */
	public void init();
	
	/**
	 * 获取AccessToken
	 * @return
	 */
	public String getAccessToken();
	
	/**
	 * 获取JsapiTicket
	 * @return
	 */
	public String getJsapiTicket();
	
	/**
	 * 生成签名
	 * @param noncestr 随机字符串
	 * @param timestamp 时间戳
	 * @param url 访问的url
	 * @param signaType 加密方式 微信为SHA-1
	 * @return signature
	 * @throws AppBizException
	 */
	public String signa(String noncestr, String timestamp, String url, String signaType) throws AppBizException ;
	

}
