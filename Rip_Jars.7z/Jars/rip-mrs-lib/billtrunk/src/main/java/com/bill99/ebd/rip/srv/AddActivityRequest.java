package com.bill99.ebd.rip.srv;

import java.io.Serializable;
import java.util.Date;

import com.bill99.ebd.rip.enums.ActivitySrcType;
import com.bill99.ebd.rip.enums.BooleanType;

/**
 * 活动添加请求
 * 
 * @author jakoes.wu
 * @date 2015年2月6日下午12:40:08
 * @project app-rip-20150203
 *
 */
public class AddActivityRequest implements Serializable{

	/**
	 * @author jakoes.wu
	 * @updatedate 2015年2月6日下午12:39:57
	 */
	private static final long serialVersionUID = 1L;
	
	private String activityName;//活动名称
	private Date startTime;//活动开始时间
	private Date endTime;//活动结束时间
	private String description;//描述
	private String instruction;//使用说明
    private String adContent;//广告内容
    private String activityAddress;//活动地址
	/**
	 * @see com.bill99.ebd.rip.dal.model.ActivitySrcType
	 */
	private ActivitySrcType srcType; //活动来源 SPDB-浦发活动 MMP-快营通活动 KQB-快钱包自建活动  EXT-外部导入活动
	private BooleanType isCheckWhiteList;
	
	public ActivitySrcType getSrcType() {
		return srcType;
	}
	public void setSrcType(ActivitySrcType srcType) {
		this.srcType = srcType;
	}
	public String getActivityName() {
		return activityName;
	}
	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
	public Date getStartTime() {
		return startTime;
	}
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}
	public Date getEndTime() {
		return endTime;
	}
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getInstruction() {
		return instruction;
	}
	public void setInstruction(String instruction) {
		this.instruction = instruction;
	}
	public String getAdContent() {
		return adContent;
	}
	public void setAdContent(String adContent) {
		this.adContent = adContent;
	}
	public String getActivityAddress() {
		return activityAddress;
	}
	public void setActivityAddress(String activityAddress) {
		this.activityAddress = activityAddress;
	}
	public BooleanType getIsCheckWhiteList() {
		return isCheckWhiteList;
	}
	public void setIsCheckWhiteList(BooleanType isCheckWhiteList) {
		this.isCheckWhiteList = isCheckWhiteList;
	}
    
    
}
