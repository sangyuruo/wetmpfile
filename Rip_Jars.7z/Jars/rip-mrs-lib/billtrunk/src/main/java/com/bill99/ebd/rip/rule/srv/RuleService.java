/**
 * 
 */
package com.bill99.ebd.rip.rule.srv;

import java.util.List;
import java.util.Set;

import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.rule.dal.dao.RuleCond;
import com.bill99.ebd.rip.rule.dal.model.Rule;

/**
 * @project: app-rip
 * @description:
 * @author: lei.yu
 * @create_time: 2015年5月22日
 * @modify_time: 2015年5月22日
 */
public interface RuleService {
	/**
	 * 执行规则
	 * 
	 * @param ruleGroupName
	 * @param facts
	 */
	public List<Object> ruleGroupAction(String ruleGroupName, List<Object> facts);

	public void updateRule(Rule rule);

	public void addRule(String ruleGroupName, Rule rule) throws AppBizException;

	public List<Rule> queryList(RuleCond cond, int first, int max);
	
	public Rule get(Long id);
	
	public void delRules(Set<Long> ruleIds);
	
	public Rule getValidByName(String name) throws AppBizException;

}
