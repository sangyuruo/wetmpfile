package com.bill99.ebd.rip.whitelist.dal.dao;

import com.bill99.ebd.rip.dal.dao.hibernate.generic.GenericCurdDao;
import com.bill99.ebd.rip.whitelist.dal.model.WhiteList;
import com.bill99.ebd.rip.whitelist.dal.model.WhiteListCond;

/**
 * @ClassName: WhiteListDao
 * @Description: WhiteListDao
 * @author gumin
 * @date 2015年8月19日 下午3:15:24
 */
public interface WhiteListDao extends
		GenericCurdDao<WhiteList, Integer, WhiteListCond> {

}
