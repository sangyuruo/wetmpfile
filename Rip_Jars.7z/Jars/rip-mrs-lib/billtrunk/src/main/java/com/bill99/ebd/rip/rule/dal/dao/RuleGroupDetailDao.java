package com.bill99.ebd.rip.rule.dal.dao;

import java.util.List;
import java.util.Set;

import com.bill99.ebd.rip.dal.dao.hibernate.generic.GenericCurdDao;
import com.bill99.ebd.rip.rule.dal.model.RuleGroupDetail;

public interface RuleGroupDetailDao extends GenericCurdDao<RuleGroupDetail, Long, RuleGroupDetailCond> {

	public List<RuleGroupDetail> queryByGroupId(Long ruleGroupId);

	public Set<Long> queryRuleGroupIdByRuleId(Long ruleId);
	
	public List<RuleGroupDetail> queryRuleGroupByRuleId(Long ruleId);

}
