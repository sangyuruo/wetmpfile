package com.bill99.ebd.rip.whitelist.srv.impl;

import java.util.List;

import javax.annotation.Resource;

import com.bill99.ebd.rip.enums.WhiteListKeyType;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.whitelist.dal.dao.WhiteListDao;
import com.bill99.ebd.rip.whitelist.dal.model.WhiteList;
import com.bill99.ebd.rip.whitelist.dal.model.WhiteListCond;
import com.bill99.ebd.rip.whitelist.srv.WhiteListService;

/**
 * @ClassName: WhiteListService
 * @Description: 白名单服务
 * @author gumin
 * @date 2015年8月19日 下午3:17:11
 */
public class WhiteListServiceImpl implements WhiteListService {

	// 白名单dao
	@Resource(name = "")
	private WhiteListDao whiteListDao;

	@Override
	public void save(WhiteList whiteList) throws AppBizException {
		whiteListDao.add(whiteList);
	}
	
	public List<WhiteList> query(WhiteListCond cond, int arg1, int arg2) throws AppBizException {
		return whiteListDao.queryList(cond, arg1, arg2);
	}
	
	@Override
	public boolean isExist(String whiteListName, WhiteListKeyType whiteListKeyType, String keyWord) {
		WhiteListCond cond = new WhiteListCond();
		cond.setWhiteListName(whiteListName);
		cond.setWhiteListKeyType(whiteListKeyType);
		cond.setKeyWord(keyWord);
		List<WhiteList> whiteLists = whiteListDao.queryList(cond, 0, 1);
		return !whiteLists.isEmpty();
	}

}
