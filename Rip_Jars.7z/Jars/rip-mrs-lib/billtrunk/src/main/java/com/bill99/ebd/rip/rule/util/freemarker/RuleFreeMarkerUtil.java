/**
 * 
 */
package com.bill99.ebd.rip.rule.util.freemarker;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bill99.ebd.rip.enums.AppExCodeEnum;
import com.bill99.ebd.rip.enums.BaseAssertFltType;
import com.bill99.ebd.rip.exception.AppBizException;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;

/**
 * @project: app-rip
 * @description:
 * @author: lei.yu
 * @create_time: 2015年5月30日
 * @modify_time: 2015年5月30日
 */
public class RuleFreeMarkerUtil {
	private static final Log LOG = LogFactory.getLog(RuleFreeMarkerUtil.class);
	private static final Configuration FREEMARKER_CFG = new Configuration();
	static {
		FREEMARKER_CFG.setEncoding(Locale.ENGLISH, "UTF-8");
	}

	public static final String getResult(String templateString, Object data) throws AppBizException {
		Template template = null;
		StringWriter writer = new StringWriter();
		try {
			template = createTemplate(templateString);
			template.process(data, writer);
		} catch (IOException e) {
			LOG.error("compile rule error!", e);
			throw new AppBizException(AppExCodeEnum.RULE_COMPILE_FAILED);
		} catch (TemplateException e) {
			LOG.error("compile rule error!", e);
			throw new AppBizException(AppExCodeEnum.RULE_COMPILE_FAILED);
		}
		template = null;
		String result = writer.toString();
		return result;
	}

	public static final String genStringAssert(final String expression, final String operator, final String constant)
			throws AppBizException {
		Map<String, String> para = new HashMap<String, String>();
		para.put("constant", constant);
		para.put("expression", expression);
		para.put("operator", operator);
		return getResult(BaseAssertFltType.STRING.getFtl(), para);
	}

	public static final String genDateAssert(final String expression, final String pattenExpression,
			final String operator, final String constant, final String pattenConstant) throws AppBizException {
		Map<String, String> para = new HashMap<String, String>();
		para.put("constant", constant);
		para.put("pattenConstant", pattenConstant);
		para.put("expression", expression);
		para.put("pattenExpression", pattenExpression);
		para.put("operator", operator);
		return getResult(BaseAssertFltType.DATE.getFtl(), para);
	}

	public static final String genNumberAssert(final String expression, final String operator, final String constant)
			throws AppBizException {
		Map<String, String> para = new HashMap<String, String>();
		para.put("constant", constant);
		para.put("expression", expression);
		para.put("operator", operator);
		return getResult(BaseAssertFltType.NUMBER.getFtl(), para);
	}

	private static Template createTemplate(String templateString) throws IOException {
		StringReader reader = new StringReader(templateString.toString());
		Template template = new Template(UUID.randomUUID().toString(), reader, FREEMARKER_CFG);
		template.getConfiguration().setClassicCompatible(true);// 处理空值为空字符串
		return template;
	}

	public static String readInputStreamReaderAsString(InputStreamReader in) throws AppBizException {
		StringBuffer fileData = new StringBuffer(1000);
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(in);
			char[] buf = new char[1024];
			int numRead = 0;
			while ((numRead = reader.read(buf)) != -1) {
				String readData = String.valueOf(buf, 0, numRead);
				fileData.append(readData);
				buf = new char[1024];
			}
		} catch (IOException e) {
			LOG.error("read rule ftl error!", e);
			throw new AppBizException(AppExCodeEnum.RULE_COMPILE_FAILED);
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e) {
					LOG.error("read rule ftl error!", e);
					throw new AppBizException(AppExCodeEnum.RULE_COMPILE_FAILED);
				}
			}
		}
		return fileData.toString();
	}

	public static void main(String[] args) {
		System.out.println("1234abcd".compareTo("1234abcd"));
		System.out.println("1234abcd".compareTo("2234abcd"));
		System.out.println("2234abcd".compareTo("1234abcd"));
		System.out.println("1234aacd".compareTo("1234abcd"));
		System.out.println("1234accd".compareTo("1234abcd"));
	}
}
