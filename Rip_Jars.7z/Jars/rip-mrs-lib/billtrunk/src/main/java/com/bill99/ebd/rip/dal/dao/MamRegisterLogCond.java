/**
 * 
 */
package com.bill99.ebd.rip.dal.dao;

import com.bill99.ebd.rip.dal.dao.hibernate.generic.Condition;
import com.bill99.ebd.rip.dal.dao.hibernate.generic.OrderableCondition;
import com.bill99.ebd.rip.dal.model.MamRegisterLog;

/**
 * @project: app-rip-1007
 * @description: 
 * @author: lei.yu
 * @create_time: 2015年10月9日
 * @modify_time: 2015年10月9日
 */
@Condition
public class MamRegisterLogCond extends MamRegisterLog implements OrderableCondition{

	private static final long serialVersionUID = 5532926060059284189L;

	private String orders;
	
	@Override
	public void setOrders(String orders) {
		this.orders = orders;
	}

	@Override
	public String getOrders() {
		return orders;
	}

}
