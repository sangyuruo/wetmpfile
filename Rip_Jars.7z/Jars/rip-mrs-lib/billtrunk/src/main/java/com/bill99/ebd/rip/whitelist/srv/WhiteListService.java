package com.bill99.ebd.rip.whitelist.srv;

import java.util.List;

import com.bill99.ebd.rip.enums.WhiteListKeyType;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.whitelist.dal.model.WhiteList;
import com.bill99.ebd.rip.whitelist.dal.model.WhiteListCond;



/**
* @ClassName: WhiteListService 
* @Description: 白名单服务
* @author gumin
* @date 2015年8月19日 下午3:17:11 
*
 */
public interface WhiteListService {

	/**
	 * 判断是否存在白名单信息
	 * 
	 * @param whiteListName 白名单组名称
	 * @param whiteListKeyType 白名单key类型
	 * @param keyWord 白名单key
	 */
	public boolean isExist(String whiteListName, WhiteListKeyType whiteListKeyType, String keyWord);
	
	/**
	* @Title: save 
	* @Description: 保存白名单
	* @param WebWhiteList whiteList
	* @throws AppBizException
	 */
	public void save(WhiteList whiteList)  throws AppBizException;
	
	/**
	* @Title: query 
	* @Description: 白名单查询
	* @param WhiteListCond cond
	* @param int arg1
	* @param int arg2
	* @return List<WhiteList>
	* @throws AppBizException
	 */
	public List<WhiteList> query(WhiteListCond cond, int arg1, int arg2) throws AppBizException;
	
}
