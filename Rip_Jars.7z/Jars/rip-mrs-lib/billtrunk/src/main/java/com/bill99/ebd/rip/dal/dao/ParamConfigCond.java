package com.bill99.ebd.rip.dal.dao;

import com.bill99.ebd.rip.dal.dao.hibernate.generic.Condition;
import com.bill99.ebd.rip.dal.model.ParamConfig;

@Condition
public class ParamConfigCond extends ParamConfig {

	private static final long serialVersionUID = 1L;
}
