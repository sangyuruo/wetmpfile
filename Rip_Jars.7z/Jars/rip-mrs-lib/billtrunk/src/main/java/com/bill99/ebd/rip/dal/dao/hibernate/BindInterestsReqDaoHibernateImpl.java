package com.bill99.ebd.rip.dal.dao.hibernate;

import com.bill99.ebd.rip.dal.dao.BindInterestsReqCond;
import com.bill99.ebd.rip.dal.dao.BindInterestsReqDao;
import com.bill99.ebd.rip.dal.dao.hibernate.generic.HibernateGenericDao;
import com.bill99.ebd.rip.dal.model.BindInterestsReq;

/**
 * @author jakoes.wu
 * @create 2014-9-29下午8:44:39
 * @project app-rip-20140903
 */
public class BindInterestsReqDaoHibernateImpl extends HibernateGenericDao<BindInterestsReq, Long, BindInterestsReqCond>
		implements BindInterestsReqDao {

}
