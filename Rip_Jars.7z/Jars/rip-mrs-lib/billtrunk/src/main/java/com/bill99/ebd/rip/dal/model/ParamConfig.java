package com.bill99.ebd.rip.dal.model;

// Generated 2014-9-11 16:37:01 by Hibernate Tools 3.2.2.GA

import java.util.Date;

public class ParamConfig implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	private Integer id;
	private String name;// 参数名
	private String value;// 参数值
	private String type;// 参数所属项目类型
	private Date createTime;
	private Date updateTime;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}
