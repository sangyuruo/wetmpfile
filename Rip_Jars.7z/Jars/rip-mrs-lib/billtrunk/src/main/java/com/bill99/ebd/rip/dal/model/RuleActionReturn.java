package com.bill99.ebd.rip.dal.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class RuleActionReturn implements Serializable {
	private static final long serialVersionUID = 2593218317806898967L;
	private List<Object> returns = new ArrayList<Object>();

	public void add(Object ret) {
		returns.add(ret);
	}

	public List<Object> getReturns() {
		return returns;
	}
}
