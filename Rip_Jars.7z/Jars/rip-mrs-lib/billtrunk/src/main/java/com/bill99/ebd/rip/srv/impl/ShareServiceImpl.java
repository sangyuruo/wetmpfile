package com.bill99.ebd.rip.srv.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bill99.ebd.rip.dal.dao.ShareCond;
import com.bill99.ebd.rip.dal.dao.ShareDao;
import com.bill99.ebd.rip.dal.model.Share;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.srv.ShareService;

/**
 * 分享接口实现
 * @author emily.gu
 * @create_time 2015.09.29
 */
public class ShareServiceImpl implements ShareService {
	
	private final Log log = LogFactory.getLog(getClass());
	
	@Resource(name = "shareDao")
	private ShareDao shareDao;

	@Override
	public List<Share> query(ShareCond cond, int arg1, int arg2)
			throws AppBizException {
		
		log.info("ShareServiceImpl.query in ......");
		return shareDao.queryList(cond, arg1, arg2);
	}
	
	

}
