package com.bill99.ebd.rip.rule.dal.dao;

import com.bill99.ebd.rip.dal.dao.hibernate.generic.GenericCurdDao;
import com.bill99.ebd.rip.rule.dal.model.Rule;

public interface RuleDao extends GenericCurdDao<Rule, Long, RuleCond> {

}
