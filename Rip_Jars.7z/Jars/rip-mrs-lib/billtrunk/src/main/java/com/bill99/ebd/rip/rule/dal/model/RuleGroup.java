/**
 * 
 */
package com.bill99.ebd.rip.rule.dal.model;

import java.io.Serializable;
import java.util.Date;

/**
 * @project: app-rip-0603-mam
 * @description:
 * @author: lei.yu
 * @create_time: 2015年5月22日
 * @modify_time: 2015年5月22日
 */
public class RuleGroup implements Serializable {

	private static final long serialVersionUID = -4710424497603805876L;
	private Long ruleGroupId;// pk
	private String ruleGroupName;// 规则组名称
	private Date createTime;// 创建时间
	private Date updateTime;// 更新时间

	public Long getRuleGroupId() {
		return ruleGroupId;
	}

	public String getRuleGroupName() {
		return ruleGroupName;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setRuleGroupId(Long ruleGroupId) {
		this.ruleGroupId = ruleGroupId;
	}

	public void setRuleGroupName(String ruleGroupName) {
		this.ruleGroupName = ruleGroupName;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

}
