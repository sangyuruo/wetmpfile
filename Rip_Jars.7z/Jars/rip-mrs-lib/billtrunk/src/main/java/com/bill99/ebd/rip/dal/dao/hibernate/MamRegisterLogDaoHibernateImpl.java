/**
 * 
 */
package com.bill99.ebd.rip.dal.dao.hibernate;

import com.bill99.ebd.rip.dal.dao.MamRegisterLogCond;
import com.bill99.ebd.rip.dal.dao.MamRegisterLogDao;
import com.bill99.ebd.rip.dal.dao.hibernate.generic.HibernateGenericDao;
import com.bill99.ebd.rip.dal.model.MamRegisterLog;

/**
 * @project: app-rip-1007
 * @description:
 * @author: lei.yu
 * @create_time: 2015年10月9日
 * @modify_time: 2015年10月9日
 */
public class MamRegisterLogDaoHibernateImpl extends HibernateGenericDao<MamRegisterLog, Long, MamRegisterLogCond>
		implements MamRegisterLogDao {

}
