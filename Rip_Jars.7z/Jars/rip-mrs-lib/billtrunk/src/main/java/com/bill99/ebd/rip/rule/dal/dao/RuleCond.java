package com.bill99.ebd.rip.rule.dal.dao;

import java.util.List;

import com.bill99.ebd.rip.dal.dao.hibernate.generic.Condition;
import com.bill99.ebd.rip.dal.dao.hibernate.generic.Expression;
import com.bill99.ebd.rip.enums.RuleStatus;
import com.bill99.ebd.rip.rule.dal.model.Rule;

@Condition
public class RuleCond extends Rule {

	private static final long serialVersionUID = -6457978513842200680L;
	private List<RuleStatus> statusList;

	@Expression(persistenceProperty = "status", operator = "in")
	public List<RuleStatus> getStatusList() {
		return statusList;
	}

	public void setStatusList(List<RuleStatus> statusList) {
		this.statusList = statusList;
	}
}
