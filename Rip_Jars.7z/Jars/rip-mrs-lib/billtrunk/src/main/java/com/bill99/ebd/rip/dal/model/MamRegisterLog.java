/**
 * 
 */
package com.bill99.ebd.rip.dal.model;

import java.io.Serializable;
import java.util.Date;

/**
 * @project: app-rip-1007
 * @description: 账户注册日志
 * @author: lei.yu
 * @create_time: 2015年10月9日
 * @modify_time: 2015年10月9日
 */
public class MamRegisterLog implements Serializable {

	private static final long serialVersionUID = 3546541316895136540L;

	private Long mamRegisterLogId;
	/**
	 * 账户注册激活时间
	 */
	private Date creationDate;
	/**
	 * 会员类别<br>
	 * 1:个人会员;2:企业会员
	 */
	private String memberType;
	/**
	 * 业务编码 ,标识请求方的业务编码
	 */
	private String bizCode;
	/**
	 * 注册渠道<br>
	 * mobile:app注册
	 */
	private String regFrom;
	/**
	 * 会员号
	 */
	private String memberCode;
	/**
	 * 创建时间
	 */
	private Date createTime;
	/**
	 * 更新时间
	 */
	private Date updateTime;
	
	/**
	 * 用户标识内容
	 * */
	private String idcontent;
	
	/**
	 * 用户标识类型 1-Email 2-手机,小灵通 3-电话
	 * */
	private String idcontentType ;
	
	private String message;//原始消息-json
	private String memo;

	public Long getMamRegisterLogId() {
		return mamRegisterLogId;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public String getMemberType() {
		return memberType;
	}

	public String getBizCode() {
		return bizCode;
	}

	public String getRegFrom() {
		return regFrom;
	}

	public String getMemberCode() {
		return memberCode;
	}

	public void setMamRegisterLogId(Long mamRegisterLogId) {
		this.mamRegisterLogId = mamRegisterLogId;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public void setMemberType(String memberType) {
		this.memberType = memberType;
	}

	public void setBizCode(String bizCode) {
		this.bizCode = bizCode;
	}

	public void setRegFrom(String regFrom) {
		this.regFrom = regFrom;
	}

	public void setMemberCode(String memberCode) {
		this.memberCode = memberCode;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getIdcontent() {
		return idcontent;
	}

	public void setIdcontent(String idcontent) {
		this.idcontent = idcontent;
	}

	public String getIdcontentType() {
		return idcontentType;
	}

	public void setIdcontentType(String idcontentType) {
		this.idcontentType = idcontentType;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}
	
}
