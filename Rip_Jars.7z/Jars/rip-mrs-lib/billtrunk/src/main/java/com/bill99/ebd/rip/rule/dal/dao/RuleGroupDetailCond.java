/**
 * 
 */
package com.bill99.ebd.rip.rule.dal.dao;

import com.bill99.ebd.rip.dal.dao.hibernate.generic.Condition;
import com.bill99.ebd.rip.rule.dal.model.RuleGroupDetail;

/**
 * @project: app-rip-0603-mam
 * @description:
 * @author: lei.yu
 * @create_time: 2015年5月22日
 * @modify_time: 2015年5月22日
 */
@Condition
public class RuleGroupDetailCond extends RuleGroupDetail {

	private static final long serialVersionUID = 8051378276318578289L;

}
