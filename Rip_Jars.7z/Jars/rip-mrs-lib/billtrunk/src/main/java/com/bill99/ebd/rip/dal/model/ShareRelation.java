package com.bill99.ebd.rip.dal.model;

import java.io.Serializable;

import com.bill99.ebd.rip.dal.model.BasePojo;

/**
 * 分享关系表
 * @author chao.zhou
 *
 */
public class ShareRelation extends BasePojo implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String registerPhoneNo;
	private String shareCodes;
	private Integer status;//是否被激活;0，未激活；1，已激活。默认0.
	private String activityName;
	private String mem;
	public String getRegisterPhoneNo() {
		return registerPhoneNo;
	}
	public void setRegisterPhoneNo(String registerPhoneNo) {
		this.registerPhoneNo = registerPhoneNo;
	}
	public String getShareCodes() {
		return shareCodes;
	}
	public void setShareCodes(String shareCodes) {
		this.shareCodes = shareCodes;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public String getActivityName() {
		return activityName;
	}
	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
	public String getMem() {
		return mem;
	}
	public void setMem(String mem) {
		this.mem = mem;
	}
	
}
