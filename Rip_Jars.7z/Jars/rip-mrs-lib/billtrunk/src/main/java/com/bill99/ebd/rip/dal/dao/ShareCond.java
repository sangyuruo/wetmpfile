package com.bill99.ebd.rip.dal.dao;

import com.bill99.ebd.rip.dal.dao.hibernate.generic.Condition;
import com.bill99.ebd.rip.dal.dao.hibernate.generic.OrderableCondition;
import com.bill99.ebd.rip.dal.model.Share;

/**
 * 分享查询条件
 * @author emily.gu
 * @date 2015.09.28
 */
@Condition
public class ShareCond extends Share implements OrderableCondition{

	private static final long serialVersionUID = 1342910911591189055L;
	
	private String orders;
	
	// 唯一ID
	private Integer id;
	
	// 业务code
	private String bizCode;
	
	// 分享类型
	private String type;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getBizCode() {
		return bizCode;
	}

	public void setBizCode(String bizCode) {
		this.bizCode = bizCode;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Override
	public String getOrders() {
		return orders;
	}

	@Override
	public void setOrders(String s) {
		this.orders = s;
		
	}

}
