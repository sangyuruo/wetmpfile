/**
 * 
 */
package com.bill99.ebd.rip.rule.dal.dao.hibernate;

import com.bill99.ebd.rip.dal.dao.hibernate.generic.HibernateGenericDao;
import com.bill99.ebd.rip.rule.dal.dao.RuleCond;
import com.bill99.ebd.rip.rule.dal.dao.RuleDao;
import com.bill99.ebd.rip.rule.dal.model.Rule;

public class RuleDaoHibernateImpl extends HibernateGenericDao<Rule, Long, RuleCond> implements RuleDao {

}
