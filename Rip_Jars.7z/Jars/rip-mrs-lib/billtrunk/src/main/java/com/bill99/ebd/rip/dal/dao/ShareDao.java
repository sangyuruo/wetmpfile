package com.bill99.ebd.rip.dal.dao;

import com.bill99.ebd.rip.dal.dao.hibernate.generic.GenericCurdDao;
import com.bill99.ebd.rip.dal.model.Share;

/**
 * 分享接口
 * @author emily.gu
 * @create_time 2015.09.29
 */
public interface ShareDao extends
     GenericCurdDao<Share, Integer, ShareCond> {

}
