package com.bill99.ebd.rip.dal.dao;

import com.bill99.ebd.rip.dal.dao.hibernate.generic.GenericCurdDao;
import com.bill99.ebd.rip.dal.model.ActivityCheck;

public interface ActivityCheckDao extends GenericCurdDao<ActivityCheck, Long, ActivityCheckCond> {

}
