/**
 * 
 */
package com.bill99.ebd.rip.dal.dao;

import com.bill99.ebd.rip.dal.model.BindInterestsResp;

/**
 * @project: app-rip-0617
 * @description: 
 * @author: lei.yu
 * @create_time: 2015年6月3日
 * @modify_time: 2015年6月3日
 */
public class BindInterestsRespCond extends BindInterestsResp{

	private static final long serialVersionUID = -3227239235018257577L;

}
