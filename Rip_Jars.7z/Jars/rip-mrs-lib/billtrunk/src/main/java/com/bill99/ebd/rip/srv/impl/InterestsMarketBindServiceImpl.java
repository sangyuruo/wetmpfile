/**
 * 
 */
package com.bill99.ebd.rip.srv.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bill99.ebd.rip.dal.model.BindInterestsReq;
import com.bill99.ebd.rip.enums.AppExCodeEnum;
import com.bill99.ebd.rip.enums.RuleGroupType;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.mrs.facade.BindInterestsRequest;
import com.bill99.ebd.rip.rule.srv.RuleService;
import com.bill99.ebd.rip.srv.ActivityCheckService;
import com.bill99.ebd.rip.srv.BindInterestsReqService;
import com.bill99.ebd.rip.srv.BindInterestsRespService;
import com.bill99.ebd.rip.srv.BindInterestsRuleService;
import com.bill99.ebd.rip.srv.InterestsMarketBindService;

import net.sf.json.JSONObject;

/**
 * @project: app-rip-0520
 * @description:
 * @author: lei.yu
 * @create_time: 2015年5月6日
 * @modify_time: 2015年5月6日
 */
public class InterestsMarketBindServiceImpl implements InterestsMarketBindService {

    private final static Logger logger = LoggerFactory.getLogger(InterestsMarketBindServiceImpl.class);

    @Autowired
    private RuleService ruleService;

    @Autowired
    private BindInterestsReqService bindInterestsReqService;

    @Autowired
    private BindInterestsRespService bindInterestsRespService;

    @Autowired
    private BindInterestsRuleService bindInterestsRuleService;

    @Autowired
    private ActivityCheckService activityCheckService;

    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Throwable.class)
    public void bindInterests(BindInterestsRequest request) {
        try {
            this.ruleActionAndBind(request);
        } catch (AppBizException e) {
            this.bindInterestsRespService.saveBindInterestsResp(request.getRequestId(), null, e.getErrorCode());
            logger.error("@@meet exception when call[InterestsMarketBindService.bindInterests]:" + e.getMessage(), e);
        } catch (Exception e) {
            this.bindInterestsRespService.saveBindInterestsResp(request.getRequestId(), null,
                    AppExCodeEnum.UNKNOW_ERROR.getCode());
            logger.error("@@meet error when call[InterestsMarketBindService.bindInterests]:" + e.getMessage(), e);
        }
    }

    private void bindInterests(BindInterestsRequest request, String memCode,
            BindInterestsRuleActionReturn actionReturn) {
        String requestId = request.getRequestId();
        try {
            this.activityCheckService.checkActivity(actionReturn.getActivityId(), memCode);
            this.bindInterestsRuleService.bindInterests(request, memCode, actionReturn);
            this.bindInterestsRespService.saveBindInterestsResp(requestId, actionReturn, "00");
        } catch (AppBizException e) {
            this.bindInterestsRespService.saveBindInterestsResp(requestId, actionReturn, e.getErrorCode());
            logger.error("@@meet exception when call[bindInterestsRuleService.bindInterests]:" + e.getMessage(), e);
        } catch (Exception e) {
            this.bindInterestsRespService.saveBindInterestsResp(requestId, actionReturn,
                    AppExCodeEnum.UNKNOW_ERROR.getCode());
            logger.error("@@meet error when call[bindInterestsRuleService.bindInterests]:" + e.getMessage(), e);
        }
    }

    private void checkParam(BindInterestsRequest request) {
        if (StringUtils.isBlank(request.getRequestId())) {
            logger.error("@@InterestsMarketFacadeImpl[bindInterests] requestId is required");
        }
        if (request.getRequestId().length() > 50) {
            logger.error("@@InterestsMarketFacadeImpl[bindInterests] requestId length > 32");
        }
        if (request.getRequestTime() == null) {
            logger.error("@@InterestsMarketFacadeImpl[bindInterests] requestTime is required");
        }
        if (StringUtils.isBlank(request.getProductGroup())) {
            logger.error("@@InterestsMarketFacadeImpl[bindInterests] productGroup is required");
        }
        if (request.getProductGroup().length() > 32) {
            logger.error("@@InterestsMarketFacadeImpl[bindInterests] productGroup length > 32");
        }
        if (StringUtils.isBlank(request.getMemCode())) {
            logger.error("@@InterestsMarketFacadeImpl[bindInterests] memCode is required");
        }
        if (request.getMemCode().length() > 32) {
            logger.error("@@InterestsMarketFacadeImpl[bindInterests] memCode length > 32");
        }
        if (StringUtils.isNotBlank(request.getActivityId()) && request.getActivityId().length() > 32) {
            logger.error("@@InterestsMarketFacadeImpl[bindInterests] activityId length > 32");
        }
        String paraJsonString = JSONObject.fromObject(request.getPara()).toString();
        if (StringUtils.isNotBlank(paraJsonString) && paraJsonString.length() > 4000) {
            logger.error("@@InterestsMarketFacadeImpl[bindInterests]request received, {}",
                    ToStringBuilder.reflectionToString(request));
        }
    }

    private void recordParam(BindInterestsRequest request) throws AppBizException {
        BindInterestsReq bindReq = new BindInterestsReq();
        BeanUtils.copyProperties(request, bindReq, new String[] { "para" });
        bindReq.setPara(JSONObject.fromObject(request.getPara()).toString());
        Date now = new Date();
        bindReq.setCreateTime(now);
        bindReq.setUpdateTime(now);
        this.bindInterestsReqService.save(bindReq);
    }

    private List<Object> ruleAction(BindInterestsRequest request) {
        List<Object> facts = new ArrayList<Object>();
        BindInterestsFact fact = new BindInterestsFact();
        fact.setProductGroup(request.getProductGroup());
        fact.setExtInfo(request.getPara());
        facts.add(fact);

        List<Object> ruleActionReturn = this.ruleService.ruleGroupAction(RuleGroupType.BIND_INTERESTS.name(), facts);
        return ruleActionReturn;
    }

    private void ruleActionAndBind(BindInterestsRequest request) throws AppBizException {
        this.checkParam(request);
        this.recordParam(request);
        this.bindInterestsReqService.checkReqIdUnique(request.getRequestId());

        List<Object> ruleActionReturns = this.ruleAction(request);
        logger.info("@@InterestsMarketFacadeImpl[bindInterests] ruls size: {}" + ruleActionReturns.size());
        if (ruleActionReturns.size() == 0) {
            logger.info("@@No match event, return.");
            return;
        }

        String memCode = request.getMemCode();
        for (Object ruleActionReturn : ruleActionReturns) {
            this.bindInterests(request, memCode, (BindInterestsRuleActionReturn) ruleActionReturn);
        }
    }

}
