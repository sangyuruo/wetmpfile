package com.bill99.ebd.rip.srv.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.dal.dao.BindInterestsReqCond;
import com.bill99.ebd.rip.dal.dao.BindInterestsReqDao;
import com.bill99.ebd.rip.dal.model.BindInterestsReq;
import com.bill99.ebd.rip.enums.AppExCodeEnum;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.srv.BindInterestsReqService;

/**
 * @project: app-rip-0520
 * @description:
 * @author: lei.yu
 * @create_time: 2015年5月6日
 * @modify_time: 2015年5月6日
 */
public class BindInterestsReqServiceImpl implements BindInterestsReqService {

	@Autowired
	private BindInterestsReqDao bindInterestsReqDao;

	@Override
	public void save(BindInterestsReq req) throws AppBizException {
		bindInterestsReqDao.saveOrUpdate(req);
	}

	@Override
	public void checkReqIdUnique(String reqId) throws AppBizException {
		BindInterestsReqCond cond = new BindInterestsReqCond();
		cond.setRequestId(reqId);
		List<BindInterestsReq> queryList = bindInterestsReqDao.queryList(cond, 0, 2);
		if (queryList.size() > 1) {
			throw new AppBizException(AppExCodeEnum.BIND_INTERESTS_REQ_EXIST.getCode(),
					AppExCodeEnum.BIND_INTERESTS_REQ_EXIST.getMessage());
		}
	}

	@Override
	public List<BindInterestsReq> queryByMembercode(String membercode) {
		BindInterestsReqCond cond = new BindInterestsReqCond();
		cond.setMemCode(membercode);
		List<BindInterestsReq> queryList = bindInterestsReqDao.queryList(cond, 0, -1);
		return queryList;
	}

}
