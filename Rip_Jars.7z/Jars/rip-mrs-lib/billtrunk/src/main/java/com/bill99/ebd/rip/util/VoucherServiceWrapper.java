/**
 * 
 */
package com.bill99.ebd.rip.util;

import java.util.Random;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.enums.AppExCodeEnum;
import com.bill99.ebd.rip.enums.HoldScene;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.srv.impl.HoldVoucherResponse;

/**
 * @author shuangye.liu
 * @since Nov 18, 2016
 */
public class VoucherServiceWrapper {

    private static final Logger logger = LoggerFactory.getLogger(VoucherServiceWrapper.class);

    private static final String URL_SUFFIX_HOLD_VOUCHER = "/holdVoucher";

    private static final String CHANNELS_MRS = "MRS";

    private String voucherServiceBaseURL;

    private RestClient restClient;

    private Random ra = new Random();

    private HoldVoucherRequest buildHoldVoucherRequest(Integer interestsId, String consumerMembercode, String mobile,
            String deviceId) {
        HoldVoucherRequest request = new HoldVoucherRequest();
        request.setChannel(CHANNELS_MRS);
        request.setOrderNo(
                CHANNELS_MRS + String.valueOf(System.currentTimeMillis()) + String.valueOf(this.ra.nextInt(10000)));
        request.setInterestsId(interestsId);
        request.setConsumerMembercode(consumerMembercode);
        request.setMobile(mobile);
        request.setDeviceId(deviceId);
        request.setHoldScene(HoldScene.BEFORE.getIdentity());
        return request;
    }

    public String holdVoucher(Integer interestsId, String consumerMembercode, String mobile, String deviceId)
            throws AppBizException {
        try {
            String url = this.voucherServiceBaseURL + URL_SUFFIX_HOLD_VOUCHER;
            HoldVoucherRequest request = this.buildHoldVoucherRequest(interestsId, consumerMembercode, mobile,
                    deviceId);
            logger.info("@@hold voucher URL: {}, request {}", url, ToStringBuilder.reflectionToString(request));

            HoldVoucherResponse response = this.restClient.post(url, request, HoldVoucherResponse.class);
            logger.info("@@hold voucher response:" + ToStringBuilder.reflectionToString(response));

            if (response == null) {
                throw new AppBizException(AppExCodeEnum.UNKNOW_ERROR);
            }

            if (!AppExCodeEnum.SUCCESS.getCode().equals(response.getResponseCode())) {
                throw new AppBizException(response.getResponseCode(), response.getResponseMessage());
            }

            if (StringUtils.isBlank(response.getVoucherNo())) {
                throw new AppBizException(AppExCodeEnum.UNKNOW_ERROR);
            }

            return response.getVoucherNo();
        } catch (AppBizException e) {
            logger.error("@@holdvoucher meet AppBizException:" + e.getMessage(), e);
            throw e;
        } catch (Throwable e) {
            logger.error("@@holdvoucher meet unknow exception:" + e.getMessage(), e);
            throw new AppBizException(AppExCodeEnum.UNKNOW_ERROR);
        }
    }

    @Autowired
    public void setRestClient(RestClient restClient) {
        this.restClient = restClient;
    }

    public void setVoucherServiceBaseURL(String voucherServiceBaseURL) {
        this.voucherServiceBaseURL = voucherServiceBaseURL;
    }

}
