/**
 * 
 */
package com.bill99.ebd.rip.dal.dao;

import com.bill99.ebd.rip.dal.dao.hibernate.generic.GenericCurdDao;
import com.bill99.ebd.rip.dal.model.BindInterestsResp;

/**
 * @project: app-rip-0617
 * @description:
 * @author: lei.yu
 * @create_time: 2015年6月3日
 * @modify_time: 2015年6月3日
 */
public interface BindInterestsRespDao extends GenericCurdDao<BindInterestsResp, Long, BindInterestsRespCond> {

}
