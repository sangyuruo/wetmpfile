/**
 * 
 */
package com.bill99.ebd.rip.rule.dal.model;

import java.io.Serializable;
import java.util.Date;

/**
 * @project: app-rip-0603-mam
 * @description:
 * @author: lei.yu
 * @create_time: 2015年5月22日
 * @modify_time: 2015年5月22日
 */
public class RuleGroupDetail implements Serializable {

	private static final long serialVersionUID = -4710424497603805876L;
	private Long ruleGroupDetailId;// pk
	private Long ruleGroupId;// 规则组id
	private Long ruleId;// 规则id
	private Date createTime;// 创建时间
	private Date updateTime;// 更新时间

	public Long getRuleGroupDetailId() {
		return ruleGroupDetailId;
	}

	public Long getRuleGroupId() {
		return ruleGroupId;
	}

	public Long getRuleId() {
		return ruleId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setRuleGroupDetailId(Long ruleGroupDetailId) {
		this.ruleGroupDetailId = ruleGroupDetailId;
	}

	public void setRuleGroupId(Long ruleGroupId) {
		this.ruleGroupId = ruleGroupId;
	}

	public void setRuleId(Long ruleId) {
		this.ruleId = ruleId;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

}
