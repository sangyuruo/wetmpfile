/**
 * 
 */
package com.bill99.ebd.rip.srv.impl;

import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.srv.ActivityCheckPlugin;
import com.bill99.ebd.rip.whitelist.srv.ActivityWhiteListRuleService;

/**
 * @project: app-rip-1007
 * @description:
 * @author: lei.yu
 * @create_time: 2015年10月12日
 * @modify_time: 2015年10月12日
 */
public class ActivityWhiteListCheckImpl implements ActivityCheckPlugin {

	@Autowired
	private ActivityWhiteListRuleService activityWhiteListRuleService;

	@Override
	public void check(Integer activityId, String memCode) throws AppBizException {
		activityWhiteListRuleService.checkWhiteList(activityId, memCode);
	}

}
