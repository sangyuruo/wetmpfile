package com.bill99.ebd.rip.srv.impl;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.dal.dao.ShareRelationDao;
import com.bill99.ebd.rip.dal.model.ShareCode;
import com.bill99.ebd.rip.dal.model.ShareRelation;
import com.bill99.ebd.rip.enums.TrueFalse;
import com.bill99.ebd.rip.srv.spread.ShareRelationService;
import com.bill99.ebd.rip.wrapper.MaServiceWrapper;

public class ShareRelationServiceImpl implements ShareRelationService {
	public static final int firstResult = 0;
	public static final int maxResult = 10;
	private static final Log logger = LogFactory.getLog(ShareRelationServiceImpl.class);
	@Resource
	private ShareRelationDao shareRelationDao;

	@Autowired
	private MaServiceWrapper maServiceWrapper;

	@Override
	public void addEntity(ShareRelation shareRelation) {
		shareRelationDao.add(shareRelation);
	}

	@Override
	public void changeShareRelationStatus(String content) {
		String hql = "from ShareRelation where registerPhoneNo=? ";
		List<ShareRelation> list = shareRelationDao.queryByHql(hql, content);
		if (list.size() == 1) {
			ShareRelation shareRelation = list.get(0);
			shareRelation.setStatus(TrueFalse.TRUE.getCode());// 表示状态已激活
			shareRelation.setUpdateTime(new Date());
			shareRelationDao.saveOrUpdate(shareRelation);
		}
	}

	@Override
	public List<ShareRelation> queryByMobile(String mobile) {
		String hql = "from ShareRelation where registerPhoneNo=? ";
		return shareRelationDao.queryByHql(hql, mobile);

	}

	@Override
	public List<ShareRelation> getInvitation(String memcode) {
		String shareCodes = getShareCodesByMemcode(memcode);
		String hql = "from ShareRelation where shareCodes=? and status=1 order by updateTime desc";
		return shareRelationDao.queryByHql(hql, shareCodes);
	}

	// 根据Memcode得到ShareCodes
	private String getShareCodesByMemcode(String memcode) {
		String hql = "from ShareCode where memcode=?";
		List<ShareCode> shareCode = shareRelationDao.queryByHql(hql, memcode);
		if (shareCode != null && shareCode.size() > 0) {
			return shareCode.get(0).getShareCodes();
		}
		return "";
	}

	// 根据ShareCodes得到Memcode
	private String getMemcodeByShareCodes(String shareCodes) {
		String hql = "from ShareCode where shareCodes=?";
		List<ShareCode> shareCode = shareRelationDao.queryByHql(hql, shareCodes);
		if (shareCode != null && shareCode.size() > 0) {
			return shareCode.get(0).getMemcode();
		}
		return "";
	}

	@Override
	public List<ShareRelation> getInvitationByActivity(String memcode,
		String activityName) {
		String shareCodes = getShareCodesByMemcode(memcode);
		Object[] params = {shareCodes, activityName};
		String hql = "from ShareRelation where shareCodes=? and activityName = ? and status=1 order by updateTime desc";
		return shareRelationDao.queryByHql(hql, params);
	}
	
}
