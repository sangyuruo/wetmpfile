/**
 * 
 */
package com.bill99.ebd.rip.rule.dal.dao;

import com.bill99.ebd.rip.dal.dao.hibernate.generic.Condition;
import com.bill99.ebd.rip.rule.dal.model.RuleGroup;

/**
 * @project: app-rip-0603-mam
 * @description: 
 * @author: lei.yu
 * @create_time: 2015年5月22日
 * @modify_time: 2015年5月22日
 */
@Condition
public class RuleGroupCond extends RuleGroup{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2282324152895229699L;

}
