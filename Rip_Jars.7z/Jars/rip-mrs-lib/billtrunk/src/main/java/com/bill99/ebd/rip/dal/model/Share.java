package com.bill99.ebd.rip.dal.model;

import java.io.Serializable;
import java.util.Date;

import com.bill99.ebd.rip.enums.BooleanType;

public class Share  implements Serializable{

	private static final long serialVersionUID = 4462441928981629364L;
	
	// 唯一ID
	private Integer id;
	
	// 业务code
	private String bizCode;
	
	// 分享标题
	private String title;
	
	// 分享链接
	private String link;
	
	// 图标链接
	private String imgUrl;
	
	// 分享简介
	private String desc;
	
	// 按钮上的字
	private String worldob;
	
	// 分享类型
	private String type;
	
	// 创建时间
	private Date createTime;
	
	// 更新时间
	private Date updateTime;
	
	//是否要求实名分享
	private BooleanType isRequireRealNameShare; 

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getBizCode() {
		return bizCode;
	}

	public void setBizCode(String bizCode) {
		this.bizCode = bizCode;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}
	
	public String getImgUrl() {
		return imgUrl;
	}

	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	public String getWorldob() {
		return worldob;
	}

	public void setWorldob(String worldob) {
		this.worldob = worldob;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	
	
	public BooleanType getIsRequireRealNameShare() {
		return isRequireRealNameShare;
	}

	public void setIsRequireRealNameShare(BooleanType isRequireRealNameShare) {
		this.isRequireRealNameShare = isRequireRealNameShare;
	}
}
