/**
 * 
 */
package com.bill99.ebd.rip.whitelist.srv;

import com.bill99.ebd.rip.exception.AppBizException;

/**
 * @project: app-rip-0819
 * @description: 
 * @author: lei.yu
 * @create_time: 2015年8月19日
 * @modify_time: 2015年8月19日
 */
public interface ActivityWhiteListRuleService {

	public void checkWhiteList(Integer activityId, String memberCode) throws AppBizException;
	
	//TODO @wang.wei should remove to intra service
	//public void add(Integer activityId, List<ActivityWhiteListRuleDTO> activityWhiteListRules) throws AppBizException;
	
	//TODO @wang.wei should remove to intra service
	//public void deleteByActivityId(Integer activityId) throws AppBizException;

}
