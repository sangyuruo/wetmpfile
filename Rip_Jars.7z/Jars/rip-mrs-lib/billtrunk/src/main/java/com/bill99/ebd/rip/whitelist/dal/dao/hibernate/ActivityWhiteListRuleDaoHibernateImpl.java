/**
 * 
 */
package com.bill99.ebd.rip.whitelist.dal.dao.hibernate;

import com.bill99.ebd.rip.dal.dao.hibernate.generic.HibernateGenericDao;
import com.bill99.ebd.rip.whitelist.dal.dao.ActivityWhiteListRuleDao;
import com.bill99.ebd.rip.whitelist.dal.model.ActivityWhiteListRule;
import com.bill99.ebd.rip.whitelist.dal.model.ActivityWhiteListRuleCond;

/**
 * @project: app-rip-0819
 * @description:
 * @author: lei.yu
 * @create_time: 2015年8月19日
 * @modify_time: 2015年8月19日
 */
public class ActivityWhiteListRuleDaoHibernateImpl extends
		HibernateGenericDao<ActivityWhiteListRule, Long, ActivityWhiteListRuleCond> implements ActivityWhiteListRuleDao {

}
