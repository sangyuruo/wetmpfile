/**
 * 
 */
package com.bill99.ebd.rip.rule.dal.dao.hibernate;

import java.util.List;

import com.bill99.ebd.rip.dal.dao.hibernate.generic.HibernateGenericDao;
import com.bill99.ebd.rip.rule.dal.dao.RuleGroupCond;
import com.bill99.ebd.rip.rule.dal.dao.RuleGroupDao;
import com.bill99.ebd.rip.rule.dal.model.RuleGroup;

public class RuleGroupDaoHibernateImpl extends HibernateGenericDao<RuleGroup, Long, RuleGroupCond> implements
		RuleGroupDao {

	@Override
	public RuleGroup queryByName(String ruleGroupName) {
		RuleGroupCond cond = new RuleGroupCond();
		cond.setRuleGroupName(ruleGroupName);
		List<RuleGroup> queryList = queryList(cond, 0, 1);
		if (queryList.size() == 0) {
			return null;
		}
		return queryList.get(0);
	}

	@Override
	public void save(RuleGroup ruleGroup) {
		RuleGroup oldRuleGroup = queryByName(ruleGroup.getRuleGroupName());
		if (oldRuleGroup == null) {
			add(ruleGroup);
		} else {
			ruleGroup.setRuleGroupId(oldRuleGroup.getRuleGroupId());
			save(ruleGroup);
		}
	}

}
