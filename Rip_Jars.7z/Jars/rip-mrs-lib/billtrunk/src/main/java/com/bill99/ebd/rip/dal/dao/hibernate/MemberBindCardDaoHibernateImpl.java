package com.bill99.ebd.rip.dal.dao.hibernate;

import com.bill99.ebd.rip.dal.dao.MemberBindCardCond;
import com.bill99.ebd.rip.dal.dao.MemberBindCardDao;
import com.bill99.ebd.rip.dal.dao.hibernate.generic.HibernateGenericDao;
import com.bill99.ebd.rip.dal.model.MemberBindCard;

/**
 * 
 * 
 * @author pengfei.shen
 * @create 2016年8月8日 下午7:41:28
 * @project
 */
public class MemberBindCardDaoHibernateImpl extends HibernateGenericDao<MemberBindCard, Long, MemberBindCardCond>
		implements MemberBindCardDao {

}
