/**
 * 
 */
package com.bill99.ebd.rip.srv;

import java.util.List;

import com.bill99.ebd.rip.dal.model.ActivityCheck;
import com.bill99.ebd.rip.enums.ActivityCheckType;
import com.bill99.ebd.rip.exception.AppBizException;

/**
 * @project: app-rip
 * @description:
 * @author: lei.yu
 * @create_time: 2015年5月22日
 * @modify_time: 2015年5月22日
 */
public interface ActivityCheckService {
	public List<ActivityCheckType> queryByActivityId(Integer activityId) throws AppBizException;
	
	public ActivityCheck get(Integer activityId, ActivityCheckType type);

	public void checkActivity(Integer activityId, String memCode) throws AppBizException;

	public void add(Integer activityId, ActivityCheckType type);
	
	public void delete(Integer activityId, ActivityCheckType type);

	public void saveActivityCheck(Integer activityId, String isCheck, ActivityCheckType type);
}
