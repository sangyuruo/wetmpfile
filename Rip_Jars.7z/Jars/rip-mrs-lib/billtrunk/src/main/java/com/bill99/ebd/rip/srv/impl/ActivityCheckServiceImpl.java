/**
 * 
 */
package com.bill99.ebd.rip.srv.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.dal.dao.ActivityCheckCond;
import com.bill99.ebd.rip.dal.dao.ActivityCheckDao;
import com.bill99.ebd.rip.dal.model.ActivityCheck;
import com.bill99.ebd.rip.enums.ActivityCheckType;
import com.bill99.ebd.rip.enums.BooleanType;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.srv.ActivityCheckPlugin;
import com.bill99.ebd.rip.srv.ActivityCheckService;

/**
 * @project: app-rip
 * @description:
 * @author: lei.yu
 * @create_time: 2015年5月22日
 * @modify_time: 2015年5月22日
 */
public class ActivityCheckServiceImpl implements ActivityCheckService {

	@Autowired
	private ActivityCheckDao activityCheckDao;

	private Map<String, ActivityCheckPlugin> checkMap = new HashMap<String, ActivityCheckPlugin>();

	@Override
	public List<ActivityCheckType> queryByActivityId(Integer activityId) throws AppBizException {
		List<ActivityCheckType> checkTypes = new ArrayList<ActivityCheckType>();
		ActivityCheckCond cond = new ActivityCheckCond();
		cond.setActivityId(activityId);
		List<ActivityCheck> activityChecks = activityCheckDao.queryList(cond, 0, -1);
		if (activityChecks.size() == 0) {
			return checkTypes;
		}
		for (ActivityCheck activityCheck : activityChecks) {
			checkTypes.add(activityCheck.getActivityCheckType());
		}
		return checkTypes;
	}

	@Override
	public ActivityCheck get(Integer activityId, ActivityCheckType type) {
		ActivityCheckCond cond = new ActivityCheckCond();
		cond.setActivityId(activityId);
		cond.setActivityCheckType(type);
		List<ActivityCheck> activityChecks = activityCheckDao.queryList(cond, 0, 2);
		if (activityChecks.size() == 0) {
			return null;
		}

		return activityChecks.get(0);
	}

	@Override
	public void checkActivity(Integer activityId, String memCode) throws AppBizException {
		List<ActivityCheckType> activityCheckTypes = queryByActivityId(activityId);
		for (ActivityCheckType activityCheckType : activityCheckTypes) {
			checkMap.get(activityCheckType.name()).check(activityId, memCode);
		}
	}

	@Override
	public void add(Integer activityId, ActivityCheckType type) {
		ActivityCheckCond cond = new ActivityCheckCond();
		cond.setActivityId(activityId);
		cond.setActivityCheckType(type);
		List<ActivityCheck> activityChecks = activityCheckDao.queryList(cond, 0, 1);
		if (activityChecks.size() == 1) {
			return;
		}

		ActivityCheck check = new ActivityCheck();
		check.setActivityId(activityId);
		check.setActivityCheckType(type);
		Date now = new Date();
		check.setCreateTime(now);
		check.setUpdateTime(now);
		activityCheckDao.add(check);
	}

	@Override
	public void delete(Integer activityId, ActivityCheckType type) {
		ActivityCheck activityCheck = get(activityId, type);
		if (activityCheck != null) {
			activityCheckDao.delete(activityCheck);
		}
	}

	@Override
	public void saveActivityCheck(Integer activityId, String isCheck, ActivityCheckType type) {
		if (BooleanType.TRUE.name().equals(isCheck)) {
			add(activityId, type);
		} else {
			delete(activityId, type);
		}
	}

	public void setCheckMap(Map<String, ActivityCheckPlugin> checkMap) {
		this.checkMap = checkMap;
	}
}
