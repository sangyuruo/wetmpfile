/**
 * 
 * @author jing.xu
 * @date 2015年8月20日下午7:42:11
 * @project app-rip
 *
 */
package com.bill99.ebd.rip.srv;

import java.util.Map;

/**
 * 参数配置服务类
 * 
 * @author jing.xu
 * @date 2015年8月20日下午7:42:11
 * @project app-rip
 *
 */
public interface ParamConfigService {

	/**
	 * 获取某项目类型下所有参数
	 * 
	 * @param type
	 * @return
	 * @author jing.xu
	 * @updatedate 2015年8月20日下午7:44:17
	 */
	public Map<String, String> getByType(String type);

	/**
	 * 根据type,name获取指定参数
	 * 
	 * @param type
	 * @param name
	 * @return
	 * @author jing.xu
	 * @updatedate 2015年8月20日下午7:45:19
	 */
	public String getByName(String type, String name);

	/**
	 * 添加一个记录
	 * 
	 * @param type
	 * @param name
	 * @param value
	 * @throws Exception
	 * @author jing.xu
	 * @updatedate 2015年8月20日下午7:58:24
	 */
	public void addParam(String type, String name, String value)
			throws Exception;

}
