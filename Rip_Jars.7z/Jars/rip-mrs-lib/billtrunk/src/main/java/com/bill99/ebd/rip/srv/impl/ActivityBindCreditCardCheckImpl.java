/**
 * 
 */
package com.bill99.ebd.rip.srv.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.dal.model.Activity;
import com.bill99.ebd.rip.enums.AppExCodeEnum;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.srv.ActivityCheckPlugin;
import com.bill99.ebd.rip.srv.ActivityService;
import com.bill99.ebd.rip.wrapper.MaServiceWrapper;

/**
 * @project: app-rip-1007
 * @description:
 * @author: lei.yu
 * @create_time: 2015年10月12日
 * @modify_time: 2015年10月12日
 */
public class ActivityBindCreditCardCheckImpl implements ActivityCheckPlugin {

	private static final String VERIFIED = "1";
	private static final String CREDIT_CARD_TYPE = "0001";

	@Autowired
	private ActivityService activityService;

	@Autowired
	private MaServiceWrapper maServiceWrapper;

	@Override
	public void check(Integer activityId, String memCode) throws AppBizException {
		Activity activity = activityService.getAndCheck(activityId);
		checkIsBindCreditCard(memCode, activity.getStartTime(), activity.getEndTime());
	}


	private void checkIsBindCreditCard(String memberCode, Date startDate, Date endDate) throws AppBizException {
		Map<String, Object> resultMap = maServiceWrapper.queryMemberCards(memberCode, VERIFIED, CREDIT_CARD_TYPE);

		@SuppressWarnings("unchecked")
		List<Map<String, Object>> bindingCards = (List<Map<String, Object>>) resultMap.get("bindCards");
		if (bindingCards.size() == 0) {
			throw new AppBizException(AppExCodeEnum.NOT_BIND_CREDIT_CARD);
		}

		boolean isBind = false;
		for (Map<String, Object> bindingCardMap : bindingCards) {
			Date creationDate = new Date((Long) bindingCardMap.get("creationDate"));
			if (creationDate.compareTo(startDate) >= 0 && creationDate.compareTo(endDate) <= 0) {
				isBind = true;
				break;
			}
		}
		if (!isBind) {
			throw new AppBizException(AppExCodeEnum.NOT_BIND_CREDIT_CARD);
		}
	}
}
