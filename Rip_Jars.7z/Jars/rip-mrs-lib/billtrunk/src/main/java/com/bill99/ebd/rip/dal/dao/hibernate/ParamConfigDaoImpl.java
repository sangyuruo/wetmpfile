package com.bill99.ebd.rip.dal.dao.hibernate;

import com.bill99.ebd.rip.dal.dao.ParamConfigCond;
import com.bill99.ebd.rip.dal.dao.ParamConfigDao;
import com.bill99.ebd.rip.dal.dao.hibernate.generic.HibernateGenericDao;
import com.bill99.ebd.rip.dal.model.ParamConfig;

public class ParamConfigDaoImpl extends HibernateGenericDao<ParamConfig, Integer, ParamConfigCond> implements ParamConfigDao{

}
