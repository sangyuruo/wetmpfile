package com.bill99.ebd.rip.whitelist.dal.model;

import java.io.Serializable;
import java.util.Date;

import com.bill99.ebd.rip.enums.WhiteListKeyType;

/**
* @ClassName: WhiteList 
* @Description: 白名单模型
* @author gumin
* @date 2015年8月19日 下午2:57:16 
 */
public class WhiteList implements Serializable{

	private static final long serialVersionUID = 4423302067981466783L;
	
	// 唯一ID
	private Integer id;
	
	// 组名
	private String whiteListName;
	
	// 关键字类型 ： 电话号码 || memberCode
	private WhiteListKeyType whiteListKeyType;
	
	// 关键字 ： 电话号码 || memberCode
	private String keyWord;
	
	// 创建时间
	private Date createTime;
	
	// 更新时间
	private Date updateTime;

	public Integer getId() {
		return id;
	}

	public String getWhiteListName() {
		return whiteListName;
	}

	public WhiteListKeyType getWhiteListKeyType() {
		return whiteListKeyType;
	}

	public String getKeyWord() {
		return keyWord;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public void setWhiteListName(String whiteListName) {
		this.whiteListName = whiteListName;
	}

	public void setWhiteListKeyType(WhiteListKeyType whiteListKeyType) {
		this.whiteListKeyType = whiteListKeyType;
	}

	public void setKeyWord(String keyWord) {
		this.keyWord = keyWord;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	
}
