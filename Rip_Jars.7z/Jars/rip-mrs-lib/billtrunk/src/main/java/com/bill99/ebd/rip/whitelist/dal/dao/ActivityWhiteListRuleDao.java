/**
 * 
 */
package com.bill99.ebd.rip.whitelist.dal.dao;

import com.bill99.ebd.rip.dal.dao.hibernate.generic.GenericCurdDao;
import com.bill99.ebd.rip.whitelist.dal.model.ActivityWhiteListRule;
import com.bill99.ebd.rip.whitelist.dal.model.ActivityWhiteListRuleCond;

/**
 * @project: app-rip-0819
 * @description:
 * @author: lei.yu
 * @create_time: 2015年8月19日
 * @modify_time: 2015年8月19日
 */
public interface ActivityWhiteListRuleDao extends
		GenericCurdDao<ActivityWhiteListRule, Long, ActivityWhiteListRuleCond> {

}
