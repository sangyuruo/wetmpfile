package com.bill99.ebd.rip.dal.dao;

import com.bill99.ebd.rip.dal.model.ShareCode;

public class ShareCodeCond extends ShareCode{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
