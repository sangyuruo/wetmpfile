/**
 * 
 */
package com.bill99.ebd.rip.srv.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.dal.dao.MamRegisterLogCond;
import com.bill99.ebd.rip.dal.dao.MamRegisterLogDao;
import com.bill99.ebd.rip.dal.model.MamRegisterLog;
import com.bill99.ebd.rip.enums.AppExCodeEnum;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.srv.MamRegisterLogService;

/**
 * @project: app-rip-1007
 * @description:
 * @author: lei.yu
 * @create_time: 2015年10月9日
 * @modify_time: 2015年10月9日
 */
public class MamRegisterLogServiceImpl implements MamRegisterLogService {

	@Autowired
	private MamRegisterLogDao mamRegisterLogDao;

	@Override
	public void add(MamRegisterLog mamRegisterLog) {
		Date now = new Date();
		mamRegisterLog.setCreateTime(now);
		mamRegisterLog.setUpdateTime(now);
		mamRegisterLogDao.add(mamRegisterLog);
	}

	@Override
	public MamRegisterLog getByMemberCode(String memberCode) throws AppBizException {
		MamRegisterLogCond cond = new MamRegisterLogCond();
		cond.setMemberCode(memberCode);
		cond.setOrders("createTime-");
		List<MamRegisterLog> MamRegisterLogs = mamRegisterLogDao.queryList(cond, 0, 1);
		if (MamRegisterLogs.size() == 0) {
			throw new AppBizException(AppExCodeEnum.MEMBER_IS_EMPTY_AND_MOBILE_NOT_REGISTER);
		}
		return MamRegisterLogs.get(0);
	}

}
