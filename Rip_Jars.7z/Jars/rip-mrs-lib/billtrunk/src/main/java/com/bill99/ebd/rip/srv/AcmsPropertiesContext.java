package com.bill99.ebd.rip.srv;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * ACMS参数上下文
 * 
 * @author jakoes.wu
 * @date 2016年2月3日下午12:54:29
 * @project app-rip-website-20160203
 * 
 */
public class AcmsPropertiesContext {

    public static final String EBD_RIP_WEBSITE_ACMS_H5_IP_LIMIT = "ebd.rip.website.notify.validatecode.limit.ip";
    public static final String EBD_RIP_WEBSITE_ACMS_H5_MOBILE_LIMIT_DAY = "ebd.rip.website.notify.validatecode.limit.day";
    public static final String EBD_RIP_WEBSITE_ACMS_H5_MOBILE_LIMIT_MINUTE = "ebd.rip.website.notify.validatecode.limit.minute";
    public static final String EBD_RIP_WEBSITE_ACMS_H5_MARKETING_ACTIVITY_INTERESTS = "ebd.rip.global.marketing.d11.interests";
    public static final String EBD_RIP_WEBSITE_ACMS_H5_MARKETING_ACTIVITY_MMC = "ebd.rip.global.marketing.d11.mmc";

    private Map<String, String> propertiesMap = new ConcurrentHashMap<String, String>();

    public void setPropertiesMap(Map<String, String> propertiesMap) {
        this.propertiesMap = propertiesMap;
    }

    public String getProperty(String key) {
        return propertiesMap.get(key);
    }

    public void setProperty(String key, String value) {
        propertiesMap.put(key, value);
    }
}
