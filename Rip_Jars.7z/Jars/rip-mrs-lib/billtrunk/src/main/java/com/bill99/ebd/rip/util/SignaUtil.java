package com.bill99.ebd.rip.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bill99.ebd.rip.enums.AppExCodeEnum;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.weixin.srv.impl.WeixinServiceImpl;

/**
 * 签名工具
 * @author emily.gu
 * @create_time 2015.10.09
 */
public class SignaUtil {
	
	private final static Log logger = LogFactory.getLog(WeixinServiceImpl.class);
	
	/**
	 * 加签
	 * @param signaType
	 * @param signaData
	 * @return
	 * @throws AppBizException 
	 */
	public static String signa(String signaType, String signaData) throws AppBizException {
		logger.info("SignaUtil.signa in ......  ");
		String signature = null;
		
		// 签名
		MessageDigest md = null; 
		try {
			md = MessageDigest.getInstance("SHA-1");  
			byte[] digest = md.digest(signaData.getBytes());  
			signature = byteToStr(digest);
			System.out.println(" signature : " + signature);
		} catch (NoSuchAlgorithmException e) {
			logger.error(e.getMessage());
			throw new AppBizException(AppExCodeEnum.UNKNOW_ERROR.getCode(), 
					AppExCodeEnum.UNKNOW_ERROR.getMessage());
		}		
		
		logger.info("WeixinServiceImpl.signa out ......  ");
		return signature;
	}
	
	// 将字节数组转换为十六进制字符串 
    private static String byteToStr(byte[] byteArray) {  
        String strDigest = "";  
        for (int i = 0; i < byteArray.length; i++) {  
            strDigest += byteToHexStr(byteArray[i]);  
        }  
        return strDigest;  
    }  
    
    // 将字节转换为十六进制字符串
    private static String byteToHexStr(byte mByte) {  
        char[] Digit = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };  
        char[] tempArr = new char[2];  
        tempArr[0] = Digit[(mByte >>> 4) & 0X0F];  
        tempArr[1] = Digit[mByte & 0X0F];  
        String s = new String(tempArr);  
        return s;  
    }  

}
