/**
 * 
 */
package com.bill99.ebd.rip.dal.model;

import java.io.Serializable;
import java.util.Date;

/**
 * @project: app-rip-0617
 * @description:
 * @author: lei.yu
 * @create_time: 2015年6月2日
 * @modify_time: 2015年6月2日
 */
public class BindInterestsResp implements Serializable {
	private static final long serialVersionUID = 7952710715190358759L;
	private Long bindInterestsRespId;// pk
	private String requestId;// 请求方id
	private Integer activityId; // 活动id
	private String ruleName; // 规则名称
	private String interestsInfo; // 权益包json
	private String memo;// 备注
	private String respCode;// 处理返回code
	private Date createTime;// 创建时间
	private Date updateTime;// 更新时间

	public Long getBindInterestsRespId() {
		return bindInterestsRespId;
	}

	public String getRequestId() {
		return requestId;
	}

	public Integer getActivityId() {
		return activityId;
	}

	public String getRuleName() {
		return ruleName;
	}

	public String getInterestsInfo() {
		return interestsInfo;
	}

	public String getMemo() {
		return memo;
	}

	public String getRespCode() {
		return respCode;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setBindInterestsRespId(Long bindInterestsRespId) {
		this.bindInterestsRespId = bindInterestsRespId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public void setActivityId(Integer activityId) {
		this.activityId = activityId;
	}

	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}

	public void setInterestsInfo(String interestsInfo) {
		this.interestsInfo = interestsInfo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	public void setRespCode(String respCode) {
		this.respCode = respCode;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
}
