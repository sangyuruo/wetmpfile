/**
 * 
 */
package com.bill99.ebd.rip.acms.handlers;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bill99.ebd.rip.srv.AcmsPropertiesContext;
import com.bill99.inf.acms.client.core.ChangeHandler;
import com.bill99.inf.acms.client.core.ChangedConfig;
import com.bill99.inf.acms.client.core.ConfigOperation;

/**
 * IP限制回调器
 * 
 * @author jakoes.wu
 * @date 2016年2月3日下午1:03:28
 * @project app-rip-website-20160203
 * 
 */
public class AcmsRIPChangeHandler implements ChangeHandler {
    private static final Log log = LogFactory.getLog(AcmsRIPChangeHandler.class);

    @Resource
    private AcmsPropertiesContext acmsPropertiesContext;

    @Override
    public void handle(List<ChangedConfig> changedConfigs) {
        for (ChangedConfig changedConfig : changedConfigs) {
            log.info("@@acms properties handled.key:{" + changedConfig.getConfigKey() + "},value:{"
                    + changedConfig.getConfigValue() + "},Operation:{" + changedConfig.getOp() + "}");
            if (!ConfigOperation.Update.equals(changedConfig.getOp())) {
                return;
            }

            acmsPropertiesContext.setProperty(changedConfig.getConfigKey(), changedConfig.getConfigValue());
        }
    }
}
