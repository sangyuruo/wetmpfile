/**
 * 
 */
package com.bill99.ebd.rip.dal.dao;

import com.bill99.ebd.rip.dal.dao.hibernate.generic.Condition;
import com.bill99.ebd.rip.dal.model.MemberBindCard;

/**
 * 
 * 
 * @author pengfei.shen
 * @create 2016年8月8日 下午7:40:15
 * @project
 */
@Condition
public class MemberBindCardCond extends MemberBindCard{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
}
