/**
 * 
 */
package com.bill99.ebd.rip.rule.srv.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;

import com.bill99.ebd.rip.dal.model.RuleActionReturn;
import com.bill99.ebd.rip.enums.AppExCodeEnum;
import com.bill99.ebd.rip.enums.RuleStatus;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.rule.dal.dao.RuleCond;
import com.bill99.ebd.rip.rule.dal.dao.RuleDao;
import com.bill99.ebd.rip.rule.dal.dao.RuleGroupDao;
import com.bill99.ebd.rip.rule.dal.dao.RuleGroupDetailDao;
import com.bill99.ebd.rip.rule.dal.model.Rule;
import com.bill99.ebd.rip.rule.dal.model.RuleGroup;
import com.bill99.ebd.rip.rule.dal.model.RuleGroupDetail;
import com.bill99.ebd.rip.rule.srv.RuleService;
import com.bill99.ebd.rip.rule.srv.RuleTemplateFactory;

/**
 * @project: app-rip
 * @description:
 * @author: lei.yu
 * @create_time: 2015年5月22日
 * @modify_time: 2015年5月22日
 */
public class RuleServiceImpl implements RuleService {

	@Autowired
	private RuleGroupDao ruleGroupDao;
	@Autowired
	private RuleGroupDetailDao ruleGroupDetailDao;
	@Autowired
	private RuleDao ruleDao;
	@Autowired
	private RuleTemplateFactory ruleTemplateFactory;
	/**
	 * 规则模板缓存
	 */
	private ConcurrentHashMap<Long, RuleTemplateCart> ruleTemplateCacheByGroupId = new ConcurrentHashMap<Long, RuleTemplateCart>();

	private class RuleTemplateCart {
		private RuleTemplate ruleTemplate;
		private java.util.Date updateTime;

		public RuleTemplate getRuleTemplate() {
			return ruleTemplate;
		}

		public void setRuleTemplate(RuleTemplate ruleTemplate) {
			this.ruleTemplate = ruleTemplate;
		}

		public java.util.Date getUpdateTime() {
			return updateTime;
		}

		public void setUpdateTime(java.util.Date updateTime) {
			this.updateTime = updateTime;
		}
	}

	@Override
	public List<Object> ruleGroupAction(String ruleGroupName, List<Object> facts) {
		RuleTemplate ruleTemplate = getRuleTemplateByGroupName(ruleGroupName);
		List<Object> internalFacts = new ArrayList<Object>();
		internalFacts.addAll(facts);

		RuleActionReturn rar = new RuleActionReturn();
		internalFacts.add(rar);

		ruleTemplate.ruleAction(internalFacts);

		return rar.getReturns();
	}

	@Override
	public void updateRule(Rule rule) {
		Date now = new Date();
		rule.setUpdateTime(now);
		Rule oldRule = ruleDao.get(rule.getRuleId());
		BeanUtils.copyProperties(rule, oldRule);
		ruleDao.saveOrUpdate(oldRule);

		Set<Long> ruleGroupIds = ruleGroupDetailDao.queryRuleGroupIdByRuleId(rule.getRuleId());
		for (Long ruleGroupId : ruleGroupIds) {
			RuleGroup ruleGroup = ruleGroupDao.get(ruleGroupId);
			ruleGroup.setUpdateTime(now);
			ruleGroupDao.saveOrUpdate(ruleGroup);
		}
	}

	@Override
	public void addRule(String ruleGroupName, Rule rule) throws AppBizException {
		checkRulePara(rule);

		addRule(rule);

		Assert.notNull(ruleGroupName);
		RuleGroup ruleGrp = ruleGroupDao.queryByName(ruleGroupName);
		updateRuleGroup(ruleGrp);

		addRulGroupDetail(rule, ruleGrp.getRuleGroupId());
	}

	private void updateRuleGroup(RuleGroup ruleGrp) {
		Assert.notNull(ruleGrp);
		Date now = new Date();
		ruleGrp.setUpdateTime(now);
		ruleGroupDao.saveOrUpdate(ruleGrp);
	}

	private void addRulGroupDetail(Rule rule, Long ruleGroupId) {
		RuleGroupDetail detail = new RuleGroupDetail();
		detail.setRuleGroupId(ruleGroupId);
		detail.setRuleId(rule.getRuleId());
		Date now2 = new Date();
		detail.setCreateTime(now2);
		detail.setUpdateTime(now2);
		ruleGroupDetailDao.add(detail);
	}

	private void addRule(Rule rule) {
		if (rule.getEnableTime().after(new Date())) {
			rule.setStatus(RuleStatus.INIT);
		} else {
			rule.setStatus(RuleStatus.ENABLE);
		}
		Date now = new Date();
		rule.setCreateTime(now);
		rule.setUpdateTime(now);
		ruleDao.add(rule);
	}

	private void checkRulePara(Rule rule) throws AppBizException {
		Date startTime = rule.getEnableTime();
		Date endTime = rule.getExpireTime();

		if (StringUtils.isBlank(rule.getRuleName())) {
			throw new AppBizException(AppExCodeEnum.RULE_NAME_NOT_EMPTY);
		}
		if (startTime == null) {
			throw new AppBizException(AppExCodeEnum.RULE_STARTTIME_NOT_EMPTY);
		}
		if (endTime == null) {
			throw new AppBizException(AppExCodeEnum.RULE_ENDTIME_NOT_EMPTY);
		}
		if (startTime.after(endTime)) {
			throw new AppBizException(AppExCodeEnum.RULE_STARTTIME_NOT_AFTER_ENDTIME);
		}
		if (endTime.before(new Date())) {
			throw new AppBizException(AppExCodeEnum.RULE_ENDTIME_NOT_BEFORE_CURRENTTIME);
		}

		// TODO
		RuleCond cond = new RuleCond();
		cond.setRuleName(rule.getRuleName());
		List<RuleStatus> statusList = new ArrayList<RuleStatus>();
		statusList.add(RuleStatus.INIT);
		statusList.add(RuleStatus.ENABLE);
		cond.setStatusList(statusList);
		List<Rule> ruleList = ruleDao.queryList(cond, 0, 1);
		if (!ruleList.isEmpty()) {
			throw new AppBizException(AppExCodeEnum.RULE_EXIST);
		}
	}

	@Override
	public List<Rule> queryList(RuleCond cond, int first, int max) {
		return ruleDao.queryList(cond, first, max);
	}

	private RuleTemplate getRuleTemplateByGroupName(String ruleGroupName) {
		RuleGroup ruleGrp = ruleGroupDao.queryByName(ruleGroupName);
		Long ruleGroupId = ruleGrp.getRuleGroupId();
		RuleTemplateCart cart = ruleTemplateCacheByGroupId.get(ruleGroupId);
		if (cart != null && cart.getUpdateTime().equals(ruleGrp.getUpdateTime())) {
			return cart.getRuleTemplate();
		} else {
			// 规则组更新
			List<Rule> rules = queryRuleByGroupId(ruleGroupId);
			List<String> ruleDrls = new ArrayList<String>();
			for (Rule rule : rules) {
				ruleDrls.add(rule.getRule());
			}

			RuleTemplate rt = ruleTemplateFactory.newRuleTemplate(ruleDrls);

			cart = new RuleTemplateCart();
			cart.setUpdateTime(ruleGrp.getUpdateTime());
			cart.setRuleTemplate(rt);

			ruleTemplateCacheByGroupId.put(ruleGroupId, cart);
			return cart.ruleTemplate;
		}
	}

	private List<Rule> queryRuleByGroupId(Long ruleGroupId) {
		// TODO @lei.yu需要优化,使用表关联的方式查询
		List<RuleGroupDetail> ruleGroupDetails = ruleGroupDetailDao.queryByGroupId(ruleGroupId);
		List<Rule> rules = new ArrayList<Rule>();
		for (RuleGroupDetail ruleGroupDetail : ruleGroupDetails) {
			Rule rule = ruleDao.get(ruleGroupDetail.getRuleId());
			if (RuleStatus.ENABLE.equals(rule.getStatus())) {
				rules.add(rule);
			}
		}
		return rules;
	}

	@Override
	public Rule get(Long id) {
		return ruleDao.get(id);
	}

	@Override
	public void delRules(Set<Long> ruleIds) {
		Set<Long> ruleGroupIds = new HashSet<Long>();
		for (Long ruleId : ruleIds) {
			Rule rule = ruleDao.get(ruleId);
			ruleDao.delete(rule);

			List<RuleGroupDetail> ruleGroupDetails = ruleGroupDetailDao.queryRuleGroupByRuleId(ruleId);
			for (RuleGroupDetail ruleGroupDetail : ruleGroupDetails) {
				ruleGroupIds.add(ruleGroupDetail.getRuleGroupId());
				ruleGroupDetailDao.delete(ruleGroupDetail);
			}
		}

		for (Long ruleGroupId : ruleGroupIds) {
			RuleGroup ruleGroup = ruleGroupDao.get(ruleGroupId);
			updateRuleGroup(ruleGroup);
		}
	}

	@Override
	public Rule getValidByName(String name) throws AppBizException {
		RuleCond cond = new RuleCond();
		cond.setRuleName(name);
		List<RuleStatus> statusList = new ArrayList<RuleStatus>();
		statusList.add(RuleStatus.INIT);
		statusList.add(RuleStatus.ENABLE);
		cond.setStatusList(statusList);
		List<Rule> ruleList = ruleDao.queryList(cond, 0, 2);
		if (ruleList.size() == 0) {
			throw new AppBizException(AppExCodeEnum.ACTIVITY_RULE_NOT_FOUND);
		}
		if (ruleList.size() > 1) {
			throw new AppBizException(AppExCodeEnum.RULE_EXIST);
		}
		return ruleList.get(0);
	}
}
