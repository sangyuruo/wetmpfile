/**
 * 
 */
package com.bill99.ebd.rip.srv.impl;

import java.io.Serializable;

/**
 * @project: app-rip-0520
 * @description:
 * @author: lei.yu
 * @create_time: 2015年5月6日
 * @modify_time: 2015年5月6日
 */
public class InterestsPackage implements Serializable {
	private static final long serialVersionUID = 3429793281744598600L;
	private Integer interestsId;// 权益Pk
	private Integer cnt;// 数量

	public InterestsPackage(int interestsId, int cnt) {
		this.interestsId = interestsId;
		this.cnt = cnt;
	}
	
	public Integer getInterestsId() {
		return interestsId;
	}

	public Integer getCnt() {
		return cnt;
	}

	public void setInterestsId(Integer interestsId) {
		this.interestsId = interestsId;
	}

	public void setCnt(Integer cnt) {
		this.cnt = cnt;
	}

}
