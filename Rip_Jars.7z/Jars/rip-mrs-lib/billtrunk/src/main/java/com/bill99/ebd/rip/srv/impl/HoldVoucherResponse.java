package com.bill99.ebd.rip.srv.impl;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * 领券结果
 * 
 * @author jakoes.wu
 * @date 2016年10月18日下午2:13:58
 * @project rip-mrs-lib-20161014
 * 
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class HoldVoucherResponse {

    private String requestId;

    private String responseCode;

    private String responseMessage;

    private String consumerMembercode;

    private String voucherNo;

    public String getConsumerMembercode() {
        return this.consumerMembercode;
    }

    public String getRequestId() {
        return this.requestId;
    }

    public String getResponseCode() {
        return this.responseCode;
    }

    public String getResponseMessage() {
        return this.responseMessage;
    }

    public String getVoucherNo() {
        return this.voucherNo;
    }

    public void setConsumerMembercode(String consumerMembercode) {
        this.consumerMembercode = consumerMembercode;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public void setResponseCode(String responseCode) {
        this.responseCode = responseCode;
    }

    public void setResponseMessage(String responseMessage) {
        this.responseMessage = responseMessage;
    }

    public void setVoucherNo(String voucherNo) {
        this.voucherNo = voucherNo;
    }

}
