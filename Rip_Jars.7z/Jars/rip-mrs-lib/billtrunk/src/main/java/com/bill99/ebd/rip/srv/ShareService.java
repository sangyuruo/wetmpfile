package com.bill99.ebd.rip.srv;

import java.util.List;

import com.bill99.ebd.rip.dal.dao.ShareCond;
import com.bill99.ebd.rip.dal.model.Share;
import com.bill99.ebd.rip.exception.AppBizException;

/**
 * 分享接口
 * @author emily.gu
 * @create_time 2015.09.29
 */
public interface ShareService {
	
	/**
	* @Title: query 
	* @Description: 分享数据查询
	* @param ShareCond cond
	* @param int arg1
	* @param int arg2
	* @return List<Share>
	* @throws AppBizException
	 */
	public List<Share> query(ShareCond cond, int arg1, int arg2) throws AppBizException;

}
