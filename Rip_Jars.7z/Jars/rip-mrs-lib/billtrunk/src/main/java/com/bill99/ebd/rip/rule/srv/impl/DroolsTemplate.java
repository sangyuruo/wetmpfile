package com.bill99.ebd.rip.rule.srv.impl;

import java.io.ByteArrayInputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.drools.FactHandle;
import org.drools.RuleBase;
import org.drools.RuleBaseFactory;
import org.drools.WorkingMemory;
import org.drools.compiler.DrlParser;
import org.drools.compiler.PackageBuilder;
import org.drools.lang.descr.PackageDescr;

/**
 * @description: Drools模板，规则化服务工具类
 */
public class DroolsTemplate implements RuleTemplate {
	/**
	 * ruleBase
	 */
	private RuleBase ruleBase;

	/**
	 * 规则drl
	 */
	private List<String> rules;

	public DroolsTemplate(List<String> rules) {
		this.rules = rules;
		ruleBase = getRuleBase();
	}

	public void ruleAction(List<Object> facts) {
		ruleAction(facts, new HashMap<String, Object>());
	}

	public void ruleAction(List<Object> facts, Map<String, Object> globalParameters) {
		WorkingMemory wm = getWorkingMemory(facts);

		for (Iterator<String> it = globalParameters.keySet().iterator(); it.hasNext();) {
			String globalParameterName = it.next();
			Object globalParameterValue = globalParameters.get(globalParameterName);
			wm.setGlobal(globalParameterName, globalParameterValue);
		}

		wm.fireAllRules();
	}

	/**
	 * 返回RuleBase当前的WorkingMemory,并注入相关事实.
	 * 
	 * @param assertObjects
	 *            注入的事实,变长参数支持多种输入方式.
	 * @return WorkingMemory
	 */
	private WorkingMemory getWorkingMemory(List<Object> assertObjects) {
		WorkingMemory currentWorkingMemory = getRuleBase().newWorkingMemory();

		for (Object object : assertObjects) {
			assertObject(currentWorkingMemory, object);
		}

		// 缺省注入一个推断对象
		assertObject(currentWorkingMemory, new Inference());

		return currentWorkingMemory;
	}

	/**
	 * 往workingMemory中注入事实的函数,如果workingMemory中已存在该事实,进行更新.
	 * 
	 * @param workingMemory
	 * @param element
	 *            事实
	 */
	private void assertObject(WorkingMemory workingMemory, Object element) {
		if (element == null) {
			return;
		}

		FactHandle fact = workingMemory.getFactHandle(element);
		if (fact == null) {
			workingMemory.assertObject(element);
		} else {
			workingMemory.modifyObject(fact, element);
		}
	}

	/**
	 * 得到RuleBase
	 * 
	 * @return RuleBase
	 */
	private RuleBase getRuleBase() {
		if (ruleBase == null) {
			try {
				compileRuleBase();
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}
		return ruleBase;
	}

	/**
	 * 根据dsr编译RuleBase.
	 */
	private void compileRuleBase() {
		ruleBase = RuleBaseFactory.newRuleBase();
		try {
			if (rules != null) {
				for (String rule : rules) {
					PackageBuilder builder = new PackageBuilder();
					PackageDescr packageDescr;
					Reader drlReader = new InputStreamReader(new ByteArrayInputStream(rule.getBytes()));
					packageDescr = new DrlParser().parse(drlReader);
					builder.addPackage(packageDescr);
				ruleBase.addPackage(builder.getPackage());
			}
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
}