package com.bill99.ebd.rip.srv.impl;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.dal.dao.ActivityCond;
import com.bill99.ebd.rip.dal.dao.ActivityDao;
import com.bill99.ebd.rip.dal.dao.MerchantDao;
import com.bill99.ebd.rip.dal.dao.VoucherRepositoryDao;
import com.bill99.ebd.rip.dal.model.Activity;
import com.bill99.ebd.rip.enums.ActivitySrcType;
import com.bill99.ebd.rip.enums.ActivityStatus;
import com.bill99.ebd.rip.enums.AppExCodeEnum;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.srv.ActivityInterestsRelService;
import com.bill99.ebd.rip.srv.ActivityService;
import com.bill99.ebd.rip.srv.AddActivityRequest;
import com.bill99.ebd.rip.srv.InterestsService;

public class ActivityServiceImpl implements ActivityService {

	private final Log log = LogFactory.getLog(getClass());
	
	private ActivityDao activityDao;
	private MerchantDao merchantDao;
	@Autowired
	private VoucherRepositoryDao voucherRepositoryDao;
	@Autowired
	private InterestsService interestsService;
	@Autowired
	private ActivityInterestsRelService activityInterestsRelService;
	

	public void setMerchantDao(MerchantDao merchantDao) {
		this.merchantDao = merchantDao;
	}

	public void setActivityDao(ActivityDao activityDao) {
		this.activityDao = activityDao;
	}

	public List<Activity> loadAllActivity() throws AppBizException {
		return activityDao.loadAll();
	}

	public List<Activity> queryActivity(ActivityCond cond) {

		return activityDao.queryList(cond, 0, -1);
	}

	@Override
	public Activity addActivity(AddActivityRequest addActivityRequest) throws AppBizException {

		String activityName = addActivityRequest.getActivityName();
		Date startTime = addActivityRequest.getStartTime();
		Date endTime = addActivityRequest.getEndTime();
		ActivitySrcType srcType = addActivityRequest.getSrcType();
		
		checkActivityPara(activityName, startTime, endTime, srcType);
		ActivityCond cond = new ActivityCond();
		cond.setActivityName(activityName);
		cond.setStartTime(startTime);
		cond.setEndTime(endTime);
		List<Activity> activityList = activityDao.queryList(cond, 0, 1);
		if (!activityList.isEmpty()) {
			throw new AppBizException(AppExCodeEnum.ACTIVITY_EXIST.getCode(),
					AppExCodeEnum.ACTIVITY_EXIST.getMessage());
		}
		Activity activity = new Activity();
		activity.setActivityName(activityName);
		activity.setStartTime(startTime);
		activity.setEndTime(endTime);
		activity.setCreateTime(new Date());
		activity.setUpdateTime(new Date());
		if (activity.getStartTime().after(new Date())) {
			activity.setStatus(ActivityStatus.INIT.getId());
		} else {
			activity.setStatus(ActivityStatus.ENABLE.getId());
		}
		activity.setIsLoan(Activity.IS_NOT_LOAN);

		activity.setActivityAddress(addActivityRequest.getActivityAddress());
		activity.setInstruction(addActivityRequest.getInstruction());
		activity.setAdContent(addActivityRequest.getAdContent());
		activity.setDescription(addActivityRequest.getDescription());
		activity.setSrcType(srcType);
		activityDao.add(activity);
		return activity;
	}

	private void checkActivityPara(String activityName, Date startTime, Date endTime, ActivitySrcType srcType)
			throws AppBizException {
		if(srcType == null){
			throw new AppBizException(AppExCodeEnum.UNKNOW_ERROR.getCode(), "activity srcType is empty!");
		}
		if (StringUtils.isBlank(activityName)) {
			throw new AppBizException(AppExCodeEnum.ACTIVITY_NAME_NOT_EMPTY.getCode(),
					AppExCodeEnum.ACTIVITY_NAME_NOT_EMPTY.getMessage());
		}
		if (startTime == null) {
			throw new AppBizException(AppExCodeEnum.ACTIVITY_STARTTIME_NOT_EMPTY.getCode(),
					AppExCodeEnum.ACTIVITY_STARTTIME_NOT_EMPTY.getMessage());
		}
		if (endTime == null) {
			throw new AppBizException(AppExCodeEnum.ACTIVITY_ENDTIME_NOT_EMPTY.getCode(),
					AppExCodeEnum.ACTIVITY_ENDTIME_NOT_EMPTY.getMessage());
		}
		if (startTime.after(endTime)) {
			throw new AppBizException(AppExCodeEnum.ACTIVITY_STARTTIME_NOT_AFTER_ENDTIME.getCode(),
					AppExCodeEnum.ACTIVITY_STARTTIME_NOT_AFTER_ENDTIME.getMessage());
		}
		if (endTime.before(new Date())) {
			throw new AppBizException(AppExCodeEnum.ACTIVITY_ENDTIME_NOT_BEFORE_CURRENTTIME.getCode(),
					AppExCodeEnum.ACTIVITY_ENDTIME_NOT_BEFORE_CURRENTTIME.getMessage());
		}
	}
	
	@Override
	public void updateActivity(Activity activity) throws AppBizException {
		String activityName = activity.getActivityName();
		Date startTime = activity.getStartTime();
		Date endTime = activity.getEndTime();
		ActivitySrcType srcType = activity.getSrcType();
		checkActivityPara(activityName, startTime, endTime, srcType);
		
		activity.setUpdateTime(new Date());
		activityDao.saveOrUpdate(activity);
		
	}

	public Activity addActivity(String activityName, Date startTime, Date endTime) throws AppBizException {
		AddActivityRequest addActivityRequest = new AddActivityRequest();
		addActivityRequest.setActivityName(activityName);
		addActivityRequest.setStartTime(startTime);
		addActivityRequest.setEndTime(endTime);
		addActivityRequest.setSrcType(ActivitySrcType.SPDB);
		return addActivity(addActivityRequest);
	}

	public Activity getActivityById(Integer activityId) throws AppBizException {

		return activityDao.get(activityId);
	}

	@Override
	public Activity getActivityByExtActivityId(String extActivityId) throws AppBizException {
		ActivityCond cond = new ActivityCond();
		cond.setExtActivityId(extActivityId);
		List<Activity> activitys = activityDao.queryList(cond, 0, 2);
		if (activitys.size() != 1) {
			throw new AppBizException(AppExCodeEnum.ACTIVITY_NOT_FOUND.getCode(),
					AppExCodeEnum.ACTIVITY_NOT_FOUND.getMessage());
		}
		return activitys.get(0);
	}
	
	/**
	* @Title: getAndCheck 
	* @Description: 查询活动，并校验状态
	* @param String activityId
	* @return Activity
	* @throws NumberFormatException
	 */
	public Activity getAndCheck(Integer activityId) throws AppBizException {
		Activity a = getActivityById(new Integer(activityId));

		if (a == null) {
			throw new AppBizException(
					AppExCodeEnum.ACTIVITY_NOT_FOUND.getCode(),
					AppExCodeEnum.ACTIVITY_NOT_FOUND.getMessage());
		}

		// 判断对应的活动状态是否正常 - 4008
		if (ActivityStatus.INIT.getId().equals(a.getStatus())) {
			throw new AppBizException(
					AppExCodeEnum.VOUCHER_ACTIVITY_INVALID.getCode(),
					AppExCodeEnum.VOUCHER_ACTIVITY_INVALID.getMessage());
		}
		if (ActivityStatus.DISABLED.getId().equals(a.getStatus())) {
			throw new AppBizException(
					AppExCodeEnum.VOUCHER_ACTIVITY_INVALID.getCode(),
					AppExCodeEnum.VOUCHER_ACTIVITY_INVALID.getMessage());
		}

		return a;
	}
	
}
