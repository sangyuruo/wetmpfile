/**
 * 
 */
package com.bill99.ebd.rip.srv.impl;

import java.io.Serializable;
import java.util.List;

import com.bill99.ebd.rip.enums.InterestsSelectType;

/**
 * @project: app-rip-0603-mam
 * @description: 绑定权益规则处理结果
 * @author: lei.yu
 * @create_time: 2015年5月23日
 * @modify_time: 2015年5月23日
 */
public class BindInterestsRuleActionReturn implements Serializable {
	private static final long serialVersionUID = -1829046853381556940L;

	private List<InterestsPackage> interestsPackages;// 权益包列表

	private InterestsSelectType selectType;// 选择方式

	private Integer activityId;// 活动id
	
	private String ruleName;

	public BindInterestsRuleActionReturn(String selectType, int activityId, List<InterestsPackage> interestsPackages) {
		super();
		this.interestsPackages = interestsPackages;
		this.selectType = InterestsSelectType.valueOf(selectType);
		this.activityId = activityId;
	}

	public BindInterestsRuleActionReturn(String ruleName, String selectType, int activityId, List<InterestsPackage> interestsPackages) {
		super();
		this.ruleName = ruleName;
		this.interestsPackages = interestsPackages;
		this.selectType = InterestsSelectType.valueOf(selectType);
		this.activityId = activityId;
	}

	public List<InterestsPackage> getInterestsPackages() {
		return interestsPackages;
	}

	public InterestsSelectType getSelectType() {
		return selectType;
	}

	public void setInterestsPackages(List<InterestsPackage> interestsPackages) {
		this.interestsPackages = interestsPackages;
	}

	public void setSelectType(InterestsSelectType selectType) {
		this.selectType = selectType;
	}

	public Integer getActivityId() {
		return activityId;
	}

	public void setActivityId(Integer activityId) {
		this.activityId = activityId;
	}

	public String getRuleName() {
		return ruleName;
	}

	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}
}
