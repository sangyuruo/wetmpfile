/**
 * 
 */
package com.bill99.ebd.rip.srv.impl;

import java.io.Serializable;
import java.util.Map;

/**
 * @project: rip-market-inf-0520
 * @description:
 * @author: lei.yu
 * @create_time: 2015年5月5日
 * @modify_time: 2015年5月5日
 */
public class BindInterestsFact implements Serializable {
	private static final long serialVersionUID = 1522556757700519193L;
	/**
	 * 产品线
	 */
	private String productGroup;
	/**
	 * 附加参数
	 */
	private Map<String, String> extInfo;

	public String getProductGroup() {
		return productGroup;
	}

	public Map<String, String> getExtInfo() {
		return extInfo;
	}

	public void setProductGroup(String productGroup) {
		this.productGroup = productGroup;
	}

	public void setExtInfo(Map<String, String> extInfo) {
		this.extInfo = extInfo;
	}

}
