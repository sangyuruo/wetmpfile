/**
 * 
 */
package com.bill99.ebd.rip.srv;

import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.mrs.facade.BindInterestsRequest;

/**
 * @project: app-rip-0520
 * @description:
 * @author: lei.yu
 * @create_time: 2015年5月6日
 * @modify_time: 2015年5月6日
 */
public interface InterestsMarketBindService {
	/**
	 * 异步活动绑定权益
	 * 
	 * @param request
	 * @throws AppBizException 
	 */
	public void bindInterests(BindInterestsRequest request);
}
