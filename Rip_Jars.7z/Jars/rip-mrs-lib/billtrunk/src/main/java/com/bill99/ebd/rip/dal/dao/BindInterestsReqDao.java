/**
 * 
 */
package com.bill99.ebd.rip.dal.dao;

import com.bill99.ebd.rip.dal.dao.hibernate.generic.GenericCurdDao;
import com.bill99.ebd.rip.dal.model.BindInterestsReq;

/**
 * @project: app-rip-0520-2
 * @description:
 * @author: lei.yu
 * @create_time: 2015年5月12日
 * @modify_time: 2015年5月12日
 */
public interface BindInterestsReqDao extends GenericCurdDao<BindInterestsReq, Long, BindInterestsReqCond> {

}
