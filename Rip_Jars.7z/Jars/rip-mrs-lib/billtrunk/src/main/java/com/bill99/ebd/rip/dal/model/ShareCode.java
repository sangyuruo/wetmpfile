package com.bill99.ebd.rip.dal.model;

import java.io.Serializable;

import com.bill99.ebd.rip.dal.model.BasePojo;

/**
 * 分享码
 * @author chao.zhou
 *
 */
public class ShareCode extends BasePojo implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String memcode;//分享码所有者
	private String shareCodes;//分享码
	private String mem;//预留字段
	private Integer memType;//是否是快钱会员 1,快钱会员；2非快钱会员，memcode为空
	
	public String getMemcode() {
		return memcode;
	}
	public void setMemcode(String memcode) {
		this.memcode = memcode;
	}
	
	public Integer getMemType() {
		return memType;
	}
	public void setMemType(Integer memType) {
		this.memType = memType;
	}
	public String getShareCodes() {
		return shareCodes;
	}
	public void setShareCodes(String shareCodes) {
		this.shareCodes = shareCodes;
	}
	public String getMem() {
		return mem;
	}
	public void setMem(String mem) {
		this.mem = mem;
	}
	
}
