package com.bill99.ebd.rip.rule.srv;

import java.util.List;

import com.bill99.ebd.rip.rule.srv.impl.RuleTemplate;

public interface RuleTemplateFactory {
	/**
	 * 获得一个RuleTemplate实例
	 * 
	 * @return
	 */
	public RuleTemplate newRuleTemplate(List<String> rules);
}
