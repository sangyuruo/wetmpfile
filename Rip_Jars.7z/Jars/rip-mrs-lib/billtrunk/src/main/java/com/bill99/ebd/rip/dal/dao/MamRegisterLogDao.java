/**
 * 
 */
package com.bill99.ebd.rip.dal.dao;

import com.bill99.ebd.rip.dal.dao.hibernate.generic.GenericCurdDao;
import com.bill99.ebd.rip.dal.model.MamRegisterLog;

/**
 * @project: app-rip-1007
 * @description:
 * @author: lei.yu
 * @create_time: 2015年10月9日
 * @modify_time: 2015年10月9日
 */
public interface MamRegisterLogDao extends GenericCurdDao<MamRegisterLog, Long, MamRegisterLogCond> {

}
