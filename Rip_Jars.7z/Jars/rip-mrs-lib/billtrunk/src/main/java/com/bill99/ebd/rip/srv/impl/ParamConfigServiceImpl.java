package com.bill99.ebd.rip.srv.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.dal.dao.ParamConfigCond;
import com.bill99.ebd.rip.dal.dao.ParamConfigDao;
import com.bill99.ebd.rip.dal.model.ParamConfig;
import com.bill99.ebd.rip.srv.ParamConfigService;

public class ParamConfigServiceImpl implements ParamConfigService {

	@Autowired
	private ParamConfigDao paramConfigDao;

	@Override
	public Map<String, String> getByType(String type) {
		ParamConfigCond cond = new ParamConfigCond();
		cond.setType(type);
		List<ParamConfig> list = paramConfigDao.queryList(cond, 0, -1);
		Map<String, String> result = new HashMap<String, String>();
		for (ParamConfig p : list) {
			result.put(p.getName(), p.getValue());
		}
		return result;
	}

	@Override
	public String getByName(String type, String name) {
		ParamConfigCond cond = new ParamConfigCond();
		cond.setType(type);
		cond.setName(name);
		List<ParamConfig> list = paramConfigDao.queryList(cond, 0, -1);
		return list.size() > 0 ? list.get(0).getValue() : null;
	}

	@Override
	public void addParam(String type, String name, String value)
			throws Exception {
		if (null != getByName(type, name)) {
			throw new Exception("参数名已存在");
		}
		ParamConfig pc = new ParamConfig();
		pc.setName(name);
		pc.setValue(value);
		pc.setType(type);
		pc.setCreateTime(new Date());
		pc.setUpdateTime(new Date());
		paramConfigDao.saveOrUpdate(pc);
	}

}
