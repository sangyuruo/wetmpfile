/**
 * 
 */
package com.bill99.ebd.rip.whitelist.dal.model;

import java.io.Serializable;
import java.util.Date;

import com.bill99.ebd.rip.enums.WhiteListKeyType;

/**
 * @project: app-rip-0819
 * @description:
 * @author: lei.yu
 * @create_time: 2015年8月19日
 * @modify_time: 2015年8月19日
 */
public class ActivityWhiteListRule implements Serializable {

	private static final long serialVersionUID = 6601367534017855602L;

	private Long activityWhiteListRuleId;
	private Integer activityId;
	private String whiteListName;
	private WhiteListKeyType whiteListKeyType;
	private Date createTime;
	private Date updateTime;

	public Long getActivityWhiteListRuleId() {
		return activityWhiteListRuleId;
	}

	public Integer getActivityId() {
		return activityId;
	}

	public String getWhiteListName() {
		return whiteListName;
	}

	public WhiteListKeyType getWhiteListKeyType() {
		return whiteListKeyType;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setActivityWhiteListRuleId(Long activityWhiteListRuleId) {
		this.activityWhiteListRuleId = activityWhiteListRuleId;
	}

	public void setActivityId(Integer activityId) {
		this.activityId = activityId;
	}

	public void setWhiteListName(String whiteListName) {
		this.whiteListName = whiteListName;
	}

	public void setWhiteListKeyType(WhiteListKeyType whiteListKeyType) {
		this.whiteListKeyType = whiteListKeyType;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
}
