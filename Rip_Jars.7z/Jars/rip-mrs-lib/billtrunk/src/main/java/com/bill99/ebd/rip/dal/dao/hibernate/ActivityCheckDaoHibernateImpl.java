/**
 * 
 */
package com.bill99.ebd.rip.dal.dao.hibernate;

import com.bill99.ebd.rip.dal.dao.ActivityCheckCond;
import com.bill99.ebd.rip.dal.dao.ActivityCheckDao;
import com.bill99.ebd.rip.dal.dao.hibernate.generic.HibernateGenericDao;
import com.bill99.ebd.rip.dal.model.ActivityCheck;

public class ActivityCheckDaoHibernateImpl extends HibernateGenericDao<ActivityCheck, Long, ActivityCheckCond>
		implements ActivityCheckDao {

}
