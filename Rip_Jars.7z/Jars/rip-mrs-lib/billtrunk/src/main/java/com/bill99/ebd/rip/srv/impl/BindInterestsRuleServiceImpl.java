package com.bill99.ebd.rip.srv.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.math.RandomUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.enums.InterestsSelectType;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.mrs.facade.BindInterestsRequest;
import com.bill99.ebd.rip.srv.BindInterestsRuleService;
import com.bill99.ebd.rip.util.ToStringUtils;
import com.bill99.ebd.rip.util.VoucherServiceWrapper;

/**
 * @project: app-rip-0617
 * @description:
 * @author: lei.yu
 * @create_time: 2015年6月3日
 * @modify_time: 2015年6月3日
 */
public class BindInterestsRuleServiceImpl implements BindInterestsRuleService {

    private static final Logger logger = LoggerFactory.getLogger(BindInterestsRuleServiceImpl.class);

    private VoucherServiceWrapper voucherService;

    @Override
    public void bindInterests(BindInterestsRequest request, String memCode,
            BindInterestsRuleActionReturn bindInterestsRuleActionReturn) throws AppBizException {
        List<InterestsPackage> interestsPackages = this.selectByType(bindInterestsRuleActionReturn.getSelectType(),
                bindInterestsRuleActionReturn.getInterestsPackages());
        this.bindInterests(bindInterestsRuleActionReturn.getActivityId(), memCode, interestsPackages, request);
    }

    private void bindInterests(Integer activityId, String memberCode, List<InterestsPackage> interestsPackages,
            BindInterestsRequest request) throws AppBizException {
        for (InterestsPackage interestsPackage : interestsPackages) {
            Integer interestsId = interestsPackage.getInterestsId();
            String deviceId = null;
            String mobile = null;
            Map<String, String> paramMap = request.getPara();
            if (!CollectionUtils.sizeIsEmpty(paramMap)) {
                deviceId = paramMap.get("deviceId");
                mobile = paramMap.get("mobile");
            }
            this.voucherService.holdVoucher(interestsId, memberCode, mobile, deviceId);
        }
    }

    @SuppressWarnings("unchecked")
    private List<InterestsPackage> selectByType(InterestsSelectType selectType,
            List<InterestsPackage> interestsPackages) throws AppBizException {
        if (CollectionUtils.isEmpty(interestsPackages)) {
            return Collections.EMPTY_LIST;
        }
        if (InterestsSelectType.ALL == selectType) {
            logger.info("@@Select all Interests Package: {}",
                    ToStringUtils.recursiveReflectionToString(interestsPackages));
            return interestsPackages;
        }
        if (InterestsSelectType.RANDOM == selectType) {
            List<InterestsPackage> resultList = new ArrayList<InterestsPackage>();
            int pos = RandomUtils.nextInt(new Random(), interestsPackages.size());
            resultList.add(interestsPackages.get(pos));
            logger.info("@@Random select Interests Package: {}", ToStringUtils.recursiveReflectionToString(resultList));
            return resultList;
        }
        return Collections.EMPTY_LIST;
    }

    @Autowired
    public void setVoucherService(VoucherServiceWrapper voucherService) {
        this.voucherService = voucherService;
    }
}
