/**
 * 
 */
package com.bill99.ebd.rip.rule.dal.dao.hibernate;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.bill99.ebd.rip.dal.dao.hibernate.generic.HibernateGenericDao;
import com.bill99.ebd.rip.rule.dal.dao.RuleGroupDetailCond;
import com.bill99.ebd.rip.rule.dal.dao.RuleGroupDetailDao;
import com.bill99.ebd.rip.rule.dal.model.RuleGroupDetail;

public class RuleGroupDetailDaoHibernateImpl extends HibernateGenericDao<RuleGroupDetail, Long, RuleGroupDetailCond>
		implements RuleGroupDetailDao {

	@Override
	public List<RuleGroupDetail> queryByGroupId(Long ruleGroupId) {
		RuleGroupDetailCond cond = new RuleGroupDetailCond();
		cond.setRuleGroupId(ruleGroupId);
		return queryList(cond, 0, -1);
	}

	@Override
	public Set<Long> queryRuleGroupIdByRuleId(Long ruleId) {
		List<RuleGroupDetail> ruleGroupDetails = queryRuleGroupByRuleId(ruleId);
		Set<Long> ruleGroupIds = new HashSet<Long>();
		for (RuleGroupDetail ruleGroupDetail : ruleGroupDetails) {
			ruleGroupIds.add(ruleGroupDetail.getRuleGroupId());
		}
		return ruleGroupIds;
	}

	@Override
	public List<RuleGroupDetail> queryRuleGroupByRuleId(Long ruleId) {
		RuleGroupDetailCond cond = new RuleGroupDetailCond();
		cond.setRuleId(ruleId);
		return queryList(cond, 0, -1);
	}

}
