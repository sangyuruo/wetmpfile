package com.bill99.ebd.rip.rule.dal.dao;

import com.bill99.ebd.rip.dal.dao.hibernate.generic.GenericCurdDao;
import com.bill99.ebd.rip.rule.dal.model.RuleGroup;

public interface RuleGroupDao extends GenericCurdDao<RuleGroup, Long, RuleGroupCond> {

	public RuleGroup queryByName(String ruleGroupName);

	public void save(RuleGroup ruleGroup);

}
