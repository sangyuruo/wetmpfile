package com.bill99.ebd.rip.rule.srv.impl;

import java.util.List;

import com.bill99.ebd.rip.rule.srv.RuleTemplateFactory;

public class DroolRuleTemplateFactory implements RuleTemplateFactory {
	public RuleTemplate newRuleTemplate(List<String> rules) {
		return new DroolsTemplate(rules);
	}

}
