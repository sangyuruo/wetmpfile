/**
 * 
 */
package com.bill99.ebd.rip.dal.model;

import java.io.Serializable;
import java.util.Date;

/**
 * 用户帮卡信息
 * 
 * @author pengfei.shen
 * @create 2016年8月8日 下午7:29:41
 * @project
 */
public class MemberBindCard implements Serializable {
	/**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    private Long idMemberBindCard;//唯一标识
    private String membercode;//用户membercode
    private String firstCardNo;
    private Date firstCardBindDate;
    private Date createTime;// 创建时间
	private Date updateTime;// 更新时间
	private String mome;//备注
   
    public Long getIdMemberBindCard() {
        return idMemberBindCard;
    }
    public void setIdMemberBindCard(Long idMemberBindCard) {
        this.idMemberBindCard = idMemberBindCard;
    }
    public String getMembercode() {
        return membercode;
    }
    public void setMembercode(String membercode) {
        this.membercode = membercode;
    }
    public String getFirstCardNo() {
        return firstCardNo;
    }
    public void setFirstCardNo(String firstCardNo) {
        this.firstCardNo = firstCardNo;
    }
    public Date getFirstCardBindDate() {
        return firstCardBindDate;
    }
    public void setFirstCardBindDate(Date firstCardBindDate) {
        this.firstCardBindDate = firstCardBindDate;
    }
    public Date getCreateTime() {
        return createTime;
    }
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
    public Date getUpdateTime() {
        return updateTime;
    }
    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
    public String getMome() {
        return mome;
    }
    public void setMome(String mome) {
        this.mome = mome;
    }
	
}
