/**
 * 
 */
package com.bill99.ebd.rip.srv;

import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.mrs.facade.BindInterestsRequest;
import com.bill99.ebd.rip.srv.impl.BindInterestsRuleActionReturn;

/**
 * @project: app-rip-0617
 * @description:
 * @author: lei.yu
 * @create_time: 2015年6月3日
 * @modify_time: 2015年6月3日
 */
public interface BindInterestsRuleService {

	public void bindInterests(BindInterestsRequest request, String memCode,
			BindInterestsRuleActionReturn bindInterestsRuleActionReturn) throws AppBizException;

}
