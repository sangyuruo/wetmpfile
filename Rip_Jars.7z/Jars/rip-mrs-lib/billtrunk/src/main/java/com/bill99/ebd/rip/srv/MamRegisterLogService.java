/**
 * 
 */
package com.bill99.ebd.rip.srv;

import com.bill99.ebd.rip.dal.model.MamRegisterLog;
import com.bill99.ebd.rip.exception.AppBizException;

/**
 * @project: app-rip-1007
 * @description: 
 * @author: lei.yu
 * @create_time: 2015年10月9日
 * @modify_time: 2015年10月9日
 */
public interface MamRegisterLogService {
	public void add(MamRegisterLog mamRegisterLog);
	
	public MamRegisterLog getByMemberCode(String memberCode) throws AppBizException;
}
