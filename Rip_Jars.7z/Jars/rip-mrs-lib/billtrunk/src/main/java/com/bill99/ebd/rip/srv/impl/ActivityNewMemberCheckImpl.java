/**
 * 
 */
package com.bill99.ebd.rip.srv.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.dal.model.Activity;
import com.bill99.ebd.rip.dal.model.MamRegisterLog;
import com.bill99.ebd.rip.enums.AppExCodeEnum;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.srv.ActivityCheckPlugin;
import com.bill99.ebd.rip.srv.ActivityService;
import com.bill99.ebd.rip.srv.MamRegisterLogService;
import com.bill99.ebd.rip.wrapper.MaServiceWrapper;

/**
 * @project: app-rip-1007
 * @description:
 * @author: lei.yu
 * @create_time: 2015年10月12日
 * @modify_time: 2015年10月12日
 */
public class ActivityNewMemberCheckImpl implements ActivityCheckPlugin {

    private static final String VERIFIED = "1";
    private static final String REG_FROM_APP = "mobile";

    @Autowired
    private MamRegisterLogService mamRegisterLogService;

    @Autowired
    private ActivityService activityService;

    @Autowired
    private MaServiceWrapper maServiceWrapper;

    @Override
    public void check(Integer activityId, String memCode) throws AppBizException {
        Activity activity = this.activityService.getAndCheck(activityId);
        this.checkIsNewMember(memCode, activity.getStartTime(), activity.getEndTime());
        this.checkIsVerifiedMember(memCode, activity.getStartTime(), activity.getEndTime());
    }

    private void checkIsNewMember(String memberCode, Date startDate, Date endDate) throws AppBizException {
        MamRegisterLog mamRegisterLog = this.mamRegisterLogService.getByMemberCode(memberCode);
        if (!REG_FROM_APP.equals(mamRegisterLog.getRegFrom())) {
            throw new AppBizException(AppExCodeEnum.NOT_REG_FROM_APP);
        }
        Date creationDate = mamRegisterLog.getCreationDate();
        if (creationDate.compareTo(startDate) < 0 || creationDate.compareTo(endDate) > 0) {
            throw new AppBizException(AppExCodeEnum.NOT_NEW_MEMBER);
        }
    }

    private void checkIsVerifiedMember(String memberCode, Date startDate, Date endDate) throws AppBizException {
        Map<String, Object> resultMap = this.maServiceWrapper.queryMemberCards(memberCode, VERIFIED, null);

        @SuppressWarnings("unchecked")
        List<Map<String, Object>> bindingCards = (List<Map<String, Object>>) resultMap.get("bindCards");
        if (bindingCards.size() == 0) {
            throw new AppBizException(AppExCodeEnum.NOT_BIND_CARD);
        }

        boolean isBind = false;
        for (Map<String, Object> bindingCardMap : bindingCards) {
            Date creationDate = new Date((Long) bindingCardMap.get("creationDate"));
            if (creationDate.compareTo(startDate) >= 0 && creationDate.compareTo(endDate) <= 0) {
                isBind = true;
                break;
            }
        }
        if (!isBind) {
            throw new AppBizException(AppExCodeEnum.NOT_BIND_CARD);
        }
    }

}
