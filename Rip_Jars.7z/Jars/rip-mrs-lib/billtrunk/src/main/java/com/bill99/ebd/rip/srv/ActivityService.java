package com.bill99.ebd.rip.srv;

import java.util.Date;
import java.util.List;

import com.bill99.ebd.rip.dal.dao.ActivityCond;
import com.bill99.ebd.rip.dal.model.Activity;
import com.bill99.ebd.rip.exception.AppBizException;

/**
 * 活动服务
 * 
 * @author jakoes.wu
 * @create 2014-9-11下午2:53:37
 * @project app-rip-20140903
 */
public interface ActivityService {

	/**
	 * 加载所有活动
	 * 
	 * @return
	 * @throws AppBizException
	 */
	public List<Activity> loadAllActivity() throws AppBizException;

	public List<Activity> queryActivity(ActivityCond cond);

	public Activity addActivity(String activityName, Date startTime, Date endTime) throws AppBizException;
	public Activity addActivity(AddActivityRequest addActivityRequest) throws AppBizException;
	public void updateActivity(Activity activity) throws AppBizException;

	public Activity getActivityById(Integer activityId) throws AppBizException;

	public Activity getActivityByExtActivityId(String extActivityId) throws AppBizException;
	
	/**
	* @Title: getAndCheck 
	* @Description: 查询活动，并校验状态
	* @param String activityId
	* @return Activity
	* @throws NumberFormatException
	 */
	public Activity getAndCheck(Integer activityId) throws AppBizException;
	
	 
}
