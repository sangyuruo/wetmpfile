package com.bill99.ebd.rip.dal.dao;

import com.bill99.ebd.rip.dal.dao.hibernate.generic.GenericCurdDao;
import com.bill99.ebd.rip.dal.model.ParamConfig;

/**
 * 参数配置DAO接口
 * 
 * @author jakoes.wu
 * @create 2014-9-25下午7:47:13
 * @project app-rip-20140903
 */
public interface ParamConfigDao extends
		GenericCurdDao<ParamConfig, Integer, ParamConfigCond> {

}
