package com.bill99.ebd.rip.dal.dao.hibernate;

import com.bill99.ebd.rip.dal.dao.ShareCond;
import com.bill99.ebd.rip.dal.dao.ShareDao;
import com.bill99.ebd.rip.dal.dao.hibernate.generic.HibernateGenericDao;
import com.bill99.ebd.rip.dal.model.Share;

/**
 * 分享接口实现
 * @author emily.gu
 * @create_time 2015.09.28
 */
public class ShareDaoHibernateImpl extends
             HibernateGenericDao<Share, Integer, ShareCond>  implements ShareDao {



}
