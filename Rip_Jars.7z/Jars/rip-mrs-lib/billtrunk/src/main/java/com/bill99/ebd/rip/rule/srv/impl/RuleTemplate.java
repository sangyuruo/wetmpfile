/**
 * 
 */
package com.bill99.ebd.rip.rule.srv.impl;

import java.util.List;
import java.util.Map;

public interface RuleTemplate {
	/**
	 * 执行规则
	 * 
	 * @param facts
	 */
	public void ruleAction(List<Object> facts);

	/**
	 * 执行规则
	 * 
	 * @param facts
	 * @param globalParameters
	 */
	public void ruleAction(List<Object> facts, Map<String, Object> globalParameters);
}
