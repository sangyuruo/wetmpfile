package com.bill99.ebd.rip.rule.dal.model;

import java.io.Serializable;
import java.util.Date;

import com.bill99.ebd.rip.enums.RuleStatus;

public class Rule implements Serializable {
	private static final long serialVersionUID = -6126299215599674591L;
	public Long ruleId;// 规则id
	public String ruleName;// 规则名称
	public Date enableTime;// 生效时间
	public Date expireTime;// 失效时间
	public String rule;// 规则drl
	public RuleStatus status;// 状态
	public Date createTime;// 创建时间
	public Date updateTime;// 更新时间

	public Long getRuleId() {
		return ruleId;
	}

	public Date getEnableTime() {
		return enableTime;
	}

	public Date getExpireTime() {
		return expireTime;
	}

	public String getRule() {
		return rule;
	}

	public RuleStatus getStatus() {
		return status;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setRuleId(Long ruleId) {
		this.ruleId = ruleId;
	}

	public void setEnableTime(Date enableTime) {
		this.enableTime = enableTime;
	}

	public void setExpireTime(Date expireTime) {
		this.expireTime = expireTime;
	}

	public void setRule(String rule) {
		this.rule = rule;
	}

	public void setStatus(RuleStatus status) {
		this.status = status;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getRuleName() {
		return ruleName;
	}

	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}
}
