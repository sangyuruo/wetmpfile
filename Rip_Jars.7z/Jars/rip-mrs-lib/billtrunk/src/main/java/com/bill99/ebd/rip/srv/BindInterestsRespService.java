/**
 * 
 */
package com.bill99.ebd.rip.srv;

import com.bill99.ebd.rip.dal.model.BindInterestsResp;
import com.bill99.ebd.rip.srv.impl.BindInterestsRuleActionReturn;

/**
 * @project: app-rip-0520-2
 * @description:
 * @author: lei.yu
 * @create_time: 2015年5月12日
 * @modify_time: 2015年5月12日
 */
public interface BindInterestsRespService {
	public void add(BindInterestsResp resp);

	public void saveBindInterestsResp(String resquestId, BindInterestsRuleActionReturn actionReturn, String errorCode);
	
	public boolean isRespSuccess(String requestId);
}
