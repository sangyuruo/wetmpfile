package com.bill99.ebd.rip.util;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;

import com.bill99.ebd.rip.enums.AppExCodeEnum;
import com.bill99.ebd.rip.exception.AppBizException;

/**
 * json工具类
 * @author emily.gu
 * @create_time 2015.10.09
 */
public class JsonUtil {
	
	private final static Log logger = LogFactory.getLog(JsonUtil.class);
	
	/**
	 * json to map
	 * @param jsonString
	 * @return Map<String, String>
	 */
	public static Map<String, String> convert2Map(String jsonString) throws AppBizException {
		ObjectMapper mapper = new ObjectMapper();
		
		Map<String, String> jsonMap = new HashMap<String, String>();
		try {
			jsonMap = mapper.readValue(jsonString, new TypeReference<Map<String, String>>() {
			});
		} catch (JsonParseException e) {
			logger.error("parse josnString[" + jsonString + "] JsonParseException!", e);
			throw new AppBizException(AppExCodeEnum.UNKNOW_ERROR.getCode(), 
					AppExCodeEnum.UNKNOW_ERROR.getMessage());
		} catch (JsonMappingException e) {
			logger.error("parse josnString[" + jsonString + "] JsonMappingException!", e);
			throw new AppBizException(AppExCodeEnum.UNKNOW_ERROR.getCode(), 
					AppExCodeEnum.UNKNOW_ERROR.getMessage());
		} catch (IOException e) {
			logger.error("parse josnString[" + jsonString + "] IOException!", e);
			throw new AppBizException(AppExCodeEnum.UNKNOW_ERROR.getCode(), 
					AppExCodeEnum.UNKNOW_ERROR.getMessage());
		}
		return jsonMap;
	}

}
