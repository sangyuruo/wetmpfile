package com.bill99.ebd.rip.srv.spread;

import java.util.List;

import com.bill99.ebd.rip.dal.model.ShareRelation;

public interface ShareRelationService {

	public void addEntity(ShareRelation shareRelation);

	public void changeShareRelationStatus(String content);

	public List<ShareRelation> queryByMobile(String mobile);

	public List<ShareRelation> getInvitation(String memcode);
	
	public List<ShareRelation> getInvitationByActivity(String memcode, String activityName);
	
	//TODO SHOULD BE SPLIT ASAP
	//public List<ShareRelationDto> getTopTenInvitation() throws Exception;
}
