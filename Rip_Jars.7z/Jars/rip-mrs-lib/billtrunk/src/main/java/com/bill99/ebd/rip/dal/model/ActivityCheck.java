/**
 * 
 */
package com.bill99.ebd.rip.dal.model;

import java.io.Serializable;
import java.util.Date;

import com.bill99.ebd.rip.enums.ActivityCheckType;

/**
 * @project: app-rip-1007
 * @description: 活动校验
 * @author: lei.yu
 * @create_time: 2015年10月10日
 * @modify_time: 2015年10月10日
 */
public class ActivityCheck implements Serializable {

	private static final long serialVersionUID = 1759290547206813803L;
	/**
	 * pk
	 */
	private Long activityCheckId;
	/**
	 * 活动id
	 */
	private Integer activityId;
	/**
	 * 校验类型
	 */
	private ActivityCheckType activityCheckType;
	/**
	 * 创建时间
	 */
	private Date createTime;
	/**
	 * 更新时间
	 */
	private Date updateTime;

	public Integer getActivityId() {
		return activityId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setActivityId(Integer activityId) {
		this.activityId = activityId;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Long getActivityCheckId() {
		return activityCheckId;
	}

	public ActivityCheckType getActivityCheckType() {
		return activityCheckType;
	}

	public void setActivityCheckId(Long activityCheckId) {
		this.activityCheckId = activityCheckId;
	}

	public void setActivityCheckType(ActivityCheckType activityCheckType) {
		this.activityCheckType = activityCheckType;
	}
}
