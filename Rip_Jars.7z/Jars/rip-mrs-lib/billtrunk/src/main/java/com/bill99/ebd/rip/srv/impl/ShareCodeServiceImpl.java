package com.bill99.ebd.rip.srv.impl;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.dal.dao.ShareCodeDao;
import com.bill99.ebd.rip.dal.model.ShareCode;
import com.bill99.ebd.rip.srv.ShareCodeService;

public class ShareCodeServiceImpl implements ShareCodeService{
	private final Log log = LogFactory.getLog(getClass());
	
	private static final Integer LENTH = 5;
	private final Integer MEMTYPE_1=1;
	private final Integer MEMTYPE_2=2;
	
	@Autowired
	private ShareCodeDao shareCodeDao;
	@Override
	public boolean getShareCodeByShareCodes(String shareCodes) {
		String hql= "from ShareCode where shareCodes=?";
		List<ShareCode> list = shareCodeDao.queryByHql(hql, shareCodes);
		if(list.isEmpty()||list.size()==0){
			return false;
		}
		return true;
	}
	@Override
	public synchronized void  insert(ShareCode shareCode,boolean b) {
		
		//生成随机唯一分享
		String shareCodes= newCodes();
		//设置值
		shareCode.setShareCodes(shareCodes);
		shareCode.setCreateTime(new Date());
		shareCode.setUpdateTime(new Date());
		if(b){
			shareCode.setMemType(MEMTYPE_1);
		}else{
			shareCode.setMemType(MEMTYPE_2);
		}
		shareCodeDao.add(shareCode);
	}
	private String newCodes() {
		//生成指定长度的字母和数字的随机组合字符串
		String shareCodes= RandomStringUtils.randomAlphanumeric(LENTH);
		//检查随机码是否唯一。
		if(this.getShareCodeByShareCodes(shareCodes)){
			this.newCodes();
		};
		return shareCodes;
	}
	@Override
	public void batchInsert(Integer number,String memo) {
		for (int i = 0; i < number; i++) {
			ShareCode shareCode = new ShareCode();
			shareCode.setMem(memo);
			this.insert(shareCode, false);
		}
	}
	

	@Override
	public List<ShareCode> queryShareCodeByMemberCode(String memberCode) {
	
		String hql= "from ShareCode where memcode=?";
		List<ShareCode> list= shareCodeDao.queryByHql(hql, memberCode);
		return list;
	}
	
	
	@Override
	public List<ShareCode> queryShareCodeByMem(String mem) {
		String hql= "from ShareCode where mem=?";
		List<ShareCode> list= shareCodeDao.queryByHql(hql, mem);
		return list;
	}
}
