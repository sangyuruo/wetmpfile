package com.bill99.ebd.rip.dal.dao.hibernate;

import com.bill99.ebd.rip.dal.dao.ShareRelationCond;
import com.bill99.ebd.rip.dal.dao.ShareRelationDao;
import com.bill99.ebd.rip.dal.dao.hibernate.generic.HibernateGenericDao;
import com.bill99.ebd.rip.dal.model.ShareRelation;

public class ShareRelationDaoHibernateImpl extends HibernateGenericDao<ShareRelation, Integer, ShareRelationCond>
	implements ShareRelationDao{

}
