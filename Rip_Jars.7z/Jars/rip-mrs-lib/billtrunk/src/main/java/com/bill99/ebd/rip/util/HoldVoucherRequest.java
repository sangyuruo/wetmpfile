package com.bill99.ebd.rip.util;

/**
 * 领券请求
 * 
 * @author jakoes.wu
 * @date 2016年10月18日下午2:13:58
 * @project rip-mrs-lib-20161014
 * 
 */
public class HoldVoucherRequest {

    private String channel;

    private Integer interestsId;

    private String consumerMembercode;

    private String mobile;

    private String deviceId;

    private String holdScene;

    private String orderNo;

    public String getChannel() {
        return this.channel;
    }

    public String getConsumerMembercode() {
        return this.consumerMembercode;
    }

    public String getDeviceId() {
        return this.deviceId;
    }

    public String getHoldScene() {
        return this.holdScene;
    }

    public Integer getInterestsId() {
        return this.interestsId;
    }

    public String getMobile() {
        return this.mobile;
    }

    public String getOrderNo() {
        return this.orderNo;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public void setConsumerMembercode(String consumerMembercode) {
        this.consumerMembercode = consumerMembercode;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public void setHoldScene(String holdScene) {
        this.holdScene = holdScene;
    }

    public void setInterestsId(Integer interestsId) {
        this.interestsId = interestsId;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

}
