/**
 * 
 */
package com.bill99.ebd.rip.srv;

/**
 * MA消息监听器
 * 
 * @project: app-rip-0603-mam
 * @description:
 * @author: lei.yu
 * @create_time: 2015年5月26日
 * @modify_time: 2015年5月26日
 */
public interface AcctsysMessageReceiver {
	public void onMessage(String string);
}
