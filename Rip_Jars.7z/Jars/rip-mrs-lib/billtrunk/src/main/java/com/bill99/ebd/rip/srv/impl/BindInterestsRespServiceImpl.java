/**
 * 
 */
package com.bill99.ebd.rip.srv.impl;

import java.util.Date;
import java.util.List;

import net.sf.json.JSONArray;

import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.dal.dao.BindInterestsRespCond;
import com.bill99.ebd.rip.dal.dao.BindInterestsRespDao;
import com.bill99.ebd.rip.dal.model.BindInterestsResp;
import com.bill99.ebd.rip.srv.BindInterestsRespService;

/**
 * @project: app-rip-0617
 * @description:
 * @author: lei.yu
 * @create_time: 2015年6月3日
 * @modify_time: 2015年6月3日
 */
public class BindInterestsRespServiceImpl implements BindInterestsRespService {

	private static final String SUCCESS_CODE = "00";
	@Autowired
	private BindInterestsRespDao bindInterestsRespDao;

	@Override
	public void add(BindInterestsResp resp) {
		Date now = new Date();
		resp.setCreateTime(now);
		resp.setUpdateTime(now);
		bindInterestsRespDao.add(resp);
	}

	@Override
	public void saveBindInterestsResp(String resquestId, BindInterestsRuleActionReturn actionReturn, String errorCode) {
		BindInterestsResp resp = new BindInterestsResp();
		if (actionReturn != null) {
			resp.setActivityId(actionReturn.getActivityId());
			resp.setRuleName(actionReturn.getRuleName());
			resp.setInterestsInfo(JSONArray.fromObject(actionReturn.getInterestsPackages()).toString());
		}
		resp.setRequestId(resquestId);
		resp.setRespCode(errorCode);
		add(resp);
	}

	@Override
	public boolean isRespSuccess(String requestId) {
		BindInterestsRespCond cond = new BindInterestsRespCond();
		cond.setRequestId(requestId);
		cond.setRespCode(SUCCESS_CODE);
		List<BindInterestsResp> resp = bindInterestsRespDao.queryList(cond, 0, 1);
		return resp.size() == 1;
	}

}
