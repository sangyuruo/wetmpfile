package com.bill99.ebd.rip.srv;

import java.util.List;

import com.bill99.ebd.rip.dal.model.ShareCode;

public interface ShareCodeService {

	public boolean getShareCodeByShareCodes(String shareCodes);

	public void insert(ShareCode shareCode,boolean b);
	
	public void batchInsert(Integer number, String memo);
	
	public List<ShareCode> queryShareCodeByMemberCode(String memberCode);
	
	public List<ShareCode> queryShareCodeByMem(String mem);
	
	
}
