/**
 * 
 */
package com.bill99.ebd.rip.srv.impl;

import java.io.IOException;
import java.text.ParseException;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.dal.dao.MemberBindCardCond;
import com.bill99.ebd.rip.dal.dao.MemberBindCardDao;
import com.bill99.ebd.rip.dal.model.MamRegisterLog;
import com.bill99.ebd.rip.dal.model.MemberBindCard;
import com.bill99.ebd.rip.enums.MaMessageChannel;
import com.bill99.ebd.rip.enums.ProductGroup;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.mrs.facade.BindInterestsRequest;
import com.bill99.ebd.rip.srv.AcctsysMessageReceiver;
import com.bill99.ebd.rip.srv.InterestsMarketBindService;
import com.bill99.ebd.rip.srv.MamRegisterLogService;
import com.bill99.ebd.rip.srv.spread.ShareRelationService;
import com.bill99.ebd.rip.wrapper.MaServiceWrapper;
import com.bill99.ebd.rip.wrapper.model.ma.BindingCard;

/**
 * MA消息监听器
 * 
 * @project: app-rip-0603-mam
 * @description:
 * @author: lei.yu
 * @author jakoes.wu updated by 2015-12-1
 * @create_time: 2015年5月26日
 * @modify_time: 2015年5月26日
 */
public class AcctsysMessageReceiverImpl implements AcctsysMessageReceiver {

    private static final Logger logger = LoggerFactory.getLogger(AcctsysMessageReceiverImpl.class);

    private static final String VALUE_EVENT_TYPE_REGISTER = "EVENT001";// 注册
    private static final String VALUE_EVENT_TYPE_BIND = "EVENT002";// 绑定
    private static final String VALUE_REGFROM_MOBILE = "mobile";// 是否手机注册
    private static final String KEY_EVENTTYPE = "eventType";// 事件类型 EVENT001-注册 EVENT002-绑卡
    private static final String KEY_MEMBERCODE = "memberCode";// 会员编号
    private static final String KEY_BIZCODE = "bizCode";
    private static final String KEY_REQUEST_ID = "requestId";
    private static final String KEY_REQUEST_TIME = "requestTime";
    private static final String KEY_CREATION_DATE = "creationDate";
    private static final String KEY_MEMBER_TYPE = "memberType";// 会员类型 1-个人 2-商户
    private static final String KEY_REG_FROM = "regFrom";// 注册渠道
    private static final String KEY_IDCONTENT = "idcontent";// 用户标识内容,手机号或邮箱
    private static final String KEY_IDCONTENT_TYPE = "idcontentType";// 用户标识类型 1-Email 2-手机,小灵通 3-电话

    @Autowired
    private InterestsMarketBindService interestsMarketBindService;

    @Autowired
    private MamRegisterLogService mamRegisterLogService;

    @Autowired
    private MaServiceWrapper maServiceWrapper;

    @Autowired
    private ShareRelationService shareRelationService;

    @Autowired
    private MemberBindCardDao memberBindCardDao;

    private ObjectMapper mapper = new ObjectMapper();

    private void addMamRegisterLog(String eventJson, Map<String, String> eventMap) {
        MamRegisterLog mamRegisterLog = new MamRegisterLog();
        mamRegisterLog.setBizCode(eventMap.get(KEY_BIZCODE));
        if (eventMap.get(KEY_CREATION_DATE) != null) {
            mamRegisterLog.setCreationDate(this.parseDate(eventMap.get(KEY_CREATION_DATE), "yyyy-MM-dd HH:mm:ss"));
        } else {
            mamRegisterLog.setCreationDate(new Date());
        }
        mamRegisterLog.setMemberCode(eventMap.get(KEY_MEMBERCODE));// 会员编号
        mamRegisterLog.setMemberType(eventMap.get(KEY_MEMBER_TYPE));// 1-个人会员 2-企业会员
        mamRegisterLog.setRegFrom(eventMap.get(KEY_REG_FROM));// 注册渠道 mobile,www.99bill.com,QuickPayment,Ebpp
        mamRegisterLog.setIdcontent(eventMap.get(KEY_IDCONTENT));
        mamRegisterLog.setIdcontentType(eventMap.get(KEY_IDCONTENT_TYPE));
        mamRegisterLog.setMessage(eventJson);
        this.mamRegisterLogService.add(mamRegisterLog);
    }

    private void bindInterests(Map<String, String> jsonMap) {
        BindInterestsRequest req = new BindInterestsRequest();
        req.setRequestId(jsonMap.get(KEY_REQUEST_ID));
        req.setRequestTime(this.parseDate(jsonMap.get(KEY_REQUEST_TIME), "yyyyMMddHHmmssSSS"));
        req.setProductGroup(ProductGroup.MAM.name());
        req.setMemCode(jsonMap.get(KEY_MEMBERCODE));
        req.setPara(jsonMap);
        this.interestsMarketBindService.bindInterests(req);
    }

    private void changeShareRelationStatus(Map<String, String> eventMap) {
        try {
            String phoneNo = this.findPhoneNo(eventMap);
            if (!eventMap.containsKey(KEY_IDCONTENT)) {
                eventMap.put(KEY_IDCONTENT, phoneNo);
            }
            this.shareRelationService.changeShareRelationStatus(phoneNo);
        } catch (AppBizException e) {
            logger.info("@@meet error when call ma ", e);
        }
    }

    private Map<String, String> convert2Map(String jsonString) {
        Map<String, String> jsonMap = new HashMap<String, String>();
        try {
            jsonMap = this.mapper.readValue(jsonString, new TypeReference<Map<String, String>>() {
            });
        } catch (IOException e) {
            logger.error("parse josnString[" + jsonString + "] IOException!", e);
        }
        return jsonMap;
    }

    private void findAndHandleFirstBindCardInfo(String memberCode) throws AppBizException {
        List<BindingCard> cards = this.maServiceWrapper.queryMemberAllVerifiedCards(memberCode);
        if (CollectionUtils.isEmpty(cards)) {
            return;
        }
        MemberBindCardCond cond = new MemberBindCardCond();
        cond.setMembercode(memberCode);

        List<MemberBindCard> list = this.memberBindCardDao.queryList(cond, 0, -1);
        if (CollectionUtils.isNotEmpty(list)) {
            return;
        }

        Collections.sort(cards, new Comparator<BindingCard>() {
            @Override
            public int compare(BindingCard o1, BindingCard o2) {
                Date date1 = o1.getCreationDate();
                Date date2 = o2.getCreationDate();
                return date1.compareTo(date2);
            }
        });
        Date now = new Date();
        BindingCard firstCard = cards.iterator().next();
        MemberBindCard memberBindCard = new MemberBindCard();
        memberBindCard.setFirstCardBindDate(firstCard.getCreationDate());
        // memberBindCard.setFirstCardNo(firstCard.getBankAcctID());
        memberBindCard.setMembercode(firstCard.getMemberCode());
        memberBindCard.setCreateTime(now);
        memberBindCard.setUpdateTime(now);
        this.memberBindCardDao.saveOrUpdate(memberBindCard);
    }

    private String findPhoneNo(Map<String, String> eventMap) throws AppBizException {
        // retrieve from memory
        String mobile = eventMap.get(KEY_IDCONTENT);
        String memberCode = eventMap.get(KEY_MEMBERCODE);

        // retrieve from local DB
        if (StringUtils.isBlank(mobile)) {
            try {
                MamRegisterLog mamRegisterLog = this.mamRegisterLogService.getByMemberCode(memberCode);
                mobile = mamRegisterLog.getIdcontent();
            } catch (AppBizException e) {
                logger.warn("@@mobile not found,membercode==" + memberCode);
            }
        }

        // retrieve from remoting service
        if (StringUtils.isBlank(mobile)) {
            logger.warn("@@phoneNo is empty in MA message,try to find by remoting invoke...");
            mobile = this.maServiceWrapper.getMobileByMembercode(memberCode);
            logger.info("@@remoting invoke compeleted,phoneNo is:" + mobile);
        }
        return mobile;
    }

    private void handleBindEvent(Map<String, String> eventMap) {
        if (!VALUE_EVENT_TYPE_BIND.equals(eventMap.get(KEY_EVENTTYPE))) {
            return;
        }

        String memberCode = eventMap.get(KEY_MEMBERCODE);

        try {
            // save first bind card info
            this.findAndHandleFirstBindCardInfo(memberCode);
        } catch (Throwable e) {
            logger.error("@@meet error when do [findAndHandleFirstBindCardInfo]:" + e.getMessage(), e);
        }

        // 绑卡
        try {
            MamRegisterLog registerLog = this.mamRegisterLogService.getByMemberCode(memberCode);
            // 手机用户绑卡后更新分享状态为激活
            if (VALUE_REGFROM_MOBILE.equals(registerLog.getRegFrom())) {
                this.changeShareRelationStatus(eventMap);
                logger.info("@@share relations status changed OK!");
            }
        } catch (Throwable e) {
            logger.error("@@meet error when do [changeShareRelationStatus]:" + e.getMessage(), e);
        }
    }

    private void handleRegisterEvent(String eventJson, Map<String, String> eventMap) {

        if (!VALUE_EVENT_TYPE_REGISTER.equals(eventMap.get(KEY_EVENTTYPE))) {
            return;
        }

        this.addMamRegisterLog(eventJson, eventMap);

        logger.info("@@MA Register info saved to db compeleted!");
    }

    @Override
    public void onMessage(final String eventJson) {
        logger.info("@@MA Message received,message=" + eventJson);

        // 忽略存量注册消息（QuickPayment,Ebpp）
        Map<String, String> eventMap = this.convert2Map(eventJson);
        if (VALUE_EVENT_TYPE_REGISTER.equals(eventMap.get(KEY_EVENTTYPE))) {
            boolean channelIgnore = MaMessageChannel.isChannelIgnore(eventMap.get(KEY_REG_FROM));
            if (channelIgnore) {
                logger.info("@@message is ignored,regFrom=" + eventMap.get(KEY_REG_FROM));
                return;
            }
        }

        this.processMessage(eventJson);
    }

    private Date parseDate(String requestTime, String format) {
        try {
            return DateUtils.parseDate(requestTime, new String[] { format });
        } catch (ParseException e) {
            logger.error("requestTime[" + requestTime + "] format error!", e);
        }
        return new Date();
    }

    private void processMessage(String eventJson) {
        long beginTime = System.currentTimeMillis();
        logger.info("@@begin to process request...");
        try {
            // 参数转换 Json -> Map
            Map<String, String> eventMap = this.convert2Map(eventJson);

            // 处理注册信息
            this.handleRegisterEvent(eventJson, eventMap);

            // 处理绑卡信息
            this.handleBindEvent(eventMap);

            // 送权益
            this.bindInterests(eventMap);

        } catch (Throwable e) {
            logger.error("@@process meet error. ", e);
        } finally {
            long endTime = System.currentTimeMillis();
            logger.info("@@process compeleted,spent [{}] ms", (endTime - beginTime));
        }
    }

    public void setMamRegisterLogService(MamRegisterLogService mamRegisterLogService) {
        this.mamRegisterLogService = mamRegisterLogService;
    }

}
