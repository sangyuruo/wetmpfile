/**
 * 
 */
package com.bill99.ebd.rip.dal.dao;

import com.bill99.ebd.rip.dal.dao.hibernate.generic.Condition;
import com.bill99.ebd.rip.dal.dao.hibernate.generic.OrderableCondition;
import com.bill99.ebd.rip.dal.model.BindInterestsReq;

/**
 * @project: app-rip-0520-2
 * @description:
 * @author: lei.yu
 * @create_time: 2015年5月12日
 * @modify_time: 2015年5月12日
 */
@Condition
public class BindInterestsReqCond extends BindInterestsReq implements OrderableCondition {

	private static final long serialVersionUID = 5278802110316887501L;
	private String orders;

	@Override
	public void setOrders(String orders) {
		this.orders = orders;
	}

	@Override
	public String getOrders() {
		return orders;
	}
}
