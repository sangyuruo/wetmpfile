/**
 * 
 */
package com.bill99.ebd.rip.whitelist.srv.impl;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.enums.AppExCodeEnum;
import com.bill99.ebd.rip.enums.WhiteListKeyType;
import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.whitelist.dal.dao.ActivityWhiteListRuleDao;
import com.bill99.ebd.rip.whitelist.dal.model.ActivityWhiteListRule;
import com.bill99.ebd.rip.whitelist.dal.model.ActivityWhiteListRuleCond;
import com.bill99.ebd.rip.whitelist.srv.ActivityWhiteListRuleService;
import com.bill99.ebd.rip.whitelist.srv.WhiteListService;
import com.bill99.ebd.rip.wrapper.MaServiceWrapper;
import com.bill99.seashell.common.util.StringUtil;

/**
 * @project: app-rip-0819
 * @description:
 * @author: lei.yu
 * @create_time: 2015年8月19日
 * @modify_time: 2015年8月19日
 */
public class ActivityWhiteListRuleServiceImpl implements ActivityWhiteListRuleService {
	
	//logger for class ActivityWhiteListRuleServiceImpl
	private static final Log logger = 
			LogFactory.getLog(ActivityWhiteListRuleServiceImpl.class);

	@Autowired
	private ActivityWhiteListRuleDao activityWhiteListRuleDao;

	@Autowired
	private WhiteListService whiteListService;

	@Autowired
	private MaServiceWrapper maServiceWrapper;

	@Override
	public void checkWhiteList(Integer activityId, String memberCode) throws AppBizException {
		ActivityWhiteListRuleCond cond = new ActivityWhiteListRuleCond();
		cond.setActivityId(activityId);
		List<ActivityWhiteListRule> activityWhiteListRules = activityWhiteListRuleDao.queryList(cond, 0, 1);
		boolean pass = false;
		for (ActivityWhiteListRule activityWhiteListRule : activityWhiteListRules) {
			WhiteListKeyType whiteListKeyType = activityWhiteListRule.getWhiteListKeyType();
			String whiteListName = activityWhiteListRule.getWhiteListName();
			// 未配置白名单类型
			if (whiteListKeyType == null) {
				for (WhiteListKeyType type : WhiteListKeyType.values()) {
					String keyWord = getWhiteListkeyWord(type, memberCode);
					if (!StringUtil.isEmpty(keyWord) && whiteListService.isExist(whiteListName, type, keyWord)) {
						pass = true;
						break;
					}
				}
			} else {
				// 配置白名单类型
				String keyWord = getWhiteListkeyWord(whiteListKeyType, memberCode);
				if (! StringUtil.isEmpty(keyWord) && whiteListService.isExist(whiteListName, whiteListKeyType, keyWord)) {
					pass = true;
					break;
				}
			}
		}
		if (!pass) {
			throw new AppBizException(AppExCodeEnum.WHITE_LIST_NOT_EXIST);
		}
	}

	private String getWhiteListkeyWord(WhiteListKeyType whiteListKeyType, String keyWord) throws AppBizException {
		if (WhiteListKeyType.MEMBERCODE.equals(whiteListKeyType)) {
			return keyWord;
		}
		if (WhiteListKeyType.EMAIL.equals(whiteListKeyType)) {
			try {
				return maServiceWrapper.getEmailByMembercode(keyWord);
			} catch (AppBizException e) {
				logger.error("get email by membercode meet error.", e);
				return null;
			}
		}
		if (WhiteListKeyType.MOBILE.equals(whiteListKeyType)) {
			try {
				return maServiceWrapper.getMobileByMembercode(keyWord);
			} catch (AppBizException e) {
				logger.error("get mobile by membercode meet error.", e);
				return null;
			}
		}
		return keyWord;
	}
}
