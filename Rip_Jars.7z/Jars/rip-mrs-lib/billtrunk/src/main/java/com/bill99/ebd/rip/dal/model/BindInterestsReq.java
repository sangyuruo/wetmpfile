/**
 * 
 */
package com.bill99.ebd.rip.dal.model;

import java.io.Serializable;
import java.util.Date;

/**
 * @project: app-rip-0520-2
 * @description:
 * @author: lei.yu
 * @create_time: 2015年5月12日
 * @modify_time: 2015年5月12日
 */
public class BindInterestsReq implements Serializable {
	private static final long serialVersionUID = 5576497569820313542L;
	private Long bindInterestsReqId;//
	private String requestId;// 请求id
	private Date requestTime;// 请求时间
	private String productGroup;// 产品线
	private String memCode;// 受益人用户标示
	private String activityId;// 活动id
	private String para;// 附加参数
	private Date createTime;// 创建时间
	private Date updateTime;// 更新时间

	public Long getBindInterestsReqId() {
		return bindInterestsReqId;
	}

	public String getRequestId() {
		return requestId;
	}

	public Date getRequestTime() {
		return requestTime;
	}

	public String getProductGroup() {
		return productGroup;
	}

	public String getMemCode() {
		return memCode;
	}

	public String getActivityId() {
		return activityId;
	}

	public String getPara() {
		return para;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setBindInterestsReqId(Long bindInterestsReqId) {
		this.bindInterestsReqId = bindInterestsReqId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public void setRequestTime(Date requestTime) {
		this.requestTime = requestTime;
	}

	public void setProductGroup(String productGroup) {
		this.productGroup = productGroup;
	}

	public void setMemCode(String memCode) {
		this.memCode = memCode;
	}

	public void setActivityId(String activityId) {
		this.activityId = activityId;
	}

	public void setPara(String para) {
		this.para = para;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
}
