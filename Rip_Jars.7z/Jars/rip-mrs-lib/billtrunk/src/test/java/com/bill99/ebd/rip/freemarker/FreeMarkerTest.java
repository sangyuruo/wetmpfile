/**
 * 
 */
package com.bill99.ebd.rip.freemarker;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

import junit.framework.Assert;

import org.junit.Test;

import com.bill99.ebd.rip.enums.BaseAssertFltType;
import com.bill99.ebd.rip.enums.InterestsSelectType;
import com.bill99.ebd.rip.srv.impl.InterestsPackage;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;

/**
 * @project: app-rip
 * @description:
 * @author: lei.yu
 * @create_time: 2015年5月30日
 * @modify_time: 2015年5月30日
 */
public class FreeMarkerTest {
	private static final Configuration FREEMARKER_CFG = new Configuration(); 
	static {
		FREEMARKER_CFG.setEncoding(Locale.ENGLISH, "UTF-8");
	}

	@Test
	public void testBase() throws TemplateException, IOException {
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("ruleName", "lc bind rule 1");
		List<String> asserts = new ArrayList<String>();
		asserts.add(genStringAssert("LC", "productGroup"));
		asserts.add(genStringAssert("LC02", "extInfo.get(\"lcEventType\")"));
		asserts.add(genStringAssert("123456", "extInfo.get(\"lcProductId\")"));
		asserts.add(genDateAssert("20150528185116705", "yyyyMMddHHmmssSSS", "extInfo.get(\"reqTime\")",
				"yyyyMMddHHmmssSSS", ">"));
		asserts.add(genAmtAssert("500", "extInfo.get(\"amt\")", "<"));
		data.put("asserts", asserts);
		List<InterestsPackage> interestsPackages = new ArrayList<InterestsPackage>();
		interestsPackages.add(new InterestsPackage(511, 2));
		interestsPackages.add(new InterestsPackage(513, 3));
		data.put("interestsPackages", interestsPackages);
		data.put("selectType", InterestsSelectType.ALL.name());
		data.put("activityId", 760);

		String result = getResult(
				readInputStreamReaderAsString(new InputStreamReader(
						FreeMarkerTest.class.getResourceAsStream("test.ftl"))), data);
		System.out.println(result.length());
		System.out.println(result);
		Assert.assertEquals(
				result,
				readInputStreamReaderAsString(new InputStreamReader(FreeMarkerTest.class
						.getResourceAsStream("compareDrools.drl"))));
	}

	public static final String getResult(String templateString, Object data) throws TemplateException, IOException {
		Template template = null;
		StringWriter writer = new StringWriter();
		template = createTemplate(templateString);
		template.process(data, writer);
		template = null;
		String result = writer.toString();
		return result;
	}

	private static final String genStringAssert(final String constant, final String expression)
			throws TemplateException, IOException {
		Map<String, String> para = new HashMap<String, String>();
		para.put("constant", constant);
		para.put("expression", expression);
		return getResult(BaseAssertFltType.STRING.getFtl(), para);
	}

	private static final String genDateAssert(final String constant, final String pattenConstant,
			final String expression, final String pattenExpression, final String operator) throws TemplateException,
			IOException {
		Map<String, String> para = new HashMap<String, String>();
		para.put("constant", constant);
		para.put("pattenConstant", pattenConstant);
		para.put("expression", expression);
		para.put("pattenExpression", pattenExpression);
		para.put("operator", operator);
		return getResult(BaseAssertFltType.DATE.getFtl(), para);
	}

	private static final String genAmtAssert(final String constant, final String expression, final String operator)
			throws TemplateException, IOException {
		Map<String, String> para = new HashMap<String, String>();
		para.put("constant", constant);
		para.put("expression", expression);
		para.put("operator", operator);
		return getResult(BaseAssertFltType.NUMBER.getFtl(), para);
	}

	private static Template createTemplate(String templateString) throws IOException {
		StringReader reader = new StringReader(templateString.toString());
		Template template = new Template(UUID.randomUUID().toString(), reader, FREEMARKER_CFG);
		template.getConfiguration().setClassicCompatible(true);// 处理空值为空字符串
		return template;
	}

	private static String readInputStreamReaderAsString(InputStreamReader in) throws IOException {
		StringBuffer fileData = new StringBuffer(1000);
		BufferedReader reader = new BufferedReader(in);
		char[] buf = new char[1024];
		int numRead = 0;
		while ((numRead = reader.read(buf)) != -1) {
			String readData = String.valueOf(buf, 0, numRead);
			fileData.append(readData);
			buf = new char[1024];
		}
		reader.close();
		return fileData.toString();
	}
}
