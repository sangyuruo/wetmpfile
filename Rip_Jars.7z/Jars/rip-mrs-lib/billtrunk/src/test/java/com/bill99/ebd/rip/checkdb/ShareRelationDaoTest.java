package com.bill99.ebd.rip.checkdb;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.dal.dao.ShareRelationCond;
import com.bill99.ebd.rip.dal.dao.ShareRelationDao;
import com.bill99.ebd.rip.dal.model.ShareRelation;
import com.bill99.ebd.rip.junit.SpringConfiguredJunit4Test;

public class ShareRelationDaoTest extends SpringConfiguredJunit4Test{

 
	@Autowired
	private ShareRelationDao dao;
	
	@Test
	public void checkConfigration() throws Exception{
		
		ShareRelation entity =  getEntityNewInstanceBatch(ShareRelation.class);
		entity.setId(-99999);
		dao.add(entity);
		System.out.println(ToStringBuilder.reflectionToString(entity));		
		
		ShareRelation item = dao.get(entity.getId());
		ShareRelationCond cond = new ShareRelationCond();
		List<ShareRelation> list = dao.queryList(cond, 0, -1);
		System.out.println("=========size:" + list.size());
		dao.delete(entity);
		assertEquals(item.getId(), entity.getId());
		assertTrue("result list is empty",!list.isEmpty());
	}
	
	 
}
