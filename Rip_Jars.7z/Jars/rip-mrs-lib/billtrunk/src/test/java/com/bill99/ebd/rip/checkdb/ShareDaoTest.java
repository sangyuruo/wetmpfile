package com.bill99.ebd.rip.checkdb;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.dal.dao.ShareCond;
import com.bill99.ebd.rip.dal.dao.ShareDao;
import com.bill99.ebd.rip.dal.model.Share;
import com.bill99.ebd.rip.enums.BooleanType;
import com.bill99.ebd.rip.junit.SpringConfiguredJunit4Test;

public class ShareDaoTest extends SpringConfiguredJunit4Test{

 
	@Autowired
	private ShareDao dao;
	
	@Test
	public void checkConfigration() throws Exception{
		
		Share entity =  getEntityNewInstanceBatch(Share.class);
		entity.setIsRequireRealNameShare(BooleanType.TRUE);
		dao.add(entity);
		System.out.println(ToStringBuilder.reflectionToString(entity));		
		
		Share item = dao.get(entity.getId());
		ShareCond cond = new ShareCond();
		List<Share> list = dao.queryList(cond, 0, -1);
		System.out.println("=========size:" + list.size());
		dao.delete(entity);
		assertEquals(item.getId(), entity.getId());
		assertTrue("result list is empty",!list.isEmpty());
	}
	 
}
