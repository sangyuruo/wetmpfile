package com.bill99.ebd.rip.checkdb;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.dal.dao.ActivityCheckCond;
import com.bill99.ebd.rip.dal.dao.ActivityCheckDao;
import com.bill99.ebd.rip.dal.model.ActivityCheck;
import com.bill99.ebd.rip.enums.ActivityCheckType;
import com.bill99.ebd.rip.junit.SpringConfiguredJunit4Test;

public class ActivityCheckDaoTest extends SpringConfiguredJunit4Test{

 
	@Autowired
	private ActivityCheckDao dao;
	
	@Test
	public void checkConfigration() throws Exception{
		
		ActivityCheck entity =  getEntityNewInstanceBatch(ActivityCheck.class);
		entity.setActivityCheckId(-99999L);
		entity.setActivityCheckType(ActivityCheckType.IS_BIND_CREDIT_CARD);
		dao.add(entity);
		System.out.println(ToStringBuilder.reflectionToString(entity));		
		
		ActivityCheck item = dao.get(entity.getActivityCheckId());
		ActivityCheckCond cond = new ActivityCheckCond();
		List<ActivityCheck> list = dao.queryList(cond, 0, -1);
		System.out.println("=========size:" + list.size());
		dao.delete(entity);
		assertEquals(item.getActivityCheckId(), entity.getActivityCheckId());
		assertTrue("result list is empty",!list.isEmpty());
	}
	
	 
}
