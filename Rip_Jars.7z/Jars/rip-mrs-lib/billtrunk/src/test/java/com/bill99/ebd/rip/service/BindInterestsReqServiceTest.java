/**
 * 
 */
package com.bill99.ebd.rip.service;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;

import com.bill99.ebd.rip.srv.BindInterestsReqService;

/**
 * @project: app-rip
 * @description: 
 * @author: lei.yu
 * @create_time: 2015年5月18日
 * @modify_time: 2015年5月18日
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:springContext.xml")
@TransactionConfiguration(defaultRollback = false)
public class BindInterestsReqServiceTest {

	@Resource
	private BindInterestsReqService bindInterestsReqService;
	
	@Test
	public void checkReqIdUniqueTest() throws Exception {
		//bindInterestsReqService.updateResponeCode("zg0000000000000039", "2234");
		bindInterestsReqService.checkReqIdUnique("NotExistsReqId");
	}
}
