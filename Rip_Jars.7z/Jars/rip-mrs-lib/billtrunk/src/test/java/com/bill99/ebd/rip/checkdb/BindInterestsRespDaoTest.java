package com.bill99.ebd.rip.checkdb;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.dal.dao.BindInterestsRespCond;
import com.bill99.ebd.rip.dal.dao.BindInterestsRespDao;
import com.bill99.ebd.rip.dal.model.BindInterestsResp;
import com.bill99.ebd.rip.junit.SpringConfiguredJunit4Test;

public class BindInterestsRespDaoTest extends SpringConfiguredJunit4Test{

 
	@Autowired
	private BindInterestsRespDao dao;
	
	@Test
	public void checkConfigration() throws Exception{
		
		BindInterestsResp entity =  getEntityNewInstanceBatch(BindInterestsResp.class);
		entity.setBindInterestsRespId(-99999L);
		dao.add(entity);
		System.out.println(ToStringBuilder.reflectionToString(entity));		
		
		BindInterestsResp item = dao.get(entity.getBindInterestsRespId());
		BindInterestsRespCond cond = new BindInterestsRespCond();
		List<BindInterestsResp> list = dao.queryList(cond, 0, -1);
		System.out.println("=========size:" + list.size());
		dao.delete(entity);
		assertEquals(item.getBindInterestsRespId(), entity.getBindInterestsRespId());
		assertTrue("result list is empty",!list.isEmpty());
	}
	
	 
}
