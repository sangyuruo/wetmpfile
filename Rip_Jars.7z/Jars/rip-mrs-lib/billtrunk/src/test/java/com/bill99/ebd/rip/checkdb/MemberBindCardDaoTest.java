package com.bill99.ebd.rip.checkdb;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.dal.dao.MemberBindCardCond;
import com.bill99.ebd.rip.dal.dao.MemberBindCardDao;
import com.bill99.ebd.rip.dal.model.MemberBindCard;
import com.bill99.ebd.rip.junit.SpringConfiguredJunit4Test;

public class MemberBindCardDaoTest extends SpringConfiguredJunit4Test{

 
    @Autowired
    private MemberBindCardDao dao;
    
    @Test
    public void checkConfigration() throws Exception{
        
        MemberBindCard entity =  getEntityNewInstanceBatch(MemberBindCard.class);
        
        dao.add(entity);
        System.out.println(ToStringBuilder.reflectionToString(entity));     
        
        MemberBindCard item = dao.get(entity.getIdMemberBindCard());
        MemberBindCardCond cond = new MemberBindCardCond();
        List<MemberBindCard> list = dao.queryList(cond, 0, -1);
        System.out.println("=========size:" + list.size());
        
        assertEquals(item.getIdMemberBindCard(), entity.getIdMemberBindCard());
        assertTrue("result list is empty",!list.isEmpty());
        dao.delete(entity);
    }
    
     
}
