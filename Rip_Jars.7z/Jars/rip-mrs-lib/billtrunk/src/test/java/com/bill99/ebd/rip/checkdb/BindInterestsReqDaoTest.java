package com.bill99.ebd.rip.checkdb;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.dal.dao.BindInterestsReqCond;
import com.bill99.ebd.rip.dal.dao.BindInterestsReqDao;
import com.bill99.ebd.rip.dal.model.BindInterestsReq;
import com.bill99.ebd.rip.junit.SpringConfiguredJunit4Test;

public class BindInterestsReqDaoTest extends SpringConfiguredJunit4Test{

 
	@Autowired
	private BindInterestsReqDao dao;
	
	@Test
	public void checkConfigration() throws Exception{
		
		BindInterestsReq entity =  getEntityNewInstanceBatch(BindInterestsReq.class);
		entity.setBindInterestsReqId(-99999L);
		dao.add(entity);
		System.out.println(ToStringBuilder.reflectionToString(entity));		
		
		BindInterestsReq item = dao.get(entity.getBindInterestsReqId());
		BindInterestsReqCond cond = new BindInterestsReqCond();
		List<BindInterestsReq> list = dao.queryList(cond, 0, -1);
		System.out.println("=========size:" + list.size());
		dao.delete(entity);
		assertEquals(item.getBindInterestsReqId(), entity.getBindInterestsReqId());
		assertTrue("result list is empty",!list.isEmpty());
	}
	
	 
}
