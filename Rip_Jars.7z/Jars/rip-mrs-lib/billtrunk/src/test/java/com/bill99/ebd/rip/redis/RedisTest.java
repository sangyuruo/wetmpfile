package com.bill99.ebd.rip.redis;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Calendar;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;

import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.util.HttpClientCall;
import com.bill99.ebd.rip.weixin.srv.WeixinService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:test/springContext.xml")
@TransactionConfiguration(defaultRollback = false)
public class RedisTest {
	
	@Resource(name = "weixinService")
	private WeixinService weixinService;
	
	@Test
	public void test () {
		String scc = weixinService.getAccessToken();
		System.out.println("aaaa : " + scc);
    }
	
	/*@Test
	public void setTest() {
		bill99Jedis.getSet("asd", "a");
	}*/
	
	@Test
	public void getTest() {
		/*System.out.println("qwe");
		Object ob = bill99Jedis.get("asd");
		System.out.println(ob.toString());*/
		sha();
	}
	
	// 1 获取AccessToken
	private String getAccessToken() {
		String getAccessTokenStr = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=wx964175b2dc3fc263&secret=160346e959388266b38aa8ab645ce3c7";
		String accessToken = httpCall(getAccessTokenStr);
		System.out.println("getAccessToken =======================");
		System.out.println("accessToken : " + accessToken);
		
		return accessToken;
		
		/*{"errcode":40013,"errmsg":"invalid appid"}*/
		
		/*String accessToken = 
				"{\"access_token\":\"ahKSmvFT_liQAutGevpQ_ZpAaaETT_PPkyx3BcFu3Z7huHInb9LYb7Hl5AlibCdZVRFHKp2CdLHcBr9yCrHf-uL6tNemkKIL1C8ozv3LYKo\",\"expires_in\":7200}";*/
	}
	
	// 2 获取JsapiTicket
	private String getJsapiTicket(){
		String getJsapiTicketStr = "https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token=ahKSmvFT_liQAutGevpQ_ZpAaaETT_PPkyx3BcFu3Z7huHInb9LYb7Hl5AlibCdZVRFHKp2CdLHcBr9yCrHf-uL6tNemkKIL1C8ozv3LYKo&type=jsapi";
		
		String jsapiTicket = httpCall(getJsapiTicketStr);
		
		System.out.println("getJsapiTicket =======================");
		System.out.println("jsapiTicket : " + jsapiTicket);
		
		 /*{"errcode":0,"errmsg":"ok","ticket":"kgt8ON7yVITDhtdwci0qefxgmL8XmF-z67_YqDSsWZSiMs72tQ_RuwqPmqmlJBzDXdyN091GLXQih9j5ukly_A","expires_in":7200}*/
		/*{"errcode":40001,"errmsg":"invalid credential, access_token is invalid or not latest hint: [LQ0430vr20]"}*/
		return jsapiTicket;
		
	}
	
	// 3 签名
	private void sha() {
		String noncestr = "3edc$RFV";
		String  jsapiTicket = "kgt8ON7yVITDhtdwci0qefxgmL8XmF-z67_YqDSsWZSiMs72tQ_RuwqPmqmlJBzDXdyN091GLXQih9j5ukly_A";
		Calendar c = Calendar.getInstance();
		String timestamp = (c.getTimeInMillis() / 1000)+ "";
		System.out.println("timestamp : " + timestamp);
		String url = "https://office.99bill.net/Pages/Home.aspx";
		
		StringBuffer sb = new StringBuffer("jsapi_ticket=");
		sb.append(jsapiTicket);
		sb.append("&noncestr=").append(noncestr);
		sb.append("&timestamp=").append(timestamp);
		sb.append("&url=").append(url);
		
		System.out.println(sb.toString());
		
		// 签名
		MessageDigest md = null; 
		try {
			md = MessageDigest.getInstance("SHA-1");  
			byte[] digest = md.digest(sb.toString().getBytes());  
			String signature = byteToStr(digest);
			System.out.println(" signature : " + signature);
		} catch (NoSuchAlgorithmException e) {
			System.out.println(e.getMessage());
		}
		
	}
	
	// 将字节数组转换为十六进制字符串 
    private static String byteToStr(byte[] byteArray) {  
        String strDigest = "";  
        for (int i = 0; i < byteArray.length; i++) {  
            strDigest += byteToHexStr(byteArray[i]);  
        }  
        return strDigest;  
    }  
    
    // 将字节转换为十六进制字符串
    private static String byteToHexStr(byte mByte) {  
        char[] Digit = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };  
        char[] tempArr = new char[2];  
        tempArr[0] = Digit[(mByte >>> 4) & 0X0F];  
        tempArr[1] = Digit[mByte & 0X0F];  
        String s = new String(tempArr);  
        return s;  
    }  
	
	private String httpCall(String str) {
		
		HttpClientCall call = new HttpClientCall(str);
		String returnStr = null;
		try {
			returnStr = call.call();
		} catch (AppBizException e) {
			System.out.println("{ " + e.getErrorCode() + " : " + e.getErrorMessage() + " }");
		}
		return returnStr;
		
	}
	
	
	

}
