package com.bill99.ebd.rip.checkdb;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.dal.dao.MamRegisterLogCond;
import com.bill99.ebd.rip.dal.dao.MamRegisterLogDao;
import com.bill99.ebd.rip.dal.model.MamRegisterLog;
import com.bill99.ebd.rip.junit.SpringConfiguredJunit4Test;

public class MamRegisterLogDaoTest extends SpringConfiguredJunit4Test{

 
	@Autowired
	private MamRegisterLogDao dao;
	
	@Test
	public void checkConfigration() throws Exception{
		
		MamRegisterLog entity =  getEntityNewInstanceBatch(MamRegisterLog.class);
		entity.setMamRegisterLogId(-99999L);
		dao.add(entity);
		System.out.println(ToStringBuilder.reflectionToString(entity));		
		
		MamRegisterLog item = dao.get(entity.getMamRegisterLogId());
		MamRegisterLogCond cond = new MamRegisterLogCond();
		List<MamRegisterLog> list = dao.queryList(cond, 0, -1);
		System.out.println("=========size:" + list.size());
		dao.delete(entity);
		assertEquals(item.getMamRegisterLogId(), entity.getMamRegisterLogId());
		assertTrue("result list is empty",!list.isEmpty());
	}
	
	 
}
