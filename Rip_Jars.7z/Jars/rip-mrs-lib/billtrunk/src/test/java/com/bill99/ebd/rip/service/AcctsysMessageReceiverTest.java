/**
 * 
 */
package com.bill99.ebd.rip.service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.annotation.Resource;

import org.apache.commons.lang.time.DateFormatUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;

import com.bill99.ebd.rip.srv.AcctsysMessageReceiver;

/**
 * @project: app-rip-0603-mam
 * @description:
 * @author: lei.yu
 * @create_time: 2015年5月26日
 * @modify_time: 2015年5月26日
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:springContext.xml")
@TransactionConfiguration(defaultRollback = false)
public class AcctsysMessageReceiverTest {

	@Resource
	private AcctsysMessageReceiver acctsysMessageReceiver;

	private ObjectMapper mapper = new ObjectMapper();

	@Test
	public void acctsysMessageReceiverTest() throws Exception {
		for (int i = 0; i < 5; i++) {
			Map<String, String> para = new HashMap<String, String>();
			para.put("requestId", UUID.randomUUID().toString());
			para.put("requestTime", DateFormatUtils.format(new Date(), "yyyyMMddHHmmssSSS"));
			para.put("memberCode", "10011637747");
			para.put("eventType", "EVENT001");
			para.put("eventDesc", "EVENT001 abc");
			para.put("bizCode", "MAM.website");
			para.put("source", "MAM");
			para.put("regFrom", "mobile");

			acctsysMessageReceiver.onMessage(mapper.writeValueAsString(para));
		}
	}

}
