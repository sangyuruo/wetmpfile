/**
 * 
 */
package com.bill99.ebd.rip.service;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;

import com.bill99.ebd.rip.dal.dao.ShareCond;
import com.bill99.ebd.rip.dal.model.Share;
import com.bill99.ebd.rip.srv.ShareService;

/**
 * @project: app-rip-0603-mam
 * @description:
 * @author: lei.yu
 * @create_time: 2015年5月25日
 * @modify_time: 2015年5月25日
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:springContext.xml")
@TransactionConfiguration(defaultRollback = false)
public class ShareServiceTest  {

	@Autowired
	private ShareService shareService;

	@Test
	public void query() throws Exception {
		ShareCond cond = new ShareCond();
		List<Share> list = shareService.query(cond, 0, -1);
		System.out.println(list.size());
	}

}
