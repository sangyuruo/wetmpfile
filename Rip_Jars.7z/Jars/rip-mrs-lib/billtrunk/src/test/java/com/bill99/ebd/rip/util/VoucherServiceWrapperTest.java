/**
 * 
 */
package com.bill99.ebd.rip.util;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.junit.SpringConfiguredJunit4Test;

/**
 * @author shuangye.liu
 * @since Nov 29, 2016
 */
public class VoucherServiceWrapperTest extends SpringConfiguredJunit4Test {

    @Autowired
    private VoucherServiceWrapper voucherService;

    @Test
    public void test_hold() throws Exception {
        String voucherNo = this.voucherService.holdVoucher(28094, "10012328042", null, null);
        Assert.assertNotNull(voucherNo);
    }

}
