/**
 * 
 */
package com.bill99.ebd.rip.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;

import com.bill99.ebd.rip.enums.RuleGroupType;
import com.bill99.ebd.rip.rule.srv.RuleService;
import com.bill99.ebd.rip.srv.impl.BindInterestsFact;
import com.bill99.ebd.rip.srv.impl.BindInterestsRuleActionReturn;
import com.bill99.ebd.rip.srv.impl.InterestsPackage;

/**
 * @project: app-rip-0603-mam
 * @description:
 * @author: lei.yu
 * @create_time: 2015年5月25日
 * @modify_time: 2015年5月25日
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:springContext.xml")
@TransactionConfiguration(defaultRollback = false)
public class RuleServiceTest  {

	@Autowired
	private RuleService ruleService;

	@Test
	public void ruleActionTest() throws Exception {
		List<Object> facts = new ArrayList<Object>();
		BindInterestsFact fact = new BindInterestsFact();
		fact.setProductGroup("TEST-1");
		Map<String, String> extInfo = new HashMap<String, String>();
		extInfo.put("lcEventId", "TEST-1-01");
		extInfo.put("lcProductId", "123456");
		fact.setExtInfo(extInfo);
		facts.add(fact);

		List<Object> ruleGroupAction = ruleService.ruleGroupAction(RuleGroupType.BIND_INTERESTS.name(), facts);
		for (Object object : ruleGroupAction) {
			BindInterestsRuleActionReturn bReturn = (BindInterestsRuleActionReturn) object;
			System.out.println(bReturn.getActivityId());
			System.out.println(bReturn.getSelectType());
			for (InterestsPackage interestsPackage : bReturn.getInterestsPackages()) {
				System.out.println(interestsPackage.getInterestsId());
				System.out.println(interestsPackage.getCnt());
			}
		}

	}

	@Test
	public void ruleActionMamTest() throws Exception {
		List<Object> facts = new ArrayList<Object>();
		BindInterestsFact fact = new BindInterestsFact();
		fact.setProductGroup("MAM");
		Map<String, String> extInfo = new HashMap<String, String>();
		extInfo.put("eventType", "EVENT001");
		extInfo.put("memberType", "1");
		fact.setExtInfo(extInfo);
		facts.add(fact);

		List<Object> ruleGroupAction = ruleService.ruleGroupAction(RuleGroupType.BIND_INTERESTS.name(), facts);
		for (Object object : ruleGroupAction) {
			BindInterestsRuleActionReturn bReturn = (BindInterestsRuleActionReturn) object;
			System.out.println(bReturn.getActivityId());
			System.out.println(bReturn.getSelectType());
			for (InterestsPackage interestsPackage : bReturn.getInterestsPackages()) {
				System.out.println(interestsPackage.getInterestsId());
				System.out.println(interestsPackage.getCnt());
			}
		}
	}
}
