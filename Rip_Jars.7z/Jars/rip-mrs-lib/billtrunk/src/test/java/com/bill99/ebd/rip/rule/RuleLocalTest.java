/**
 * 
 */
package com.bill99.ebd.rip.rule;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;

import com.bill99.ebd.rip.dal.model.RuleActionReturn;
import com.bill99.ebd.rip.junit.AbstractJunit4Test;
import com.bill99.ebd.rip.rule.srv.impl.DroolsTemplate;
import com.bill99.ebd.rip.rule.srv.impl.RuleTemplate;
import com.bill99.ebd.rip.srv.impl.BindInterestsFact;
import com.bill99.ebd.rip.srv.impl.BindInterestsRuleActionReturn;
import com.bill99.ebd.rip.srv.impl.InterestsPackage;

/**
 * @project: app-rip-0603-mam
 * @description:
 * @author: lei.yu
 * @create_time: 2015年5月25日
 * @modify_time: 2015年5月25日
 */
public class RuleLocalTest extends AbstractJunit4Test {

	@Test
	public void ruleActionLocalTest() throws Exception {
		List<String> rules = new ArrayList<String>();
		rules.add(readInputStreamReaderAsString(new InputStreamReader(RuleLocalTest.class
				.getResourceAsStream("prodDrools-1.drl"))));
		rules.add(readInputStreamReaderAsString(new InputStreamReader(RuleLocalTest.class
				.getResourceAsStream("prodDrools-3.drl"))));
		rules.add(readInputStreamReaderAsString(new InputStreamReader(RuleLocalTest.class
				.getResourceAsStream("prodDrools-2.drl"))));
		rules.add(readInputStreamReaderAsString(new InputStreamReader(RuleLocalTest.class
				.getResourceAsStream("prodDrools-5.drl"))));
		rules.add(readInputStreamReaderAsString(new InputStreamReader(RuleLocalTest.class
				.getResourceAsStream("prodDrools-4.drl"))));
		List<Object> facts = new ArrayList<Object>();
		BindInterestsFact fact = new BindInterestsFact();
		fact.setProductGroup("TEST-1");
		Map<String, String> extInfo = new HashMap<String, String>();
		extInfo.put("lcEventId", "TEST-1-01");
		extInfo.put("lcProductId", "123456");
		fact.setExtInfo(extInfo);
		facts.add(fact);

		RuleTemplate ruleTemplate = new DroolsTemplate(rules);
		List<Object> internalFacts = new ArrayList<Object>();
		internalFacts.addAll(facts);
		RuleActionReturn rar = new RuleActionReturn();
		internalFacts.add(rar);

		ruleTemplate.ruleAction(internalFacts);

		for (Object object : rar.getReturns()) {
			BindInterestsRuleActionReturn bReturn = (BindInterestsRuleActionReturn) object;
			System.out.println(bReturn.getActivityId());
			System.out.println(bReturn.getSelectType());
			for (InterestsPackage interestsPackage : bReturn.getInterestsPackages()) {
				System.out.println(interestsPackage.getInterestsId());
				System.out.println(interestsPackage.getCnt());
			}
		}

	}

	@Test
	public void localDrlTest() throws Exception {
		List<String> rules = new ArrayList<String>();
		rules.add(readInputStreamReaderAsString(new InputStreamReader(RuleLocalTest.class
				.getResourceAsStream("testFtlDrools.drl"))));
		List<BindInterestsFact> facts = new ArrayList<BindInterestsFact>();
		BindInterestsFact fact = new BindInterestsFact();
		fact.setProductGroup("LC");
		Map<String, String> para = new HashMap<String, String>();
		para.put("lcEventType", "LC02");
		para.put("lcProductId", "123456");
		para.put("amt", "222");
		para.put("reqTime", "20150529185116705");
		fact.setExtInfo(para);
		facts.add(fact);

		RuleTemplate ruleTemplate = new DroolsTemplate(rules);
		List<Object> internalFacts = new ArrayList<Object>();
		internalFacts.addAll(facts);
		RuleActionReturn rar = new RuleActionReturn();
		internalFacts.add(rar);

		ruleTemplate.ruleAction(internalFacts);

		List<Object> returns = rar.getReturns();
		if (returns.size() == 0) {
			System.out.println("return val is null");
			return;
		}
		BindInterestsRuleActionReturn returnVale = (BindInterestsRuleActionReturn) returns.get(0);
		System.out.println(returnVale.getActivityId());
	}
	
	@Test
	public void localProdDrlTest() throws Exception {
		List<String> rules = new ArrayList<String>();
		rules.add(readInputStreamReaderAsString(new InputStreamReader(RuleLocalTest.class
				.getResourceAsStream("testProdDrools.drl"))));
		List<BindInterestsFact> facts = new ArrayList<BindInterestsFact>();
		BindInterestsFact fact = new BindInterestsFact();
		fact.setProductGroup("MAM");
		Map<String, String> para = new HashMap<String, String>();
		para.put("eventType", "EVENT001");
		para.put("memberType", "1");
		para.put("creationDate", "2015-06-22 23:59:59");
		fact.setExtInfo(para);
		facts.add(fact);

		RuleTemplate ruleTemplate = new DroolsTemplate(rules);
		List<Object> internalFacts = new ArrayList<Object>();
		internalFacts.addAll(facts);
		RuleActionReturn rar = new RuleActionReturn();
		internalFacts.add(rar);

		ruleTemplate.ruleAction(internalFacts);

		List<Object> returns = rar.getReturns();
		if (returns.size() == 0) {
			System.out.println("return val is null");
			return;
		}
		BindInterestsRuleActionReturn returnVale = (BindInterestsRuleActionReturn) returns.get(0);
		System.out.println(returnVale.getActivityId());
	}

	@Test
	public void performanceTest() throws Exception {
		List<String> rules = new ArrayList<String>();
		for (int j = 0; j < 500; j++) {
			rules.add(String.format(
					readInputStreamReaderAsString(new InputStreamReader(RuleLocalTest.class
							.getResourceAsStream("testPerformanceDrools.drl"))), String.valueOf(j), String.valueOf(j)));
		}
		Date startInit = new Date();
		RuleTemplate ruleTemplate = new DroolsTemplate(rules);
		Date endInit = new Date();
		System.out.println(String.format("init rule time [%ss]",
				(endInit.getTime() - startInit.getTime()) / 1000));

		List<BindInterestsFact> facts = new ArrayList<BindInterestsFact>();
		BindInterestsFact fact = new BindInterestsFact();
		fact.setProductGroup("MAM");
		Map<String, String> para = new HashMap<String, String>();
		para.put("eventType", "EVENT001");
		para.put("memberType", "1");
		para.put("creationDate", "2015-06-22 23:59:59");
		fact.setExtInfo(para);
		facts.add(fact);

		List<Object> internalFacts = new ArrayList<Object>();
		internalFacts.addAll(facts);
		RuleActionReturn rar = new RuleActionReturn();
		internalFacts.add(rar);

		Date startAction = new Date();
		for (int i = 0; i < 1000; i++) {
			ruleTemplate.ruleAction(internalFacts);
		}
		Date endAction = new Date();
		System.out.println(String.format("rule execute time [%ss]",
				(endAction.getTime() - startAction.getTime())/1000));

		List<Object> returns = rar.getReturns();
		if (returns.size() == 0) {
			System.out.println("return val is null");
			return;
		}
//		for (Object object : returns) {
//			BindInterestsRuleActionReturn returnVale = (BindInterestsRuleActionReturn)object;
//			System.out.println(returnVale.getActivityId());
//		}
		BindInterestsRuleActionReturn returnVale = (BindInterestsRuleActionReturn)returns.get(0);
		System.out.println(returnVale.getActivityId());
	}

	private static String readInputStreamReaderAsString(InputStreamReader in) throws IOException {
		StringBuffer fileData = new StringBuffer(1000);
		BufferedReader reader = new BufferedReader(in);
		char[] buf = new char[1024];
		int numRead = 0;
		while ((numRead = reader.read(buf)) != -1) {
			String readData = String.valueOf(buf, 0, numRead);
			fileData.append(readData);
			buf = new char[1024];
		}
		reader.close();
		return fileData.toString();
	}
}
