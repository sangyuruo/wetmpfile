/**
 * 
 */
package com.bill99.ebd.rip.whitelist;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;

import com.bill99.ebd.rip.exception.AppBizException;
import com.bill99.ebd.rip.whitelist.srv.ActivityWhiteListRuleService;
import com.bill99.ebd.rip.wrapper.MaServiceWrapper;

/**
 * @project: app-rip-0617
 * @description:
 * @author: lei.yu
 * @create_time: 2015年6月11日
 * @modify_time: 2015年6月11日 
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:springContext.xml")
@TransactionConfiguration(defaultRollback = false)
public class ActivityWhiteListRuleServiceTest {

	@Autowired
	private ActivityWhiteListRuleService activityWhiteListRuleService;

	@Autowired
	private MaServiceWrapper memberIdentityService;
	
	@Test
	public void checkActivityWhiteListRuleTest() throws AppBizException {
		activityWhiteListRuleService.checkWhiteList(2004, "10011797954");
	}
	
	@Test
	public void aaTest() throws AppBizException {
		String mobile = memberIdentityService.getMobileByMembercode("10012187519");
		System.out.println(mobile);
	}
}
