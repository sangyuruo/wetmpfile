package com.bill99.ebd.rip.checkdb;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.bill99.ebd.rip.dal.dao.ParamConfigCond;
import com.bill99.ebd.rip.dal.dao.ParamConfigDao;
import com.bill99.ebd.rip.dal.model.ParamConfig;
import com.bill99.ebd.rip.junit.SpringConfiguredJunit4Test;

public class ParamConfigDaoTest extends SpringConfiguredJunit4Test{

 
	@Autowired
	private ParamConfigDao dao;
	
	@Test
	public void checkConfigration() throws Exception{
		
		ParamConfig entity =  getEntityNewInstanceBatch(ParamConfig.class);
		entity.setId(-99999);
		dao.add(entity);
		System.out.println(ToStringBuilder.reflectionToString(entity));		
		
		ParamConfig item = dao.get(entity.getId());
		ParamConfigCond cond = new ParamConfigCond();
		List<ParamConfig> list = dao.queryList(cond, 0, -1);
		System.out.println("=========size:" + list.size());
		dao.delete(entity);
		assertEquals(item.getId(), entity.getId());
		assertTrue("result list is empty",!list.isEmpty());
	}
	
	 
}
