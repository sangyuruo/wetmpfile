package com.bill99.ebd.rip.service;

import java.util.HashMap;
import java.util.Map;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.bill99.ebd.rip.srv.ParamConfigService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:springContext.xml")
@Transactional
@TransactionConfiguration(transactionManager = "txManager", defaultRollback = true)
public class ParamConfigServiceTest {

	@Autowired
	ParamConfigService paramConfigService;

	@Test
	public void Test() {
		Map<String, String> result = new HashMap<String, String>();
		try {
			paramConfigService
					.addParam("ParamConfigServiceTest", "baidumovieurl",
							"http://m.dianying.baidu.com/activity/5zhounian/general?planId=3w");
			paramConfigService.addParam("ParamConfigServiceTest", "startDate",
					"2015/9/9");
			paramConfigService.addParam("ParamConfigServiceTest", "endDate",
					"2015/9/29");
			result = paramConfigService.getByType("ParamConfigServiceTest");
		} catch (Exception e) {
			e.printStackTrace();
		}
		Assert.assertEquals(3, result.size());
	}

}
