package com.bill99.ebd.rip.junit;

import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang.CharUtils;
import org.apache.commons.lang.StringUtils;

public class AbstractJunit4Test {

	protected  <T>T getEntityNewInstanceBatch(Class<T> clazz) throws IllegalAccessException, InvocationTargetException, InstantiationException{
		return getEntityNewInstance(clazz,1).get(0);
	}
	protected  <T>List<T> getEntityNewInstance(Class<T> clazz,int batchNum) throws IllegalAccessException, InvocationTargetException, InstantiationException{
		T entity = null;
		List<T> list = new ArrayList<T>(); 
		System.out.println(clazz.getSimpleName() + " entity = new " + clazz.getSimpleName() +   "();");
		PropertyDescriptor[] propertyDescriptors = PropertyUtils.getPropertyDescriptors(clazz);
		
		for(int i=1;i<=batchNum;i++){
			entity = clazz.newInstance();
			for(PropertyDescriptor item:propertyDescriptors){
				if(item.getPropertyType().isAssignableFrom(Class.class)){
					continue;
				}
				String setterName = item.getWriteMethod().getName();
				String propertyName = item.getName();
				if(propertyName.equals("id")){
					continue;
				}
				//String setterNameToUse = StringUtils.removeStart(setterName, "set"); 
				//String dbColumnName = propertyToField(propertyName);
				String output = "";
				if(item.getPropertyType().isAssignableFrom(String.class)){
					//状态和标志类字段设置值为0或1
					if(StringUtils.containsIgnoreCase(propertyName, "status") || StringUtils.containsIgnoreCase(propertyName, "flag") || StringUtils.containsIgnoreCase(propertyName, "type") || StringUtils.containsIgnoreCase(propertyName, "channel")){
						output = "entity." + setterName + "(i%2==0?'1':'2');";
						BeanUtils.setProperty(entity, propertyName, (i%2==0?'1':'2'));
					}else{
						output = "entity." + setterName + "(\"" + propertyName+i + "\");";
						BeanUtils.setProperty(entity, propertyName, propertyName+i);
					}
						
				}else if(item.getPropertyType().isAssignableFrom(Integer.class)){
					output = "entity." + setterName + "(" + i + ");";
					BeanUtils.setProperty(entity, propertyName, i);
				}else if(item.getPropertyType().isAssignableFrom(Double.class)){
					output = "entity." + setterName + "(" + (i+0.1) + ");";
					BeanUtils.setProperty(entity, propertyName, (i+0.1));
				}else if(item.getPropertyType().isAssignableFrom(BigDecimal.class)){
					output = "entity." + setterName + "(new BigDecimal(" + (i+0.2) +  "));";
					BeanUtils.setProperty(entity, propertyName, (i+0.2));
				}else if(item.getPropertyType().isAssignableFrom(Long.class)){
					output = "entity." + setterName + "(new Long(" + (i+1) +  "));";
					BeanUtils.setProperty(entity, propertyName, (i+0.2));
				}else if(item.getPropertyType().isAssignableFrom(Date.class)){
					output = "entity." + setterName + "(new Date());";
					BeanUtils.setProperty(entity, propertyName, new Date());
				}else if(item.getPropertyType().isAssignableFrom(Character.class)){
					output = "entity." + setterName + "(i%2==0?'1':'2');";
					BeanUtils.setProperty(entity, propertyName, (i%2==0?'1':'2'));
				}else if(item.getPropertyType().isAssignableFrom(Boolean.class)){
					output = "entity." + setterName + "(i%2==0?'1':'0');";
					BeanUtils.setProperty(entity, propertyName, (i%2==0?'1':'0'));
				}
				
				System.out.println(output);
			}
			list.add(entity);
		}
		
		return list;
	}
	protected void printEntityNewInstanceStr(Class clazz){
		
		System.out.println(clazz.getSimpleName() + " entity = new " + clazz.getSimpleName() +   "();");
		PropertyDescriptor[] propertyDescriptors = PropertyUtils.getPropertyDescriptors(clazz);
		
		int i=1;
		for(PropertyDescriptor item:propertyDescriptors){
			if(item.getPropertyType().isAssignableFrom(Class.class)){
				continue;
			}
			String setterName = item.getWriteMethod().getName();
			String propertyName = item.getName();
			//String setterNameToUse = StringUtils.removeStart(setterName, "set");
			String dbColumnName = propertyToField(propertyName);
			String output = "";
			if(item.getPropertyType().isAssignableFrom(String.class)){
				//状态和标志类字段设置值为0或1
				if(StringUtils.containsIgnoreCase(propertyName, "status") || StringUtils.containsIgnoreCase(propertyName, "flag")){
					output = "entity." + setterName + "(i%2==0?'1':'0');";
				}else{
					output = "entity." + setterName + "(\"" + propertyName+i + "\");";
				}				
			}else if(item.getPropertyType().isAssignableFrom(Integer.class)){
				output = "entity." + setterName + "(" + i + ");";
			}else if(item.getPropertyType().isAssignableFrom(Double.class)){
				output = "entity." + setterName + "(" + (i+0.1) + ");";
			}else if(item.getPropertyType().isAssignableFrom(BigDecimal.class)){
				output = "entity." + setterName + "(new BigDecimal(" + (i+10.1) +  "));";
			}else if(item.getPropertyType().isAssignableFrom(Date.class)){
				output = "entity." + setterName + "(new Date());";
			}else if(item.getPropertyType().isAssignableFrom(Character.class)){
				output = "entity." + setterName + "('1');";
			}
			System.out.println(output);
			i++;
		}
		 
	}
	
	/**
	 * 对象属性转换为字段  例如：userName to user_name
	 * @param property 字段名
	 * @return
	 */
	public static String propertyToField(String property) {
		if (null == property) {
			return "";
		}
		char[] chars = property.toCharArray();
		StringBuffer sb = new StringBuffer();
		for (char c : chars) {
			if (CharUtils.isAsciiAlphaUpper(c)) {
				sb.append("_" + StringUtils.lowerCase(CharUtils.toString(c)));
			} else {
				sb.append(c);
			}
		}
		return sb.toString();
	}

	/**
	 * 字段转换成对象属性 例如：user_name to userName
	 * @param field
	 * @return
	 */
	public static String fieldToProperty(String field) {
		if (null == field) {
			return "";
		}
		char[] chars = field.toCharArray();
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < chars.length; i++) {
			char c = chars[i];
			if (c == '_') {
				int j = i + 1;
				if (j < chars.length) {
					sb.append(StringUtils.upperCase(CharUtils.toString(chars[j])));
					i++;
				}
			} else {
				sb.append(c);
			}
		}
		return sb.toString();
	}
}
