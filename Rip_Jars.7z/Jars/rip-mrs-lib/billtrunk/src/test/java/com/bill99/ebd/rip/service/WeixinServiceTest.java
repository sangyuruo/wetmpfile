/**
 * 
 */
package com.bill99.ebd.rip.service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;

import com.bill99.ebd.rip.weixin.srv.WeixinService;

/**
 * @project: app-rip-0603-mam
 * @description:
 * @author: lei.yu
 * @create_time: 2015年5月25日
 * @modify_time: 2015年5月25日
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:springContext.xml")
@TransactionConfiguration(defaultRollback = false)
public class WeixinServiceTest {

	@Autowired
	private WeixinService weixinService;

	@Test
	public void initTest() throws Exception {
		weixinService.init();
	}

}
