package com.bill99.ebd.rip.fund.vo;

import java.io.Serializable;

/**
 * @author yong.zheng
 * @version 创建时间：2017年6月12日 上午10:06:20 类说明
 */
public class FundoutStatus implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private String orderNo;// 营销出款交易的订单编号
    private String status;// 出款状态 S-出款成功 F-出款失败
    private Long amount;// 出款金额，单位：分

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Long getAmount() {
        return amount;
    }

    public void setAmount(Long amount) {
        this.amount = amount;
    }
}
