package com.bill99.ebd.rip.fund.vo;

import com.bill99.ebd.rip.ApiBaseResponse;

/**
 * @author yong.zheng
 * @version 创建时间：2017年6月9日 上午11:00:55 类说明
 */
public class FundoutResponse extends ApiBaseResponse {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

}
