package com.bill99.ebd.rip.fund.vo;

import java.io.Serializable;
import java.util.Date;

import com.bill99.ebd.rip.ApiBaseRequest;

/**
 * @author yong.zheng
 * @version 创建时间：2017年6月9日 上午11:01:04 类说明
 */
public class FundoutRequest extends ApiBaseRequest implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private String payeeMembercode;// 收款商户会员编号

    private String payeeMemberAcctcode;// 收款商户账户

    private Long amount;// 出款金额，单位：分

    private String interestsOid;// 权益oid

    private Date txnTime; // 交易时间

    public String getPayeeMembercode() {
        return payeeMembercode;
    }

    public void setPayeeMembercode(String payeeMembercode) {
        this.payeeMembercode = payeeMembercode;
    }

    public String getPayeeMemberAcctcode() {
        return payeeMemberAcctcode;
    }

    public void setPayeeMemberAcctcode(String payeeMemberAcctcode) {
        this.payeeMemberAcctcode = payeeMemberAcctcode;
    }

    public Long getAmount() {
        return amount;
    }

    public void setAmount(Long amount) {
        this.amount = amount;
    }

    public String getInterestsOid() {
        return interestsOid;
    }

    public void setInterestsOid(String interestsOid) {
        this.interestsOid = interestsOid;
    }

    public Date getTxnTime() {
        return txnTime;
    }

    public void setTxnTime(Date txnTime) {
        this.txnTime = txnTime;
    }
}
