package com.bill99.ebd.rip.fund.service;

import com.bill99.ebd.rip.RipException;
import com.bill99.ebd.rip.fund.vo.FundoutRequest;
import com.bill99.ebd.rip.fund.vo.FundoutResponse;
import com.bill99.ebd.rip.fund.vo.QueryStatusRequest;
import com.bill99.ebd.rip.fund.vo.QueryStatusResponse;
import com.bill99.ebd.rip.fund.vo.ReverseFundoutRequest;
import com.bill99.ebd.rip.fund.vo.ReverseFundoutResponse;

/**
 * @author yong.zheng
 * @version 创建时间：2017年6月9日 上午10:57:40 类说明
 */
public interface FundService {

    /**
     * 营销出款
     * 
     * @param request
     * @return
     * @throws RipException
     */
    FundoutResponse fundout(FundoutRequest request) throws RipException;

    /**
     * 冲正营销出款
     * 
     * @param request
     * @return
     * @throws RipException
     */
    ReverseFundoutResponse reverseFundout(ReverseFundoutRequest request) throws RipException;

    /**
     * 营销出款状态查询
     * 
     * @param request
     * @return
     * @throws RipException
     */
    QueryStatusResponse queryStatus(QueryStatusRequest request) throws RipException;
}
