package com.bill99.ebd.rip.fund.vo;

import java.io.Serializable;

import com.bill99.ebd.rip.ApiBaseRequest;

/**
 * @author yong.zheng
 * @version 创建时间：2017年6月9日 上午11:03:40 类说明
 */
public class QueryStatusRequest extends ApiBaseRequest implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

}
