/**
 * 
 */
package com.bill99.ebd.rip;

import java.io.Serializable;

/**
 * @author yong.zheng
 * @version 创建时间：2017年6月9日 上午10:57:40 类说明
 */
public class ApiBaseResponse implements Serializable {

    private static final long serialVersionUID = 1L;

    private String requestId;

    private String responseCode = "00";

    private String responseMessage;

    /**
     * @return the requestId
     */
    public String getRequestId() {
        return this.requestId;
    }

    /**
     * @return the responseCode
     */
    public String getResponseCode() {
        return this.responseCode;
    }

    /**
     * @return the responseMessage
     */
    public String getResponseMessage() {
        return this.responseMessage;
    }

    /**
     * @param requestId
     *            the requestId to set
     */
    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    /**
     * @param responseCode
     *            the responseCode to set
     */
    public void setResponseCode(String responseCode) {
        this.responseCode = responseCode;
    }

    /**
     * @param responseMessage
     *            the responseMessage to set
     */
    public void setResponseMessage(String responseMessage) {
        this.responseMessage = responseMessage;
    }

}
