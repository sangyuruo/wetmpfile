package com.bill99.ebd.rip.fund.vo;

import java.io.Serializable;
import java.util.Date;

import com.bill99.ebd.rip.ApiBaseRequest;

/**
 * @author yong.zheng
 * @version 创建时间：2017年6月9日 上午11:02:27 类说明
 */
public class ReverseFundoutRequest extends ApiBaseRequest implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private String origOrderNo;// 营销出款时请求的orderNo

    private Date txnTime; // 交易时间

    public String getOrigOrderNo() {
        return origOrderNo;
    }

    public void setOrigOrderNo(String origOrderNo) {
        this.origOrderNo = origOrderNo;
    }

    public Date getTxnTime() {
        return txnTime;
    }

    public void setTxnTime(Date txnTime) {
        this.txnTime = txnTime;
    }
}
