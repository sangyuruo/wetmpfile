/**
 * 
 */
package com.bill99.ebd.rip.interest;

import java.io.Serializable;
import java.util.List;
import java.util.UUID;

import com.bill99.ebd.rip.ApiBaseRequest;

/**
 * 
 * @author jinlei.zhuang
 * @date May 17, 2017 2:48:56 PM
 * @since rip-interest-inf0516
 */
public class GetUsableInterestRequest extends ApiBaseRequest implements Serializable {

    private static final long serialVersionUID = 1L;

    private String operationType;

    private List<String> skuCodes;

    private Integer orderAmount;

    private String payMode;

    private String transactionPhase;

    private UUID interestOid;
    
    // true:如果不传支付方式，则不校验支付方式;false:强制校验权益的支付方式是否满足
    private Boolean notCheckPayModeIfNotHas;

    public UUID getInterestOid() {
        return this.interestOid;
    }

    public String getOperationType() {
        return this.operationType;
    }

    public Integer getOrderAmount() {
        return this.orderAmount;
    }

    public String getPayMode() {
        return this.payMode;
    }

    public List<String> getSkuCodes() {
        return this.skuCodes;
    }

    public String getTransactionPhase() {
        return this.transactionPhase;
    }

    public void setInterestOid(UUID interestOid) {
        this.interestOid = interestOid;
    }

    public void setOperationType(String operationType) {
        this.operationType = operationType;
    }

    public void setOrderAmount(Integer orderAmount) {
        this.orderAmount = orderAmount;
    }

    public void setPayMode(String payMode) {
        this.payMode = payMode;
    }

    public void setSkuCodes(List<String> skuCodes) {
        this.skuCodes = skuCodes;
    }

    public void setTransactionPhase(String transactionPhase) {
        this.transactionPhase = transactionPhase;
    }

    public Boolean getNotCheckPayModeIfNotHas() {
        return notCheckPayModeIfNotHas;
    }

    public void setNotCheckPayModeIfNotHas(Boolean notCheckPayModeIfNotHas) {
        this.notCheckPayModeIfNotHas = notCheckPayModeIfNotHas;
    }

}
