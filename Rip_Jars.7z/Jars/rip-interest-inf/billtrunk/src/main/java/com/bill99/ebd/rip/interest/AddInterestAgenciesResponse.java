/**
 * 
 */
package com.bill99.ebd.rip.interest;

import java.io.Serializable;

import com.bill99.ebd.rip.ApiBaseResponse;

/**
 * 
 * 
 * @author jinlei.zhuang
 * @date May 2, 2017 1:57:47 PM
 * @project rip-interest-inf0426
 *
 */
public class AddInterestAgenciesResponse extends ApiBaseResponse implements Serializable {

    private static final long serialVersionUID = 1L;

}
