/**
 * 
 */
package com.bill99.ebd.rip.interest;

import java.io.Serializable;
import java.util.List;
import java.util.UUID;

import com.bill99.ebd.rip.ApiBaseRequest;

/**
 * @author shuangye.liu
 * @since Apr 13, 2017
 */
public class UpdateInterestSkusRequest extends ApiBaseRequest implements Serializable {

    private static final long serialVersionUID = 1L;

    private UUID interestOid;

    private List<String> skus;

    // 领用 或者 核销
    private String operationType;

    public UUID getInterestOid() {
        return this.interestOid;
    }

    public String getOperationType() {
        return this.operationType;
    }

    public List<String> getSkus() {
        return this.skus;
    }

    public void setInterestOid(UUID interestOid) {
        this.interestOid = interestOid;
    }

    public void setOperationType(String operationType) {
        this.operationType = operationType;
    }

    public void setSkus(List<String> skus) {
        this.skus = skus;
    }

}
