/**
 * 
 */
package com.bill99.ebd.rip.interest;

import java.io.Serializable;
import java.util.UUID;

import com.bill99.ebd.rip.ApiBaseRequest;

/**
 * @author shuangye.liu
 * @since Apr 13, 2017
 */
public class QueryInterestAgenciesRequest extends ApiBaseRequest implements Serializable {

    private static final long serialVersionUID = 1L;

    private UUID interestOid;

    private Integer pageNo;

    private Integer pageSize;

    // 领用 或者 核销
    private String operationType;

    private String memberCode;

    public UUID getInterestOid() {
        return this.interestOid;
    }

    public String getMemberCode() {
        return this.memberCode;
    }

    public String getOperationType() {
        return this.operationType;
    }

    public Integer getPageNo() {
        return this.pageNo;
    }

    public Integer getPageSize() {
        return this.pageSize;
    }

    public void setInterestOid(UUID interestOid) {
        this.interestOid = interestOid;
    }

    public void setMemberCode(String memberCode) {
        this.memberCode = memberCode;
    }

    public void setOperationType(String operationType) {
        this.operationType = operationType;
    }

    public void setPageNo(Integer pageNo) {
        this.pageNo = pageNo;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

}
