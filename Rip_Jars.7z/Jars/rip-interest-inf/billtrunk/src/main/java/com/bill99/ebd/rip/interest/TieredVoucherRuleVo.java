/**
 * 
 */
package com.bill99.ebd.rip.interest;

import java.io.Serializable;
import java.util.List;

/**
 * @author shuangye.liu
 * @since Apr 13, 2017
 */
public class TieredVoucherRuleVo implements Serializable {

    private static final long serialVersionUID = 1L;

    private List<TieredRuleItemVo> ruleItems;

    public List<TieredRuleItemVo> getRuleItems() {
        return this.ruleItems;
    }

    public void setRuleItems(List<TieredRuleItemVo> ruleItems) {
        this.ruleItems = ruleItems;
    }

}
