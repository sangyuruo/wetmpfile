/**
 * 
 */
package com.bill99.ebd.rip.interest;

import java.io.Serializable;

/**
 * 
 * @author shuangye.liu
 * @since Apr 13, 2017
 */
public class InterestProcessAgencyVo implements Serializable {

    private static final long serialVersionUID = 1L;

    // 受理方code
    private String memberCode;

    private String operationType;

    public String getMemberCode() {
        return this.memberCode;
    }

    public String getOperationType() {
        return this.operationType;
    }

    public void setMemberCode(String memberCode) {
        this.memberCode = memberCode;
    }

    public void setOperationType(String operationType) {
        this.operationType = operationType;
    }

}
