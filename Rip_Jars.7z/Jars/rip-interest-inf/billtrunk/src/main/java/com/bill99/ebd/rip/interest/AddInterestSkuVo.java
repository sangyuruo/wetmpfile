/**
 * 
 */
package com.bill99.ebd.rip.interest;

import java.io.Serializable;

/**
 * 
 * 
 * @author jinlei.zhuang
 * @date May 9, 2017 7:15:05 PM
 * @project rip-interest-inf0426
 *
 */
public class AddInterestSkuVo implements Serializable {

    private static final long serialVersionUID = 1L;

    private String skuCode;

    private String memberCode;

    private String skuName;

    public String getMemberCode() {
        return this.memberCode;
    }

    public String getSkuCode() {
        return this.skuCode;
    }

    public String getSkuName() {
        return this.skuName;
    }

    public void setMemberCode(String memberCode) {
        this.memberCode = memberCode;
    }

    public void setSkuCode(String skuCode) {
        this.skuCode = skuCode;
    }

    public void setSkuName(String skuName) {
        this.skuName = skuName;
    }

}
