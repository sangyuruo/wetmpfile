/**
 * 
 */
package com.bill99.ebd.rip.interest;

import java.io.Serializable;
import java.util.List;
import java.util.UUID;

import com.bill99.ebd.rip.ApiBaseRequest;

/**
 * 
 * 
 * @author jinlei.zhuang
 * @date May 2, 2017 1:57:30 PM
 * @project rip-interest-inf0426
 *
 */
public class DeleteInterestAgenciesRequest extends ApiBaseRequest implements Serializable {

    private static final long serialVersionUID = 1L;

    private UUID interestOid;

    private List<String> memberCodes;

    // 领用 或者 核销
    private String operationType;

    public UUID getInterestOid() {
        return this.interestOid;
    }

    public List<String> getMemberCodes() {
        return this.memberCodes;
    }

    public String getOperationType() {
        return this.operationType;
    }

    public void setInterestOid(UUID interestOid) {
        this.interestOid = interestOid;
    }

    public void setMemberCodes(List<String> memberCodes) {
        this.memberCodes = memberCodes;
    }

    public void setOperationType(String operationType) {
        this.operationType = operationType;
    }

}
