/**
 * 
 */
package com.bill99.ebd.rip.interest;

import java.io.Serializable;
import java.util.UUID;

import com.bill99.ebd.rip.ApiBaseRequest;

/**
 * 通过资金池OID查询权益概要列表请求对象
 * 
 * @author haipeng.cheng
 * @since 2017年8月2日 下午4:35:39
 * @project rip-interest-inf_0731
 */
public class QueryCreditlineInterestsRequest extends ApiBaseRequest implements Serializable {

    private static final long serialVersionUID = 1L;

    private UUID creditlineOid;

    private Integer pageNo;

    private Integer pageSize;

    public UUID getCreditlineOid() {
        return creditlineOid;
    }

    public void setCreditlineOid(UUID creditlineOid) {
        this.creditlineOid = creditlineOid;
    }

    public Integer getPageNo() {
        return pageNo;
    }

    public void setPageNo(Integer pageNo) {
        this.pageNo = pageNo;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }
}
