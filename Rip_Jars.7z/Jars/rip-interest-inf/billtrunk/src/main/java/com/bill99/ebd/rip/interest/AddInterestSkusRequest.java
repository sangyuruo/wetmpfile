/**
 * 
 */
package com.bill99.ebd.rip.interest;

import java.io.Serializable;
import java.util.List;
import java.util.UUID;

import com.bill99.ebd.rip.ApiBaseRequest;

/**
 * 
 * 
 * @author jinlei.zhuang
 * @date May 2, 2017 1:41:09 PM
 * @project rip-interest-inf0426
 *
 */
public class AddInterestSkusRequest extends ApiBaseRequest implements Serializable {

    private static final long serialVersionUID = 1L;

    private UUID interestOid;

    private List<AddInterestSkuVo> skus;

    // 领用 或者 核销
    private String operationType;

    public UUID getInterestOid() {
        return this.interestOid;
    }

    public String getOperationType() {
        return this.operationType;
    }


    public void setInterestOid(UUID interestOid) {
        this.interestOid = interestOid;
    }

    public void setOperationType(String operationType) {
        this.operationType = operationType;
    }

    public List<AddInterestSkuVo> getSkus() {
        return skus;
    }

    public void setSkus(List<AddInterestSkuVo> skus) {
        this.skus = skus;
    }


}
