/**
 * 
 */
package com.bill99.ebd.rip.interest;

import com.bill99.ebd.rip.RipException;

/**
 * @author shuangye.liu
 * @since Apr 13, 2017
 */
public interface RipInterestService {

    /**
     * 添加权益受理方
     * 
     * @param request
     * @return
     * @throws RipException
     * @author jinlei.zhuang
     * @date May 2, 2017 2:00:49 PM
     * 
     */
    AddInterestAgenciesResponse addInterestAgencies(AddInterestAgenciesRequest request) throws RipException;

    /**
     * 添加权益sku列表
     * 
     * @param request
     * @return
     * @throws RipException
     * @author jinlei.zhuang
     * @date May 2, 2017 2:01:00 PM
     * 
     */
    AddInterestSkusResponse addInterestSkus(AddInterestSkusRequest request) throws RipException;

    /**
     * 创建权益
     * 
     * @param request
     * @return
     * @throws RipException
     */
    CreateInterestResponse createInterest(CreateInterestRequest request) throws RipException;

    /**
     * 删除权益受理方
     * 
     * @param request
     * @return
     * @throws RipException
     * @author jinlei.zhuang
     * @date May 2, 2017 2:01:10 PM
     * 
     */
    DeleteInterestAgenciesResponse deleteInterestAgencies(DeleteInterestAgenciesRequest request) throws RipException;

    /**
     * 删除权益sku列表
     * 
     * @param request
     * @return
     * @throws RipException
     * @author jinlei.zhuang
     * @date May 2, 2017 2:01:13 PM
     * 
     */
    DeleteInterestSkusResponse deleteInterestSkus(DeleteInterestSkusRequest request) throws RipException;

    /**
     * 关闭领用
     * 
     * @param request
     * @return
     * @throws RipException
     */
    DisableHoldResponse disableHold(DisableHoldRequest request) throws RipException;

    /**
     * 延长权益领用、核销时间
     * 
     * @param request
     * @return
     * @throws RipException
     */
    ExtendInterestTimeResponse extendInterestTime(ExtendInterestTimeRequest request) throws RipException;

    /**
     * 根据oid查询权益详细信息
     * 
     * @param request
     * @return
     * @throws RipException
     */
    QueryInterestByOidResponse getInterestByOid(QueryInterestByOidRequest request) throws RipException;

    /**
     * 返回可以领用或核销的单个权益，为空抛出异常
     * 
     * @param request
     * @return
     * @throws RipException
     * @author jinlei.zhuang
     * @date May 18, 2017 8:21:37 PM
     *
     */
    GetUsableInterestResponse getUsableInterest(GetUsableInterestRequest request) throws RipException;

    /**
     * 查询商户可以受理权益
     * 
     * @param request
     * @return
     * @throws RipException
     */
    QueryAgencyInterestsResponse queryAgencyInterests(QueryAgencyInterestsRequest request) throws RipException;

    /**
     * 根据条件查询权益列表
     * 
     * @param request
     * @return
     * @throws RipException
     */
    QueryInterestResponse queryInterest(QueryInterestRequest request) throws RipException;

    /**
     * 查询权益受理方
     * 
     * @param request
     * @return
     * @throws RipException
     */
    QueryInterestAgenciesResponse queryInterestAgencies(QueryInterestAgenciesRequest request) throws RipException;

    /**
     * 查询权益领用或者核销SKU列表
     * 
     * @param request
     * @return
     * @throws RipException
     */
    QueryInterestSkusResponse queryInterestSkus(QueryInterestSkusRequest request) throws RipException;

    /**
     * 返回可以领用或核销的权益列表
     * 
     * @param request
     * @return
     * @throws RipException
     * @author jinlei.zhuang
     * @date May 17, 2017 2:25:16 PM
     *
     */
    QueryUsableInterestsResponse queryUsableInterests(QueryUsableInterestsRequest request) throws RipException;

    /**
     * 返回商户可核销权益列表(包括可用以及不可用)
     * 
     * @param request
     * @return
     * @throws RipException
     */
    QueryUsableInterestsResponse queryWriteoffableInterestList(QueryUsableInterestsRequest request) throws RipException;

    /**
     * 更新权益状态
     * 
     * @param request
     * @return
     * @throws RipException
     */
    UpdateInterestStatusResponse updateInterestStatus(UpdateInterestStatusRequest request) throws RipException;

    /**
     * 查询资金池关联的权益概要列表
     * 
     * @param request
     * @return
     * @throws RipException
     */
    QueryCreditlineInterestsResponse queryCreditlineInterests(QueryCreditlineInterestsRequest request)
            throws RipException;

}
