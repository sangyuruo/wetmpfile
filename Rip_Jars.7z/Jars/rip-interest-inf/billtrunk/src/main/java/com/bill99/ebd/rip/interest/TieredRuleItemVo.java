/**
 * 
 */
package com.bill99.ebd.rip.interest;

import java.io.Serializable;

/**
 * @author shuangye.liu
 * @since Apr 13, 2017
 */
public class TieredRuleItemVo implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 只支持满减或代金券
     */
    private String voucherType;

    // 最小使用订单金额
    private Integer minOrderAmount;

    /**
     * 优惠金额
     */
    private Integer deductAmount;

    /**
     * 订单金额对应本阶梯的阀值。 <br/>
     * 比如有2个阶梯: 0-10，10-正无穷，则阀值分别为 0， 10
     */
    private Integer thresholdAmount;

    /**
     * 是否只适用于第一次领取本权益
     */
    private Boolean isFirst;

    public Integer getDeductAmount() {
        return this.deductAmount;
    }

    public Boolean getIsFirst() {
        return this.isFirst;
    }

    public Integer getMinOrderAmount() {
        return this.minOrderAmount;
    }

    public Integer getThresholdAmount() {
        return this.thresholdAmount;
    }

    public String getVoucherType() {
        return this.voucherType;
    }

    public void setDeductAmount(Integer deductAmount) {
        this.deductAmount = deductAmount;
    }

    public void setIsFirst(Boolean isFirst) {
        this.isFirst = isFirst;
    }

    public void setMinOrderAmount(Integer minOrderAmount) {
        this.minOrderAmount = minOrderAmount;
    }

    public void setThresholdAmount(Integer thresholdAmount) {
        this.thresholdAmount = thresholdAmount;
    }

    public void setVoucherType(String voucherType) {
        this.voucherType = voucherType;
    }

}
