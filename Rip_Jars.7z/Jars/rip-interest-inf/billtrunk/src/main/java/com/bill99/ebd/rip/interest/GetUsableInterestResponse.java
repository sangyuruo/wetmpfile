/**
 * 
 */
package com.bill99.ebd.rip.interest;

import java.io.Serializable;
import java.util.Set;
import java.util.UUID;

import com.bill99.ebd.rip.ApiBaseResponse;

/**
 * 
 * @author jinlei.zhuang
 * @date May 17, 2017 2:48:50 PM
 * @since rip-interest-inf0516
 */
public class GetUsableInterestResponse extends ApiBaseResponse implements Serializable {

    private static final long serialVersionUID = 1L;

    private InterestVo interestVo;

    public InterestVo getInterestVo() {
        return this.interestVo;
    }

    public void setInterestVo(InterestVo interestVo) {
        this.interestVo = interestVo;
    }

}
