/**
 * 
 */
package com.bill99.ebd.rip.interest;

import java.io.Serializable;
import java.util.List;

import com.bill99.ebd.rip.ApiBaseResponse;

/**
 * 通过资金池OID查询权益概要列表返回结果对象
 * 
 * @author haipeng.cheng
 * @since 2017年8月2日 下午4:36:29
 * @project rip-interest-inf_0731
 */
public class QueryCreditlineInterestsResponse extends ApiBaseResponse implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer total;

    private Integer pageNo;

    private Integer pageSize;

    private List<InterestSummaryVo> interestSummaryVos;

    public List<InterestSummaryVo> getInterestSummaryVos() {
        return interestSummaryVos;
    }

    public void setInterestSummaryVos(List<InterestSummaryVo> interestSummaryVos) {
        this.interestSummaryVos = interestSummaryVos;
    }

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    public Integer getPageNo() {
        return pageNo;
    }

    public void setPageNo(Integer pageNo) {
        this.pageNo = pageNo;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

}
