package com.bill99.ebd.rip.interest;

import java.io.Serializable;

/**
 * 扩展属性Vo
 * 
 * @author haipeng.cheng
 * @since 2017年8月16日 下午1:59:19
 * @project rip-interest-inf_0816
 */
public class PropertyVo implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private String name;

    private String value;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
