/**
 * 
 */
package com.bill99.ebd.rip.interest;

import java.io.Serializable;

import com.bill99.ebd.rip.ApiBaseResponse;

/**
 * @author shuangye.liu
 * @since Apr 15, 2017
 */
public class QueryInterestByOidResponse extends ApiBaseResponse implements Serializable {

    private static final long serialVersionUID = 1L;

    private InterestVo interestVo;

    public InterestVo getInterestVo() {
        return interestVo;
    }

    public void setInterestVo(InterestVo interestVo) {
        this.interestVo = interestVo;
    }

}
