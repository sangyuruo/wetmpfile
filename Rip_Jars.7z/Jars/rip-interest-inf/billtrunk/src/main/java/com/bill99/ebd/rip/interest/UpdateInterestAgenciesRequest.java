package com.bill99.ebd.rip.interest;

import java.io.Serializable;
import java.util.List;
import java.util.UUID;

import com.bill99.ebd.rip.ApiBaseRequest;

/**
 * 
 * @author shuangye.liu
 * @since Apr 13, 2017
 */
public class UpdateInterestAgenciesRequest extends ApiBaseRequest implements Serializable {

    private static final long serialVersionUID = 1L;

    private UUID interestOid;

    private List<InterestProcessAgencyVo> processAgencies;

    public UUID getInterestOid() {
        return this.interestOid;
    }

    public List<InterestProcessAgencyVo> getProcessAgencies() {
        return this.processAgencies;
    }

    public void setInterestOid(UUID interestOid) {
        this.interestOid = interestOid;
    }

    public void setProcessAgencies(List<InterestProcessAgencyVo> processAgencies) {
        this.processAgencies = processAgencies;
    }

}
