/**
 * 
 */
package com.bill99.ebd.rip.interest;

import java.io.Serializable;
import java.util.List;

import com.bill99.ebd.rip.ApiBaseResponse;

/**
 * @author shuangye.liu
 * @since May 4, 2017
 */
public class QueryAgencyInterestsResponse extends ApiBaseResponse implements Serializable {

    private static final long serialVersionUID = 1L;

    private List<AgencyInterestVo> agencyInterests;

    public List<AgencyInterestVo> getAgencyInterests() {
        return this.agencyInterests;
    }

    public void setAgencyInterests(List<AgencyInterestVo> agencyInterests) {
        this.agencyInterests = agencyInterests;
    }

}
