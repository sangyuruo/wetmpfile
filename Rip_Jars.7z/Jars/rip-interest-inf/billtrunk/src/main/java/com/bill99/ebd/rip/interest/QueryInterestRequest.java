/**
 * 
 */
package com.bill99.ebd.rip.interest;

import java.io.Serializable;
import java.util.UUID;

import com.bill99.ebd.rip.ApiBaseRequest;

/**
 * @author shuangye.liu
 * @since Apr 15, 2017
 */
public class QueryInterestRequest extends ApiBaseRequest implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer pageNo;

    private Integer pageSize;

    private UUID interestOid;

    private String interestName;

    // 发布方 member code
    private String issuerMemberCode;

    // 发布方名称
    private String issuerName;

    // 创建渠道：intra、会员营销中心
    private String createChannel;

    private String interestStatus;

    public String getCreateChannel() {
        return this.createChannel;
    }

    public String getInterestName() {
        return this.interestName;
    }

    public UUID getInterestOid() {
        return this.interestOid;
    }

    public String getInterestStatus() {
        return this.interestStatus;
    }

    public String getIssuerMemberCode() {
        return this.issuerMemberCode;
    }

    public String getIssuerName() {
        return this.issuerName;
    }

    public Integer getPageNo() {
        return this.pageNo;
    }

    public Integer getPageSize() {
        return this.pageSize;
    }

    public void setCreateChannel(String createChannel) {
        this.createChannel = createChannel;
    }

    public void setInterestName(String interestName) {
        this.interestName = interestName;
    }

    public void setInterestOid(UUID interestOid) {
        this.interestOid = interestOid;
    }

    public void setInterestStatus(String interestStatus) {
        this.interestStatus = interestStatus;
    }

    public void setIssuerMemberCode(String issuerMemberCode) {
        this.issuerMemberCode = issuerMemberCode;
    }

    public void setIssuerName(String issuerName) {
        this.issuerName = issuerName;
    }

    public void setPageNo(Integer pageNo) {
        this.pageNo = pageNo;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

}
