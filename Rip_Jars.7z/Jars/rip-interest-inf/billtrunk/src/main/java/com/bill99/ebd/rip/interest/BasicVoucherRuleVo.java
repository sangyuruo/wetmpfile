/**
 * 
 */
package com.bill99.ebd.rip.interest;

import java.io.Serializable;

/**
 * @author shuangye.liu
 * @since Apr 13, 2017
 */
public class BasicVoucherRuleVo implements Serializable {

    private static final long serialVersionUID = 1L;

    // 优惠券类型
    private String voucherType;

    // 减少金额
    private Integer deductAmount;

    // 核销最小订单金额
    private Integer minOrderAmount;

    // 折扣券核销最大优惠金额
    private Integer maxAmount;

    // 折扣比率：单位万分之一
    private Integer discountRatio;

    // BASIC-基本凭证券、FPD_INTEREST-理财加息券
    private String subType;

    public Integer getDeductAmount() {
        return this.deductAmount;
    }

    public Integer getDiscountRatio() {
        return this.discountRatio;
    }

    public Integer getMaxAmount() {
        return this.maxAmount;
    }

    public Integer getMinOrderAmount() {
        return this.minOrderAmount;
    }

    public String getVoucherType() {
        return this.voucherType;
    }

    public void setDeductAmount(Integer deductAmount) {
        this.deductAmount = deductAmount;
    }

    public void setDiscountRatio(Integer discountRatio) {
        this.discountRatio = discountRatio;
    }

    public void setMaxAmount(Integer maxAmount) {
        this.maxAmount = maxAmount;
    }

    public void setMinOrderAmount(Integer minOrderAmount) {
        this.minOrderAmount = minOrderAmount;
    }

    public void setVoucherType(String voucherType) {
        this.voucherType = voucherType;
    }

    public String getSubType() {
        return subType;
    }

    public void setSubType(String subType) {
        this.subType = subType;
    }
}
