/**
 * 
 */
package com.bill99.ebd.rip.interest;

import java.io.Serializable;
import java.util.UUID;

import com.bill99.ebd.rip.ApiBaseRequest;

/**
 * @author shuangye.liu
 * @since Apr 13, 2017
 */
public class QueryInterestSkusRequest extends ApiBaseRequest implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer pageNo;

    private Integer pageSize;

    private UUID interestOid;

    // 领用 或者 核销
    private String operationType;

    private String skuCode;

    public UUID getInterestOid() {
        return this.interestOid;
    }

    public String getOperationType() {
        return this.operationType;
    }

    public Integer getPageNo() {
        return this.pageNo;
    }

    public Integer getPageSize() {
        return this.pageSize;
    }

    public String getSkuCode() {
        return this.skuCode;
    }

    public void setInterestOid(UUID interestOid) {
        this.interestOid = interestOid;
    }

    public void setOperationType(String operationType) {
        this.operationType = operationType;
    }

    public void setPageNo(Integer pageNo) {
        this.pageNo = pageNo;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public void setSkuCode(String skuCode) {
        this.skuCode = skuCode;
    }

}
