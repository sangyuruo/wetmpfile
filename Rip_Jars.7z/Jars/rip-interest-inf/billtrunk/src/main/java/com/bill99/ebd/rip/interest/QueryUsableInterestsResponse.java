/**
 * 
 */
package com.bill99.ebd.rip.interest;

import java.io.Serializable;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import com.bill99.ebd.rip.ApiBaseResponse;

/**
 * 
 * @author jinlei.zhuang
 * @date May 17, 2017 2:48:50 PM
 * @since rip-interest-inf0516
 */
public class QueryUsableInterestsResponse extends ApiBaseResponse implements Serializable {

    private static final long serialVersionUID = 1L;

    private List<InterestVo> interestVos;
    
    // 完全不可用的权益oid列表
    private Set<UUID> interestOidSetOfNotUseable;

    public List<InterestVo> getInterestVos() {
        return this.interestVos;
    }

    public void setInterestVos(List<InterestVo> interestVos) {
        this.interestVos = interestVos;
    }

    public Set<UUID> getInterestOidSetOfNotUseable() {
        return interestOidSetOfNotUseable;
    }

    public void setInterestOidSetOfNotUseable(Set<UUID> interestOidSetOfNotUseable) {
        this.interestOidSetOfNotUseable = interestOidSetOfNotUseable;
    }

}
