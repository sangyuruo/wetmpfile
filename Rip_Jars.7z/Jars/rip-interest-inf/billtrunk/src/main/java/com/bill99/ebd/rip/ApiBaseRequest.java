/**
 * 
 */
package com.bill99.ebd.rip;

import java.io.Serializable;

/**
 * @author shuangye.liu
 * @since Apr 6, 2016
 */
public class ApiBaseRequest implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 调用者ID，保留作为权限检查根据
     */
    private String callerId;

    /**
     * 请求来源渠道，和 orderNo 一起可以唯一标识一个外部交易
     */
    private String channel;

    /**
     * 外部交易ID，和 channel 一起可以唯一标识一个外部交易
     */
    private String orderNo;

    /**
     * C端用户 member code
     */
    private String consumerMemberCode;

    /**
     * B端用户 member code
     */
    private String merchantMemberCode;

    /**
     * @return the callerId
     */
    public String getCallerId() {
        return this.callerId;
    }

    /**
     * @return the channel
     */
    public String getChannel() {
        return this.channel;
    }

    /**
     * @return the consumerMemberCode
     */
    public String getConsumerMemberCode() {
        return this.consumerMemberCode;
    }

    /**
     * @return the merchantMemberCode
     */
    public String getMerchantMemberCode() {
        return this.merchantMemberCode;
    }

    /**
     * @return the orderNo
     */
    public String getOrderNo() {
        return this.orderNo;
    }

    /**
     * @param callerId
     *            the callerId to set
     */
    public void setCallerId(String callerId) {
        this.callerId = callerId;
    }

    /**
     * @param channel
     *            the channel to set
     */
    public void setChannel(String channel) {
        this.channel = channel;
    }

    /**
     * @param consumerMemberCode
     *            the consumerMemberCode to set
     */
    public void setConsumerMemberCode(String consumerMemberCode) {
        this.consumerMemberCode = consumerMemberCode;
    }

    /**
     * @param merchantMemberCode
     *            the merchantMemberCode to set
     */
    public void setMerchantMemberCode(String merchantMemberCode) {
        this.merchantMemberCode = merchantMemberCode;
    }

    /**
     * @param orderNo
     *            the orderNo to set
     */
    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

}
