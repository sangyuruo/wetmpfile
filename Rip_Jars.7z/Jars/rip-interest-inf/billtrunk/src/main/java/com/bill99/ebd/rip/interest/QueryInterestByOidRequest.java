/**
 * 
 */
package com.bill99.ebd.rip.interest;

import java.io.Serializable;
import java.util.UUID;

import com.bill99.ebd.rip.ApiBaseRequest;

/**
 * @author shuangye.liu
 * @since Apr 15, 2017
 */
public class QueryInterestByOidRequest extends ApiBaseRequest implements Serializable {

    private static final long serialVersionUID = 1L;

    private UUID interestOid;

    public UUID getInterestOid() {
        return interestOid;
    }

    public void setInterestOid(UUID interestOid) {
        this.interestOid = interestOid;
    }

}
