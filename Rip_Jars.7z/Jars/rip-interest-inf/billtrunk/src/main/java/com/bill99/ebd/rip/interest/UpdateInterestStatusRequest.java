package com.bill99.ebd.rip.interest;

import java.io.Serializable;
import java.util.UUID;

import com.bill99.ebd.rip.ApiBaseRequest;

public class UpdateInterestStatusRequest extends ApiBaseRequest implements Serializable {

    private static final long serialVersionUID = 1L;

    private UUID interestOid;

    private String status;

    public UUID getInterestOid() {
        return this.interestOid;
    }

    public String getStatus() {
        return this.status;
    }

    public void setInterestOid(UUID interestOid) {
        this.interestOid = interestOid;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}
