/**
 * 
 */
package com.bill99.ebd.rip.interest;

import java.io.Serializable;
import java.util.List;

/**
 * @author shuangye.liu
 * @since Apr 13, 2017
 */
public class VoucherGenerationRuleVo implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer effectiveInterval;

    private Integer effectiveDay;

    private String generationType;

    // 是否有扩展属性
    private Boolean extendedFlag;

    // 扩展属性
    private List<PropertyVo> extendedPros;

    // 基础优惠券型生成规则
    private BasicVoucherRuleVo basicRule;

    // 随机优惠券生成规则
    private RandomVoucherRuleVo randomRule;

    // 百分比随机优惠券生成规则
    private PercentVoucherRuleVo percentRule;

    // 阶梯优惠券生成规则
    private TieredVoucherRuleVo tieredRule;

    public BasicVoucherRuleVo getBasicRule() {
        return this.basicRule;
    }

    public Integer getEffectiveDay() {
        return this.effectiveDay;
    }

    public Integer getEffectiveInterval() {
        return this.effectiveInterval;
    }

    public String getGenerationType() {
        return this.generationType;
    }

    public PercentVoucherRuleVo getPercentRule() {
        return this.percentRule;
    }

    public RandomVoucherRuleVo getRandomRule() {
        return this.randomRule;
    }

    public TieredVoucherRuleVo getTieredRule() {
        return this.tieredRule;
    }

    public void setBasicRule(BasicVoucherRuleVo basicRule) {
        this.basicRule = basicRule;
    }

    public void setEffectiveDay(Integer effectiveDay) {
        this.effectiveDay = effectiveDay;
    }

    public void setEffectiveInterval(Integer effectiveInterval) {
        this.effectiveInterval = effectiveInterval;
    }

    public void setGenerationType(String generationType) {
        this.generationType = generationType;
    }

    public void setPercentRule(PercentVoucherRuleVo percentRule) {
        this.percentRule = percentRule;
    }

    public void setRandomRule(RandomVoucherRuleVo randomRule) {
        this.randomRule = randomRule;
    }

    public void setTieredRule(TieredVoucherRuleVo tieredRule) {
        this.tieredRule = tieredRule;
    }

    public Boolean getExtendedFlag() {
        return extendedFlag;
    }

    public void setExtendedFlag(Boolean extendedFlag) {
        this.extendedFlag = extendedFlag;
    }

    public List<PropertyVo> getExtendedPros() {
        return extendedPros;
    }

    public void setExtendedPros(List<PropertyVo> extendedPros) {
        this.extendedPros = extendedPros;
    }

}
