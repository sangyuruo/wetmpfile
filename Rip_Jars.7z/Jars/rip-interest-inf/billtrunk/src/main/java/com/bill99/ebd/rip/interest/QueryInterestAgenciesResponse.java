/**
 * 
 */
package com.bill99.ebd.rip.interest;

import java.io.Serializable;
import java.util.List;

import com.bill99.ebd.rip.ApiBaseResponse;

/**
 * @author shuangye.liu
 * @since Apr 13, 2017
 */
public class QueryInterestAgenciesResponse extends ApiBaseResponse implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer total;

    private Integer pageNo;

    private Integer pageSize;

    private List<InterestProcessAgencyVo> processAgencies;

    public Integer getPageNo() {
        return this.pageNo;
    }

    public Integer getPageSize() {
        return this.pageSize;
    }

    public List<InterestProcessAgencyVo> getProcessAgencies() {
        return this.processAgencies;
    }

    public Integer getTotal() {
        return this.total;
    }

    public void setPageNo(Integer pageNo) {
        this.pageNo = pageNo;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public void setProcessAgencies(List<InterestProcessAgencyVo> processAgencies) {
        this.processAgencies = processAgencies;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

}
