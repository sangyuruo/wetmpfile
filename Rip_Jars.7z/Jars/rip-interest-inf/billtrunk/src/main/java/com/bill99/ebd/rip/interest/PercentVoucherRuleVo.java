/**
 * 
 */
package com.bill99.ebd.rip.interest;

import java.io.Serializable;

/**
 * @author shuangye.liu
 * @since Apr 13, 2017
 */
public class PercentVoucherRuleVo implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 只支代金券
     */
    private String voucherType;

    /**
     * 计算基数
     */
    private String calculationBase;

    /**
     * 最大返券金额
     */
    private Integer maxAmount;

    /**
     * 最小返券金额（如果订单金额小于 minAmount，则为订单金额）
     */
    private Integer minAmount;

    /**
     * 打折比例，单位万分之一
     */
    private Integer discountRatio;

    /**
     * 取整方式：1，四舍五入；2，截取小数；
     */
    private String roundingMode;

    public String getCalculationBase() {
        return this.calculationBase;
    }

    public Integer getDiscountRatio() {
        return this.discountRatio;
    }

    public Integer getMaxAmount() {
        return this.maxAmount;
    }

    public Integer getMinAmount() {
        return this.minAmount;
    }

    public String getRoundingMode() {
        return this.roundingMode;
    }

    public String getVoucherType() {
        return this.voucherType;
    }

    public void setCalculationBase(String calculationBase) {
        this.calculationBase = calculationBase;
    }

    public void setDiscountRatio(Integer discountRatio) {
        this.discountRatio = discountRatio;
    }

    public void setMaxAmount(Integer maxAmount) {
        this.maxAmount = maxAmount;
    }

    public void setMinAmount(Integer minAmount) {
        this.minAmount = minAmount;
    }

    public void setRoundingMode(String roundingMode) {
        this.roundingMode = roundingMode;
    }

    public void setVoucherType(String voucherType) {
        this.voucherType = voucherType;
    }

}
