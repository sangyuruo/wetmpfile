/**
 * 
 */
package com.bill99.ebd.rip.interest;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

/**
 * 
 * 
 * @author shuangye.liu
 * @since Apr 13, 2017
 */
public class InterestVo implements Serializable {

    private static final long serialVersionUID = 1L;

    private UUID oid;

    private String name;

    // 活动目标
    private String purpose;

    // 用户须知
    private String instruction;

    // 载体
    private String mediaType;

    // 领取通知模板oid
    private UUID holdTemplateOid;

    // 是否结算
    private Boolean settlementFlag;

    // 发布方 member code
    private String issuerMemberCode;

    // 发布方名称
    private String issuerName;

    // 垫资方 member code
    private String stakeholderMemberCode;

    // 创建渠道
    private String createChannel;

    // 来源渠道：内部、外部
    private String sourceChannel;

    private Date startTime;

    private Date endTime;

    private String status;

    // 交易场景
    private String transactionPhase;

    private VoucherGenerationRuleVo generationRule;

    private OperationLimitVo holdLimit;

    private OperationLimitVo writeoffLimit;

    private Boolean writeoffable = true;

    private String notUsableCode;

    private String notUsableMsg;

    public String getCreateChannel() {
        return this.createChannel;
    }

    public Date getEndTime() {
        return this.endTime;
    }

    public VoucherGenerationRuleVo getGenerationRule() {
        return this.generationRule;
    }

    public OperationLimitVo getHoldLimit() {
        return this.holdLimit;
    }

    public UUID getHoldTemplateOid() {
        return this.holdTemplateOid;
    }
    public String getInstruction() {
        return this.instruction;
    }

    public String getIssuerMemberCode() {
        return this.issuerMemberCode;
    }

    public String getIssuerName() {
        return this.issuerName;
    }

    public String getMediaType() {
        return this.mediaType;
    }

    public String getName() {
        return this.name;
    }

    public String getNotUsableCode() {
        return this.notUsableCode;
    }

    public String getNotUsableMsg() {
        return this.notUsableMsg;
    }

    public UUID getOid() {
        return this.oid;
    }

    public String getPurpose() {
        return this.purpose;
    }

    public Boolean getSettlementFlag() {
        return this.settlementFlag;
    }

    public String getSourceChannel() {
        return this.sourceChannel;
    }

    public String getStakeholderMemberCode() {
        return this.stakeholderMemberCode;
    }

    public Date getStartTime() {
        return this.startTime;
    }

    public String getStatus() {
        return this.status;
    }

    public String getTransactionPhase() {
        return this.transactionPhase;
    }

    public Boolean getWriteoffable() {
        return this.writeoffable;
    }

    public OperationLimitVo getWriteoffLimit() {
        return this.writeoffLimit;
    }

    public void setCreateChannel(String createChannel) {
        this.createChannel = createChannel;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public void setGenerationRule(VoucherGenerationRuleVo generationRule) {
        this.generationRule = generationRule;
    }

    public void setHoldLimit(OperationLimitVo holdLimit) {
        this.holdLimit = holdLimit;
    }

    public void setHoldTemplateOid(UUID holdTemplateOid) {
        this.holdTemplateOid = holdTemplateOid;
    }

    public void setInstruction(String instruction) {
        this.instruction = instruction;
    }

    public void setIssuerMemberCode(String issuerMemberCode) {
        this.issuerMemberCode = issuerMemberCode;
    }

    public void setIssuerName(String issuerName) {
        this.issuerName = issuerName;
    }

    public void setMediaType(String mediaType) {
        this.mediaType = mediaType;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setNotUsableCode(String notUsableCode) {
        this.notUsableCode = notUsableCode;
    }

    public void setNotUsableMsg(String notUsableMsg) {
        this.notUsableMsg = notUsableMsg;
    }

    public void setOid(UUID oid) {
        this.oid = oid;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    public void setSettlementFlag(Boolean settlementFlag) {
        this.settlementFlag = settlementFlag;
    }

    public void setSourceChannel(String sourceChannel) {
        this.sourceChannel = sourceChannel;
    }

    public void setStakeholderMemberCode(String stakeholderMemberCode) {
        this.stakeholderMemberCode = stakeholderMemberCode;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setTransactionPhase(String transactionPhase) {
        this.transactionPhase = transactionPhase;
    }

    public void setWriteoffable(Boolean writeoffable) {
        this.writeoffable = writeoffable;
    }

    public void setWriteoffLimit(OperationLimitVo writeoffLimit) {
        this.writeoffLimit = writeoffLimit;
    }
}
