package com.bill99.ebd.rip.interest;

import java.io.Serializable;

import com.bill99.ebd.rip.ApiBaseRequest;

/**
 * 
 * @author shuangye.liu
 * @since Apr 13, 2017
 */
public class CreateInterestRequest extends ApiBaseRequest implements Serializable {

    private static final long serialVersionUID = 1L;

    private InterestVo interest;

    public InterestVo getInterest() {
        return this.interest;
    }

    public void setInterest(InterestVo interest) {
        this.interest = interest;
    }

}
