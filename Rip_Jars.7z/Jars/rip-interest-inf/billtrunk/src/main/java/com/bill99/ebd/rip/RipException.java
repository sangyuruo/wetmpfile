/**
 * 
 */
package com.bill99.ebd.rip;

/**
 * @author shuangye.liu
 * @since Feb 7, 2017
 */
public class RipException extends Exception {

    private static final long serialVersionUID = 1L;

    private String code;

    public RipException(String code, String messsage) {
        this(code, messsage, null);
    }

    public RipException(String code, String messsage, Throwable e) {
        super(messsage, e);
        this.code = code;
    }

    public String getCode() {
        return this.code;
    }

    public void setCode(String code) {
        this.code = code;
    }

}
