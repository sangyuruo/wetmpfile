/**
 * 
 */
package com.bill99.ebd.rip.interest;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.UUID;

/**
 * 
 * 
 * @author shuangye.liu
 * @since Apr 13, 2017
 */
public class OperationLimitVo implements Serializable {

    private static final long serialVersionUID = 1L;

    // 开始时间
    private Date beginTime;

    // 结束时间
    private Date endTime;

    // 风控限制
    private UUID riskOid;

    // 资金池
    private UUID creditlineOid;

    // 是否启动sku限制
    private Boolean skuLimitFlag;

    // 领用最小订单金额：分
    private Integer thresholdAmount;

    // 操作总开关
    private Boolean operationFlag;

    // 多选周1到周7启用
    private List<Integer> weekLimits;

    // 支付方式
    private List<String> payModes;

    public Date getBeginTime() {
        return this.beginTime;
    }

    public UUID getCreditlineOid() {
        return this.creditlineOid;
    }

    public Date getEndTime() {
        return this.endTime;
    }

    public Boolean getOperationFlag() {
        return this.operationFlag;
    }

    public List<String> getPayModes() {
        return this.payModes;
    }

    public UUID getRiskOid() {
        return this.riskOid;
    }

    public Boolean getSkuLimitFlag() {
        return this.skuLimitFlag;
    }

    public Integer getThresholdAmount() {
        return this.thresholdAmount;
    }

    public List<Integer> getWeekLimits() {
        return this.weekLimits;
    }

    public void setBeginTime(Date beginTime) {
        this.beginTime = beginTime;
    }

    public void setCreditlineOid(UUID creditlineOid) {
        this.creditlineOid = creditlineOid;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public void setOperationFlag(Boolean operationFlag) {
        this.operationFlag = operationFlag;
    }

    public void setPayModes(List<String> payModes) {
        this.payModes = payModes;
    }

    public void setRiskOid(UUID riskOid) {
        this.riskOid = riskOid;
    }

    public void setSkuLimitFlag(Boolean skuLimitFlag) {
        this.skuLimitFlag = skuLimitFlag;
    }

    public void setThresholdAmount(Integer thresholdAmount) {
        this.thresholdAmount = thresholdAmount;
    }

    public void setWeekLimits(List<Integer> weekLimits) {
        this.weekLimits = weekLimits;
    }

}
