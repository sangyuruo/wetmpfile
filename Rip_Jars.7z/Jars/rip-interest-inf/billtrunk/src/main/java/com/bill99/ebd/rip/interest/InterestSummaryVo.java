/**
 * 
 */
package com.bill99.ebd.rip.interest;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

/**
 * @author shuangye.liu
 * @since Apr 15, 2017
 */
public class InterestSummaryVo implements Serializable {

    private static final long serialVersionUID = 1L;

    private UUID oid;

    private String name;

    // 载体
    private String mediaType;

    // 生成类型
    private String generationType;

    // 发布方 member code
    private String issuerMemberCode;

    // 发布方名称
    private String issuerName;

    // 交易场景
    private String transactionPhase;

    // 来源渠道：内部、外部
    private String sourceChannel;

    // 创建渠道：intra、会员营销中心
    private String createChannel;

    // 生效间隔
    private Integer effectiveInterval;

    // 生效时长
    private Integer effectiveDay;

    // 状态
    private String status;

    private Date startTime;

    private Date endTime;

    private Boolean holdFlag;

    private UUID holdCreditlineOid;

    private UUID writeCreditlineOid;

    public String getCreateChannel() {
        return this.createChannel;
    }

    public Integer getEffectiveDay() {
        return this.effectiveDay;
    }

    public Integer getEffectiveInterval() {
        return this.effectiveInterval;
    }

    public Date getEndTime() {
        return this.endTime;
    }

    public String getGenerationType() {
        return this.generationType;
    }

    public UUID getHoldCreditlineOid() {
        return this.holdCreditlineOid;
    }

    public Boolean getHoldFlag() {
        return this.holdFlag;
    }

    public String getIssuerMemberCode() {
        return this.issuerMemberCode;
    }

    public String getIssuerName() {
        return this.issuerName;
    }

    public String getMediaType() {
        return this.mediaType;
    }

    public String getName() {
        return this.name;
    }

    public UUID getOid() {
        return this.oid;
    }

    public String getSourceChannel() {
        return this.sourceChannel;
    }

    public Date getStartTime() {
        return this.startTime;
    }

    public String getStatus() {
        return this.status;
    }

    public String getTransactionPhase() {
        return this.transactionPhase;
    }

    public UUID getWriteCreditlineOid() {
        return this.writeCreditlineOid;
    }

    public void setCreateChannel(String createChannel) {
        this.createChannel = createChannel;
    }

    public void setEffectiveDay(Integer effectiveDay) {
        this.effectiveDay = effectiveDay;
    }

    public void setEffectiveInterval(Integer effectiveInterval) {
        this.effectiveInterval = effectiveInterval;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public void setGenerationType(String generationType) {
        this.generationType = generationType;
    }

    public void setHoldCreditlineOid(UUID holdCreditlineOid) {
        this.holdCreditlineOid = holdCreditlineOid;
    }

    public void setHoldFlag(Boolean holdFlag) {
        this.holdFlag = holdFlag;
    }

    public void setIssuerMemberCode(String issuerMemberCode) {
        this.issuerMemberCode = issuerMemberCode;
    }

    public void setIssuerName(String issuerName) {
        this.issuerName = issuerName;
    }

    public void setMediaType(String mediaType) {
        this.mediaType = mediaType;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setOid(UUID oid) {
        this.oid = oid;
    }

    public void setSourceChannel(String sourceChannel) {
        this.sourceChannel = sourceChannel;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setTransactionPhase(String transactionPhase) {
        this.transactionPhase = transactionPhase;
    }

    public void setWriteCreditlineOid(UUID writeCreditlineOid) {
        this.writeCreditlineOid = writeCreditlineOid;
    }

}
