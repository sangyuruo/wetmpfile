/**
 * 
 */
package com.bill99.ebd.rip.interest;

import java.io.Serializable;

import com.bill99.ebd.rip.ApiBaseResponse;

/**
 * @author shuangye.liu
 * @since Apr 13, 2017
 */
public class UpdateInterestAgenciesResponse extends ApiBaseResponse implements Serializable {

	private static final long serialVersionUID = 1L;

}
