/**
 * 
 */
package com.bill99.ebd.rip.interest;

import java.io.Serializable;
import java.util.List;

import com.bill99.ebd.rip.ApiBaseResponse;

/**
 * @author shuangye.liu
 * @since Apr 13, 2017
 */
public class QueryInterestSkusResponse extends ApiBaseResponse implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer total;

    private Integer pageNo;

    private Integer pageSize;

    // sku 列表
    private List<InterestSkuVo> skus;

    public Integer getPageNo() {
        return this.pageNo;
    }

    public Integer getPageSize() {
        return this.pageSize;
    }

    public List<InterestSkuVo> getSkus() {
        return this.skus;
    }

    public Integer getTotal() {
        return this.total;
    }

    public void setPageNo(Integer pageNo) {
        this.pageNo = pageNo;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public void setSkus(List<InterestSkuVo> skus) {
        this.skus = skus;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

}
