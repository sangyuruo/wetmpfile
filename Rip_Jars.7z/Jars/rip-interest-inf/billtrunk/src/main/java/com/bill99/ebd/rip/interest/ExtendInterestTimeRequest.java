package com.bill99.ebd.rip.interest;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

import com.bill99.ebd.rip.ApiBaseRequest;

/**
 * 
 * @author shuangye.liu
 * @since Apr 13, 2017
 */
public class ExtendInterestTimeRequest extends ApiBaseRequest implements Serializable {

    private static final long serialVersionUID = 1L;

    private UUID interestOid;

    private Date holdEndTime;

    private Date writeoffEndTime;

    public Date getHoldEndTime() {
        return this.holdEndTime;
    }

    public UUID getInterestOid() {
        return this.interestOid;
    }

    public Date getWriteoffEndTime() {
        return this.writeoffEndTime;
    }

    public void setHoldEndTime(Date holdEndTime) {
        this.holdEndTime = holdEndTime;
    }

    public void setInterestOid(UUID interestOid) {
        this.interestOid = interestOid;
    }

    public void setWriteoffEndTime(Date writeoffEndTime) {
        this.writeoffEndTime = writeoffEndTime;
    }

}
