/**
 * 
 */
package com.bill99.ebd.rip.interest;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

/**
 * 
 * @author jinlei.zhuang
 * @date May 17, 2017 2:34:13 PM
 *
 */
public class AgencyEnableInterestVo implements Serializable {

    private static final long serialVersionUID = 1L;

    private String agencyMemberCode;

    private UUID interestOid;

    private String interestName;

    private Boolean holdAbility;

    private Boolean writeoffAbility;

    private Date startTime;

    private Date endTime;

    // 交易场景
    private String transactionPhase;

    // 发布方 member code
    private String issuerMemberCode;

    public String getAgencyMemberCode() {
        return this.agencyMemberCode;
    }

    public Date getEndTime() {
        return this.endTime;
    }

    public Boolean getHoldAbility() {
        return this.holdAbility;
    }

    public String getInterestName() {
        return this.interestName;
    }

    public UUID getInterestOid() {
        return this.interestOid;
    }

    public String getIssuerMemberCode() {
        return this.issuerMemberCode;
    }

    public Date getStartTime() {
        return this.startTime;
    }

    public String getTransactionPhase() {
        return this.transactionPhase;
    }

    public Boolean getWriteoffAbility() {
        return this.writeoffAbility;
    }

    public void setAgencyMemberCode(String agencyMemberCode) {
        this.agencyMemberCode = agencyMemberCode;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public void setHoldAbility(Boolean holdAbility) {
        this.holdAbility = holdAbility;
    }

    public void setInterestName(String interestName) {
        this.interestName = interestName;
    }

    public void setInterestOid(UUID interestOid) {
        this.interestOid = interestOid;
    }

    public void setIssuerMemberCode(String issuerMemberCode) {
        this.issuerMemberCode = issuerMemberCode;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public void setTransactionPhase(String transactionPhase) {
        this.transactionPhase = transactionPhase;
    }

    public void setWriteoffAbility(Boolean writeoffAbility) {
        this.writeoffAbility = writeoffAbility;
    }

}
