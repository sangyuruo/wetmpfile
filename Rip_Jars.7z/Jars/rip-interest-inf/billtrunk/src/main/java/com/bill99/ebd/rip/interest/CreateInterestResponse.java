package com.bill99.ebd.rip.interest;

import java.io.Serializable;
import java.util.UUID;

import com.bill99.ebd.rip.ApiBaseResponse;

/**
 * 
 * @author shuangye.liu
 * @since Apr 13, 2017
 */
public class CreateInterestResponse extends ApiBaseResponse implements Serializable {

    private static final long serialVersionUID = 1L;

    private UUID oid;

    /**
     * @return the oid
     */
    public UUID getOid() {
        return this.oid;
    }

    /**
     * @param oid
     *            the oid to set
     */
    public void setOid(UUID oid) {
        this.oid = oid;
    }

}