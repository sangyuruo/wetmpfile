package com.bill99.ebd.rip.facade.inf.market.cocbillapi;

import java.io.Serializable;

/**
 * 手机号请求
 * @author jun.tang
 *
 */
public class TxnCheckRequest implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/** 订单号 */
	private String orderId;
	/**卡号 */
	private String cardNo;
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getCardNo() {
		return cardNo;
	}
	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}

	
}
