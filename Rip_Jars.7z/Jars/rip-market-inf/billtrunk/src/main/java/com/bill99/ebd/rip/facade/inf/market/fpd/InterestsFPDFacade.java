/**
 * 
 */
package com.bill99.ebd.rip.facade.inf.market.fpd;

import com.bill99.ebd.rip.facade.inf.market.base.BaseResponse;


/**
 * 权益提供给理财组门面服务接口
 * 
 * @author jakoes.wu
 * @date 2015年10月10日上午10:45:39
 * @project rip-market-inf-2015100722
 *
 */
public interface InterestsFPDFacade {

	/**
	 * 查询权益
	 * @param fpdQueryRequest
	 * @return
	 * @author jakoes.wu
	 * @updatedate 2015年10月10日上午11:02:36
	 */
	public FpdQueryResponse query(FpdQueryRequest fpdQueryRequest);
	/**
	 * 核销权益
	 * @param fpdWriteoffRequest
	 * @return
	 * @author jakoes.wu
	 * @updatedate 2015年10月10日上午11:02:46
	 */
	public BaseResponse writeoff(FpdWriteoffRequest fpdWriteoffRequest);
	/**
	 * 撤销核销
	 * @param cancelWriteoffRequest
	 * @return
	 * @author jakoes.wu
	 * @updatedate 2015年10月10日上午11:02:53
	 */
	public BaseResponse cancelWriteoff(FpdCancelWriteoffRequest cancelWriteoffRequest);
	
}
