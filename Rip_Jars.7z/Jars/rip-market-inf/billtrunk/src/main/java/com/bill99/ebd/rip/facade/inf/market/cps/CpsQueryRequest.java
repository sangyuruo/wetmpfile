package com.bill99.ebd.rip.facade.inf.market.cps;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * Cps返现查询请求
 * */
public class CpsQueryRequest implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1598812037728380093L;

	private String membercode;		//商户会员编号
	
	private String merchantId;		//商户编号
	
	private BigDecimal orderAmt;		//订单金额
	
	private String cardNo;			//卡号
	
//	private String consumerId;       //移动支付用户标识
	
	private String terminalId;		//终端号
	
	private String orderId;			//订单号
	
	private Date requestTime;		//请求时间

	private String payType;  //支付方式 ：CP-刷卡支付  ； MP-移动支付

	public String getMembercode() {
		return membercode;
	}

	public void setMembercode(String membercode) {
		this.membercode = membercode;
	}

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public BigDecimal getOrderAmt() {
		return orderAmt;
	}

	public void setOrderAmt(BigDecimal orderAmt) {
		this.orderAmt = orderAmt;
	}

	public String getCardNo() {
		return cardNo;
	}

	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}

	public String getTerminalId() {
		return terminalId;
	}

	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public Date getRequestTime() {
		return requestTime;
	}

	public void setRequestTime(Date requestTime) {
		this.requestTime = requestTime;
	}

    public String getPayType() {
        return payType;
    }

    public void setPayType(String payType) {
        this.payType = payType;
    }

//    public String getConsumerId() {
//        return consumerId;
//    }
//
//    public void setConsumerId(String consumerId) {
//        this.consumerId = consumerId;
//    }

    
}
