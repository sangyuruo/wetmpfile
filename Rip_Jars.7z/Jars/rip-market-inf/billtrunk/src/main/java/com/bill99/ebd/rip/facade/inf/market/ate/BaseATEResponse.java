package com.bill99.ebd.rip.facade.inf.market.ate;

import com.bill99.ebd.rip.facade.inf.market.base.BaseResponse;

/**
 * Add requestId 
 * 
 * @author shuangye.liu
 * @since Mar 9, 2016
 */

public class BaseATEResponse extends BaseResponse {

    private static final long serialVersionUID = 8845870470874749849L;

    private String requestId;

    /**
     * @return the requestId
     */
    public String getRequestId() {
        return this.requestId;
    }

    /**
     * @param requestId
     *            the requestId to set
     */
    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

}
