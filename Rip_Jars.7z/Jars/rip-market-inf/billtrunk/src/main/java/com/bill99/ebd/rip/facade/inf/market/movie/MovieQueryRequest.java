package com.bill99.ebd.rip.facade.inf.market.movie;

import java.math.BigDecimal;

import com.bill99.ebd.rip.facade.inf.market.base.BaseRequest;

/**
 * 查可用券请求对象
 * 
 * @author jakoes.wu
 * @date 2015年10月30日下午9:03:48
 * @project rip-market-inf-20151030
 *
 */
public class MovieQueryRequest extends BaseRequest {

    /**
     * @author jakoes.wu
     * @updatedate 2015年10月30日下午8:51:00
     */
    private static final long serialVersionUID = 1L;

    private BigDecimal orderAmt;// 订单总金额

    private BigDecimal price;// 订单单价

    public BigDecimal getOrderAmt() {
        return orderAmt;
    }

    public void setOrderAmt(BigDecimal orderAmt) {
        this.orderAmt = orderAmt;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

}
