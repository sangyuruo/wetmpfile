package com.bill99.ebd.rip.facade.inf.market.ate;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * ATE查询数据传输对象
 * 
 * @author wei.wang.rd
 * 
 */
public class ATEQueryDto implements Serializable {

    private static final long serialVersionUID = -4304135102195724752L;

    /**
     * 券号
     */
    private String voucherNo;

    /**
     * 权益描述
     */
    private String interestsDesc;

    /**
     * 权益金额
     */
    private BigDecimal interestsAmt;

    /**
     * 权益面值
     */
    private BigDecimal interestsValue;

    /**
     * 支付金额
     */
    private BigDecimal payAmt;

    /**
     * 权益是否可以使用，0表示可以使用,1表示不可以使用
     */
    private String status;

    /**
     * 支持的支付方式, 如果为空则支持所有方式
     */
    private List<String> supportedPayMode;
    
    /**
     * 优惠券失效日期
     */
    private Date expDate;

    public ATEQueryDto(String voucherNo, String interestsDesc, BigDecimal interestsAmt, BigDecimal interestsValue,
            BigDecimal payAmt, List<String> supportedPayMode) {
        this.voucherNo = voucherNo;
        this.interestsDesc = interestsDesc;
        this.interestsAmt = interestsAmt;
        this.interestsValue = interestsValue;
        this.payAmt = payAmt;
        this.supportedPayMode = supportedPayMode;
    }

    public ATEQueryDto() {

    }

    public String getVoucherNo() {
        return this.voucherNo;
    }

    public void setVoucherNo(String voucherNo) {
        this.voucherNo = voucherNo;
    }

    public String getInterestsDesc() {
        return this.interestsDesc;
    }

    public void setInterestsDesc(String interestsDesc) {
        this.interestsDesc = interestsDesc;
    }

    public BigDecimal getInterestsAmt() {
        return this.interestsAmt;
    }

    public void setInterestsAmt(BigDecimal interestsAmt) {
        this.interestsAmt = interestsAmt;
    }

    public BigDecimal getInterestsValue() {
        return this.interestsValue;
    }

    public void setInterestsValue(BigDecimal interestsValue) {
        this.interestsValue = interestsValue;
    }

    public BigDecimal getPayAmt() {
        return this.payAmt;
    }

    public void setPayAmt(BigDecimal payAmt) {
        this.payAmt = payAmt;
    }

    public String getStatus() {
        return this.status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the supportedPayMode
     */
    public List<String> getSupportedPayMode() {
        return this.supportedPayMode;
    }

    /**
     * @param supportedPayMode
     *            the supportedPayMode to set
     */
    public void setSupportedPayMode(List<String> supportedPayMode) {
        this.supportedPayMode = supportedPayMode;
    }

	public Date getExpDate() {
		return expDate;
	}

	public void setExpDate(Date expDate) {
		this.expDate = expDate;
	}
}
