/**
 * 
 */
package com.bill99.ebd.rip.facade.inf.market.ate;

import java.math.BigDecimal;
import java.util.Date;

import com.bill99.ebd.rip.facade.inf.market.base.BaseRequest;

/**
 * 
 * @author shuangye.liu
 * @since Mar 9, 2016
 */
public class ATEWriteoffRequest extends BaseRequest {

    private static final long serialVersionUID = 7888602118024244902L;

    // 订单金额，必填，单位：元
    private BigDecimal orderAmt;

    // 订单编号，必填
    private String orderNo;

    // 交易时间，必填
    private Date txnTime;

    // 支付方式.
    // 1-账户余额支付
    // 2-银行卡支付(快捷支付)
    // 3-信用额度支付
    // 4-银行卡和账户余额婚后支付
    // 5-银行卡刷卡支付（CP）
    private String payMode;

    // 设备ID
    private String deviceId;

    // 主动权益券号，非必填
    private String voucherNo;

    /**
     * 安全方式
     * 
     * @see com.bill99.ebd.rip.enums.ATESecureType 1-密码支付 2-免密支付
     */
    private String secureType;

    /**
     * 渠道类型
     * 
     * @see com.bill99.ebd.rip.enums.ATEChannelType
     * 
     *      10 B扫C 11 直接账户支付 12 实体卡支付 13 线下C扫B 14 线上C扫B 15 会员扫码转账 16 理财申购 17 理财转让 18 转账 19 一卡通退卡 20 信用卡还款 21 SDK 22 分期商城
     *      23 MPOS 24 中银通
     * 
     */
    private String channelType;

    /**
     * 1-自动核销主动券 0-不自动核销主动券 传入此标识时，权益系统在未传入券号的情况下，默认核销一张用户卡券中的优惠券。 以下场景应传入’1’: 1.APP版本过低 2.B扫C且免密支付 3.实体卡支付
     */
    private String initiativeFlag;

    /**
     * @return the orderAmt
     */
    public BigDecimal getOrderAmt() {
        return this.orderAmt;
    }

    /**
     * @param orderAmt
     *            the orderAmt to set
     */
    public void setOrderAmt(BigDecimal orderAmt) {
        this.orderAmt = orderAmt;
    }

    /**
     * @return the orderNo
     */
    public String getOrderNo() {
        return this.orderNo;
    }

    /**
     * @param orderNo
     *            the orderNo to set
     */
    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    /**
     * @return the txnTime
     */
    public Date getTxnTime() {
        return this.txnTime;
    }

    /**
     * @param txnTime
     *            the txnTime to set
     */
    public void setTxnTime(Date txnTime) {
        this.txnTime = txnTime;
    }

    /**
     * @return the voucherNo
     */
    public String getVoucherNo() {
        return this.voucherNo;
    }

    /**
     * @param voucherNo
     *            the voucherNo to set
     */
    public void setVoucherNo(String voucherNo) {
        this.voucherNo = voucherNo;
    }

    /**
     * @return the payMode
     */
    public String getPayMode() {
        return this.payMode;
    }

    /**
     * @param payMode
     *            the payMode to set
     */
    public void setPayMode(String payMode) {
        this.payMode = payMode;
    }

    /**
     * @return the deviceId
     */
    public String getDeviceId() {
        return this.deviceId;
    }

    /**
     * @param deviceId
     *            the deviceId to set
     */
    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getSecureType() {
        return secureType;
    }

    public void setSecureType(String secureType) {
        this.secureType = secureType;
    }

    public String getChannelType() {
        return channelType;
    }

    public void setChannelType(String channelType) {
        this.channelType = channelType;
    }

    public String getInitiativeFlag() {
        return initiativeFlag;
    }

    public void setInitiativeFlag(String initiativeFlag) {
        this.initiativeFlag = initiativeFlag;
    }

}
