package com.bill99.ebd.rip.facade.inf.market.cps;

import java.io.Serializable;
import java.util.Date;

/**
 * Cps返现请求对象
 * @author wei.wang.rd
 * */
public class CpsNotifyRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8219349422087619761L;
	
	private String interestsId;	//权益编号
	
	private String extTxnId;	//交易ID
	
	private String membercode;	//商户会员编号
	
	private String orderId;		//订单编号
	
	private String cardNo;		//卡号
	
//	private String consumerId;    //移动支付用户标识
	
	private Date txnTime;		//交易时间
	
	private Date requestTime;	//请求时间
	
	private String payType;  //支付方式 ：CP-刷卡支付  ； MP-移动支付
	
	public String getInterestsId() {
		return interestsId;
	}

	public void setInterestsId(String interestsId) {
		this.interestsId = interestsId;
	}

	public String getExtTxnId() {
		return extTxnId;
	}

	public void setExtTxnId(String extTxnId) {
		this.extTxnId = extTxnId;
	}

	public String getMembercode() {
		return membercode;
	}

	public void setMembercode(String membercode) {
		this.membercode = membercode;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getCardNo() {
		return cardNo;
	}

	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}
	
	public Date getTxnTime() {
		return txnTime;
	}

	public void setTxnTime(Date txnTime) {
		this.txnTime = txnTime;
	}

	public Date getRequestTime() {
		return requestTime;
	}

	public void setRequestTime(Date requestTime) {
		this.requestTime = requestTime;
	}

    public String getPayType() {
        return payType;
    }

    public void setPayType(String payType) {
        this.payType = payType;
    }

//    public String getConsumerId() {
//        return consumerId;
//    }
//
//    public void setConsumerId(String consumerId) {
//        this.consumerId = consumerId;
//    }


}
