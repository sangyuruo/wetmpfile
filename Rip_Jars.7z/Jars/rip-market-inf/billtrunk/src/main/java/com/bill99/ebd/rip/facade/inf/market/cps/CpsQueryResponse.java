package com.bill99.ebd.rip.facade.inf.market.cps;

import java.math.BigDecimal;
import java.util.Date;

public class CpsQueryResponse extends CpsBaseResponse {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4138428300748222075L;
	
	private String interestsId;	//权益id
	
	private BigDecimal interestsAmt; //权益金额
	
	private String interestsDesc;	//权益描述
	
	private String interestsMode;	//1-返现；2-返券
	
	private String extTxnId;	//权益交易ID
	
	private Date responseTime;	//响应时间

	public String getInterestsId() {
		return interestsId;
	}

	public void setInterestsId(String interestsId) {
		this.interestsId = interestsId;
	}

	public BigDecimal getInterestsAmt() {
		return interestsAmt;
	}

	public void setInterestsAmt(BigDecimal interestsAmt) {
		this.interestsAmt = interestsAmt;
	}

	public String getInterestsDesc() {
		return interestsDesc;
	}

	public void setInterestsDesc(String interestsDesc) {
		this.interestsDesc = interestsDesc;
	}

	public String getExtTxnId() {
		return extTxnId;
	}

	public void setExtTxnId(String extTxnId) {
		this.extTxnId = extTxnId;
	}

	public Date getResponseTime() {
		return responseTime;
	}

	public void setResponseTime(Date responseTime) {
		this.responseTime = responseTime;
	}

	public String getInterestsMode() {
		return interestsMode;
	}

	public void setInterestsMode(String interestsMode) {
		this.interestsMode = interestsMode;
	}
	
}
