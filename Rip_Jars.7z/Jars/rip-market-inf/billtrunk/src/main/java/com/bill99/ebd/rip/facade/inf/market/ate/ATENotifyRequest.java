/**
 * 
 */
package com.bill99.ebd.rip.facade.inf.market.ate;

import java.math.BigDecimal;

import com.bill99.ebd.rip.facade.inf.market.base.BaseRequest;

/**
 * @author shuangye.liu
 * @since Mar 11, 2016
 */
public class ATENotifyRequest extends BaseRequest {

    private static final long serialVersionUID = -7723184686439246947L;

    // 订单金额
    private BigDecimal orderAmt;
    //ACS实际支付金额
    private BigDecimal payAmt;
    // 订单编号
    private String orderNo;

    // 权益券号
    private String voucherNo;

    // 支付结果. true:支付成功 false:支付失败
    private boolean payResult;
   

    // 支付方式. true:支付成功 false:支付失败
    // 10-账户余额支付
    // 11-银行卡支付(快捷支付)
    // 12-信用额度支付
    // 13-银行卡和账户余额婚后支付
    // 14-银行卡刷卡支付（CP）
    private String payMode;
    
    /**
     * 1-权益交易 
     * 2-非权益交易。
     *    权益交易是指正交易使用了券或交易后返了券
     */
    //private String interestsFlag;
    /**
     * 商品标识 {sku:num}
     */
    private String productTag;
    
    /**
     * 商品描述
     */
    private String productDesc;
    
 	/**
 	 * 设备ID
 	 */
    private String deviceId;

    /**
     * @return the orderAmt
     */
    public BigDecimal getOrderAmt() {
        return this.orderAmt;
    }

    /**
     * @param orderAmt
     *            the orderAmt to set
     */
    public void setOrderAmt(BigDecimal orderAmt) {
        this.orderAmt = orderAmt;
    }

    /**
     * @return the orderNo
     */
    public String getOrderNo() {
        return this.orderNo;
    }

    /**
     * @param orderNo
     *            the orderNo to set
     */
    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    /**
     * @return the voucherNo
     */
    public String getVoucherNo() {
        return this.voucherNo;
    }

    /**
     * @param voucherNo
     *            the voucherNo to set
     */
    public void setVoucherNo(String voucherNo) {
        this.voucherNo = voucherNo;
    }

    /**
     * @return the payResult
     */
    public boolean isPayResult() {
        return this.payResult;
    }

    /**
     * @param payResult
     *            the payResult to set
     */
    public void setPayResult(boolean payResult) {
        this.payResult = payResult;
    }

    /**
     * @return the payMode
     */
    public String getPayMode() {
        return this.payMode;
    }

    /**
     * @param payMode
     *            the payMode to set
     */
    public void setPayMode(String payMode) {
        this.payMode = payMode;
    }

//    public String getInterestsFlag() {
//        return interestsFlag;
//    }
//
//    public void setInterestsFlag(String interestsFlag) {
//        this.interestsFlag = interestsFlag;
//    }

    public String getProductTag() {
        return productTag;
    }

    public void setProductTag(String productTag) {
        this.productTag = productTag;
    }

    public String getProductDesc() {
        return productDesc;
    }

    public void setProductDesc(String productDesc) {
        this.productDesc = productDesc;
    }

	public BigDecimal getPayAmt() {
		return payAmt;
	}

	public void setPayAmt(BigDecimal payAmt) {
		this.payAmt = payAmt;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

}
