package com.bill99.ebd.rip.facade.inf.market.cocbillapi;

import java.io.Serializable;

/**
 * 返现核销请求类
 * 
 * @author jun.tang
 *
 */
public class WriteoffRequest implements Serializable {
	 
	private static final long serialVersionUID = 1L;
	/** 订单号 */
	private String orderId;
	/**会员编号 */
	private String membercode;
	
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getMembercode() {
		return membercode;
	}
	public void setMembercode(String membercode) {
		this.membercode = membercode;
	}
	
}
