package com.bill99.ebd.rip.facade.inf.market.publisher;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**
 * 更新券
 * 
 * @author pengfei.shen
 * @create 2016年3月14日 下午5:22:38
 * @project
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class UpdateCouponRequest implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String voucherNo;//券号
	private String interestType;//权益类型
	private String interestTypeName;//	权益类型名称
	private String interestName;//权益名称
	private String interestDesc;//权益使用说明
	private long couponDate;//用户获得券的时间--voucherRepository的createDate
	private long enableDate;//券生效时间
	private long expireDate;//有效期--interests-有效时间
	/**
	 * 券状态
	 * @see com.bill99.ebd.rip.enums.VoucherStatus
	 * 
	 */
	private String couponStatus;
	private String memberCode;//账户名
	private String mobile;//账户手机号
	private String idContent;//账户ID
	private long updateTime;//修改时间
	private String awareType;//感知类型

	public String getVoucherNo() {
		return voucherNo;
	}
	public void setVoucherNo(String voucherNo) {
		this.voucherNo = voucherNo;
	}
	public String getInterestType() {
		return interestType;
	}
	public void setInterestType(String interestType) {
		this.interestType = interestType;
	}
	public String getInterestTypeName() {
		return interestTypeName;
	}
	public void setInterestTypeName(String interestTypeName) {
		this.interestTypeName = interestTypeName;
	}
	public String getInterestName() {
		return interestName;
	}
	public void setInterestName(String interestName) {
		this.interestName = interestName;
	}
	public String getInterestDesc() {
		return interestDesc;
	}
	public void setInterestDesc(String interestDesc) {
		this.interestDesc = interestDesc;
	}
	public long getCouponDate() {
		return couponDate;
	}
	public void setCouponDate(long couponDate) {
		this.couponDate = couponDate;
	}
	public long getExpireDate() {
		return expireDate;
	}
	public void setExpireDate(long expireDate) {
		this.expireDate = expireDate;
	}
	public String getCouponStatus() {
		return couponStatus;
	}
	public void setCouponStatus(String couponStatus) {
		this.couponStatus = couponStatus;
	}
	public String getMemberCode() {
		return memberCode;
	}
	public void setMemberCode(String memberCode) {
		this.memberCode = memberCode;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getIdContent() {
		return idContent;
	}
	public void setIdContent(String idContent) {
		this.idContent = idContent;
	}
	public long getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(long updateTime) {
		this.updateTime = updateTime;
	}
	public String getAwareType() {
		return awareType;
	}
	public void setAwareType(String awareType) {
		this.awareType = awareType;
	}
	public long getEnableDate() {
		return enableDate;
	}
	public void setEnableDate(long enableDate) {
		this.enableDate = enableDate;
	}
}
