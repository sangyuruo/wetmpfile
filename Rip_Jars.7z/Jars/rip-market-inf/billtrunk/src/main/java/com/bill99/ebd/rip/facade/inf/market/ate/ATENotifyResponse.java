/**
 * 
 */
package com.bill99.ebd.rip.facade.inf.market.ate;

import java.math.BigDecimal;

/**
 * @author wei.wang.rd
 * @since Mar 11, 2016
 */
public class ATENotifyResponse extends BaseATEResponse {

    private static final long serialVersionUID = -7723184686439246947L;

    private String voucherNo;
    
    private BigDecimal interestsAmt;
    
	public ATENotifyResponse() {
		
	}

	public String getVoucherNo() {
		return voucherNo;
	}

	public void setVoucherNo(String voucherNo) {
		this.voucherNo = voucherNo;
	}

	public BigDecimal getInterestsAmt() {
		return interestsAmt;
	}

	public void setInterestsAmt(BigDecimal interestsAmt) {
		this.interestsAmt = interestsAmt;
	}
    
    
    
    
    
    

}
