package com.bill99.ebd.rip.facade.inf.market.ate;

import java.util.List;

/**
 * ATE查询响应
 * @author wei.wang.rd
 * 
 * */
public class ATEQueryResponse extends BaseATEResponse {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2243089177310575356L;
	
	/**
	 * 权益列表
	 * */
	private List<ATEQueryDto> interestsList;

	public List<ATEQueryDto> getInterestsList() {
		return interestsList;
	}

	public void setInterestsList(List<ATEQueryDto> interestsList) {
		this.interestsList = interestsList;
	}

}
