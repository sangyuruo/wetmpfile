package com.bill99.ebd.rip.facade.inf.market.fpd;

import java.math.BigDecimal;
import java.util.Map;

public class FpdQueryRequest extends FpdBaseRequest {

	/**
	 * @author jakoes.wu
	 * @updatedate 2015年10月10日上午10:50:26
	 */
	private static final long serialVersionUID = 1L;

	private BigDecimal orderAmt;//订单金额 R
	private String businessLine;//产品线 R
	private Map<String,String> extPara;//扩展字段
	
	public BigDecimal getOrderAmt() {
		return orderAmt;
	}
	public void setOrderAmt(BigDecimal orderAmt) {
		this.orderAmt = orderAmt;
	}
	public String getBusinessLine() {
		return businessLine;
	}
	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}
	public Map<String, String> getExtPara() {
		return extPara;
	}
	public void setExtPara(Map<String, String> extPara) {
		this.extPara = extPara;
	}

	
}
