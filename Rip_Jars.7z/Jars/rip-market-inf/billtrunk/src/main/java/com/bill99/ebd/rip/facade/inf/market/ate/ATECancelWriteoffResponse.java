/**
 * 
 */
package com.bill99.ebd.rip.facade.inf.market.ate;

/**
 * @author shuangye.liu
 * @since Mar 11, 2016
 */
public class ATECancelWriteoffResponse extends BaseATEResponse {

    private static final long serialVersionUID = -2873925650987180414L;

}
