package com.bill99.ebd.rip.facade.inf.market.cocbillapi;

import com.bill99.ebd.rip.facade.inf.market.base.BaseResponse;

/**
 * 是否匹配响应
 * @author jun.tang
 *
 */
public class TxnCheckResponse  extends BaseResponse {
	
	private static final long serialVersionUID = 1L;
	/**是否匹配*/
	private boolean match;
	public boolean isMatch() {
		return match;
	}
	public void setMatch(boolean match) {
		this.match = match;
	}
	
	

}
