package com.bill99.ebd.rip.facade.inf.market.cps;

/**
 * Cps返现查询请求（对 CpsQueryRequest 进行扩展以支持consumerId字段）
 * @author jun.tang
 * */
public class ExtCpsQueryRequest extends CpsQueryRequest {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
	
    
    private String consumerId;       //移动支付用户标识


    public String getConsumerId() {
        return consumerId;
    }


    public void setConsumerId(String consumerId) {
        this.consumerId = consumerId;
    }
    
    
}
