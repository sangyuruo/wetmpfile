package com.bill99.ebd.rip.facade.inf.market.base;

import java.io.Serializable;

/**
* @ClassName: BaseApiResponse 
* @Description: 基类
* @author gumin
* @date 2015年5月12日 下午2:51:52 
 */
public class BaseResponse implements Serializable{

	private static final long serialVersionUID = 904676182506272943L;
	
	private String responseCode;//响应码 '00'代码成功 @see AppExCodeEnum.SUCCESS.getErrorCode()
	private String responseMessage;//响应信息
	
	public BaseResponse() {
		super();
	}
	
	public BaseResponse(String responseCode, String responseMessage) {
		super();
		this.responseCode = responseCode;
		this.responseMessage = responseMessage;
	}



	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	
}
