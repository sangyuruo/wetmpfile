package com.bill99.ebd.rip.facade.inf.market.fpd;


public class FpdWriteoffRequest extends FpdBaseRequest {

	/**
	 * @author jakoes.wu
	 * @updatedate 2015年10月10日上午10:50:26
	 */
	private static final long serialVersionUID = 1L;

	private String voucherNo;//权益编号（券号） R
	private String extRequestId;//外部请求交易编号（券号） R
	private String productCode;//产品编号
	
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getVoucherNo() {
		return voucherNo;
	}
	public void setVoucherNo(String voucherNo) {
		this.voucherNo = voucherNo;
	}
	public String getExtRequestId() {
		return extRequestId;
	}
	public void setExtRequestId(String extRequestId) {
		this.extRequestId = extRequestId;
	}
	
	
}
