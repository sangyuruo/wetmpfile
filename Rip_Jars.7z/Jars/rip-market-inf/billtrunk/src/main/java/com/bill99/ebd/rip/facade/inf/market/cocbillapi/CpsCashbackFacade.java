package com.bill99.ebd.rip.facade.inf.market.cocbillapi;



/**
 * Pos机刷二维码服务门面（提供给coc-bill-api应用）。
 * @author jun.tang
 *
 */
public interface CpsCashbackFacade {
	/**
	 * 订单权益状态查询
	 * @param orderId 订单号
	 * @return 权益状态、返现金额、缩略银行卡号、缩略快钱账号
	 */
	public TxnQueryResponse queryTxnInfoByOrderId(String orderId);
	
	/**
	 * 检查卡号是否匹配
	 * @param orderId 订单号
	 * @param cardNo 明文卡号
	 * @return true or false
	 */
	public TxnCheckResponse checkTxnByOrderIdAndCardNo(TxnCheckRequest request);
	
	/**
	 * 返现核销
	 * @param orderId 订单号
	 * @param membercode 用户会员编号
	 * @return 返现金额，快钱账号
	 */
	public WriteoffResponse writeoff(WriteoffRequest writeoffRequest);
}
