package com.bill99.ebd.rip.facade.inf.market.publisher;


public interface CouponPublisher {

	/**
	 * 新增券 
	 * @param createCouponRequest
	 *
	 *@author pengfei.shen 
	 *@create 2016年3月14日 下午5:16:11
	 */
	public void createCoupon(CreateCouponRequest createCouponRequest);
	
	/**
	 * 修改券
	 * @param updateCouponRequest
	 *
	 *@author pengfei.shen
	 *@create 2016年3月14日 下午5:16:16
	 */
	public void updateCoupon(UpdateCouponRequest updateCouponRequest);
}
