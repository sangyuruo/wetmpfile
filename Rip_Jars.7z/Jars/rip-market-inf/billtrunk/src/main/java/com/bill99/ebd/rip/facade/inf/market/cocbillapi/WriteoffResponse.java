package com.bill99.ebd.rip.facade.inf.market.cocbillapi;

import java.math.BigDecimal;

import com.bill99.ebd.rip.facade.inf.market.base.BaseResponse;

/**
 * 核销（领券、核销并返现给C端）
 * @author jun.tang
 *
 */
public class WriteoffResponse extends BaseResponse  {
	
	private static final long serialVersionUID = 1L;
	
	private BigDecimal interestsAmt ;//返现金额
	
	public BigDecimal getInterestsAmt() {
		return interestsAmt;
	}
	public void setInterestsAmt(BigDecimal interestsAmt) {
		this.interestsAmt = interestsAmt;
	}
	
}
