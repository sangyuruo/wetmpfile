package com.bill99.ebd.rip.facade.inf.market.cps;

import java.io.Serializable;

public class CpsCancelOrderRequest implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    /**
     * 订单号
     */
    private String orderId;
    
    /**
     * 商户会员编号
     */
    private String membercode;

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getMembercode() {
        return membercode;
    }

    public void setMembercode(String membercode) {
        this.membercode = membercode;
    }
    
    
}
