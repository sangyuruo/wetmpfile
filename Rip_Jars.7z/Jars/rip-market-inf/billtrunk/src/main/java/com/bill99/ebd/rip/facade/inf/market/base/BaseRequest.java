package com.bill99.ebd.rip.facade.inf.market.base;

import java.io.Serializable;

public class BaseRequest implements Serializable {

    /**
     * @author jakoes.wu
     * @updatedate 2015年10月10日上午10:49:25
     */
    private static final long serialVersionUID = 1L;

    /**
     * 版本号
     */
    private String version;

    private String consumerMembercode;// 用户会员编号 R

    private String merchantMembercode;// 商户会员编号 R

    public String getConsumerMembercode() {
        return consumerMembercode;
    }

    public void setConsumerMembercode(String consumerMembercode) {
        this.consumerMembercode = consumerMembercode;
    }

    public String getMerchantMembercode() {
        return merchantMembercode;
    }

    public void setMerchantMembercode(String merchantMembercode) {
        this.merchantMembercode = merchantMembercode;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

}
