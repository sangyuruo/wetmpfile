package com.bill99.ebd.rip.facade.inf.market.movie;

import java.util.List;

import com.bill99.ebd.rip.facade.inf.market.base.BaseResponse;

/**
 * 查可用券响应对象
 * 
 * @author jakoes.wu
 * @date 2015年10月30日下午9:04:02
 * @project rip-market-inf-20151030
 *
 */
public class MovieQueryResponse extends BaseResponse {
	
	/**
	 * @author jakoes.wu
	 * @updatedate 2015年10月30日下午9:02:56
	 */
	private static final long serialVersionUID = 1L;
	
	private List<MovieQueryDto> list;//可用券对象列表

	public List<MovieQueryDto> getList() {
		return list;
	}

	public void setList(List<MovieQueryDto> list) {
		this.list = list;
	} 
	
}
