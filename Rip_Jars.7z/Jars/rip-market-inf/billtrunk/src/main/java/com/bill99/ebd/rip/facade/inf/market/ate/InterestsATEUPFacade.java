/**
 *  
 */
package com.bill99.ebd.rip.facade.inf.market.ate;

/**
 * 权益平台提供给ATE服务门面
 * 
 * @author shuangye.liu
 * @since Mar 9, 2016
 */
public interface InterestsATEUPFacade {

    /**
     * 查询主动权益 此接口只返回用户已领用过的主动权益，即用户账户里已绑定的权益。
     * 
     * @param {@link
     *            ATEQueryRequest}
     * 
     * @return {@link ATEQueryResponse}
     */
    ATEQueryResponse query(ATEQueryRequest ateQueryRequest);

    /**
     * 核销权益
     * 
     * @param ateWriteoffRequest
     * @return
     */
    ATEWriteoffResponse writeoff(ATEWriteoffRequest ateWriteoffRequest);

    /**
     * 撤销权益核销
     * 
     * @param cancelWriteoffRequest
     * @return
     */
    BaseATEResponse cancelWriteoff(ATECancelWriteoffRequest cancelWriteoffRequest);

    /**
     * 通知支付结果
     * 
     * @param ateNotifyRequest
     */
    BaseATEResponse notify(ATENotifyRequest ateNotifyRequest);
    
    /**
     * 充值 （从蝶巢账户充值到C端账户）
     * @param ateFundoutRequest
     * @return
     * @author jakoes.wu
     * @updatedate 2016年7月15日下午8:08:06
     */
    BaseATEResponse fundout(ATEFundoutRequest ateFundoutRequest);

}
