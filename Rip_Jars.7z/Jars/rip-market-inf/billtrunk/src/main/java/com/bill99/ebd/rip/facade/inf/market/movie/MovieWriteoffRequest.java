package com.bill99.ebd.rip.facade.inf.market.movie;

import java.math.BigDecimal;

import com.bill99.ebd.rip.facade.inf.market.base.BaseRequest;

/**
 * 核销请求对象
 * 
 * @author jakoes.wu
 * @date 2015年10月30日下午9:03:48
 * @project rip-market-inf-20151030
 *
 */
public class MovieWriteoffRequest extends BaseRequest {

    /**
     * @author jakoes.wu
     * @updatedate 2015年10月30日下午8:51:00
     */
    private static final long serialVersionUID = 1L;

    private BigDecimal orderAmt;// 渠道金额

    private String extSeqId;// 订单号

    private String voucherNo;// 券号

    public String getExtSeqId() {
        return extSeqId;
    }

    public void setExtSeqId(String extSeqId) {
        this.extSeqId = extSeqId;
    }

    public String getVoucherNo() {
        return voucherNo;
    }

    public void setVoucherNo(String voucherNo) {
        this.voucherNo = voucherNo;
    }

    public BigDecimal getOrderAmt() {
        return orderAmt;
    }

    public void setOrderAmt(BigDecimal orderAmt) {
        this.orderAmt = orderAmt;
    }

}
