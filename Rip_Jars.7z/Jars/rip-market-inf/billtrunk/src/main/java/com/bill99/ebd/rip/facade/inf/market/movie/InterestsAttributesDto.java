package com.bill99.ebd.rip.facade.inf.market.movie;

import java.util.Date;

import com.bill99.ebd.rip.facade.inf.market.base.BaseResponse;

/**
 * 权益属性对象
 * 
 * @author jakoes.wu
 * @date 2015年10月30日下午9:03:24
 * @project rip-market-inf-20151030
 *
 */
public class InterestsAttributesDto extends BaseResponse {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2916328995401675175L;
	private Integer interestsId;//权益ID
	private Character interestsType;//权益类型
	private String interestsTypeName;//权益类型名称，如：满减券、折扣券 @see com.bill99.ebd.rip.enums.InterestsType
	private String interestsName;//权益名称
	private String instructions;//权益使用说明
	private Date expDate;//有效期（失效日期）
	
	public Integer getInterestsId() {
		return interestsId;
	}
	public void setInterestsId(Integer interestsId) {
		this.interestsId = interestsId;
	}	
	public Character getInterestsType() {
		return interestsType;
	}
	public void setInterestsType(Character interestsType) {
		this.interestsType = interestsType;
	}
	public String getInterestsTypeName() {
		return interestsTypeName;
	}
	public void setInterestsTypeName(String interestsTypeName) {
		this.interestsTypeName = interestsTypeName;
	}
	public String getInterestsName() {
		return interestsName;
	}
	public void setInterestsName(String interestsName) {
		this.interestsName = interestsName;
	}
	public String getInstructions() {
		return instructions;
	}
	public void setInstructions(String instructions) {
		this.instructions = instructions;
	}
	public Date getExpDate() {
		return expDate;
	}
	public void setExpDate(Date expDate) {
		this.expDate = expDate;
	}
	
}
