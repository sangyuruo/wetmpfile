/**
 * 
 */
package com.bill99.ebd.rip.facade.inf.market.movie;

import com.bill99.ebd.rip.facade.inf.market.base.BaseResponse;



/**
 * 权益提供万达电影应用门面服务接口
 * 
 * @author jakoes.wu
 * @date 2015年10月30日下午8:42:20
 * @project rip-market-inf-20151030
 *
 */
public interface InterestsMovieFacade {

	/**
	 * 查询用户优惠券列表（只查未核销券）
	 * 
	 * @author jakoes.wu
	 * @updatedate 2015年10月30日下午8:43:22
	 */
	public MovieQueryResponse findVoucherList(MovieQueryRequest request);
	/**
	 * 核销
	 * 
	 * @param request
	 * @return
	 * @author jakoes.wu
	 * @updatedate 2015年10月30日下午9:08:45
	 */
	public BaseResponse writeoff(MovieWriteoffRequest request);
	/**
	 * 撤销核销
	 * 
	 * @param request
	 * @return
	 * @author jakoes.wu
	 * @updatedate 2015年10月30日下午9:14:49
	 */
	public BaseResponse cancelWriteoff(MovieCancelWriteoffRequest request);
	
	/**
	 * 根据券号查询权益属性
	 * @param voucherNo
	 * @return
	 * @author jakoes.wu
	 * @updatedate 2015年10月31日下午2:07:04
	 */
	public InterestsAttributesDto queryInterestsByVoucherNo(String voucherNo);
}
