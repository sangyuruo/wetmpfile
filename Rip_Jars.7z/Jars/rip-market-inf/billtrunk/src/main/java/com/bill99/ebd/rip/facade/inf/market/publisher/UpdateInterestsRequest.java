package com.bill99.ebd.rip.facade.inf.market.publisher;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**
 * 更新权益
 * 
 * @author pengfei.shen
 * @create 2016年3月14日 下午5:22:25
 * @project
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class UpdateInterestsRequest implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String interestsId;//权益ID
	private String interestsName;//权益名称
	private String interestsStatus;//权益状态
	private long enableDate;//核销生效日期
	private long expDate;//核销失效日期
	private long holdEnableDate;//领用生效日期
	private long holdExpDate;//领用失效日期
	private String instructions;//权益使用规则
	private String freeFlag;//是否免费
	private String generateType;//权益号生成类型
	private String shelfStatus;//权益货架状态
	private String wareType;//感知类型
	private long updateTime;//修改时间
	public String getInterestsId() {
		return interestsId;
	}
	public void setInterestsId(String interestsId) {
		this.interestsId = interestsId;
	}
	public String getInterestsName() {
		return interestsName;
	}
	public void setInterestsName(String interestsName) {
		this.interestsName = interestsName;
	}
	public String getInterestsStatus() {
		return interestsStatus;
	}
	public void setInterestsStatus(String interestsStatus) {
		this.interestsStatus = interestsStatus;
	}
	public long getEnableDate() {
		return enableDate;
	}
	public void setEnableDate(long enableDate) {
		this.enableDate = enableDate;
	}
	public long getExpDate() {
		return expDate;
	}
	public void setExpDate(long expDate) {
		this.expDate = expDate;
	}
	public long getHoldEnableDate() {
		return holdEnableDate;
	}
	public void setHoldEnableDate(long holdEnableDate) {
		this.holdEnableDate = holdEnableDate;
	}
	public long getHoldExpDate() {
		return holdExpDate;
	}
	public void setHoldExpDate(long holdExpDate) {
		this.holdExpDate = holdExpDate;
	}
	public String getInstructions() {
		return instructions;
	}
	public void setInstructions(String instructions) {
		this.instructions = instructions;
	}
	public String getFreeFlag() {
		return freeFlag;
	}
	public void setFreeFlag(String freeFlag) {
		this.freeFlag = freeFlag;
	}
	public String getGenerateType() {
		return generateType;
	}
	public void setGenerateType(String generateType) {
		this.generateType = generateType;
	}
	public String getShelfStatus() {
		return shelfStatus;
	}
	public void setShelfStatus(String shelfStatus) {
		this.shelfStatus = shelfStatus;
	}
	public String getWareType() {
		return wareType;
	}
	public void setWareType(String wareType) {
		this.wareType = wareType;
	}
	public long getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(long updateTime) {
		this.updateTime = updateTime;
	}
}
