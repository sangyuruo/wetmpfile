package com.bill99.ebd.rip.facade.inf.market.publisher;

import java.io.Serializable;
import java.util.Date;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**
 * 
 * 新增券
 * 
 * @author pengfei.shen
 * @create 2016年3月14日 下午5:22:52
 * @project
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class CreateCouponRequest implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String voucherNo;//券号
	private String interestId;//权益id
	private String interestType;//权益类型
	private String interestTypeName;//	权益类型名称
	private String interestName;//权益名称
	private String interestDesc;//权益使用说明
	private long enableDate;//生效时间
	private long expireDate;//有效期--interests-有效时间
	/**
	 * 券状态
	 * @see com.bill99.ebd.rip.enums.VoucherStatus
	 * 
	 */
	private String couponStatus;
	private String detailURL;//券详情H5地址
	private String memberCode;//账户名
	private String mobile;//账户手机号
	private String idContent;//账户ID
	private String awareType;//感知类型
	private long createTime;//创建时间

	public String getVoucherNo() {
		return voucherNo;
	}
	public void setVoucherNo(String voucherNo) {
		this.voucherNo = voucherNo;
	}
	public String getInterestId() {
		return interestId;
	}
	public void setInterestId(String interestId) {
		this.interestId = interestId;
	}
	public String getInterestType() {
		return interestType;
	}
	public void setInterestType(String interestType) {
		this.interestType = interestType;
	}
	public String getInterestTypeName() {
		return interestTypeName;
	}
	public void setInterestTypeName(String interestTypeName) {
		this.interestTypeName = interestTypeName;
	}
	public String getInterestName() {
		return interestName;
	}
	public void setInterestName(String interestName) {
		this.interestName = interestName;
	}
	public String getInterestDesc() {
		return interestDesc;
	}
	public void setInterestDesc(String interestDesc) {
		this.interestDesc = interestDesc;
	}
	public long getExpireDate() {
		return expireDate;
	}
	public void setExpireDate(long expireDate) {
		this.expireDate = expireDate;
	}
	public String getCouponStatus() {
		return couponStatus;
	}
	public void setCouponStatus(String couponStatus) {
		this.couponStatus = couponStatus;
	}
	public String getDetailURL() {
		return detailURL;
	}
	public void setDetailURL(String detailURL) {
		this.detailURL = detailURL;
	}
	public String getMemberCode() {
		return memberCode;
	}
	public void setMemberCode(String memberCode) {
		this.memberCode = memberCode;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getIdContent() {
		return idContent;
	}
	public void setIdContent(String idContent) {
		this.idContent = idContent;
	}
	public long getCreateTime() {
		return createTime;
	}
	public void setCreateTime(long createTime) {
		this.createTime = createTime;
	}
	public String getAwareType() {
		return awareType;
	}
	public void setAwareType(String awareType) {
		this.awareType = awareType;
	}
	public long getEnableDate() {
		return enableDate;
	}
	public void setEnableDate(long enableDate) {
		this.enableDate = enableDate;
	}
}
