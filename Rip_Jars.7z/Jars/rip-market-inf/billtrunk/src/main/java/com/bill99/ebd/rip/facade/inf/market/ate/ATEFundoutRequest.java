/**
 * 
 */
package com.bill99.ebd.rip.facade.inf.market.ate;

import java.math.BigDecimal;

import com.bill99.ebd.rip.facade.inf.market.base.BaseRequest;

/**
 * 充值请求类
 * 
 * @author jakoes.wu
 * @date 2016年7月15日下午8:07:38
 * @project rip-market-inf-20160715
 *
 */
public class ATEFundoutRequest extends BaseRequest {

    private static final long serialVersionUID = -7723184686439246947L;

    // 订单金额
    private BigDecimal orderAmt;

    // 订单编号
    private String orderNo;

    // 权益券号
    private String voucherNo;

    // 支付结果. true:支付成功 false:支付失败
     
    /**
     * @return the orderAmt
     */
    public BigDecimal getOrderAmt() {
        return this.orderAmt;
    }

    /**
     * @param orderAmt
     *            the orderAmt to set
     */
    public void setOrderAmt(BigDecimal orderAmt) {
        this.orderAmt = orderAmt;
    }

    /**
     * @return the orderNo
     */
    public String getOrderNo() {
        return this.orderNo;
    }

    /**
     * @param orderNo
     *            the orderNo to set
     */
    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    /**
     * @return the voucherNo
     */
    public String getVoucherNo() {
        return this.voucherNo;
    }

    /**
     * @param voucherNo
     *            the voucherNo to set
     */
    public void setVoucherNo(String voucherNo) {
        this.voucherNo = voucherNo;
    }

   
    

}
