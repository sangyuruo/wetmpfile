package com.bill99.ebd.rip.facade.inf.market.fpd;


public class FpdCancelWriteoffRequest extends FpdBaseRequest {

	/**
	 * @author jakoes.wu
	 * @updatedate 2015年10月10日上午10:50:26
	 */
	private static final long serialVersionUID = 1L;

	private String voucherNo;//权益编号（券号） R
	private String origRequestId;//原外部请求交易编号（券号） R
	
	public String getVoucherNo() {
		return voucherNo;
	}
	public void setVoucherNo(String voucherNo) {
		this.voucherNo = voucherNo;
	}
	public String getOrigRequestId() {
		return origRequestId;
	}
	public void setOrigRequestId(String origRequestId) {
		this.origRequestId = origRequestId;
	}
	 
	
	
}
