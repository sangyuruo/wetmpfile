/**
 * 
 */
package com.bill99.ebd.rip.facade.inf.market.ate;

import java.math.BigDecimal;

import com.bill99.ebd.rip.facade.inf.market.base.BaseRequest;

/**
 * @author shuangye.liu  
 * @since Mar 11, 2016
 */
public class ATECancelWriteoffRequest extends BaseRequest {

    private static final long serialVersionUID = 6015614862124240622L;

    // 订单金额，必填，单位：元
    private BigDecimal orderAmt;

    // 订单编号，必填
    private String orderNo;

    // 原订单编号，必填
    private String origOrderNo;

    // 已核销的权益卷号，必填
    private String voucherNo;

    /**
     * @return the orderAmt
     */
    public BigDecimal getOrderAmt() {
        return this.orderAmt;
    }

    /**
     * @param orderAmt
     *            the orderAmt to set
     */
    public void setOrderAmt(BigDecimal orderAmt) {
        this.orderAmt = orderAmt;
    }

    /**
     * @return the orderNo
     */
    public String getOrderNo() {
        return this.orderNo;
    }

    /**
     * @param orderNo
     *            the orderNo to set
     */
    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    /**
     * @return the origOrderNo
     */
    public String getOrigOrderNo() {
        return this.origOrderNo;
    }

    /**
     * @param origOrderNo
     *            the origOrderNo to set
     */
    public void setOrigOrderNo(String origOrderNo) {
        this.origOrderNo = origOrderNo;
    }

    /**
     * @return the voucherNo
     */
    public String getVoucherNo() {
        return this.voucherNo;
    }

    /**
     * @param voucherNo
     *            the voucherNo to set
     */
    public void setVoucherNo(String voucherNo) {
        this.voucherNo = voucherNo;
    }

}
