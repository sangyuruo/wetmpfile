package com.bill99.ebd.rip.facade.inf.market.cps;

import com.bill99.ebd.rip.facade.inf.market.base.BaseResponse;

/**
 * CPS返回基类
 * */
public class CpsBaseResponse extends BaseResponse {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5189503174936286633L;
	private String requestId;		//请求ID

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

}
