package com.bill99.ebd.rip.facade.inf.market.cps;

/**
 * Cps返现响应对象 
 * 为了达到既支持老接口又支持新街口的目的而扩充CpsNotifyResponse对象
 * @author jun.tang
 *
 */
public class ExtCpsNotifyResponse extends CpsNotifyResponse {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private String hasHoldVoucher;  //是否曾今领过券

    public String getHasHoldVoucher() {
        return hasHoldVoucher;
    }

    public void setHasHoldVoucher(String hasHoldVoucher) {
        this.hasHoldVoucher = hasHoldVoucher;
    }
    
}
