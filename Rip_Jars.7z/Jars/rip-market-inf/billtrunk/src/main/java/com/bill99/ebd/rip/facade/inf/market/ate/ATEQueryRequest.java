package com.bill99.ebd.rip.facade.inf.market.ate;

import java.math.BigDecimal;

import com.bill99.ebd.rip.facade.inf.market.base.BaseRequest;

/**
 * ATE查询请求
 * 
 * @author wei.wang.rd
 * 
 */
public class ATEQueryRequest extends BaseRequest {

    private static final long serialVersionUID = -3302631051707916071L;

    /**
     * 订单金额
     */
    private BigDecimal orderAmt;

    /**
     * 订单号
     */
    private String orderNo;

    /**
     * 设备编号
     */
    private String deviceId;
    /**
     * 支付方式
     */
    private String payMode;
    
    
    public String getPayMode() {
		return payMode;
	}

	public void setPayMode(String payMode) {
		this.payMode = payMode;
	}

	public BigDecimal getOrderAmt() {
        return this.orderAmt;
    }

    public void setOrderAmt(BigDecimal orderAmt) {
        this.orderAmt = orderAmt;
    }

    public String getOrderNo() {
        return this.orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    /**
     * @return the deviceId
     */
    public String getDeviceId() {
        return this.deviceId;
    }

    /**
     * @param deviceId
     *            the deviceId to set
     */
    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

}
