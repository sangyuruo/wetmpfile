package com.bill99.ebd.rip.facade.inf.market.cps;

import java.util.Date;

/**
 * 撤销订单的响应
 * @author jun.tang
 *
 */
public class CpsCancelOrderResponse extends CpsBaseResponse {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    private Date responseTime;

    public Date getResponseTime() {
        return responseTime;
    }

    public void setResponseTime(Date responseTime) {
        this.responseTime = responseTime;
    }
    
    
    
}
