package com.bill99.ebd.rip.facade.inf.market.fpd;

import java.util.ArrayList;
import java.util.List;

import com.bill99.ebd.rip.facade.inf.market.base.BaseResponse;


public class FpdQueryResponse extends BaseResponse {

	/**
	 * @author jakoes.wu
	 * @updatedate 2015年10月10日上午10:56:16
	 */
	private static final long serialVersionUID = 1L;

	List<FpdQueryDto> FpdQueryList= new ArrayList<FpdQueryDto>();

	public List<FpdQueryDto> getFpdQueryList() {
		return FpdQueryList;
	}

	public void setFpdQueryList(List<FpdQueryDto> fpdQueryList) {
		FpdQueryList = fpdQueryList;
	}
	
}
