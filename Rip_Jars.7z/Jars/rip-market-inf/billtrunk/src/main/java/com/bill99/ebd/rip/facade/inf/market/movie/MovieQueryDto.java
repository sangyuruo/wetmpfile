package com.bill99.ebd.rip.facade.inf.market.movie;

import java.math.BigDecimal;

/**
 * 查可用券传递对象
 * 
 * @author jakoes.wu
 * @date 2015年10月30日下午9:03:24
 * @project rip-market-inf-20151030
 *
 */
public class MovieQueryDto extends InterestsAttributesDto{
	/**
	 * 
	 */
	private static final long serialVersionUID = -6360389385948852889L;
	private String voucherNo;//券号 
	private BigDecimal payAmt;//应付金额
	private BigDecimal interestsAmt;//优惠金额（权益金额）
	
	public String getVoucherNo() {
		return voucherNo;
	}
	public void setVoucherNo(String voucherNo) {
		this.voucherNo = voucherNo;
	}
	 
	public BigDecimal getPayAmt() {
		return payAmt;
	}
	public void setPayAmt(BigDecimal payAmt) {
		this.payAmt = payAmt;
	}
	public BigDecimal getInterestsAmt() {
		return interestsAmt;
	}
	public void setInterestsAmt(BigDecimal interestsAmt) {
		this.interestsAmt = interestsAmt;
	}
	
}
