package com.bill99.ebd.rip.facade.inf.market.movie;

import com.bill99.ebd.rip.facade.inf.market.base.BaseRequest;

/**
 * 核销撤销请求对象
 * 
 * @author jakoes.wu
 * @date 2015年10月30日下午9:03:48
 * @project rip-market-inf-20151030
 *
 */
public class MovieCancelWriteoffRequest extends BaseRequest {

    /**
     * @author jakoes.wu
     * @updatedate 2015年10月30日下午8:51:00
     */
    private static final long serialVersionUID = 1L;

    private String origExtSeqId;// 原订单号

    private String voucherNo;// 券号

    public String getVoucherNo() {
        return voucherNo;
    }

    public void setVoucherNo(String voucherNo) {
        this.voucherNo = voucherNo;
    }

    public String getOrigExtSeqId() {
        return origExtSeqId;
    }

    public void setOrigExtSeqId(String origExtSeqId) {
        this.origExtSeqId = origExtSeqId;
    }

}
