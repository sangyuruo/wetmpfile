package com.bill99.ebd.rip.facade.inf.market.cocbillapi;

import java.math.BigDecimal;

import com.bill99.ebd.rip.facade.inf.market.base.BaseResponse;

/**
 * 权益状态响应
 * @author jun.tang
 *
 */
public class TxnQueryResponse extends BaseResponse {

	private static final long serialVersionUID = 1L;
	
	/**权益状态 HOLD,WRITEOFF,CANCEL,EXPIRED*/
	private String interestsStatus;
	/**权益金额*/
	private BigDecimal interestsAmt;
	/**权益银行卡号（带星号）*/
	private String shortCardNo;
	/**快钱帐号（带星号）*/
	private String shortIdContent;
	/**支付方式：CP-刷卡支付  ； MP-移动支付 */
	private String payType;
	
	public String getInterestsStatus() {
		return interestsStatus;
	}
	public void setInterestsStatus(String interestsStatus) {
		this.interestsStatus = interestsStatus;
	}
	public BigDecimal getInterestsAmt() {
		return interestsAmt;
	}
	public void setInterestsAmt(BigDecimal interestsAmt) {
		this.interestsAmt = interestsAmt;
	}
	public String getShortCardNo() {
		return shortCardNo;
	}
	public void setShortCardNo(String shortCardNo) {
		this.shortCardNo = shortCardNo;
	}
	public String getShortIdContent() {
		return shortIdContent;
	}
	public void setShortIdContent(String shortIdContent) {
		this.shortIdContent = shortIdContent;
	}
    public String getPayType() {
        return payType;
    }
    public void setPayType(String payType) {
        this.payType = payType;
    }
	
}
