package com.bill99.ebd.rip.facade.inf.market.publisher;


public interface InterestsPublisher {

	/**
	 * 新增权益
	 * @param createInterestsRequest
	 *
	 *@author pengfei.shen
	 *@create 2016年3月14日 下午5:15:33
	 */
	public void createInterests(CreateInterestsRequest createInterestsRequest);
	
	/**
	 * 修改权益
	 * @param updateInterestsRequest
	 *
	 *@author pengfei.shen
	 *@create 2016年3月14日 下午5:15:46
	 */
	public void updateInterests (UpdateInterestsRequest  updateInterestsRequest );	
}
