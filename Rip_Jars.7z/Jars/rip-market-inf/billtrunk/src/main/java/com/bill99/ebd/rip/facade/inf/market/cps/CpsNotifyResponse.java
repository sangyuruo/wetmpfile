package com.bill99.ebd.rip.facade.inf.market.cps;

import java.util.Date;

/**
 * Cps返现响应对象
 * @author wei.wang.rd
 * */
public class CpsNotifyResponse extends CpsBaseResponse {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6222623072063101949L;
	
	private Date responseTime;		//响应时间
	
//	private String hasHoldVoucher;  //是否曾今领过券
	
	public Date getResponseTime() {
		return responseTime;
	}
	
	public void setResponseTime(Date responseTime) {
		this.responseTime = responseTime;
	}

//    public String getHasHoldVoucher() {
//        return hasHoldVoucher;
//    }
//
//    public void setHasHoldVoucher(String hasHoldVoucher) {
//        this.hasHoldVoucher = hasHoldVoucher;
//    }
//	
	

}
