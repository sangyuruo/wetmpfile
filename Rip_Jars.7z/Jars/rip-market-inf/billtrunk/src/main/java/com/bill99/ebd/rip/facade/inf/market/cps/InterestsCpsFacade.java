package com.bill99.ebd.rip.facade.inf.market.cps;

/**
 * 权益平台-CPS对接接口
 * @author wei.wang.rd
 * */
public interface InterestsCpsFacade {
	
	
	/**
	 * CPS返现查询接口
	 * 	查询收单商户发布的主动权益，如果有多个符合条件的权益，创建时间排序返回最新的一个，
	 *  并从资金池里冻结返现金额。当有权益返回时，权益金额自动冻结，超时解冻
	 * */
	public CpsQueryResponse query(CpsQueryRequest queryRequest);
	
	
	/**
	 * CPS支付通知查询接口
	 * 	只在支付成功后才调用权益平台，权益平台将信息落地并视业务规定做相应的资金转账、记账等操作。
	 * 	超时（暂定60秒）未通知核销平台，则权益平台自动触发解冻操作，将冻结的资金返回资金池。
	 * */
	public CpsNotifyResponse notify(CpsNotifyRequest notifyRequest);
	
	/**
	 * 撤销订单接口。同时撤销相关权益
	 * @param request 请求
	 * @return
	 */
	public CpsCancelOrderResponse cancelOrder(CpsCancelOrderRequest request);
}
