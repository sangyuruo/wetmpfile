package com.bill99.ebd.rip.facade.inf.market.fpd;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class FpdQueryDto implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4949928649500299702L;
	
	private String voucherNo;//权益编号（券号）
	private String interestsName;//权益名称
	private BigDecimal interstsAmt;//权益金额（折扣金额）
	private BigDecimal payAmt;//支付金额 = 订单金额-折扣金额
	private Date expDate;//失效日期
	private BigDecimal origInterstsAmt;//权益面值
	
	public Date getExpDate() {
		return expDate;
	}
	public void setExpDate(Date expDate) {
		this.expDate = expDate;
	}
	public String getVoucherNo() {
		return voucherNo;
	}
	public void setVoucherNo(String voucherNo) {
		this.voucherNo = voucherNo;
	}
	public String getInterestsName() {
		return interestsName;
	}
	public void setInterestsName(String interestsName) {
		this.interestsName = interestsName;
	}
	public BigDecimal getInterstsAmt() {
		return interstsAmt;
	}
	public void setInterstsAmt(BigDecimal interstsAmt) {
		this.interstsAmt = interstsAmt;
	}
	public BigDecimal getPayAmt() {
		return payAmt;
	}
	public void setPayAmt(BigDecimal payAmt) {
		this.payAmt = payAmt;
	}
	public FpdQueryDto(String voucherNo, String interestsName,
			BigDecimal interstsAmt, BigDecimal payAmt,Date expDate) {
		super();
		this.voucherNo = voucherNo;
		this.interestsName = interestsName;
		this.interstsAmt = interstsAmt;
		this.payAmt = payAmt;
		this.expDate=expDate;
	}
	public FpdQueryDto() {
		super();
	}
	public BigDecimal getOrigInterstsAmt() {
		return origInterstsAmt;
	}
	public void setOrigInterstsAmt(BigDecimal origInterstsAmt) {
		this.origInterstsAmt = origInterstsAmt;
	}

}
