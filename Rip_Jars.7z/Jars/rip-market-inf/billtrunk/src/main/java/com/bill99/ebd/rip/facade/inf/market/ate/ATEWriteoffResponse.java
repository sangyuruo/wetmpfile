/**
 * 
 */
package com.bill99.ebd.rip.facade.inf.market.ate;

import java.math.BigDecimal;

/**
 * @author shuangye.liu
 * @since Mar 9, 2016
 */
public class ATEWriteoffResponse extends BaseATEResponse {

    private static final long serialVersionUID = 5636764657412237567L;

    // 被动权益券号
    private String voucherNo;

    // 被动权益金额
    private BigDecimal interestsAmt;

    // 支付金额 (订单金额-被动权益金额)
    private BigDecimal payAmt;

    /**
     * @return the interestsAmt
     */
    public BigDecimal getInterestsAmt() {
        return this.interestsAmt;
    }

    /**
     * @param interestsAmt
     *            the interestsAmt to set
     */
    public void setInterestsAmt(BigDecimal interestsAmt) {
        this.interestsAmt = interestsAmt;
    }

    /**
     * @return the payAmt
     */
    public BigDecimal getPayAmt() {
        return this.payAmt;
    }

    /**
     * @param payAmt
     *            the payAmt to set
     */
    public void setPayAmt(BigDecimal payAmt) {
        this.payAmt = payAmt;
    }

    /**
     * @return the voucherNo
     */
    public String getVoucherNo() {
        return this.voucherNo;
    }

    /**
     * @param voucherNo
     *            the voucherNo to set
     */
    public void setVoucherNo(String voucherNo) {
        this.voucherNo = voucherNo;
    }

}
