package com.bill99.ebd.rip.facade.inf.market.fpd;

import java.io.Serializable;

public class FpdBaseRequest implements Serializable {

	/**
	 * @author jakoes.wu
	 * @updatedate 2015年10月10日上午10:49:25
	 */
	private static final long serialVersionUID = 1L;

	private String consumerMembercode;//商户会员编号 R
	private String merchantMembercode;//用户会员编号 R 
	public String getConsumerMembercode() {
		return consumerMembercode;
	}
	public void setConsumerMembercode(String consumerMembercode) {
		this.consumerMembercode = consumerMembercode;
	}
	public String getMerchantMembercode() {
		return merchantMembercode;
	}
	public void setMerchantMembercode(String merchantMembercode) {
		this.merchantMembercode = merchantMembercode;
	}
	
	
}
